---------------------------------
 eXtreme v9.0 FINAL (15-03-2006)
 for mIRC32 v6.17

 by Kall
---------------------------------

This is the long awaited v9.0 FINAL version


*** HOW TO INSTALL ***

Just copy mIRC's executable (mirc.exe) into the script's folder, after unpacking it.
DON'T OVERWRITE THE SCRIPT'S MIRC.INI!!!

**********************


There are many things I'd like to add, many more to change, but it's getting harder 
since I don't use IRC as often as before.

I never got to add all the goodies I wanted to, but... honestly, my time as a mirc scripter has passed, 
and I think new scripters are best fit to provide the mirc scene with better and nicer scripts (or so I hope).

Lastly, I'd like to thank all users out there who always supported me for all these years. 
This version is dedicated to all of you.


Take care, hope you enjoy it.

Kall (Paulo Rem�sio)

-----------------------
kall@extreme-script.net
http://www.extreme-script.net
