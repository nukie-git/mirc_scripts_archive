;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; protection routines
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

alias _checkownban {
  if ($away) .timer 1 $rand(5,15) .raw MODE $1 -b $2
  elseif (!$input(This banmask includes you $+ $crlf $2 $crlf $+ Keep it anyway?,yw)) .raw MODE $1 -b $2
}
alias setkicks {
  if ($1 isnum 0-) _set status kicks $1
}
alias _nkicks {
  ;  if ($hget(x_prot,nokickcounter)) return
  var %nk = $iif($hget(x_status,kicks) isnum,$calc($hget(x_status,kicks) + 1),1)
  return %nk

  ;  if ($hget(x_sets,kickcounter.style)) return $replace($ifmatch,<n>,%nk)
  ;  return $strip($chr(183) $+ %nk $+ $chr(183))
}
alias _nkupd {
  var %k = $calc($hget(x_status,kicks) +1)
  hadd -m x_status kicks %k
}

;$_prot.disable(#chan) returns 1 if protections are disabled for chan or global (temporary or not)
alias _prot.disable {
  if (!$hget(x_sets,cflood)) || ($__i(tmp.noprots.,$1)) || ($_protset(disable,$1)) || (($away) && ($hget(x_away,disable.prots))) || ($__i(noprotect.,$1)) return 1
}

;$_exempt.ul(fulladdress,chan) returns 1 if user is exempt from # protections due to user level
alias _exempt.ul {
  var %f = $_getflagsd($1,$2), %tlev = $remove($level($ulist($1)),=)
  if (F isincs %f) || (B isincs %f) || (e isincs %f) || ($istok(%tlev,20,44)) return 1
}

;$_exempt.status(nick,chan) returns 1 if user is exempt, due to his/her chan mode
alias _exempt.status {
  if (($hget(x_prot,dontkickops)) && ($1 isop $2)) || (($hget(x_prot,dontkickvoices)) && ($1 isvoice $2)) || (($hget(x_prot,dontkickhalfops)) && ($1 ishop $2)) || (($hget(x_prot,dontkicknotify)) && ($nick isnotify)) return 1
}

;$_isprotected(mask,chan) checks for all users that match 'mask', and returns a nick if any of them is "protected" (friend or bot)
alias _isprotected {
  var %n = 1
  while ($ialchan($1,$2,%n)) {
    var %flags = $_getflags($ifmatch)
    if (F isincs %flags) || (B isincs %flags) return $ialchan($1,$2,%n).nick
    inc %n
  }
}

;$_isknown(fulladdress) returns 1 if user is exempt or is in notify list
alias _isknown {
  var %h = $iif(@ isin $1,$1,$address($1,5))
  if ($_exempt.ul(%h)) || ($gettok(%h,1,33) isnotify) return 1
}
;
alias _ffq {
  if (+flood* !iswm $_flood(Flood,$+(ownflood.prevent.,$1,.,$2),$numtok($1-,10),5,1 +k)) $1-
  else .timer 1 3 _ffq $1-
}
alias _ff {
  if (+flood* !iswm $_flood(Flood,$+(loop.prevent.,$1,.,$2,.,$3),1,6,3)) $1-
  elseif ($show) echo # $_pre Cannot execute $1- $+ , halted code to prevent loops.
}
alias _ff2 {
  if (+flood* !iswm $_flood(Flood,$+(loop.prevent.,$1),1,10,4)) $1-
  else echo # $_pre Halted protection to prevent server flood.
}

;/penalty <type> <nick> <chan> <kickmsg>
alias penalty {
  if ($istok($__i(banned.nicks.,$3) $__i(last.penalties.,$3),$2,32)) return
  set -u3 $_i(last.penalties.,$3) $addtok($__i(last.penalties.,$3),$2,32)
  unset $_i(flood.,$3,.*.,$address($2,2))

  var %mt = $__i(nets-clonetype), %wm
  if ($istok(clones.ctcp.kick.ban.deop,$1,46)) %wm = $address($2,$iif(%mt,%mt,2))
  else %wm = $2

  if ($__i(penalty.,$3,.,$1,.,%wm)) {
    if ($1 == clones) {
      if ($ialchan(%n,$3,0) > $_protset(clones_max,$3)) inc $_i(penalty.,$3,.,$1,.,%wm)
    }
    else inc $_i(penalty.,$3,.,$1,.,%wm)

  }
  else set -u $+ $calc($hget(x_prot,penalties.time) *60) $_i(penalty.,$3,.,$1,.,%wm) 1

  var %pp = $_protset($+($1,_penalty),$3), %p
  if (!%pp) return

  :start
  %p = $gettok(%pp,$__i(penalty.,$3,.,$1,.,%wm),183)

  if (%p == nothing) || (%p == -) return

  elseif (%p == local_warn) {
    var %msg = $replace($_echo(localwarn),<nick>,$2,<chan>,$3,<fulladdress>,$address($2,5),<me>,$me,<type>,$1)
    ae %msg
    if ($active != $3) echo $3 %msg
    set -u60 $_i(warnme) $addtok($__i(warnme),$3 $2 $4-,164)
    beep 4 100
  }

  elseif (warn* iswm %p) {

    var %target, %msg

    if (warn_chan* iswm %p) {
      var %msg = $gettok(%p,2-,58)
      if (!%msg) %msg =  $+ $2 $+ : $_echo(customwarn_public)
      _say $3 $replace(%msg,<nick>,$2,<chan>,$3,<fulladdress>,$address($2,5),<me>,$me,<type>,$1)
      %target = $+($3,$chr(32),[,$2,])
    }
    elseif (warn_ops* iswm %p) {
      var %msg = $gettok(%p,2-,58)
      if (!%msg) %msg =  $+ $2 $+ : $_echo(customwarn_public)
      .onotice $3 $replace(%msg,<nick>,$2,<chan>,$3,<fulladdress>,$address($2,5),<me>,$me,<type>,$1)
      %target = $+(@,$3,$chr(32),[,$2,])
    }
    else {
      var %msg = $gettok(%p,2-,58)
      if (!%msg) {
        if ($1 == clones) %msg = $_echo(clonewarn)
        elseif ($1 == guests) %msg = $_echo(guestwarn)
        elseif ($1 == badword) %msg = $_echo(badwordwarn)
        else %msg = $_echo(customwarn_user)
      }
      %msg = $replace(%msg,<nick>,$2,<chan>,$3,<fulladdress>,$address($2,5),<me>,$me,<type>,$1)
      if ($1 == clones) {
        fnotice $3 %wm %msg
        %target = %wm
      }
      else {
        rawnotice $2 %msg
        %target = $2
      }
    }

    echo $3 $replace($_echo(localwarn3),<nick>,$2,<chan>,$3,<fulladdress>,$address($2,5),<me>,$me,<type>,$1,<target>,%target)
  }
  elseif (%p == deop) {
    .raw MODE $3 -o $2
  }
  elseif (%p == ban) {
    .raw MODE $3 +b $_address($2,$hget(x_prot,default_banmask))
  }
  elseif (%p == tempban) {
    var %time = $calc($hget(x_prot,tempban.time) *60), %banmask = $_address($2,$hget(x_prot,default_banmask))
    .ban -u $+ %time $3 %banmask
    hadd -m x_tempbans $+($_network,:,$3,:,%banmask) $calc($ctime + %time)
  }
  elseif (%p == kick) _ff2 qkick $3 $2 $4-
  elseif (%p == filterkick) fk $3 $address($2,%mt) $4-
  elseif (%p == filterkickban) fkb $3 $address($2,%mt) $4-
  ;  elseif (%p == clonekick) clones $3 -k %mt
  ;  elseif (%p == clonekickban) ae clones $3 -kb %mt
  elseif (%p == sitekickban) fkb $3 $address($2,2) $4-
  elseif (%p == tempkickban) _ff2 qtkickb $3 $2 $4-
  elseif (%p == kickban) _ff2 qkickb $3 $2 $4-
  elseif (%p == guestkickban) guestkickban $3
  elseif (%p == badhostkickban) badhostkickban $3 $2 $4-
  elseif (custom:* iswm %p) {
    echo $3 $replace($_echo(localwarn4),<nick>,$2,<type>,$1,<chan>,$3)
    _perfd $replace($gettok(%p,2-,58),<nick>,$2,<chan>,$3,<fulladdress>,$address($2,5),<me>,$me,<type>,$1)
  }
  else {
    dec $_i(penalty.,$3,.,$1,.,%wm)
    goto start
  }

  if ($hget(x_prot,warnme)) && (%p != warn_me) && ($active != $3) && ($validwin) {
    ae $replace($_echo(localwarn2),<nick>,$2,<type>,$1,<chan>,$3,<penalty>,%p)
  }
}

;/_text.protect <nick> <chan> <type> <text>
;for text/action/notice events (lines,bytes,repeat,notice,caps,codes,chars and massflood)
alias _text.protect {

  if ($_prot.disable($2)) || ($_exempt.ul($fulladdress,$2)) || ($_exempt.status($1,$2)) || ($__i(ialupd.,$2)) return
  var %len = $len($4-), %lag = $remove($__i(lag),sec,s,+)

  if ($_protset(badword,$2)) && ($_check.badword($4-,$2)) penalty badword $1-2 $_kickmsg(badword,$2)
  elseif ($_protset(advertise,$2)) && ($_check.advertise($4-,$2)) penalty advertise $1-2 $_kickmsg(advertise,$2)
  elseif ($_protset(codes,$2)) && ($count($4-,,,,) >= $_protset(codes_max,$2)) penalty codes $1-2 $_kickmsg(codes,$2)
  elseif ($_protset(colors,$2)) && ($count($4-,) >= $_protset(colors_max,$2)) penalty colors $1-2 $_kickmsg(colors,$2)
  elseif ($_protset(caps,$2)) && ($_count.upper($4-) >= $_protset(caps_max,$2)) penalty caps $1-2 $_kickmsg(caps,$2)

  elseif (%lag < 10) {
    if ($mflood($site,$2)) {
      echo $2 $replace($_echo(massflood),<type>,$3,<chan>,$2)
      ignore -ntdu10 *!*@*
      if ($hget(x_prot,mflood_action)) _perfd $ifmatch
      else mode $2 +im
    }
    elseif ($cflood(bytes,$site,$2,$1,%len)) penalty bytes $1-2 $_kickmsg(bytes,$2)
    elseif ($_protset(chars,$2)) && (%len > $_protset(chars_max,$2)) penalty chars $1-2 $_kickmsg(chars,$2)
    elseif ($repflood($1,$2,$1,$4-)) {
      unset $_i(repeatline.,$2,.,$1)
      penalty repeat $1-2 $_kickmsg(repeat,$2)
    }
    elseif ($cflood($3,$site,$2,$1)) penalty $3 $1-2 $_kickmsg($3,$2)
  }
}

;$cflood(type,mask,chan,nick,inc) channel flood routine
alias cflood {
  if (!$_protset($1,$3)) return
  var %f = $+(cflood.,$cid,.,$1,.,$2,.,$3), %inc
  if ($5) %inc = $5
  else %inc = 1
  if (+flood* iswm $dll(dlls\aircdll.dll,Flood2,%f %inc $1 +c $3)) return 1
}

;$repflood(mask,chan,nick,text) channel repeat flood routine
alias repflood {
  if (!$_protset(repeat,$2)) return
  ;  if ($gettok($dll(dlls\aircdll.dll, FloodOptGets, disable +c $2),2,32)) return
  var %f = $+(cflood.,$cid,.repeat.,$1,.,$2), %inc
  if ($__i(repeatline.,$2,.,$1) != . $3-) {
    set -u5 $_i(repeatline.,$2,.,$1) . $3-
    .dll dlls\aircdll.dll FloodDel %f
  }
  if (+flood* iswm $dll(dlls\aircdll.dll,Flood2,%f 1 repeat +c $2)) return 1
}

;$pflood(type,mask) personal flood (and ultraflood)
alias pflood {
  if ($hget(x_sets,ultraflood) != 0) && (+flood* iswm $dll(dlls\aircdll.dll,Flood2,$+(ultraflood.$cid) 1 pflood.ultra)) {
    ae $_echo(ultraflood,$2)
    if ($hget(x_pprot,pflood.ultra_action)) _perfd $ifmatch
    else prot.ignore -dnptiu15 *!*@*
    halt
  }
  if ($hget(x_sets,pflood) != 0) && (+flood* iswm $dll(dlls\aircdll.dll,Flood2,$+(pflood.,$cid,.,$1,.,$2) 1 $+(pflood.,$1))) return 1
}

;$mflood(mask,chan) mass flood (or botnet flood)
alias mflood {
  if ($hget(x_prot,massflood) == 0) return
  var %cache = $+(x_tmp-cid,$cid,-cache)
  if ($hget(%cache,mfloodsets)) var %m = $gettok($ifmatch,1,32), %t = $gettok($ifmatch,2,32), %ms = $gettok($ifmatch,3,32), 
  else {
    var %m,%t,%ms
    if ($hget(x_prot,mflood_max) isnum) %m = $ifmatch
    else %m = 20
    if ($hget(x_prot,mflood_time) isnum) %t = $ifmatch
    else %t = 4
    if ($hget(x_prot,mflood_maxsites)) %ms = $ifmatch
    else %ms = 50
    %ms = $int($calc((%ms /100) * %m))
    hadd -mu8 %cache mfloodsets %m %t %ms
  }
  var %tb = $+(mfloodsites.cid,$cid), %fs = $hget(x_vars,%tb), %fl = $gettok($_flood(Flood,$+(mflood.,$cid),1,%m,%t),2,32)
  if (%fl == 1) hadd -mu $+ %t x_vars %tb $1
  elseif ($len(%fs) <= 800) hadd -mu10 x_vars %tb $qtok(%fs,$1,%m,44)
  if (%fl >= %m) && ($numtok(%fs,44) < %ms) {
    if ($hget(x_vars,%tb)) set -u60 $_i(mfloodsites) $2 $ifmatch
    hdel x_vars %tb
    return 1
  }
}
alias mfloodkick {
  var %l = $__i(mfloodsites), %chan = $gettok(%l,1,32), %list = $gettok(%l,2,32)
  if ($me isop %chan) _kickbanlast %chan %list $iif($1,kb)
}

;================

alias -l _rpunct2 return $remove($replace($_rempunct($replace($1-,:,�)),�,:),*)

;$_rempunct(string) replaces most usual punctuation with spaces
alias _rempunct return $replace($strip($1-),[,.,],.,�,.,?,.,�,.,!,.,;,.,:,.,$chr(44),.,",.,',.,$chr(40),.,$chr(41),.,<,.,>,.,|,.,=,.,.,$chr(32))

;$_rempunct.all(string) replaces ALL non-alphanumeric chars (punctuation) with spaces
alias _rempunct.all {
  var %tmp, %a = $regsub($1-,/[^[:alnum:]]/g,$chr(32),%tmp)
  return %tmp
}

;$_filter.digits(string) filters everything from the string, returning only the digits in it
alias _filter.digits {
  var %tmp, %a = $regsub($1-,/[^[:digit:]]/g,$null,%tmp)
  return %tmp
}

;$_count.upper(string) counts upper case chars in the string
alias _count.upper return $regex($1,/[A-Z]/g)

alias _count.upper.old {
  var %tmp, %a = $regsub($1-,/[^[:upper:]]/g,$null,%tmp)
  return $len(%tmp)
}
;$_count.lower(string) counts lower case chars in the string
alias _count.lower return $regex($1,/[a-z]/g)

alias _count.lower.old {
  var %tmp, %a = $regsub($1-,/[^[:lower:]]/g,$null,%tmp)
  return $len(%tmp)
}

;$_matchtok(string1,string2) searches for each item on string1 on string2
alias _matchtok {
  .dll dlls\aircdll.dll MatchTokString $1
  if (+* iswm $dll(dlls\aircdll.dll, MatchTok, + +r 44 $2)) return 1
}

;__________________


alias _check.spam {
  var %cache = $+(x_tmp-cid,$cid,-cache), %l = $hget(%cache,pprot.spam.list), %w
  if (%l == $null) {
    %l = $hget(x_sets,pprot.spam.list)
    .dll dlls\aircdll.dll MatchTokString %l
    hadd -mu5 %cache pprot.spam.list %l
  }
  %w = $dll(dlls\aircdll.dll, MatchTok, + +r 44 $1)
  if (+* iswm %w) {
    %w = $gettok(%w,2-,32)
    if ($gettok($_protset(spam.list.km),$findtok(%l,%w,1,1),1) != -) set -u %_kickmsg $ifmatch
    return %w
  }
}

alias _check.spam2 {
  var %wl = $hget(x_sets,pprot.spam.list), %line = $_rpunct2($1), %i = 1
  if ($istok(%line,$2,32)) return
  while ($gettok(%wl,%i,44)) {
    tokenize 9 $ifmatch
    if ($wildtok(%line,$1,1,32)) || ($1 iswm %line) {
      if ($2) set -u %_kickmsg $ifmatch
      return $1
    }
    inc %i
  }
}

alias _check.advertise {
  var %cache = $+(x_tmp-cid,$cid,-cache), %cache2 = $+(advertise.,$2), %l = $hget(%cache,%cache2), %w, %line = $remtok($1,$2,32)
  if (%l == $null) {
    %l = $_protset(advertise.list,$2)
    .dll dlls\aircdll.dll MatchTokString %l
    hadd -mu5 %cache %cache2 %l
  }
  %w = $dll(dlls\aircdll.dll, MatchTok, + +r 44 %line)
  if (+* iswm %w) {
    %w = $gettok(%w,2-,32)
    if ($gettok($_protset(advertise.list.km,$2),$findtok(%l,%w,1,44),1) != -) set -u %_kickmsg $ifmatch
    return %w
  }
}
alias _check.advertise2 {
  var %wl = $_protset(advertise.list,$2), %line = $_rpunct2($1), %i = 1
  if ($istok(%line,$2,32)) return
  while ($gettok(%wl,%i,44)) {
    tokenize 9 $ifmatch
    if ($wildtok(%line,$1,1,32)) || ($1 iswm %line) {
      if ($2) set -u %_kickmsg $ifmatch
      return $1
    }
    inc %i
  }
}

alias _check.badword {
  var %cache = $+(x_tmp-cid,$cid,-cache), %cache2 = $+(badword.,$2), %l = $hget(%cache,%cache2), %w
  if (%l == $null) {
    %l = $_protset(badword.list,$2)
    .dll dlls\aircdll.dll MatchTokString %l
    hadd -mu5 %cache %cache2 %l
  }
  %w = $dll(dlls\aircdll.dll, MatchTok, + +r 44 $1)
  if (+* iswm %w) {
    %w = $gettok(%w,2-,32)
    if ($gettok($_protset(badword.list.km,$2),$findtok(%l,%w,1,44),1) != -) set -u %_kickmsg $ifmatch
    set -u %::badword $replace(%w,a,*,e,*,i,*,o,*,u,*)
    return %w
  }
}
alias _check.badword2 {
  var %wl = $_protset(badword.list,$2), %line = $_rempunct($1), %i = 1
  while ($gettok(%wl,%i,44)) {
    tokenize 9 $ifmatch
    if ($wildtok(%line,$1,1,32)) || ($1 iswm %line) {
      if ($2) set -u %_kickmsg $ifmatch
      set -u %::badword $replace($1,a,*,e,*,i,*,o,*,u,*)
      return $1
    }
    inc %i
  }
}

alias _check.badhostmask {
  var %cache = $+(x_tmp-cid,$cid,-cache), %cache2 = $+(badhostmask.,$2), %l = $hget(%cache,%cache2), %w
  if (%l == $null) {
    %l = $_protset(badword.list,$2)
    ;    %l = $_protset(badhostmask.list,$2)
    .dll dlls\aircdll.dll MatchTokString %l
    hadd -mu5 %cache %cache2 %l
  }
  %w = $dll(dlls\aircdll.dll, MatchTok, + + 44 $1)
  if (+* iswm %w) {
    %w = $gettok(%w,2-,32)
    if ($gettok($_protset(badhostmask_kickmsg,$2),$findtok(%l,%w,1,44),44) != -) set -u %_kickmsg $ifmatch
    set -u %::badhostmask $replace(%w,a,*,e,*,i,*,o,*,u,*)
    return %w
  }
}
alias _check.badhostmask2 {
  ;  var %wl = $_protset(badhostmask.list,$2), %line = $_rempunct($1), %i = 1
  var %wl = $_protset(badword.list,$2), %line = $_rempunct($1), %i = 1
  while ($gettok(%wl,%i,44)) {
    tokenize 9 $ifmatch
    if ($wildtok(%line,$1,1,32)) || ($1 iswm %line) {
      if ($2) set -u %_kickmsg $ifmatch
      set -u %::badhostmask $replace($1,a,*,e,*,i,*,o,*,u,*)
      return $1
    }
    inc %i
  }
}

alias _check.badchans {
  var %cache = $+(x_tmp-cid,$cid,-cache), %cache2 = $+(badchan.,$2), %l = $hget(%cache,%cache2), %w, %line = $remtok($1,$2,32)
  if (%l == $null) {
    %l = $_protset(badchan.list,$2)
    .dll dlls\aircdll.dll MatchTokString %l
    hadd -mu5 %cache %cache2 %l
  }
  %w = $dll(dlls\aircdll.dll, MatchTok, + + 44 %line)
  if (+* iswm %w) {
    %w = $gettok(%w,2-,32)
    if ($gettok($_protset(badchan.list.km,$2),$findtok(%l,%w,1,44),1) != -) set -u %_kickmsg $ifmatch
    set -u %::badchan %w
    return %w
  }
}
alias _check.badchans2 {
  var %cl = $hget(x_prot,badchannel.list), %n = 1, %line = $remtok($1,$2,32)
  while ($gettok(%cl,%n,44)) {
    tokenize 9 $ifmatch
    if ($wildtok(%line,$1,1,32)) || ($1 isin %line) {
      if ($2) set -u %_kickmsg $ifmatch
      set -u %::badchan $1
      return $1
    }
    inc %n
  }
}

alias _check.badfiles {
  var %cache = $+(x_tmp-cid,$cid,-cache), %cache2 = $+(badfiles.,$2), %l = $hget(%cache,%cache2), %w
  if (%l == $null) {
    %l = $_protset(badfiles.list,$2)
    .dll dlls\aircdll.dll MatchTokString %l
    hadd -mu5 %cache %cache2 %l
  }
  %w = $dll(dlls\aircdll.dll, MatchTok, + + 44 $1)
  if (+* iswm %w) {
    %w = $gettok(%w,2-,32)
    if ($gettok($_protset(badfiles.list.km,$2),$findtok(%l,%w,1,44),1) != -) set -u %_kickmsg $ifmatch
    set -u %::badfile %w
    return %w
  }
}
alias _check.badfiles2 {
  var %fl = $hget(x_prot,badfiles.list), %file = $1, %n = 1
  while ($gettok(%fl,%n,44)) {
    tokenize 9 $ifmatch
    if ($1 iswm %file) {
      if ($2) set -u %_kickmsg $ifmatch
      set -u %::badfile $1
      return $1
    }
    inc %n
  }
}
;____________________
;**** SPAM ***** (personal)

alias _spam.detect {
  if ($hget(x_sets,pprot.spam)) && ($_check.spam($1-)) {
    if (($_isknown($fulladdress,F)) && ($hget(x_sets,pprot.spam.exemptknown))) || ($_isservice($nick,$site)) var %exempt = 1
    var %t = (ShiftF3 to view log), %i = 1
    if (!%exempt) {
      while ($comchan($nick,%i)) {
        var %chan = $ifmatch, %exempt = 0
        if ($hget(x_sets,pprot.spam.exemptops)) && ($nick isop %chan) {
          var %exempt = 1
          break
        }
        if (!%exempt) && ($me isop %chan) {
          if ($hget(x_sets,pprot.spam.usepenalty)) && (!$_prot.disable(%chan)) && (!$_exempt.status($nick,%chan)) && (!$_exempt.ul($fulladdress,%chan)) {
            penalty spam $nick %chan $_kickmsg(spam,%chan)
          }
          else var %im.op = 1
        }
        inc %i
      }
      if (%im.op) {
        set -u120 $_i(spammer) $nick
        var %t = (ShiftF3 to view log or CtrlF2 to kickban)
      }
    }
    if (!%exempt) {
      $iif($hget(x_sets,pprot.spam.showstatus),se,ae) $_warn Possible message spamming detected from $nick ( $+ $address $+ ). %t
      .write $+(",$logdirspamlog�,$_network,.log") $timestamp < $+ $fulladdress $+ > $strip($1-,c)
      halt
    }
  }

}

;____________________

alias badchan.scan {
  if ($__i(badchan.params)) {
    sr -th Error Already scanning a channel
    return
  }
  if ($1 ischan) var %c = $1, %l = $2
  else var %c = #, %l = $1
  if (%c !ischan) return

  var %w = $+(@_badchan�,%c,�,$_@network), %n = 1

  if ($1 == stop) {
    set $_i(badchan.stop) 1
    .timer 1 10 unset $__i(badchan.*)
    window -c %w
    return
  }
  window -c %w
  window -hl %w

  if ($chr(44) isin %l) {
    while ($gettok(%l,%n,44)) {
      var %nick = $ifmatch
      aline %w %nick
      inc %n
    }
  }
  else {
    while ($nick(%c,%n)) {
      var %nick = $ifmatch
      aline %w %nick
      inc %n
    }
  }

  if ($line(%w,0) >= 100) {
    sr -th Error Too many users to scan
    return
  }
  ale Scanning users for bad channels
  set $_i(badchan.start) $ticks
  set $_i(badchan.max) $iif($gettok($1-,$0,32) isnum,$ifmatch,$__i(nets-max.events))
  set $_i(badchan.chan) %c
  set $_i(badchan.params) $1-
  _badchan.wi %c
}
alias _badchan.stop {
  var %c = $__i(badchan.chan), %w = $+(@_badchan�,%c,�,$_@network)
  window -c %w
  set $_i(badchan.stop) 1
  .timer 1 10 unset $__i(badchan.*)
  .timerbadchan. $+ $cid off
}
alias _badchan.wi {
  if ($__i(badchan.stop)) return
  var %max = $__i(badchan.max), %c = $1, %w = $+(@_badchan�,%c,�,$_@network)
  if (!$window(%w)) {
    set $_i(badchan.stop) 1
    .timer 1 10 unset $__i(badchan.*)
    return
  }
  if ($line(%w,0)) {
    var %n = 1, %l
    while (%n <= %max) {
      var %nick = $line(%w,1)
      if (%nick ison %c) %l = $addtok(%l,%nick,44)
      dline %w 1
      inc %n
      if (%n > $line(%w,0)) break
    }
    .timer -m 1 500 .raw WHOIS %l
    set $_i(badchan.list) %c %l
    .timerbadchan. $+ $cid 1 180 _badchan.stop
  }
  else {
    if ($__i(badchan.start)) echo %c $_pre Bad channels scan completed ( $+ $calc(($ticks - $__i(badchan.start)) /1000) $+ secs)
    .timerbadchan. $+ $cid off
    window -c %w
    unset $_i(badchan.*)
  }
}

alias _badchan.wi2 {
  set $_i(badchan.list) $1 $2
  .raw WHOIS $2
}

alias _alimiter {
  var %1 = $_protset(autolimiter,$1), %max = $iif($_protset(autolimiter.max,$1) isnum,$ifmatch,10), %time = $calc($iif($_protset(autolimiter.time,%chan) isnum,$ifmatch,5) *60)
  if (!%1) || ($1 !ischan) || ($me !isop $1) return
  var %limit = $calc($nick($1,0) + %max)
  if ($chan($1).limit != %limit) mode $1 +l %limit

  .timeralimiter.cid $+ $cid $+ . $+ $1 1 %time _alimiter $1
}

alias _aunban {
  var %1 = $_protset(autounban,$1), %delay = $calc($iif($_protset(autounban.time,%chan) isnum,$ifmatch,5) *60)
  if (!%1) || ($1 !ischan) || ($me !isop $1) return

  set -u60 $_i(prot.aunban.,$1) 1
  .mode $1 +b

  .timeraunban.cid $+ $cid $+ . $+ $1 1 %delay _aunban $1
}


;channel idle auto-deop (/_chan.autodeop <chan> <Nmins>)
alias _chan.autodeop {
  if ($me !isop $1) return
  if ($2 isnum) var %time = $calc($2 * 60)
  else var %time = 60
  var %n = 1, %list
  while ($opnick($1,%n)) {
    var %nick = $ifmatch
    if (%nick != $me) && ($nick($1,%n).idle >= %time) %list = $addtok(%list,%nick,44)
    inc %n
  }
  if (%list) _mode.list $1 -o %list
}

;channel idle auto-kicker (every N seconds) protection
alias _chan.idle {
  if (!$_protset(idle,$1)) || ($1 !ischan) return
  var %interval = $iif($2 isnum,$2,60)

  if ($me !isop $1) goto end

  var %n = 1, %max = $calc($_protset(idle_max,$1) *60)
  if (%max !isnum 5-) return

  if (%interval > %max) %interval = $calc(%max +5)


  while ($nick($1,%n)) {
    var %nick = $ifmatch, %l = $nick($1,%n).idle
    if (%l > %max) && (%nick != $me) && (!$_exempt.status(%nick,$1)) && (!$_exempt.ul($address(%nick,5),$1)) {
      set -u %::idletime $duration($calc(%max *60))
      penalty idle %nick $1 $_kickmsg(idle,$1)
    }
    inc %n
  }
  :end
  .timerchanidle.cid $+ $cid $+ . $+ $1 1 %interval _chan.idle $1-
}



alias idlekick {
  var %c = $iif($1 ischan,$1,#), %t = $iif($1 ischan,$2,$1), %p = $iif($2 isnum,$3,$2)
  if ($me !isop %c) return
  if (%t !isnum) var %t = $$_input(Kick users with idle above ... ? (in minutes),e,Idle Kick)
  set -u %::idletime > $duration($calc(%t *60))
  var %n = 1, %km = $_kickmsg(idle,%c)
  while ($nick(%c,%n)) {
    var %nick = $ifmatch, %i = $nick(%c,%n).idle
    if (%i > %t) && (!$_exempt.status(%nick,%c)) && (!$_exempt.ul($address(%nick,5),%c)) $iif(b isin %p,qkickb,qkick) %c %nick %km
    inc %n
  }
}

alias _idlekick.win {
  var %n = 5, %k = 0, %col = 9, %win = $+(@_idlekick.win.,$_rand6)
  if (@Whois�list isin $1) %col = 3

  window -lh %win
  while ($line($1,%n)) {
    var %l = $ifmatch, %u = $gettok(%l,1,9)
    var %i = $int($calc($_aduration($gettok(%l,%col,9)) /60))
    if (%u != $me) && (%i > $3) && (!$_exempt.status(%u,$2)) && (!$_exempt.ul($address(%u,5),$2)) aline %win %u
    inc %n
  }
  var %found = $line(%win,0)
  if (%found) {
    set -u %::idletime > $duration($calc($3 *60))
    multi $2 $iif(b isin $4,kb,k) %win $_kickmsg(idle,$2)
  }
  window -c %win
}

;-================


alias _update.aircdll {
  .dll dlls\aircdll.dll FloodOptClear
  var %i = 1
  while ($hget(%i)) {
    var %table = $ifmatch

    if (x_pprot* iswm %table) {
      var %i2 = 1
      while ($hget(%table,%i2).item) {
        var %item = $ifmatch, %p = $gettok(%item,1,95), %prot = %p
        if (*_max iswm %item) hadd -m x_tmp-updaircdll %prot $hget(%table,%item) $hget(x_tmp-updaircdll,%prot)
        elseif (*_time iswm %item) hadd -m x_tmp-updaircdll %prot $hget(x_tmp-updaircdll,%prot) $hget(%table,%item)
        inc %i2
      }
    }

    if (x_prot* iswm %table) {
      var %chan = $gettok(%table,2-,45), %i2 = 1
      while ($hget(%table,%i2).item) {
        var %item = $ifmatch, %p = $gettok(%item,1,95), %prot = $iif(%chan,$+(%chan,:,%p),%p)
        if (*_max iswm %item) hadd -m x_tmp-updaircdll %prot $hget(%table,%item) $hget(x_tmp-updaircdll,%prot)
        elseif (*_time iswm %item) hadd -m x_tmp-updaircdll %prot $hget(x_tmp-updaircdll,%prot) $hget(%table,%item)
        inc %i2
      }
    }
    inc %i
  }
  var %i = 1
  while ($hget(x_tmp-updaircdll,%i).item) {
    var %prot = $ifmatch, %item = $hget(x_tmp-updaircdll,%prot), %chan
    if ($numtok(%item,32) == 2) {
      if (: isin %prot) var %chan = +c $deltok(%prot,-1,58), %prot = $gettok(%prot,-1,58)
      .dll dlls\aircdll.dll FloodOptSet %prot %item %chan
    }
    inc %i
  }
  _hfree x_tmp-updaircdll
}


;;;;; NOT IN USE YET

;x_sets
;x_sets-chanN
;x_sets-netN
;x_sets-netN-chanN
alias _update.tables {
  .dll dlls\aircdll.dll OptTableDel sets
  .dll dlls\aircdll.dll OptTableAdd sets
  var %i = 1
  while ($hget(%i)) {
    var %table = $ifmatch, %i2 = 1, %net, %chan, %sw = +
    if (x_sets* iswm %table) {
      if (net* iswm $gettok(%table,2,45)) {
        var %net = $hget(%table,net), %sw = +n
        if (chan* iswm $gettok(%table,3,45)) var %chan = $hget(%table,chan), %sw = +nc
      }
      if (chan* iswm $gettok(%table,2,45)) var %chan = $hget(%table,chan), %sw = +c
      while ($hget(%table,%i2).item) {
        var %item = $ifmatch
        .dll dlls\aircdll.dll OptSet sets %sw %net %chan %item $hget(%table,%item)
        inc %i2
      }
    }
    inc %i
  }
}

;flood routine switch (using tabo's aircdll.dll or the old method) - not in use anymore
alias _flood {
  return $dll(dlls\aircdll.dll,$1,$2-))

  if ($1 == floodclear) unset $_i(flood.*)
  else return $__flood($1,$2,$3,$4,$5)
}

;this is the old alternative to the dll
alias __flood {
  if ($1 == flooddel) { unset $_i(_flood.,$2) | return }
  var %f = $2, %inc = $3, %m = $4, %t = $5
  if ($__i(_flood.,%f)) {
    inc $_i(_flood.,%f) %inc
    var %a = $__i(_flood.,%f)
    if (%a >= %m) {
      unset $_i(_flood.,%f)
      return +FLOOD %a
    }
    return +OK %a
  }
  set -u $+ %t $_i(_flood.,%f) %inc
  return +OK %inc
}
;
;---------------
;sockscan

alias cscan {
  if (# !ischan) return

  var %i = 1, %h, %n, %s, %tb = $+(lastscan.cid,$cid)

  while ($nick(#,%i)) {
    var %n = $ifmatch, %h = $gettok($address(%n,2),2,64)

    if (%n != $me) && (%h) && (!$istok($hget(x_vars,%tb),%h,44)) {
      %s = $iif($2 == -k,$+(socks�,%n,�,#,�k),$+(socks�,%n,�,#))
      if (!$sock(%s)) sockopen %s %h $iif($hget(x_prot,socksp),$hget(x_prot,socksp),1080)
      if ($2 == -k) _var %tb $qtok($hget(x_vars,%tb),%h,20,44)
    }
    inc %i
  }
  if (%i > 2) ale Scanning # $+ ...
}
alias sscan {
  if ($1) var %h = $1
  else var %h = $$_input(Enter nick/host to scan,e,SOCKS)
  if (. !isin %h) %h = $gettok($address(%h,2),2,64)
  var %sc = socks� $+ %h
  if (%h) && (!$sock(%sc)) {
    sockopen %sc %h $iif($2 isnum,$2,1080)
    ale Scanning $1 for socks...
  }
  else ale Couldn't resolve %h $+ 's host
}
alias -l _scanend {
  sockclose $1
  if ($numtok($1,173) == 2) ale No socks found for $gettok($1,2,173)
  elseif ($numtok($1,173) == 3) && ($sock(socks�*,0) == 0) echo $iif($gettok($1,3,173) ischan,$gettok($1,3,173),-a) $_pre Socks scan completed for $gettok($1,3,173)
}
on 1:sockopen:socks�*:{
  var %s $sockname
  if ($sockerr) { _scanend %s | return }
  bset &a 1 5 1 0
  _sw %s &a
  _sw %s
  .timer. $+ %s -o 1 30 sockclose %s
}
on 1:sockread:socks�*:{
  var %s = $sockname, %n = $gettok(%s,2,173), %p
  sockread &c
  if ($bvar(&c,0) == 2) && ($bvar(&c,1,1) == 5) %p = 1
  elseif ($bvar(&c,1,1) == 87) && ($bvar(&c,8,1) == 62) %p = 2
  sockclose %s
  if (%p == 1) || (%p == 2) {
    set -u %::masksite $_screw($address(%n,2))
    set -u %::nick %n
    set -u %::chan $gettok(%s,3,173)
    $iif(%::chan ischan,echo %::chan $_pre,ale) $iif(%p == 1,Socks5,Wingate) detected on %n
    elseif (%p == 1) penalty socks5 %n %::chan $_kickmsg(socks5,%::chan)
    elseif (%p == 2) && ($hget(x_prot,wingate)) penalty socks5 %n %::chan $_kickmsg(wingate,%::chan)
    .timer $+ %s off
  }
}

;
;EOF
