;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; spambot module
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

alias -l _sb.msg {

  if ($hget(x_prot,spambot.echo) == active) ae $_pre -Spambot- $1-
  elseif ($hget(x_prot,spambot.echo) == status) se $_pre -Spambot- $1-
  else {
    var %w = @Spambot. $+ $cid
    if (!$window(%w)) window -kn %w $_gcoord(spambot,-1 -1 400 200) $_@font
    echo %w $timestamp $_pre $1-
    window -g1 %w
  }
}

on *:JOIN:#:{
  var %sn = spambot. $+ $cid
  if ($nick == $me) {
    if ($_protset(spambot,#)) set -u30 $_i(spambot.just.joined.,#) 1
  }
  elseif ($nick == $_smark(%sn,1)) {
    nickcol $nick # $_ncread(you)
  }
  elseif ($_protset(spambot,#)) && ($_smark(%sn,1) !ison #) {
    if (!$_protset(spambot.op,#)) || (($_protset(spambot.op,#)) && ($me isop #)) {
      if ($_protset(spambot.min,#)) && ($nick(#,0) == $_protset(spambot.min.val,#)) .timer 1 $rand(3,15) spambot #
    }
  }
}
raw 366:*:{
  var %sn = spambot. $+ $cid
  if ($__i(spambot.just.joined.,$2)) {
    if ($_smark(%sn,1) ison $2) .timerspambot.q.leave. $+ $cid $+ . $+ $2 off
    else {
      var %conn = 0
      if (!$_protset(spambot.op,$2)) || (($_protset(spambot.op,$2)) && ($me isop $2)) {
        if (!$_protset(spambot.min,$2)) || (($_protset(spambot.min,$2)) && ($nick($2,0) >= $_protset(spambot.min.val,$2))) spambot $2
      }
      unset $_i(spambot.just.joined.,$2)
    }
  }
}
on *!:PART:#:{
  var %sn = spambot. $+ $cid
  if ($_protset(spambot,#)) && ($_smark(%sn,1) ison #) && ($nick != $_smark(%sn,1)) {
    if ($_protset(spambot.min,#)) && ($calc($nick(#,0) -2) < $_protset(spambot.min.val,#)) .timerspambot.q.leave. $+ $cid $+ . $+ # 1 $rand(10,60) _sw %sn PART #
  }
}

on *:OP:#:_spambot.op
on *:OWNER:#:_spambot.op

on *:DEOP:#:{
  var %sn = spambot. $+ $cid
  if ($opnick == $me) && ($_smark(%sn,1) ison #) && ($_protset(spambot.op,#)) .timerspambot.q.leave. $+ $cid $+ . $+ # 1 $rand(10,60) _sw %sn PART #
}

alias -l _spambot.op {
  var %sn = spambot. $+ $cid
  if ($opnick == $me) && ($_protset(spambot,#)) && ($_protset(spambot.op,#)) {
    if ($_smark(%sn,1) ison #) .timerspambot.q.leave. $+ $cid $+ . $+ # off
    else {
      if (!$_protset(spambot.min,#)) || (($_protset(spambot.min,#)) && ($nick(#,0) >= $_protset(spambot.min.val,#))) .timer 1 $rand(3,15) spambot #
    }
  }
}
;===========================

alias spambot {
  if (!$server) return
  var %sn = spambot. $+ $cid
  if (!$sock(%sn)) {
    _identd
    sockopen %sn $iif($gettok($hget(x_prot,spambot.server),1,32),$ifmatch,$server) $iif($gettok($hget(x_prot,spambot.server),2,32) isnum,$ifmatch,$port)
    if ($1 ischan) _smark %sn 2 $1
    _smark %sn 3 $cid
    _sb.msg Connecting...
  }
  elseif ($1 == kill) || ($1 == quit) { _sw %sn QUIT :Leaving | .timer 1 2 sockclose %sn | .timerspambot.acycle. $+ $cid $+ .* off }
  elseif ($1 == part) && ($2) { _sw %sn PART $2 :Leaving }
  elseif ($1 == cycle) && ($2) { _sw %sn PART $2 | _sw %sn JOIN $2 }
  elseif ($1 == join) && ($2) { _sw %sn JOIN $2 }
  elseif ($1 == msg) && ($3 != $null) { _sw %sn PRIVMSG $2 : $+ $3- }
  elseif ($1 == do) && ($2 != $null) { _sw %sn $upper($2) $3- }
  elseif ($1 ischan) _sw %sn JOIN $1
}

alias _spambot.acycle {
  var %sn = spambot. $+ $1
  spambot cycle $2
  if ($_smark(%sn,1) ison $2) .timerspambot.acycle. $+ $cid $+ . $+ $2 1 $iif($_protset(spambot.cycle.val,$4),$calc($ifmatch *60),600) _spambot.acycle $cid $2
}

on 1:sockopen:spambot.*:{
  if ($sockerr) { _sb.msg Couldn't connect | return }
  var %nick = $iif($hget(x_prot,spambot.nick),$ifmatch,$_rand6), %pass = $iif($gettok($hget(x_prot,spambot.server),3,32),$ifmatch,$server($server).pass)
  if (%pass) _sw PASS $ifmatch
  _sw NICK %nick $+ $crlf $+ USER $iif($hget(x_prot,spambot.user) != $null,$ifmatch,$_rand6) " $+ $iif($host,$host,localhost) $+ " " $+ $iif($ip,$ip,127.0.0.1) $+ " : $+ $iif($hget(x_prot,spambot.realname) != $null,$ifmatch,$_rand6)
  _smark 1 %nick
}
on 1:sockclose:spambot.*:_sb.msg Connection closed
on 1:sockread:spambot.*:{
  if ($sockerr) return
  var %sb
  sockread %sb
  if ($sockbr == 0) return
  if (%debug) _wecho -> $sockname %sb
  tokenize 32 %sb

  var %me = $_smark(1), %nick = $right($gettok($1,1,33),-1), %address = $right($1,-1), %chan = $iif(:* iswm $3,$right($3,-1),$3), %cid = $_smark(3)
  if ($2 isnum) {
    if ($2 == 433) {
      var %nme = $iif(($hget(x_prot,spambot.altnick) && $hget(x_prot,spambot.altnick) != %me),$ifmatch,%me $+ $rand(1,10))
      _sw NICK %nme
      _smark 1 %nme
      _sb.msg %me is in use (changing to %nme $+ )
    }
    if ($2 == 366) {
      _sb.msg Joined $4
      if ($4 !ischan) || (($_protset(spambot.op,$4)) && ($me !isop $4)) {
        .timerspambot.q.leave. $+ %cid $+ . $+ $4 1 10 _sw $sockname PART $4
        _sb.msg Leaving channel in 10secs.
      }
      if ($_protset(spambot.cycle,$4)) {
        var %cycle = $iif($_protset(spambot.cycle.val,$4),$calc($ifmatch *60),600)
        .timerspambot.acycle. $+ $cid $+ . $+ $4 1 %cycle _spambot.acycle $cid $4
        _sb.msg Activating auto-cycle for every %cycle secs.
      }
    }
    if ($2 == 255) {
      if ($hget(x_prot,spambot.nickserv)) .timer 1 1 _sw $sockname nickserv identify $_pwd($ifmatch)
      if ($hget(x_prot,spambot.perform)) _perfd _sw $sockname $+ � $+ $ifmatch
      if ($_smark(2)) .timer 1 5 _sw $sockname JOIN $ifmatch
      .timer 1 1 _sw $sockname AWAY : $+ $iif($hget(x_prot,spambot.awayreason),$ifmatch,working!! don't bother)
      _sb.msg Spambot is now connected.
    }
    if (47* iswm $2) .timer 1 10 _sw $sockname JOIN $4
  }
  elseif ($1 == NICK) _smark 1 $2
  elseif ($1 == ERROR) && (leaving !isin $gettok($1-,-1,32)) _sb.msg ERROR: $right($2-,-1)
  elseif ($1 == PING) _sw PONG $2-
  elseif ($2 == JOIN) {
    if (%nick == %me) {
      .timerspambot.q.quit off
      .timerspambot.q.leave. $+ %chan off
      _smark 2 0
    }
  }
  elseif ($2 == PART) && (%nick == %me) {
    _sb.msg Left %chan
    if (!$comchan(%nick,0)) {
      .timerspambot.q.quit. $+ %cid 1 30 spambot kill
      _sb.msg No active/common channels. Disconnecting in 30secs.
    }
  }
  elseif (($2 == PART) && (%nick == $me)) || (($2 == KICK) && ($4 == $me)) || (($2 == QUIT) && (%nick == $me)) {
    .timerspambot.q.leave. $+ %cid $+ . $+ %chan 1 10 _sw $sockname PART %chan
    _sb.msg $me has left %chan $+ . Leaving in 10secs.
  }

  if (%nick == $me) || ($3 != %me) || (!$comchan(%nick,0)) || ($_isservice(%address)) return

  if ($2 == PRIVMSG) && ($_check.spam($right($4-,-1))) {
    var %i = 1
    while ($comchan(%nick,%i)) {
      var %chan = $ifmatch
      if ($me isop %chan) && ($_protset(spambot.spam,%chan)) && ($_protset(spam,%chan)) && (!$_prot.disable(%chan)) && (!$_exempt.status(%nick,%chan)) && (!$_exempt.ul(%address,%chan)) {
        penalty spam %nick %chan $_kickmsg(spam,%chan)
        _sb.msg $replace($_echo(spam),<nick>,%nick,<address>,$iif(%address,$gettok(%address,-1,33),n/a),<text>,$right($4-,-1))
      }
      inc %i
    }
  }

  elseif ($2 == NOTICE) && ($_check.spam($right($4-,-1))) {
    var %i = 1
    while ($comchan(%nick,%i)) {
      var %chan = $ifmatch
      if ($me isop %chan) && ($_protset(spambot.spam,%chan)) && ($_protset(spam,%chan)) && (!$_prot.disable(%chan)) && (!$_exempt.status(%nick,%chan)) && (!$_exempt.ul(%address,%chan)) {
        penalty spam %nick %chan $_kickmsg(spam,%chan)
        _sb.msg $replace($_echo(spam),<nick>,%nick,<address>,$iif(%address,$gettok(%address,-1,33),n/a),<text>,$right($4-,-1))
      }
      inc %i
    }
  }

  if ($4-5 == :DCC SEND) && ($_check.badfiles($6)) {
    var %i = 1
    while ($comchan(%nick,%i)) {
      var %chan = $ifmatch
      if ($me isop %chan) && ($_protset(spambot.badfiles,%chan)) && ($_protset(badfiles,%chan)) && (!$_prot.disable(%chan)) && (!$_exempt.status(%nick,%chan)) && (!$_exempt.ul(%address,%chan)) {
        penalty badfiles %nick %chan $_kickmsg(badfiles,%chan)
        _sb.msg $replace($_echo(badfiles),<nick>,%nick,<address>,$iif(%address,$gettok(%address,-1,33),n/a),<text>,$right($4-,-1),<badfile>,$right($4-,-1))
      }
      inc %i
    }
  }

}

;===========================

; this is to be run from the protection dialog ONLY
dialog sbotd {
  title "Spambot configuration"
  size -1 -1 246 231
  option pixels
  icon graphics\prot.ico, 0
  text "Nick", 1, 35 85 50 15, right
  text "AltNick", 2, 35 104 50 15, right
  text "User", 3, 35 132 50 15, right
  text "Realname", 4, 35 151 50 15, right
  text "Server [port]", 5, 16 35 70 15, right
  edit "", 11, 89 81 130 20, autohs
  edit "", 12, 89 102 130 20, autohs
  edit "", 13, 89 128 130 20, autohs
  edit "", 14, 89 149 130 20, autohs
  edit "", 15, 90 31 130 20, autohs
  box "", 7, 12 67 224 115
  box "", 8, 12 14 224 50
  button "Ok", 50, 62 197 60 25, default ok
  button "Cancel", 49, 132 197 60 25, cancel
}
on 1:dialog:sbotd:*:* {
  if ($devent == init) {
    multi.lang
    if ($dialog(protect)) {
      if ($did(protect,411) != $null) did -ra sbotd 11 $ifmatch
      if ($did(protect,412) != $null) did -ra sbotd 12 $ifmatch
      if ($did(protect,413) != $null) did -ra sbotd 13 $ifmatch
      if ($did(protect,414) != $null) did -ra sbotd 14 $ifmatch
      if ($did(protect,415) != $null) did -ra sbotd 15 $ifmatch
    }
  }
  if ($devent == sclick) {
    if ($did == 50) {
      if ($dialog(protect)) {
        did -ra protect 411 $did(11)
        did -ra protect 412 $did(12)
        did -ra protect 413 $did(13)
        did -ra protect 414 $did(14)
        did -ra protect 415 $did(15)
      }
    }
  }
}

menu @spambot.* {
  $iif($sock($+(spambot,.,$cid)),Join #chan):_sw $+(spambot,.,$cid) JOIN $$_input(Enter channel name,e,Spambot)
  $iif($sock($+(spambot,.,$cid)),Part #chan):_sw $+(spambot,.,$cid) PART $$_input(Enter channel name,e,Spambot)
  $iif($sock($+(spambot,.,$cid)),Cycle #chan):spambot cycle $$_input(Enter channel name,e,Spambot)
  -
  $iif($sock($+(spambot,.,$cid)),Msg #chan/nick):_sw $+(spambot,.,$cid) PRIVMSG $$_input(Enter target for message,e,Spambot) : $+ $$_input(Enter message,e,Spambot)
  $iif($sock($+(spambot,.,$cid)),Notice #chan/nick):_sw $+(spambot,.,$cid) NOTICE $$_input(Enter target for notice,e,Spambot) : $+ $$_input(Enter message,e,Spambot)
  -
  $iif($sock($+(spambot,.,$cid)),Send command):_sw $+(spambot,.,$cid) $$_input(Enter raw command to send,e,Spambot)
  $iif($sock($+(spambot,.,$cid)),Disconnect,Connect):spambot $iif($sock($+(spambot,.,$cid)),kill,#)
  -
  Close:_closewin $active
}

;
;EOF
