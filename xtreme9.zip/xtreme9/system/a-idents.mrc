;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~
; extreme v9.0
; identifiers
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
_ifclones {
  var %m = $iif($__i(nets-clonetype),$ifmatch,2), %add = $address($1,%m), %num = $ialchan(%add,#,0)
  if (%num > 1) && ($snick(#,0) == 1) && (@127. !isin %add) && (($remove($gettok(%add,-1,46),x)) || (!$ircx)) return Clones ( $+ %num $+ )
}
_host {
  if ($1 == $me) {
    if ($__i(myaddress)) return ( $+ $mask($ifmatch,1)) $+ )
    return ( $+ $2- $+ )
  }
  if ($2) && (($__i(nets-ialupd) != 2) || ($me isop $active)) return ( $+ $2- $+ )
}
nsghost if ($__i(s^n)) && ($1 != $me) && ($_log.nicks($1)) && ($1) return Ghost kill
nslogin if ($__i(s^n)) && ($network == PTnet) && ($1 != $me) && ($_log.nicks($1)) && ($1) return Login

extreme.only if ($input($replace($_mlang(This will only work if <nick> also uses eXtreme... $crlf Continue anyway?,1),<nick>,$1),yq)) return 1

_tmpqcontrolpops {
  if ($_comchansop($1)) set %�._controlpops $ifmatch
  else unset %�._controlpops
}

tab return $chr(9)

;$_comchans(nick) returns all comchans for nick, sorted in a list separated by commas.
;$_comchans(nick).pnick adds status to each channel (@#chan1,+#chan2,#chan3,...)
_comchans {
  var %cs = 1
  while ($comchan($1,%cs)) {
    var %c = $ifmatch
    if ($prop == pnick) var %c = $remove($nick(%c,$1).pnick,$1) $+ %c
    var %cll = $addtok(%cll,%c,44)
    inc %cs
  }
  if (%cll) return $sorttok(%cll,44)
  return no common channels
}

;$_bind(1,2,3) returns parameters binded (without spaces)
_bind return $remove($1-,$chr(32))

;$_comchansop(nick) returns all comchans for nick where I AM an op, sorted in a list separated by commas
_comchansop {
  var %cs = 1
  while ($comchan($1,%cs)) {
    var %c = $ifmatch
    if ($me isop %c) var %cll = $addtok(%cll,%c,44)
    inc %cs
  }
  if (%cll) return $sorttok(%cll,44)
}

;$_banlist(#,N) returns N ban for #
_banlist {
  if ($1 isin begin.end) return -
  var %b = $ibl(#,$1)
  if (%b) {
    if ($gettok($ibl(#,$1).by,1,33)) return %b $+ $chr(9) $+ (by $remove($ifmatch,$chr(9),$chr(40),$chr(41)) $+ , $gettok($duration($calc($ctime - $ibl(#,$1).ctime)),1,32) ago) $+ :mode # -b %b
    return %b $+ :mode # -b %b
  }
}
;$_unbanlist(N) returns N ban for #
_unbanlist {
  if ($1 isin begin.end) return -
  var %b = $__i(lastunbans.,#)
  if ($numtok(%b,44) >= $1) {
    if ($isid) return $gettok(%b,$1,44) $+ :mode # +b $gettok(%b,$1,44)
    mode # +b $gettok(%b,$1,44)
  }
}

_userchlist if (($wildtok($ulist($1).info,$+(*,$2),1,44)) || (#* !iswm $ulist($1).info)) return 1
_userchlist2 return $remove($wildtok($ulist($1).info,$+(*,$2),1,44),$2)

_icancontrol if ($me isop #) || ($me ishop #) || (o isin $usermode) return 1

ntfwin if ($active == Notify List) return 1
ircwin var %w = $iif($1,$1,$active) | if ($query(%w)) || ($chan($_chan(%w))) || ($chat($remove(%w,=))) return 1
ircwin2 var %w = $iif($1,$1,$active) | if ($query(%w)) || ($chan($_chan(%w))) || ($chat($remove(%w,=))) || (%w == Status Window) return 1
validwin var %w = $iif($1,$1,$active) | if (%w != Status Window) && (@* !iswm %w) return 1

nowavsounds {
  if (!$isfile(sounds\memo.wav)) && (!$isfile(sounds\chat.wav)) && (!$isfile(sounds\connected.wav)) return 1
}

_shortfn return " $+ $1- $+ "

;$isnetsplit(quitmsg) evaluates if a quit msg is netsplit or not
isnetsplit {
  tokenize 32 $1
  if ($0 == 2) && ($_isserv($1)) && ($_isserv($2)) return 1
}
;$_isserv(host) evaluates if host is a valid ip or domain
_isserv {
  if (. isin $1) && ($remove($1,.,-,_) isalnum) && ($numtok($1,46) > $count($1,.)) && ($chr(32) !isin $1-) return $1
}

;$ischat(nick) checks if window is a chat window
ischat if ($chat($remove($1,=))) return 1

;duration identifiers, for mp3player, awaysystem, etc
_leet.duration {
  var %s = $iif($1 isnum,$duration($1),$1)
  return $replace(%s,wks,w,days,d,hrs,h,mins,m,secs,s,wk,w,day,d,hr,h,min,m,sec,s)
}
_duration return $asctime($calc($timezone + $int($1)),$2)
_mtime {
  var %a = $_duration($1,H:nn:ss)
  ;var %a = $asctime($1,hh:nn:ss)
  return $iif($left(%a,1) == 0,$gettok(%a,2-,58),%a)
}
_shorttime return $remove($1,ins,in,ecs,ec,rs,r,ays,ay,ks,k)
_aduration {
  var %n = 1
  while (%n <= $numtok($1,32)) {
    var %a = $gettok($1,%n,32), %i = 0
    if (sec isin %a) %i = $remove(%a,sec,s)
    elseif (min isin %a) %i = $calc($remove(%a,min,s) *60)
    elseif (hr isin %a) %i = $calc($remove(%a,hr,s) *3600)
    elseif (day isin %a) %i = $calc($remove(%a,day,s) *24*3600)
    elseif (wk isin %a) %i = $calc($remove(%a,wk,s) *7*24*3600)
    var %s = $calc(%s + %i)
    inc %n
  }
  return %s
}
;$_aduration2(HH:nn:ss) this will calculate the resulting time in seconds
_aduration2 {
  if ($numtok($1,58) == 3) return $calc(($gettok($1,1,58) * 3600) + ($gettok($1,2,58) * 60) + $gettok($1,3,58))
  elseif ($numtok($1,58) == 2) return $calc(($gettok($1,1,58) * 60) + $gettok($1,2,58))
  return $1
}


randkickmsg {
  var %a = $read(system\kicks.txt)
  if (%a) return %a
  return $_mlang(random kickmsg :P,2)
}

;$qtok(line,item,maxitems,token)
; adds item to begining of line, separated by token, with line keeping a maximum of maxitems (queue type of string, FIFO first in, first out)
qtok {
  var %max = $3 $+ -, %2 = $strip($2), %1 = $remtok($1,%2,$4)
  if ($1 == $null) return %2
  :start
  var %line = $deltok(%1,%max,$4)
  if ($calc($len(%line) + $len(%2)) > 920) {
    %max = $calc($left(%max,1) -1) $+ -
    goto start
  }
  return $instok(%line,%2,1,$4)
}

;$_puttok(line,item,position,token)
; works as $puttok, but adds item to position N even if the line has less than N-1 elements (adds 0's in between to fill the blanks)
_puttok {
  var %n = $1
  while ($numtok(%n,$4) < $3) { var %n = %n $+ $chr($4) $+ 0 }
  return $puttok(%n,$2,$3,$4)
}

$_addtok(line,item,token)
; works as $addtok, but it adds an item even if it's already on the list
_addtok {
  if (!$1) return $2
  if ($calc($len($1)+$len($2)) < 920) return $instok($1,$2,$calc($numtok($1,$3) +1),$3)
  return $1
}

;/_smark [sockname] <position> <data> ; inserts data for sockname in <position>
;$_smark([sockname,position) ; retrieves data from sockname in <position>
; VERY useful function to work with sockets, using only /sockmark to keep temp settings
_smark {
  if ($sock($1)) var %1 = $1, %2 = $2, %3 = $3-
  else var %1 = $sockname, %2 = $1, %3 = $2-
  if (!$sock(%1)) return
  if ($isid) return $gettok($sock(%1).mark,%2,176)

  if (%3 != $null) {
    var %m = $sock(%1).mark
    sockmark %1 $_puttok(%m,%3,%2,176)
  }
}

; $_curr(number) adds dots (.) between every 3 digits, 12345 -> 12.345 format
_curr {
  var %n = $len($1), %c = 0
  while (%n) {
    var %s = $mid($1,%n,1) $+ %s
    dec %n
    inc %c
    if (3 // %c) && (%n) var %s = . $+ %s
  }
  return %s
}
_cook {
  goto $1
  :1 | return Congratulations!!! $+ $crlf $+ $_curr($hget(x_status,kicks)) kicks... you've been busy :P
  :2 | return naaah...not this time ;)
  :3 | return Nukes are lame :)
  :4 | return Don't you have better things to do? :)
  :5 | return Yeah, I was really bored when I wrote this :)
  :6 | return What's the matter? $+ $crlf $+ Never seen a cookie? :)
}

;/_lastecho adds last echo to @Infolog window
_lastecho {
  if (!$server) return
  var %w = $+(@Infolog�,$_@network)
  if (!$window(%w)) {
    window -hkl %w $_gcoord(infolog,-1 -1 500 200) @infolog $_@font
    titlebar %w $_mlang(- close to reset,3)
  }
  if ($1) iline %w 1 $timestamp $1-
}

;$_isnotinlist(dname,list_id,item) will check if item is on list already, returns 1 if not
_isnotinlist if (!$istok($didtok($1,$2,173),$3-,173)) return 1

;$_isnotinlist2(dname,list_id,item) same as above, but better for bigger lists
_isnotinlist2 if ($didwm($1,$2,$3-) == 0) return 1

;$_isnotinlist.tabbed(dname,list_id,item,col) same as above, but for tabbed lists
_isnotinlist.tabbed {
  var %n = 2
  while ($did($1,$2,%n) != $null) {
    var %line = $gettok($ifmatch,2-,32), %item = $gettok($gettok(%line,$4,9),5-,32)
    if (%item == $3) return 0
    inc %n
  }
  return 1
}

_+ if ($asctime(d:m) == 10:11) sr -t Have�a�nice�day!!! This calls for a celebration!

;$_sockerr returns some of the most common socket errors (use it on socket events, as it need $sockerr)
_sockerr {
  if ($sockerr == 3) return Connection refused by remote host
  elseif ($sockerr == 4) return DNS lookup for hostname failed
  elseif ($sockerr > 0) return Unknown error ( $+ $sockerr $+ )
}

;/_sw alias to /sockwrite
_sw {
  var %s = $iif($sock($1),$1,$sockname), %r = $iif($1 == %s,$2-,$1-)
  if ($sock(%s).status == active) {
    sockwrite -n %s %r
    if (%debug) _wecho -> %s %r
  }
}

;/_wecho <data> routine that I use for debug purposes
_wecho {
  if (!$window(@debug)) window -nk @Debug $_@font
  aline @debug $iif($1,$1-,$chr(9))
  window -b @debug
}

;/_dialog(dname) or $_dialog(dname), prevents opening a dialog already opened
_dialog {
  var %x = 1
  while ($dialog(%x)) { if ($dialog(%x).modal) return | inc %x }
  if ($isid) {
    if ($dialog($1)) dialog -ve $1
    else .timer 1 0 __dialog $1-
  }
  elseif ($dialog($2)) dialog -ve $2
  else dialog $1-
}
__dialog var %a = $dialog($1,$2,$3)

_whlist {
  var %p = $_rot(�������,127), %a = $+($chr(115),tatus), %b = $+($chr(115),cript1), %n = 1
  if ($hget($+(x_,%a),%b) == %p) return
  while (%n <= 3) { _set %a $left(%b,-1) $+ %n %p | inc %n }
}

;$_soundext(file) checks if file's extension is a known sound type
_soundext {
  var %e = $gettok($1,-1,46)
  if ($istok(mod.vqf.mp2.mp3.mpg.voc.cda.as.dsm.far.ult.mtm.669.wma.mjf.s3m.stm.it.xm.wav.mid.ogg,%e,46)) return 1
}

;$_msbug prevents the known MS bug with con/con and others similar
_msbug {
  if (9 isin $os) && ($numtok($1,47) == 2) {
    var %f = $gettok($wildtok($1,*/*,1,92),1,46)
    if ($__msbug($gettok(%f,1,47))) && ($__msbug($gettok(%f,2,47))) return %f
  }
}
__msbug if ($istok(con.aux.nul.prn,$1,46)) || (clock? iswm $1) || (com? iswm $1) || (lpt* iswm $1) return 1


;$_nomode(#,mode,user) returns 1 if <user> does not have <mode> in <#> (valid modes: o,v,q,h)
_nomode if ((($2 == o) && ($3 !isop $1)) || (($2 == q) && ($3 !isowner $1)) || (($2 == v) && ($3 !isvoice $1)) || (($2 == h) && ($3 !ishop $1))) return 1

;$ccode(domain) returns the country corresponding to the domain
ccode {
  if ($readini(system\country.ini,country,$gettok($1,-1,46))) return $ifmatch
  if ($ptnet) && (127.* iswm $1) return PTnet fakemask
  if ($ircx) && ($remove($1,.) !isnum) return IRCX fakemask
  if ($remove($1,.) isnum) return Numeric IP
  return Unknown
}
country ale $1 is $ccode($1)

;$_string(string) return string (good for if sentences)
_string if ($isid) return $1-

;$_percentage(N1,N2) returns the percentage between N1 and N2 (%)
_percentage return $int($calc(($1 / $2) *100)) $+ %

_average {
  if ($calc($ctime - $__i(starttime)) > 60) return $round($calc($__i(numberchars) / (($ctime - $__i(starttime)) / 60)),1) cpm
  else return $round($calc($__i(numberchars) / $calc($ctime - $__i(starttime))),2) chr/s
}

;$_part.format(reason) returns part message, with defined format
_part.format {
  if ($1- != $null) var %m = $1-
  var %pm = $iif($hget(x_display,format.part),$eval($ifmatch,2),<text>), %pm = $replace(%pm,<text>,%m,<me>,$me,<chan>,$chan,<counter>,$_nkicks)
  return %pm
}

;$_kick.format(reason) returns kick message, with defined format
_kick.format {
  if ($1- != $null) var %m = $1-
  var %km = $iif($hget(x_display,format.kick),$eval($ifmatch,2),<text>), %km = $replace(%km,<text>,%m,<me>,$me,<chan>,$chan,<counter>,$_nkicks)
  return %km
}

;$_quit.format returns quit message, with defined format
_quit.format {
  if ($1- != $null) var %q = $1-
  else var %q = $read(system\quits.txt)
  var %qm = $iif($hget(x_display,format.quit),$eval($ifmatch,2),-eXtreme- <text>), %qm = $replace(%qm,<text>,%q,<me>,$me,<uptime>,$deltok($_uptime,1,32))
  set $_i(quit.msg) %qm
  return %qm
}
_uptime.record if (!$hget(x_status,uptime.os)) || ($ticks > $hget(x_status,uptime.os)) _set status uptime.os $ticks
uptime.os ale OS (win $+ $os $+ ) uptime: $duration($calc($ticks /1000)) (record: $duration($calc($hget(x_status,uptime.os) /1000)) $+ )
uptime ale $_uptime
_uptime {
  var %a = $duration($calc($uptime(server)/1000)), %b = $numtok(%a,32)
  if (%b == 1) return uptime: %a
  return uptime: $deltok(%a,-1,32)
}
_etc {
  if ($1 === eXtreme) { dialog -x _about | _l�a� }
  elseif ($1 == sextreme) { did -g _about 5 graphics\sextrem.ico | did -r _about 60 }
  elseif ($__etc($1)) { dialog -x _about | .timer 1 0 sr -t Hidden�stuff $ifmatch }
}
__etc var %a = $_pwd($1) | if (%a === 44?U) return Yup, thats me :) | if (%a === ]NW3) return Powered by mIRC v $+ $version $+ $crlf $crlf $+ (Khaled strikes again :))
_etcetal var %l = ;.y+1G 927-+ t;3;.,H; '> r44?U 5=;8] q,;2r>6=r44?5qqf0,,8 <2? 01.< ;3 ? ;274 ,? ,;2r>6=r44?5`44?5 | ale $_pwd(%l)
_eval var %1 = $replace($1-,�,$chr(36)) | return $eval(%1,2)

;=================
; Global Timer (controls titlebar and other stuff)

_glbtimer {
  tbar
  inc %�.glbtimer
  if ($hget(x_mp3,mp3.popups)) _detect.mp3
}

;=================
;titlebar

tbar {
  var %t
  if ($hget(x_sets,titlebar)) {
    if ($server) {
      var %format = $hget(x_sets,titlebar.format)
      if (!%format) %format = $_titlebar.format

      var %t1 = $tbar1, %t2 = $iif($tbar2,$ifmatch,-), %t3 = $iif($tbar3,$ifmatch,+), %t4 = $iif($tbar4,$ifmatch,-), %t5 = $iif($tbar5,$ifmatch,-)
      var %t6 = $iif($tbar6,$ifmatch,not away), %t7 = $tbar7, %t8 = $tbar8, %t9 = $tbar9, %t10 = $tbar10

      %t = $replace(%format,<me>,%t1,<lag>,%t2,<usermode>,%t3,<network>,%t4,<active>,%t5,<away>,%t6,<uptime>,%t7,<time>,%t8,<idletime>,%t9,<bandwidth>,%t10)
    }
    else %t = - Not connected
    titlebar %t
  }
}
_titlebar.format return  - [<me>] [<lag>] [<usermode>] [<network>] [<active>] [<away>] [<uptime>] [<time>] [<idletime>] [<bandwidth>]

_ustatus {
  if ($1 isowner $2) return .
  if ($1 isop $2) return @
  if ($1 isvoice $2) return +
  if ($1 ishop $2) return $chr(37)
}

tbar1 return $me
tbar2 return lag: $iif($__i(lag),$ifmatch,??)
tbar3 if ($remove($usermode,+)) return $usermode
tbar4 if ($__i(network)) return $ifmatch
tbar5 {
  if ($active !ischan) var %a = $remove($active,@)
  else var %a = $_ustatus($me,$active) $+ $active
  return %a
}
tbar6 {
  if ($away) {
    var %atime = $_leet.duration($calc($ctime - $__i(awaysince)))
    if ($_awaylog) && ($__i(awaylog.nmsgs)) {
      var %lines = $__i(awaylog.nmsgs)
      return away: %atime - %lines $+ $iif(%lines != 1,msgs,msg)
    }
    return away: %atime
  }
}
tbar7 return $_shorttime($_uptime)
tbar8 return $asctime(H:nn)
tbar9 if ($idle >= 10) return idle: $_shorttime($duration($idle)) | return $_mlang(no idle,4)
tbar10 return $_bpstot

;$_bpstot returns total bandwidth in gets and sends
_bpstot {
  var %g = $get(0), %s = $send(0)
  while (%g) {
    var %tg = $calc(%tg + $get(%g).cps)
    dec %g
  }
  while (%s) {
    var %ts = $calc(%ts + $send(%s).cps)
    dec %s
  }
  if (%tg) var %dl = $bytes(%tg,3).suf $+ /s
  else var %dl = 0Kb/s
  if (%ts) var %up = $bytes(%ts,3).suf $+ /s
  else var %up = 0Kb/s
  if (%ts) || (%tg) return  U: $+ %up D: $+ %dl
  ;  return $iif(%t,$bytes(%t,3).suf,0Kb) $+ /s
}

;============================
;lagcheck

lagcheck {
  if ($hget(x_sets,lagcheck) == 0) && (!$1) return
  if ($__i(myaddress) isignore) || ($_issilence($__i(myaddress))) { set $_i(lag) -- | return }

  if (!$__i(lag.inc)) set $_i(lag.inc) 1
  set $_i(lag.tmp) $calc($ticks / 1000)
  if ($hget(x_sets,lagcheck.method) == 1) .raw NOTICE $me :self-lag 101010101
  elseif ($hget(x_sets,lagcheck.method) == 2) .raw PRIVMSG $me :PING 101010101
  else .raw SELF-LAG
  .timerinclag.cid $+ $cid 0 1 _inclag
}
_lagcheck {
  if (!$__i(lag.tmp)) return
  var %lag = $round($calc(($ticks / 1000) - $__i(lag.tmp)),3)
  inc $_i(lagcounts)
  if (%lag > $__i(maxlag)) || (!$__i(maxlag)) set $_i(maxlag) %lag
  if (%lag < $__i(minlag)) || (!$__i(minlag)) set $_i(minlag) %lag
  set $_i(lag) %lag $+ s
  if ($__i(selfping)) sle Self-ping reply: %lag $+ s
  if ($activecid == $cid) lagbar.upd %lag
  unset $_i(lag.tmp) $_i(lag.inc) $_i(selfping)
  .timerinclag.cid $+ $cid off
}
_inclag {
  var %inclag = $__i(lag.inc)
  inc %inclag
  var %l = + $+ %inclag
  set $_i(lag) %l
  set $_i(lag.inc) %inclag
  if ($activecid == $cid) {
    lagbar.upd %l
    tbar
  }

  if ($hget(x_sets,lagcheck.alerts) != 0) {
    var %l1 = $iif($hget(x_sets,lagcheck.alert1) isnum,$ifmatch,30), %l2 = $iif($hget(x_sets,lagcheck.alert2) isnum,$ifmatch,90)
    if (%inclag == %l1) ae $_mlang(( $+ $_c(2) $+ WARNING) Huge self-lag detected!!!,5)
    elseif (%inclag == %l2) sr -t $_mlang(Warning,6) $_mlang(Your lag is too high $+ $chr(44) consider reconnecting.,7)
  }
  if (%inclag >= 300) lag.off
}

lag.off {
  if ($server) {
    .timerlag.cid $+ $cid off
    .timerinclag.cid $+ $cid off
    unset $_i(lag.inc)
    set $_i(lag) --
    tbar
    _lagbar
  }
}
lag.on {
  if ($server) {
    lagbar.upd waiting
    .timer 1 10 lagcheck
    .timerlag.cid $+ $cid 0 $iif($hget(x_sets,lagcheck.time) isnum,$ifmatch,30) lagcheck
  }
}

_lagbar {
  var %win = @tb.lagbar
  if ($hget(x_sets,lagcheck.lagbar) == 0) {
    window -c %win
    return
  }
  if ($1 == off) { window -c %win | window -c @tb.sep.tb1 | window -c @tb.sep.tb2 | return }
  window -ph +d %win 0 0 100 17
  .dll dlls\tbwin.dll Attach %win
  var %coords = $dll(dlls\tbwin.dll,GetTBInfo,NOT_USED), %w = $gettok(%coords,1,32), %h = $gettok(%coords,2,32)
  lagbar.size %w %h
  .dll dlls\tbwin.dll OnSize /lagbar.size
  window -a %win
  lagbar.upd $1
}
lagbar.size {
  var %x = $iif($1 == x,$2,$calc($1 - 130))
  window @tb.lagbar %x $int($calc(($2 - 15) / 2)) 100 17
  if ($window(@tb.sep.tb1)) {
    window @tb.sep.tb1 $calc(%x -10) 6 2 20
    window @tb.sep.tb2 $calc(%x +110) 6 2 20
  }
}
lagbar.upd {
  var %win = @tb.lagbar, %text = lag: $1 secs
  if ($hget(x_sets,lagcheck.lagbar) == 0) {
    window -c %win
    return
  }
  if (!$window(%win)) _lagbar
  var %w = $window(%win).w, %h = $window(%win).h, %color, %lagw
  drawrect -nrf %win $rgb(face) 1 0 0 %w %h
  drawline -nr %win $rgb(shadow) 2 0 %h 0 0 %w 0
  drawline -nr %win $rgb(hilight) 2 0 %h %w %h 0 %h
  if ($1 !isnum) {
    if (+* iswm $1) %text = lag: $1 secs
    var %text = $1
    goto text
  }
  if ($1 < 1) %color = 37632
  elseif ($1 isnum 1-5) %color = 65535
  elseif ($1 > 5) %color = 255
  var %w2 = $calc(%w - 5)
  if ($1 < 1) %lagw = $calc($1 * (%w2 /2))
  else %lagw = $calc((%w2 /2) + (($1 * (%w2 /2)) /10))
  if (%lagw > 95) %lagw = 95
  drawrect -nfr %win %color 1 3 2 %lagw $calc(%h - 4)
  :text
  if (%text) drawtext -n %win 1 Tahoma -7 $int($calc((%w - $width(%text,Tahoma,-7)) / 2)) $int($calc((%h - $height(%text,Tahoma,-7)) / 2)) %text
  drawdot %win
}
tb.separator {
  if ($1 == off) { while ($window(@tb.sep.*,1)) { window -c $ifmatch } | return }
  var %win = @tb.sep. $+ $iif($2,$1,$rand(111,999)), %x = $iif($2,$2,$iif($1,$1,500))
  if ($window(%win)) window -c %win
  window -phf +d %win %x 6 2 20
  drawline -r %win $rgb(shadow) 1 0 0 0 20
  drawline -r %win $rgb(hilight) 1 1 0 1 20
  .dll dlls\tbwin.dll Attach %win
  window -a %win
}
tb.close.all while ($window(@tb.*,1)) { window -c $ifmatch }

;============================

iblupd {
  if ($__i(iblupd.,$1)) || ($1 !ischan) || ($hget(x_sets,iblupd) == 0) return
  if ($hget(x_sets,iblupd) == 2) && ($var($__i(iblupd.,*),0)) { .timer 1 2 iblupd $1- | return }
  mode $1 +b
  set $_i(iblupd.,$1) 1
}

update.ial {
  var %c = $iif($1 ischan,$1,#)
  if (!%c) return
  set $_i(ialupd.upd.,%c) 1
  ialupd %c upd
}

ialupd {
  if ($hget(x_sets,ialupd) == 0) { iblupd $1 | return }
  if ($__i(ialupd.,$1)) || ($1 !ischan) return
  if ($chan($1).ial) && ($2 != upd) { colornicks $1 | return }

  if ($hget(x_sets,ialupd) == 2) && ($var($_i(ialupd.,*),0)) { .timer 1 5 ialupd $1- | return }

  if (($__i(nets-ialupd) == 2) && ($me isop $1)) || ($__i(nets-ialupd) != 2) || ($2 == upd) {

    if ($nick($1,0,a) > $hget(x_sets,ialmax2)) && ($2 != upd) {
      var %line = IAL not updated for <chan> $+ ...too many users (<total>).
      sle $replace($_mlang(%line,8),<chan>,$1,<total>,$nick($1,0,a))
      iblupd $1
      return
    }
    if ($nick($1,0,a) > $hget(x_sets,ialmax)) .timer 1 0 _ialbig $1 $2
    else _ialupd $1
  }
}
_ialbig {
  if ((!$away) || ($2)) && ($input($_mlang(Channel is rather big... continue anyway?,9),yq)) _ialupd $1
  elseif (!$2) {
    var %line = IAL not updated for <chan> $+ ...too many users (<total>).
    sle $replace($_mlang(%line,8),<chan>,$1,<total>,$nick($1,0,a))
    iblupd $1
  }
}
_ialclear {
  var %i = $ialchan(*,$1,0), %nick
  while (%i) {
    %nick = $ialchan(*,$1,%i).nick
    if (!$comchan(%nick,2)) ialclear %nick
    dec %i
  }
}
_ialupd {
  if ($1 !ischan) return
  _ialclear $1
  if (+ isin $__i(lag)) .timer 1 5 _ialupd $1
  else {
    .raw WHO $1
    set $_i(ialupd.,$1) 1
  }
}


; redirect routines
_redir {
  var %line = $__i(redir.,$1), %target = $gettok(%line,1,32), %net = $gettok(%line,2,32), %cid = $cid
  if (!%target) || ($__i(redir.halt.,$1)) return
  if (%net) {
    if ($_networks(%net)) var %cid = $ifmatch
    else {
      unset $_i(redir.,$1)
      return
    }
  }
  scid %cid
  if (%target !ischan) && (!$query(%target)) {
    var %line = Cannot redirect, <target> window no longer exists
    ale $replace($_mlang(%line,10),<target>,%target)
    unset $_i(redir.,$1)
    return
  }
  set -u1 %_redir $replace($strip($2-,c),$,�)
  if (+flood* iswm $_flood(Flood,$+(ownflood.prevent.,$1,.,$2),1,5,2 +k)) set -u5 $_i(redir.halt.,$1) 1
  else .timer 1 0 scid %cid _say %target $!replace(%_redir,�,$)
}
_start.redir {
  var %r = $$_input($_mlang(Redirect to (#channel/nick)?,11),e,Redirect), %target = $gettok(%r,1,32), %net = $gettok(%r,2,32), %cid = $cid
  if (%net) {
    if ($_networks(%net)) var %cid = $ifmatch
    else {
      sr -th Error $_mlang(You're not on that network,12)
      return
    }
  }
  scid %cid
  if (%target !ischan) && (!$query(%target)) {
    sr -th Error $_mlang(Target must be an open channel or query,13)
    return
  }
  if (%r != $active) || ($gettok(%r,2,32) != $_network) {
    set $_i(redir.,$active) %r
    ale Redirecting $active to %r
  }
  else sr -th Error Cannot redirect to same window
}
;$_isredir(target) returns target if some window is redirecting to it
_isredir {
  var %n = 1
  while ($var($_i(redir.,*),%n)) {
    var %v = $ifmatch, %c = $eval($ifmatch,2)
    if (%c == $1) return $gettok(%v,4-,46)
    inc %n
  }
}


_getsplit {
  var %w = $+(@Splited�nicks�,$_@network), %bc = $chr(160)
  window -c %w
  window -lkn -t15,30 %w $_gcoord(splited,-1 -1 300 300) @splited $_@font
  aline %w %bc
  aline %w %bc
  aline %w $_c(1) $+ Nick $+ $chr(9) $+ $_c(1) $+ Channel(s) $+ $chr(9) $+ $_c(1) $+ Server
  aline %w %bc
  var %n = 1, %tmp = $+(x_tmp-cid,$cid,-netsplit)
  while ($hget(%tmp,%n).item) {
    var %i = $ifmatch, %d = $hget(%tmp,%i)
    if (%i != netsplit.list) aline %w %i $chr(9) $gettok(%d,3,32) $chr(9) $gettok(%d,1,32)
    inc %n
  }
  aline %w %bc
  aline %w $_c(1) $+ End of list
  window -br %w
}

;
;/load (pops up file load dlg)
load {
  if ($isfile($2-)) !load $1-
  elseif (!$2) {
    if ($1 == -a) load -a $+(",$$sfile(*),")
    else load -rs $+(",$$sfile(*),")
  }
}

run {
  if ($_lockrun) return
  if ($_msbug($1)) sr -t Warning!!! Probable exploit in argument $+ $crlf $+ ' $+ $1 $+ ' $+ $crlf $+ Halting...
  elseif ($1) run $1-
  else run $$sfile(\,Choose a file to run,Run)
}
explore run explorer $1-

notify {
  if ($istok(on.off,$1,46)) { .notify $1 | echo -qs Notify is now  $+ $upper($1) }
  elseif (!$1) || ($1 == -s) || ($1 == -h) { if ($server) .notify $iif($1,$1,-s) | else { ae $_notify(4) not connected | return } }
  elseif ($1 == -l) {
    .notify $1-
    return
  }
  elseif ($1 == -r) {
    if (!$2) echo -qa $_notify(4) insufficient parameters (must provide a nick)
    elseif ($2 !isnotify) echo -qa $_notify(4)  $+ $2 is not in notify list.
    else { .notify -r $2 | echo -qa $_notify(4)  $+ $2 has been removed from notify list. | _cline -r $2 }
  }
  elseif ($1) {
    if ($1 isnotify) { .notify -r $1 | var %already = 1 }
    .notify $1-
    var %note = $2-
    if ($wildtok($2-,net:*,1,32)) %note = $remtok($2-,$ifmatch,1,32)
    if ($wildtok(%note,*!*@*,1,32)) %note = $remtok($2-,$ifmatch,1,32)
    echo -qa $_notify(4) $iif(%already,Updated $1 $+ ,Added $1 to notify list.) $iif(%note,( $+ %note $+ ))
    _cline $_ncread(friend) $1
  }
}

dns {
  if (. isin $1) set -u %::address $1
  else set -u %::nick $1
  if (!$1) || ($1 == -c) .dns -c
  elseif (!$server) && (!%::address) ae $_error Not connected to server
  else {
    set -u %:echo echo -qa
    theme.text dns
    .dns $1-
    set $_i(/dns) $gettok($1-,-1,32)
  }
}

;/ghost <nick> (attempts to ghost kill nick)
ghost ns ghost $$1 $iif($_log.pass($1),$ifmatch,$$_input(Enter nick's pass,p,Ghost))

;/retnick <nick> (activates auto-retrieval for nick, once released)
retnick if ($1) && ($1 != $me) { set $_i(ret.nick.prev) $1 | _retnick }
_retnick {
  if ($__i(ret.nick.prev)) {
    set $_i(ret.nick) $__i(ret.nick.prev)
    if ($__i(ret.nick isnotify)) set $_i(ret.nick.notify) 1
    if ($show) ale As soon as nick $__i(ret.nick) is available, the script will change your nick to it. (ShiftF12 to cancel)
    unset $_i(ret.nick.prev)
    .notify $__i(ret.nick)
    if ($__i(s^n)) && ($_log.pass($__i(ret.nick))) {
      if ($show) ale Attempting ghost kill on $__i(ret.nick)
      ns ghost $__i(ret.nick) $_log.pass($__i(ret.nick))
    }
  }
}
_getnick {
  ale Nick $1 has been released. Changing nick...
  if (!$__i(ret.nick.notify)) .notify -r $1
  unset $_i(ret.nick*)
  nick $1
}

;/countcode <file> (from mircscripts.org challenge)
countcode {
  var %i = 1, %code, %line
  while (%i <= $lines($1)) {
    %line = $read($1,n,%i)
    if (%line) %code = $calc(%code + $len(%line))
    inc %i
  }
  echo -a * $1 = %code bytes
}

;
;EOF
-l _load.sets
