;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; raw section
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
;thx to uninvited for these ircx raws
alias -l _knock return $_c(1) $+ Knock ( $+ $_c(3) $+ $nick ( $+ $address $+ ) $1- $+ $_c(1) $+ )
raw knock:*:{
  if ($hget(x_sets,hide.knocks)) halt
  if ($2 == 471) echo -t $1 $_pre $_knock(Channel is full (+l))
  elseif ($2 == 473) echo -t $1 $_pre $_knock(Channel is invite only (+i))
  elseif ($2 == 474) {
    var %banmask = $wildtok($3-,*@*,1,32), %e = $iif(%banmask,%banmask,(+b))
    echo -t $1 $_pre $_knock(User is banned %e $+ )
  }
  elseif ($2 == 475) echo -t $1 $_pre $_knock(Channel requires the correct key (+k))
  else echo -t $1 $_pre $_knock($2-)
  halt
}
raw prop:*:{
  if ($2 != topic) {
    echo -t $1 $_pre $_c(1) $+ Prop ( $+ $_c(3) $+ $nick ( $+ $address $+ ) $upper($left($2,1)) $+ $lower($right($2,-1)) set to:  $+ $3- $+  $+ $_c(1) $+ )
    halt
  }
}
;
raw silence:*:{
  var %m = $right($1,-1), %a = $iif($left($1,1) == +,1), %tb = $+(silence.cid,$cid)
  if (!$istok($__i(silence.notshow),%m,44)) ae (Silence) $iif(%a,Added,Removed) mask %m  $+ $iif(%a,to,from) list
  if (%a) {
    _var %tb $addtok($hget(x_vars,%tb),%m,32)
    if (%m isignore) .ignore -r %m
  }
  else {
    if ($remtok($hget(x_vars,%tb),%m,32)) _var %tb $ifmatch
    else _--unset vars %tb
    var %w = $+(@Silence�list�,$_@network)
    if ($active == $window(%w)) && ($sline($active,1)) {
      dline $active $sline($active,1).ln
      if ($line($active,0) == 2) window -c $active
    }
  }
  halt
}

on ^*:LOGON:*:set -u90 $_i(logging) 1
on *:LOGON:*:{
  unset $_i(logging)
  set -u90 $_i(connecting) 1
}

raw 1:*:{
  set $_i(starttime) $ctime
  if ($wildtok($1-,*!*@*,1,32)) set $_i(myaddress) $ifmatch
  else {
    set -u30 $_i(myaddress.,$me) 1
    .raw USERHOST $me
  }
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.001
  halt
}
raw 2:*:{
  set -u %::text $2-
  set -u %::server $5
  set -u %::value $8
  set -u %:echo echo -s
  theme.text raw.002
  halt
}
raw 3:*:{
  set -u %::text $2-
  set -u %::value $6-
  set -u %:echo echo -s
  theme.text raw.003
  halt
}
raw 4:*:{
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.004
  halt
}
raw 5:*:{
  if (watch= isin $2-) set $_i(watchsys) 1
  if ($wildtok($1-,prefix=*,1,32)) set $_i(prefix) $gettok($ifmatch,2,61)
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.005
  halt
}
raw 221:*:{
  set -u %::nick $1
  set -u %::modes $2-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.221
  halt
}

;lusers
raw 251:*:{
  if ($__i(connecting)) setservices
  linesep -s
  set -u %::users $4
  set -u %::invisible $6
  set -u %::servers $11
  set -u %::text $4-
  set -u %:echo echo -s
  theme.text raw.251
  halt
}
raw 252:*:{
  set -u %::value $2
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.252
  halt
}
raw 253:*:{
  set -u %::value $2
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.253
  halt
}
raw 254:*:{
  set -u %::value $2
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.254
  halt
}
raw 255:*:{
  set -u %::users $4
  set -u %::value $7
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.255
  halt
}
raw 250:*:{
  set -u %::value $2
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.250
  halt
}
raw 265:*:{
  set -u %::users $5
  set -u %::value $7
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.265
  halt
}
raw 266:*:{
  set -u %::users $5
  set -u %::value $7
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.266
  halt
}

;SILENCE stuff
raw 271:*:{
  var %w = $+(@Silence�list�,$_@network)
  if (!$window(%w)) {
    window -klb %w $_gcoord(silence,-1 -1 250 200) @silence
    aline %w $_c(1) $+ Mask
    aline %w $chr(9)
  }
  aline %w $3
  halt
}
raw 272:*:{
  var %w = $+(@Silence�list�,$_@network)
  if ($window(%w)) window -a %w
  else ale No SILENCE entries found
  halt
}


;isaway
raw 301:*:{
  if ($__i(badchan.,$2)) || ($__i(whoislist.,$2)) halt
  if (($2 == $me) || ($query($2))) && (!$hget($+(x_tmp-cid,$cid,-whois,.,$2))) halt

  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    aline $+(@_mts.wi.cid,$cid,.,$2) away $3-
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,301))) halt
    set -u %::nick $2
    set -u %::away $3-
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.301
  }
  else {
    echo $iif(@* iswm $active,-si2,-ai2) $_pre $2 is away: $3-
  }
  halt
}

;userhost
raw 302:*:{
  var %n = $remove($gettok($2,1,61),*), %a = $right($gettok($2,-1,61),-1), %h = %n $+ ! $+ %a
  if ($__i(myaddress.,%n)) {
    if (*!*@* iswm %h) set $_i(myaddress) %h
    else set $_i(myaddress) $+($me,!,$gettok($emailaddr,1,64),@,$gettok($gettok(%h,-1,33),-1,64))
    unset $_i(myaddress.,%n)
  }
  elseif ($__i(ircops.on.join.,%n)) {
    var %chan = $ifmatch
    if (%chan ischan) echo %chan $replace($_echo(ircopjoin),<nick>,%n,<address>,%a,<chan>,%chan)
    unset $_i(ircops.on.join.,%n)
    halt
  }
  elseif ($__i(notify.,%n)) {
    if ($__i(notify.sound)) {
      if ($isfile($notify(%n).sound)) splay.event $notify(%n).sound
      else event.sound notify
      unset $_i(notify.sound)
    }
    var %add = $right($gettok($2,2,61),-1)
    set -u %::nick %n
    set -u %::address %add
    set -u %::text %add
    set -u %:comments $_notify.comments(%n,%add)
    set -u %:echo echo $color(notify) -st
    theme.text notify
    if ($__i(connecting) == $null) && ($notifyactive) && (($activecid != $cid) || ($active != Status Window)) {
      if ($activecid != $cid) set -u %:comments %:comments $_c(4) $+ ( $+ $__i(network) $+ $_c(4) $+ )
      set -u %:echo echo $color(notify) -at
      theme.text notify
    }
    unset $_i(notify.%n)
  }
  else {
    if (!$2-) {
      echo $iif(@* iswm $active,-s,-a) (USERHOST) No such user
    }
    else {
      set -u %::nick %n
      set -u %::address $gettok(%h,-1,33)
      set -u %::value $iif(* isin $gettok($2,1,61),*) $+ $left($gettok($2,-1,61),1)
      set -u %:echo echo $iif(@* iswm $active,-s,-a)
      theme.text raw.302
    }

  }
  halt
}
raw 303:*:halt

;back
raw 305:*:halt

;away
raw 306:*:halt

#extreme.whois on
raw 311:*:{
  if ($__i(last.whois)) _whois.end - $ifmatch
  set -u180 $_i(last.whois) $2

  if ($__i(getidle.,$2)) {
    set $_i(getidle.,$2) $_c(3) $+ $2 $+($_c(1),$chr(40),$_c(3),$3,$_c(1),@,$_c(3),$4,$_c(1),$chr(41),)
    halt
  }
  elseif ($istok($__i(whoislist),$2,44)) {
    set $_i(whoislist.,$2) $2 $+ � $+ $+($3,@,$4)
    halt
  }
  if ($istok($gettok($__i(badchan.list),2,32),$2,44)) {
    set $_i(badchan.,$2) $gettok($__i(badchan.list),1,32)
    set $_i(badchan.list) $gettok($__i(badchan.list),1,32) $remtok($gettok($__i(badchan.list),2,32),$2,1,44)
    halt
  }

  _echo.whois $2 start
  var %w = $+(@_mts.wi.cid,$cid,.,$2)
  window -lh %w
  aline %w nick $2
  aline %w address $+($3,@,$4)
  aline %w realname $6-
  if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,311))) halt
  set -u %::nick $2
  set -u %::ident $3
  set -u %::host $4
  set -u %::address $+($3,@,$4)
  set -u %::userlevel $remove($level($ulist($+($2,!,$3,@,$4))),=)
  set -u %::country $ccode($4)
  set -u %::realname $6-
  set -u %:echo _echo.whois $2

  theme.text raw.311
  halt
}
raw 307:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    aline $+(@_mts.wi.cid,$cid,.,$2) isregd is
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,307))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %::isregd is
    set -u %:echo _echo.whois $2
    theme.text raw.307
  }
  halt
}
raw 308:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,308))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.308
  }
  halt
}
raw 309:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,309))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.309
  }
  halt
}
raw 310:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,310))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.310
  }
  halt
}

;undernet raw, shows username
raw 330:*:{
  set -u %::nick $2
  set -u %::value $3
  set -u %::text $4- $3
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,330))) halt
    set -u %:echo _echo.whois $2
  }
  else set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.330
  halt
}

;undernet raw, shows address/ip
raw 338:*:{
  set -u %::nick $2
  set -u %::address $3
  set -u %::value $4
  set -u %::text $3-
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,338))) halt
    set -u %:echo _echo.whois $2
  }
  else set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.338
  halt
}

;whoisserver, also used by whowas
raw 312:*:{
  var %tbl = $hget($+(x_tmp-cid,$cid,-whois,.,$2))
  if (%tbl) || ($__i(whowas.,$2)) {

    if (%tbl) var %w = $+(@_mts.wi.cid,$cid,.,$2)
    else var %w = $+(@_mts.ww.cid,$cid,.,$2)
    aline %w wserver $3
    aline %w serverinfo $4-
    if ((%tbl) && ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,312)))) || (($__i(whowas.,$2)) && ($hget(x_mts,whowas))) halt

    set -u %:echo $iif(%tbl,_echo.whois $2,_custom.echo Whois)
    set -u %::nick $2
    set -u %::wserver $3
    set -u %::serverinfo $4-

    theme.text raw.312
  }
  elseif ($__i(whoislist.,$2)) set $_i(whoislist.,$2) $_puttok($__i(whoislist.,$2),$3,3,164)
  halt
}

;whowas
raw 314:*:{
  set $_i(whowas.,$2) 1

  var %w = $+(@_mts.ww.cid,$cid,.,$2)
  window -lh %w
  aline %w nick $2
  aline %w address $+($3,@,$4)
  aline %w realname $6-
  if ($hget(x_mts,whowas)) && (!$hget(x_mts,$+(raw.,314))) halt

  set -u %::nick $2
  set -u %::ident $3
  set -u %::host $4
  set -u %::address $+($3,@,$4)
  set -u %::country $ccode($4)
  set -u %::realname $6-
  set -u %::userlevel $remove($level($ulist($+($2,!,$3,@,$4))),=)
  set -u %:echo _custom.echo Whois

  theme.text raw.314
  halt
}
;end of whowas
raw 369:*:{
  if ($__i(whowas.,$2)) {
    unset $_i(whowas.,$2)
    var %w = $+(@_mts.ww.cid,$cid,.,$2)
    if ($window(%w)) {
      var %i = 1
      while ($line(%w,%i)) {
        var %l = $ifmatch, %l1 = $gettok(%l,1,32), %l2 = $gettok(%l,2-,32)
        if (%l2 != $null) set -u $+(%,::,%l1) %l2
        inc %i
      }
      window -c %w
    }
    set -u %::nick $2
    set -u %:echo _custom.echo Whois
    if ($hget(x_mts,whowas)) theme.text WHOWAS
    else theme.text raw.369
  }
  halt
}

raw 313:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    var %w = $+(@_mts.wi.cid,$cid,.,$2)
    aline %w isoper is
    aline %w operline $3-
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,313))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %::isoper is
    set -u %::operline $3-
    set -u %:echo _echo.whois $2
    theme.text raw.313
  }
  halt
}

;idle
raw 317:*:{
  if ($__i(getidle.,$2)) ale $_c(1) $+ Idle time for $__i(getidle.,$2) $+ $_c(1) $+ : $duration($3)
  elseif ($__i(whoislist.,$2)) set $_i(whoislist.,$2) $_puttok($__i(whoislist.,$2),$duration($3),4,164)
  elseif ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    var %w = $+(@_mts.wi.cid,$cid,.,$2)
    aline %w idletime $3
    aline %w signontime $iif($4 isnum,$asctime($4),n/a)
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,317))) halt
    set -u %:echo _echo.whois $2
    set -u %::nick $2
    set -u %::idletime $3
    set -u %::signontime $iif($4 isnum,$asctime($4),n/a)
    set -u %::signontime.ctime $iif($4 isnum,$4,$ctime)
    set -u %::value $iif($4 isnum,$4,$ctime)
    theme.text raw.317
  }
  halt
}
;channels (sorts and sets common channels as bold)
alias -l _chan.list {
  if ($1 == $me) return $2
  var %n = 1, %l = $_comchans($1)
  while (%n <= $numtok($2,32)) {
    var %c = $gettok($2,%n,32), %c2 = $iif($left(%c,1) isin +@.%,$right(%c,-1),%c)
    if ($istok(%l,%c2,44)) var %cl = %cl  $+ %c $+ 
    else var %cl = %cl %c
    inc %n
  }
  return %cl
}
raw 319:*:{
  if ($__i(badchan.,$2)) {
    var %c = $ifmatch
    if ($2 ison %c) && ($_check.badchans($3-,%c)) {
      penalty badchannel $2 %c $_kickmsg(badchannel,$2)
      unset $_i(badchan.,$2)
    }
  }
  elseif ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    set -u %:echo _echo.whois $2
    set -u %::nick $2
    set -u %::chan $_chan.list($2,$sorttok($3-,32))
    aline $+(@_mts.wi.cid,$cid,.,$2) chan %::chan
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,319))) halt
    theme.text raw.319
  }
  elseif ($__i(whoislist.,$2)) set $_i(whoislist.,$2) $_puttok($__i(whoislist.,$2),$3-,5,164)
  halt
}
raw 320:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,320))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.320
  }
  halt
}
raw 335:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,335))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.335
  }
  halt
}
raw 379:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,379))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.379
  }
  halt
}
raw 378:*:{
  if ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    if ($hget(x_mts,whois)) && (!$hget(x_mts,$+(raw.,378))) halt
    set -u %::nick $2
    set -u %::text $3-
    set -u %:echo _echo.whois $2
    theme.text raw.378
  }
  halt
}

;end of whois
raw 318:*:{
  _whois.end $2 $gettok($2,-1,44)
  halt
}

alias -l _whois.end {
  if ($__i(badchan.,$2)) {
    var %c = $ifmatch
    unset $_i(badchan.,$2)
    if (!$__i(badchan.start)) halt
    if ($numeric == 318) _badchan.wi %c
  }
  elseif ($hget($+(x_tmp-cid,$cid,-whois,.,$2))) {
    var %w = $+(@_mts.wi.cid,$cid,.,$2)
    if ($window(%w)) {
      var %i = 1
      while ($line(%w,%i)) {
        var %l = $ifmatch, %l1 = $gettok(%l,1,32), %l2 = $gettok(%l,2-,32)
        if (%l2 != $null) {
          if (%l1 == text) && (%::text != $null) set -u %::text %::text - %l2
          else set -u $+(%,::,%l1) %l2
        }
        inc %i
      }
      window -c %w
    }
    set -u %::nick $2
    set -u %:echo _echo.whois $2
    if (!$hget(x_mts)) && ($hget($+(x_tmp-cid,$cid,-recnicks),$2)) {
      set -u %::recnicks $ifmatch
      theme.text wi.recnicks
    }
    if ($hget(x_mts,whois)) theme.text WHOIS
    else theme.text raw.318
    _echo.whois $2 end
  }
  elseif ($istok($__i(whoislist),$2,44)) {
    var %a = $__i(whoislist.,$2)
    if ($numtok(%a,164) < 5) %a = $_puttok(%a,-,5,164)
    if ($gettok(%a,4,164) == 0) %a = $puttok(%a,-,4,164)
    _addwhoisl $iif(%a,%a,$2 $+ �-�-�-�-)
  }
  unset $_i(whoislist.,$2) $_i(getidle.,$2) $_i(last.whois)
}
#extreme.whois end

#extreme.who on
;who end
raw 315:*:{

  ;IAL update
  if ($__i(ialupd.,$2)) {
    if ($2 !ischan) halt
    unset $_i(ialupd.,$2)
    set -u10 $_i(tmp.noprots.,$2) 1
    if ($__i(ialupd.upd.,$2)) {
      ale $_c(3) $+ IAL updated for $2
      _pwait
      unset $_i(ialupd.upd.,$2)
      halt
    }
    if ($__i(bots.on.,$2)) {

      ;_botperf $ifmatch $2
      unset $_i(botperf.,$2)
    }
    iblupd $2
    _process.ul $2 prot
    halt
  }

  ;Kick away
  if ($__i(kick.away.,$2)) {
    unset if $_i(kick.away.,$2)
    halt
  }

  if ($__i(iptrace.ip)) {
    if ($__i(iptrace.num)) unset $_i(iptrace.*)
    elseif ($__i(iptrace.ip2)) {
      set $_i(iptrace.ip) $__i(iptrace.ip2)
      unset $_i(iptrace.ip2)
      .raw WHO $__i(iptrace.ip)
    }
    else {
      ale Couldn't find offender ( $+ $2 $+ ). User may be invisible (+i).
      unset $_i(iptrace.*)
    }
    halt
  }

  if ($__i(aways.scan.,$2)) && (!$__i(aways.n)) {
    _custom.echo Scans $_pre No aways found
    unset $_i(aways.scan.,$2)
    halt
  }
  if ($__i(ircop.scan.,$2)) && (!$__i(ircop.n)) {
    _custom.echo Scans $_pre No ircops found
    unset $_i(ircop.scan.,$2)
    halt
  }

  var %t = $gettok($__i(who),1,32), %w = $iif(%t,$+(@Who�,%t,�,$_@network),$+(@Who�,$_@network)), %a = $gettok($__i(who),2,32), %nicks = $remtok($gettok($__i(who),3,32),$2,44)

  if ($__i(who.upd.,$2)) {
    var %t = $ifmatch, %w = $+(@Who�,%t,�,$_@network)
    if (!$window(%w)) goto end
  }

  if ($__i(user.count)) {

    if ($window(%w)) {

      if (!$__i(who.upd.,$2)) _sortwin %w 1 9

      if ($__i(ircop.scan.,$2)) var %a = $ifmatch, %title = [ircops]
      elseif (($2 == *) && ($__i(ircop.g))) var %title = [ircops]
      elseif ($__i(aways.scan.,$2)) var %a = $ifmatch, %title = [aways]
      else var %title = scan results

      if (!%nicks) {
        if (%a) echo $iif($2 ischan,$2,-a) $_pre List complete ( $+ $round($calc(($ticks - %a) /1000),2) $+ secs)
        titlebar %w %title (users: $calc($line(%w,0) -4) $+ )
        window -br %w
      }
    }
    else {
      set -u %::value $2
      set -u %:echo _custom.echo $iif($__i(aways.scan.,$2) || $__i(ircop.scan.,$2),Scans,Who)
      theme.text raw.315
    }
  }
  else {
    window -c %w
    if (($2 == *) || ($2 == 0)) && ($__i(ircop.g)) ale No ircops found
    else ale Unable to get /WHO results for $2
  }

  :end
  if (%nicks) set $_i(who) %t %a $ifmatch
  else unset $_i(who)
  unset $_i(user.count) $_i(ircop.*) $_i(aways.*) $_i(who.upd.,$2)
  halt
}
;who replies
raw 352:*:{
  var %th = $+($6,!,$3,@,$4), %tmp = $+($3,@,$4)

  if ($__i(ialupd.,$2)) {
    var %num = $ifmatch
    if ($2 !ischan) halt
    if ($__i(ialupd.upd.,$2)) _pwait %num $nick($2,0) Updating IAL ( $+ %num $+ / $+ $nick($2,0) $+ )
    set $_i(ialupd.,$2) $calc(%num +1)
    _addseen %th on $2
    var %lev = $_getflagsh(%th,$2)
    if (B isincs $gettok(%lev,2,32)) && ($_ischanrec($gettok(%lev,1,32),$2)) set $_i(bots.on.,$2) $addtok($__i(bots.on.,$2),$6,44)
    goto end
  }

  if ($__i(kick.away.,$2)) {
    var %x = $ifmatch
    if (g isin $7) && ($6 != $me) && ($me isop $2) && (!$_exempt.status($6,$2)) && (!$_exempt.ul(%th,$2)) $iif(%x == -b,qkickb,qkick) $2 $6 $_kickmsg(masskickaway,$2)
    halt
  }
  if ($__i(iptrace.ip) == $4) {
    ale Probable offender found: $6 ( $+ %tmp $+ )
    inc $_i(iptrace.num)
    halt
  }
  if ($__i(ircop.scan.,$2)) {
    if (* !isin $7) halt
    if ($6 ison $2) sline -a $2 $6
    inc $_i(ircop.n)
    var %scans = 1
  }
  elseif ($__i(aways.scan.,$2)) {
    if (g !isin $7) halt
    if ($6 ison $2) sline -a $2 $6
    inc $_i(aways.n)
    var %scans = 1
  }
  else var %wholist = 1

  inc $_i(user.count)

  if ((%scans) && ($hget(x_wins,scans) == window)) || ((%wholist) && ($hget(x_wins,who) == window)) {

    var %t = $gettok($__i(who),1,32), %w = $iif(%t,$+(@Who�,%t,�,$_@network),$+(@Who�,$_@network))
    var %line = $6 $chr(9) %tmp $chr(9) $iif(g !isin $7,No,$+($_c(1),Yes,)) $chr(9) $iif(* isin $7,$+($_c(2),Yes,),No) $chr(9) $_userstat($7) $chr(9) $8 $chr(9) $5 $chr(9) $9- $iif(%t ischan,$chr(9) $duration($nick(%t,$6).idle))

    if ($__i(who.upd.,$6)) {
      var %t = $ifmatch, %w = $+(@Who�,%t,�,$_@network)
      if (!$window(%w)) goto end
    }
    if (!$window(%w)) {
      var %bc = $chr(9)
      window -knl -t13,38,45,51,58,60,77,100 +e %w $_gcoord(who,-1 -1 770 400) @who $_@font
      aline %w %bc
      aline %w %bc
      var %lin = $_c(1) $+ Nick $chr(9) $_c(1) $+ Address $chr(9) $_c(1) $+ Away $chr(9) $_c(1) $+ IRCOp $chr(9) $_c(1) $+ Status $chr(9) $_c(1) $+ H $chr(9) $_c(1) $+ Server $chr(9) $_c(1) $+ Realname
      if (%t ischan) var %lin = %lin $chr(9) $_c(1) $+ Idle on %t $+ 
      aline %w %lin
      aline %w %bc
    }
    aline %w %line
  }

  else {
    set -u %::nick $6
    set -u %::address %tmp
    set -u %::cmode $remove($7,*,g,h)
    set -u %::away $iif(h isin $7,H,G)
    set -u %::chan $2
    set -u %::wserver $5
    set -u %::realname $9-
    set -u %::value $8
    set -u %::isoper $iif(* isin $7,is,is not)
    set -u %::text $2-
    set -u %:echo _custom.echo Who
    theme.text raw.352
  }

  :end
  colornick.ial $2 $6 %th $7
  halt
}

alias -l _userstat {
  if (. isin $1) return $_c(4) $+ Owner
  if (@ isin $1) return $_c(4) $+ Op
  if (% isin $1) return $_c(1) $+ HalfOp
  if (+ isin $1) return $_c(1) $+ Voice
  return User
}

#extreme.who end

;/list start
raw 321:*:return
;/list items
raw 322:*:return
;/list end
raw 323:*:halt

;chan modes
raw 324:*:{
  if ($__i(request.chanmode.,$2)) {
    set -u %::chan $2
    set -u %::modes $3-
    set -u %:echo echo $iif($2 ischan,$2,-a)
    theme.text raw.324
    unset $_i(request.chanmode.,$2)
  }
  halt
}

;homepage
raw 328:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif($2 ischan,$2,-a)
  theme.text raw.328
  halt
}
;creation time
raw 329:*:{
  if ($__i(just.kicked.,$2)) || ($__i(just.cycled.,$2)) || (!$hget(x_display,onjoin.showcreate)) halt
  set -u %::chan $2
  set -u %::value $3
  set -u %::text $iif($3 isnum,$asctime($3))
  set -u %:echo echo $2
  theme.text raw.329
  halt
}
;topic
raw 332:*:{
  if ($__i(just.kicked.,$2)) || ($__i(just.cycled.,$2)) halt
  if ($3-) addnewtopic $2 $strip($3-)
  if (($__i(just.joined.,$2)) && ($hget(x_display,onjoin.showtopic))) || (!$__i(just.joined.,$2)) {
    set -u %::chan $2
    set -u %::text $3-
    set -u %:echo echo $color(topic) -i2 $2
    theme.text raw.332
  }
  halt
}
;topic author/date
raw 333:*:{
  if ($__i(just.kicked.,$2)) || ($__i(just.cycled.,$2)) halt
  if (($__i(just.joined.,$2)) && ($hget(x_display,onjoin.showtopic))) || (!$__i(just.joined.,$2)) {
    set -u %::chan $2
    set -u %::nick $3
    set -u %::text $iif($4 isnum,$asctime($4),$4)
    set -u %:echo echo $color(topic) $2
    theme.text raw.333
  }
  halt
}
raw 341:*:{
  set -u %::nick $2
  set -u %::chan $3
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  halt
}
raw 346:*:_raws @Invite $2-
raw 347:*:_raws2 @Invite $2
raw 348:*:_raws @Except $2-
raw 349:*:_raws2 @Except $2

;links
raw 364:*:{
  if ($__i(links2servers.p)) {
    writeini $__i(links2servers.path) servers n $+ $__i(links2servers.n) $iif($__i(links2servers.g),$+($ifmatch,:)) $2- $+ SERVER: $+ $1 $+ : $+ $__i(links2servers.p) $+ GROUP: $+ $__i(links2servers.g)
    inc $_i(links2servers.n)
    inc $_i(links2servers.nr)
    halt
  }
}
;links end
raw 365:*:{
  if ($__i(links2servers.p)) {
    sle Done! $__i(links2servers.nr) server(s) added. Assumed port $__i(links2servers.p) for all, in $iif($__i(links2servers.g),$ifmatch,n/a) group.
    unset $_i(links2servers.*)
    halt
  }
}
;/links2servers (retrieves /links list, and exports it to servers.ini)
alias links2servers {
  if (!$server) return
  if ($network) set $_i(links2servers.g) $network
  else set $_i(links2servers.g) $_input(Group? (cancel for none),e,Links))
  if ($_input(What port should be assumed?,e,Links,6667)) set $_i(links2servers.p) $ifmatch
  else set $_i(links2servers.p) 6667
  if ($input(Ready to retrieve links. $crlf $+ Continue?,yq)) {
    set $_i(links2servers.n) $server(0)
    set $_i(links2servers.path) $readini(mirc.ini,files,servers)
    if ($__i(links2servers.path)) links
    else {
      sr -th Error Couldn't find servers.ini
      unset $_i(links2servers.*)
    }
  }
  else unset $_i(links2servers.*)
}


;names
raw 353:*:{
  if ($__i(names.,$3)) || (($hget(x_display,onjoin.shownames)) && ($__i(just.joined.,$3))) {
    if (!$4-) {
      _custom.echo Names $_pre No "visible" nicks on $3
      unset $_i(names.,$3)
      halt
    }
    elseif (!$__i(just.kicked.,$3)) || (!$__i(just.cycled.,$3)) {
      set -u %::chan $3
      set -u %::text $remove($4-,:)
      if ($__i(just.joined.,$3)) set -u %:echo echo $3
      else set -u %:echo _custom.echo Names
      theme.text raw.353
    }
    set $_i(names.,$3) 2
  }
  halt
}
;names end
raw 366:*:{
  var %just.joined = $__i(just.joined.,$2)
  if ($__i(names.,$2)) || (($hget(x_display,onjoin.shownames)) && (%just.joined)) {
    if ($__i(names.,$2) == 1) {
      _custom.echo Names $_pre No "visible" nicks on $2
      halt
    }
    unset $_i(names.,$2)
    if (!$__i(just.kicked.,$2)) && (!$__i(just.cycled.,$2)) {
      set -u %::chan $2
      if (%just.joined) set -u %:echo echo $2
      ;        else set -u %:echo echo $iif(@* iswm $active,-s,-a)
      else set -u %:echo _custom.echo Names
      theme.text raw.366
    }
  }
  if ($2 ischan) {
    colornicks $2
    if (%just.joined) .signal -n join.end $2
  }
  halt
}

on *:signal:join.end:{
  if (($__i(just.kicked.,$1)) && ($__i(banned.from) != $1)) || ($__i(just.cycled.,$1)) goto next

  if ($_protset(idle,$1)) _chan.idle $1

  if ($__i(banned.from) == $1) {
    unset $_i(banned.from)
    .timer 1 0 _restore.chan.buf $1
  }

  if ($hget(x_display,onjoin.showstats)) echo $1 $chanstats($1)
  if ($hget(x_display,onjoin.showsynch)) echo $1 $_c(1) $+ [ $+ Synched in $calc(($ticks - $__i(synch.time.,$1)) / 1000) secs $+ $_c(1) $+ ]
  linesep $1

  if ($hget(x_perform,on_joinme)) _perfd $ifmatch

  :next
  nickcol $me $1 $_ncread(you)
  if ($nick($1,0) == 1) && ($me isop $1) {
    if ($_net(chan.defmodes)) {
      var %modes = $ifmatch
      .timer 1 $rand(2,5) if ($me isop $1) .raw MODE $1 %modes
    }
    iblupd $1
    if ($hget(x_spambot,status)) && (!$hget(x_spambot,event)) && ($istok($hget(x_spambot,chans),$1,44)) spambot $1
  }
  elseif ($__i(nets-ialupd) == 1) ialupd $1

  ;  if ($__i(bots.on.,$1)) _botperf $ifmatch $1

  unset $_i(just.joined.,$1) $_i(synch.time.,$1) $_i(just.kicked.,$1) $_i(topic,$1) $_i(just.cycled.,$1)
}
alias _perc {
  return $nick($1,0,$2) $_c(1) $+ ( $+ $int($calc(($nick($1,0,$2) / $nick($1,0,a)) * 100)) $+ % $+ $_c(1) $+ )
}
alias chanstats {
  return $replace($_echo(chanstats),<total>,$nick($1,0,a),<perc_owners>,$_perc($1,q),<perc_ops>,$_perc($1,o),<perc_voices>,$_perc($1,v),<perc_regulars>,$_perc($1,r))
}

;bans
raw 367:*:{
  if ($2 !ischan) halt
  if ($__i(iblupd.,$2)) {
    if ($2 ischan) && ($gettok($4,1,33) == $me) _process.tempbans $2 $3
    halt
  }
  elseif ($__i(prot.aunban.,$2)) {
    var %time = $_protset(autounban.olderthan,$2), %own = $_protset(autounban.own,$2), %nick = $gettok($4,1,33)
    if ($5 isnum) && ($calc($ctime - $5) >= %time) && ($me isop $2) && ((%nick == $me) || (!%own)) set $_i(banstoreset.,$2) $addtok($__i(banstoreset.,$2),$3,32)
    halt
  }
  elseif ($__i(aunban.,$2)) {
    var %lb = $ifmatch
    if ($gettok($4,1,33) == $me) || (!$hget(x_sets,auto-unban.own)) set $_i(aunban.list.,$2) $deltok($instok($__i(aunban.list.,$2),$3,1,32),$calc(%lb +1),32)
  }
  elseif ($__i(resetall.,$2)) {
    if ($len($__i(banstoreset.,$2)) > 850) {
      _arbans - $2 $__i(banstoreset.,$2)
      unset $_i(banstoreset.,$2)
    }
    set $_i(banstoreset.,$2) $addtok($__i(banstoreset.,$2),$3,32)
  }
  elseif ($__i(resetmine.,$2)) {
    if ($gettok($4,1,33) == $me) {
      inc $_i(bcountme.,$2)
      set $_i(banstoreset.,$2) $addtok($__i(banstoreset.,$2),$3,32)
    }
  }
  else {
    set -u %::chan $2
    if ($hget(x_wins,bans) == window) _addban $2 $3 $+ $chr(9) $+ $_c(4) $+ $iif($4,$4,-) $+  $+ $chr(9) $+ $iif($5,$validbandur($calc($ctime - $5)) ago,-)
    else {
      if (!$__i(bcount.,$2)) _custom.echo Bans $_pre $_c(1) $+ Listing bans for $2
      _custom.echo Bans $_c(1) $+ $calc($__i(bcount.,$2) +1) $+ . $3 $_c(1) $+ set by $iif($4,$4,-) $_c(1) $+ [ $+ $iif($5,$validbandur($calc($ctime - $5)) ago,-) $+ $_c(1) $+ ]
    }
    if ($3 iswm $__i(myaddress)) || ($3 iswm $puttok($__i(myaddress),$ip,2,64)) set $_i(banned.,$2) $addtok($__i(banned.,$2),$3,32)
  }
  inc $_i(bcount.,$2)
  halt
}
;bans end
raw 368:*:{
  if ($2 !ischan) halt
  if ($__i(iblupd.,$2)) unset $_i(iblupd.,$2)
  elseif ($__i(aunban.list.,$2)) .raw mode $2 - $+ $str(b,$numtok($ifmatch,32)) $__i(aunban.list.,$2))
  elseif ($__i(banstoreset.,$2)) _arbans - $2 $ifmatch
  elseif ($__i(prot.aunban.,$2)) unset $_i(prot.aunban.,$2)
  elseif ($__i(aunban.,$2)) unset $_i(aunban.,$2)
  elseif ($__i(resetmine.,$2)) && (!$__i(bcountme.,$2)) echo $2 $_pre No bans set by you were found for $2
  elseif ($window($+(@Bans�,$2,�,$_@network))) {
    var %w = $+(@Bans�,$2,�,$_@network)
    titlebar %w (total: $calc($line(%w,0) -4) $+ )
    window -rb %w
    if ($me isop $2) && ($__i(banned.,$2)) .timer 1 0 _rem.mybans $2 $ifmatch
  }
  elseif (!$__i(bcount.,$2)) echo $2 $_pre No bans found for $2
  else {
    set -u %::chan $2
    _custom.echo Bans $_c(1) $+ End of list
  }

  unset $_i(reset*.,$2) $_i(banned.,$2) $_i(banstoreset.,$2) $_i(prot.aunban.,$2)) $_i(aunban*.,$2)) $_i(bcount*.,$2) | halt
}

;MOTD
raw 372:*:{
  if ($__i(motd)) {
    var %w = $+(@MOTD�,$server)
    if ($window(%w)) aline %w $iif($2,$2-,$chr(9))
    halt
  }
  if ($skipmotd) && ($__i(connecting)) halt
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.372
  halt
}
raw 375:*:{
  if ($__i(motd)) {
    var %w = $+(@MOTD�,$server)
    if (!$window(%w)) window -nkl %w $_gcoord(motd,-1 -1 350 250) @motd $_@font
    halt
  }
  if ($skipmotd) && ($__i(connecting)) halt
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.375
  halt
}
;motd end
raw 376:*:{
  if ($__i(motd)) {
    unset $_i(motd)
    var %w = $+(@MOTD�,$server)
    if ($window(%w)) window -a %w
    halt
  }
  if ($skipmotd) && ($__i(connecting)) halt
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.376
  halt
}

;RPL_ISASERVICE
raw 377:*:{
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.377
  halt
}

;you're an ircop
raw 381:*:{
  set -u %::text $2-
  set -u %:echo echo -a
  theme.text raw.381
  halt
}
raw 391:*:{
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.391
  halt
}
;no such nick
raw 401:*:{
  if ($__i(whoislist) == $2) {
    .timer 1 1 whoislist $__i(whoislparams) 1
    var %c = $__i(whoislchan), %w = $+(@_whoislist�,%c,�,$_@network)
    window -c %w
    unset $_i(whoisl*)
    halt
  }
  if ($istok($__i(whoislist),$2,44)) { _addwhoisl $2 $+ �-�-�-�- | halt }

  if ($__i(badchan.list) == $2) {
    .timer 1 1 badchan.scan $__i(badchan.params) 1
    var %w = $+(@_badchan�,$__i(badchan.chan),�,$_@network)
    window -c %w
    unset $_i(badchan.*)
    halt
  }
  if ($__i(badchan.,$2)) halt

  if ($_isredir($2)) {
    unset $_i(redir.,$ifmatch)
    ale Not redirecting anymore ( $+ $2 $+ : no such nick)
    halt
  }
  if ($__i(/nick) == $2) && ($__i(lag.tmp)) {
    _lagcheck
    halt
  }
  if ($__i(lastnoticed.,$2)) {
    _ovn.manual $2 $ifmatch
    unset $_i(lastnoticed.,$2)
    halt
  }
  if ($query($2)) .timer 1 0 _closethis $2

  set -u %::nick $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.401

  halt
}

;no such nick/server
raw 402:*:{
  if ($__i(whoislist.,$2)) { _addwhoisl $2 $+ �-�-�-�- | halt }

  if ($query($2)) .timer 1 0 _closethis $2
  set -u %::nick $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.402
  halt
}
;no such channel
raw 403:*:{
  if ($_isredir($2)) {
    unset $_i(redir.,$ifmatch)
    ale Not redirecting anymore ( $+ $2 $+ : no such channel)
  }
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.403
  halt
}
;cannot send to channel
raw 404:*:{
  if ($_isredir($2)) {
    unset $_i(redir.,$ifmatch)
    ale Not redirecting anymore ( $+ $2 $+ : cannot send to channel)
  }
  else {
    set -u %::chan $2
    set -u %::text $3-
    set -u %:echo echo $iif(@* iswm $active,-s,-a)
    theme.text raw.404
  }
  halt
}
raw 405:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.405
  halt
}
raw 406:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.406
  halt
}

;invalid command
raw 421:*:{
  if ($2 == self-lag) _lagcheck
  elseif ($2 == silence) {
    .timersilence.* off
    if ($__i(lastsilence)) {
      var %a = $wildtok($__i(lastsilence),*@*,1,32)
      if (%a isignore) .ignore -r %a
      ignore $__i(lastsilence)
    }
    sr -th Error Looks like your server/network doesn't support the SILENCE command. $iif($__i(lastsilence),Using ignore instead.)
    unset $_i(lastsilence)
    _unset prot silence
  }
  else {
    set -u %::value $upper($2)
    set -u %:echo echo $iif(@* iswm $active,-s,-a)
    theme.text raw.421
  }
  halt
}
raw 429:*:{
  halt
}

raw 432:*:{
  set -u %::nick $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.432
  halt
}

;nick in use
raw 433:*:{
  var %st = $__i(starttime), %ar = $hget(x_sets,auto-retrieve)
  if ($2 == $me) && (%st) {
    ale That nick is yours already
    halt
  }

  set -u %::nick $2
  set -u %::text $3-
  if (%st) && (!%ar) {
    set -u %:comments (Press ShiftF12 to take nick when released)
  }
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.433
  if (%st) {
    %:echo Retrieving /WHOIS info for $2
    wi $2
    set -u30 $_i(ret.nick.prev) $2
    if (%ar) _retnicka
    elseif ($away) .timer 1 10 _retnicka
  }

  if ($__i(connecting)) {
    if ($2 == $anick) {
      .nick $mnick $+ $rand(11,99)
    }
  }
  halt
}
;target change too fast
raw 439:*:{
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.439
  halt
}

;nick is not on chan
raw 441:*:{
  if (!$istok($__i(last.penalties),$2,44)) {
    set -u %::nick $2
    set -u %::chan $3
    set -u %::text $4-
    set -u %:echo echo $3
    theme.text raw.441
  }
  halt
}
;you're not on chan
raw 442:*:{
  if ($__i(just.parted.,$2)) {
    unset $_i(just.parted.,$2)
    halt
  }
  set -u %::nick $me
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo -s
  theme.text raw.442
  halt
}
;user already on chan
raw 443:*:{
  set -u %::nick $2
  set -u %::chan $3-
  set -u %::text $4-
  set -u %:echo echo -s
  theme.text raw.443
  halt
}
;+j chanmode
raw 447:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.447
  halt
}
;chan key already set
raw 467:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.467
  halt
}
;only servers can change
raw 468:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.468
  halt
}

;chan full
raw 471:*:{
  var %timer = $+(retry.,$2,.cid,$cid)
  if (!$timer(%timer)) {
    if ($__i(s^c)) var %.f9 = , or ShiftF9 to use ChanServ invite
    elseif ($__i(network) == undernet) var %.f9 = , or ShiftF9 to use X invite
    set -u %::chan $2
    set -u %:comments (Press CtrlF9 to retry every 5s $+ %.f9 $+ )
    set -u %:echo echo $iif(@* iswm $active,-s,-a)
    theme.text raw.471
    set -u60 $_i(chan.full) $addtok($__i(chan.full),$2,164)
  }
  halt
}
raw 472:*:{
  set -u %::value $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.472
  halt
}

;invite only
raw 473:*:{
  set -u60 $_i(invite.only) $addtok($__i(invite.only),$2,164)
  if ($__i(s^n)) var %i = (Press ShiftF9 to use ChanServ)
  elseif ($__i(network) == undernet) var %i = (Press ShiftF9 to use X)
  set -u %::chan $2
  set -u %:comments %i
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.473
  halt
}

;banned
raw 474:*:{
  set -u60 $_i(banned.from) $2
  if ($__i(s^n)) || ($__i(network) == undernet) {
    if ($__i(just.kicked.,$2)) && ($hget(x_prot,auto-unban)) { f8 | var %t = (Attempting to unban) }
    else var %t = (Press F8 to try to unban)
  }
  set -u %::chan $2
  set -u %:comments %t
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.474
  halt
}

;chan key
raw 475:*:{
  set -u %::chan $2
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.475
  halt
}

raw 477:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.477
  halt
}

;invalid ban/banlist full
raw 478:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.478
  if ($gettok($3,2,64) != *) {
    var %lb = $iif($hget(x_sets,remove.lastbans),$ifmatch,4)
    sr -t Info Banlist for $2 is full. $+ $crlf $+ Removing oldest %lb entries...
    set $_i(aunban.,$2) %lb
    .raw mode $2 +b
  }
  halt
}

raw 482:*:{
  set -u %::chan $2
  set -u %::text $3-
  set -u %:echo echo $iif(@* iswm $active,-s,-a)
  theme.text raw.482
  halt
}
raw 501:*:ale $2- | halt
raw 502:*:ale $2- | halt
raw 554:*:ale [ $+ $2 $+ ] $3- | halt
raw 555:*:ale [ $+ $2 $+ ] $3- | halt
raw 600:*:halt
raw 601:*:halt
raw 602:*:halt
raw 603:*:halt
raw 604:*:{
  set -u30 $_i(notify.time.,$2) $iif($5 isnum,$5,0)
  halt
}

raw 605:*:halt
raw 606:*:halt

; about notify (watch)
raw 607:*:halt
raw 608:*:halt

raw 800:*:halt
raw 801:*:ale [ $+ $2 $+ ] $3- | halt
raw 803:*:ale [ $+ $2 $+ ] $3- | halt
raw 804:*:ale [ $+ $2 $+ ] $3- | halt
raw 805:*:ale [ $+ $2 $+ ] $3- | halt
raw 812:*:return
raw 818:*:ale [ $+ $2 $+ ] $3- | halt
raw 819:*:ale [ $+ $2 $+ ] $3- | halt
raw 900:*:ale [ $+ $2 $+ ] $3- | halt
raw 913:*:ale [ $+ $2 $+ ] $3- | halt
raw 999:*:se (Error) $3- | halt

#extreme.custom.raws on
raw 0:*:se $1- | halt
raw *:*:{
  set -u %::text $2-
  set -u %:echo echo -s
  theme.text raw.other
  halt
}
#extreme.custom.raws end
;
alias -l _raws {
  if (!$window($1)) {
    window -klbh $1 $_gcoord(ban,-1 -1 350 200) $_@font
    titlebar $1 list�for $2
    aline $1 $_c(1) $+  $remove($1,@) Mask
    aline $1 $chr(9)
  }
  aline $1 $3
  halt
}
alias -l _raws2 {
  if ($window($1)) window -a $1
  else echo $2 $_pre No $remove($1,@) $+ s found for $2
  halt
}
alias _closethis {
  if ($query($1)) && ($input(User is not on IRC. $+ $crlf $+ Close query?,yq)) close -m $1
}

;
;EOF
