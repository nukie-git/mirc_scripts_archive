;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; system dialogs
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
;help dialog

alias help {
  sr -t Info 'HELP': This feature is not available at the moment
  return

  if ($1) help $1-
  else _dialog -m help help
}

dialog help {
  title "Help Dialog"
  size -1 -1 316 203
  option dbu
  icon graphics\help.ico, 0
  tab "Topics", 301, 7 6 301 170
  list 19, 14 29 77 140, tab 301
  edit "", 20, 95 28 205 140, tab 301 read multi vsbar
  tab "Commands", 302
  edit "", 23, 14 29 52 10, tab 302
  list 21, 14 43 77 126, tab 302 sort
  edit "", 22, 95 28 205 140, tab 302 read multi
  text "", 123, 29 189 72 10, disable
  icon 24, 10 181 17 17,  $shortfn($mircexe), 0
  button "Close", 250, 264 186 35 12, default ok
}
alias -l _read if ($ini(system\help,$1)) loadbuf -oert $+ $1 help 20 system\help | else did -ra help 20 *** Error in help file
on 1:dialog:help:*:*:{
  if ($devent == init) {
    multi.lang
    did -ra help 123 eXtreme $xtreme.ver
    didtok help 19 46 Intro.�.Channel Protections.Personal Protections.�.Away System.DCC/CTCP.Display.�.Userlist.Misc Lists.Network Settings.�.TCP/IP.Scans.MP3 System.Perform/Events.Utilities.�.Ignore/Silence.Notify/Watch.Import/Export.Addons.Hashtables.�.FKeys.�.�.
    window -lh @_helpc
    loadbuf @_helpc system\helpcoms
    var %h = 1, %t
    while (%h <= $line(@_helpc,0)) {
      %t = $line(@_helpc,%h)
      did -a help 21 $gettok(%t,1,59)
      inc %h
    }
    window -c @_helpc
    did -ra help 20 $str($crlf,3) $+ $str($chr(160),45) $+ No topic selected
    did -ra help 22 $str($crlf,3) $+ $str($chr(160),45) $+ Select a command ( $+ $lines(system\helpcoms) $+ )
  }
  if ($devent == edit) && ($did == 23) { if ($didwm(21,$+($did(23),*))) did -c help 21 $ifmatch | elseif (!$did(23)) did -c help 21 1 }
  if ($devent == sclick) {
    if ($did == 19) {
      if ($did(19).seltext == $chr(160)) {
        did -ra help 20 $str($crlf,3) $+ $str($chr(160),40) $+ No topic selected
        return
      }
      var %l = $gettok($did(19).seltext,1,32)
      _read %l
    }
    if ($did == 21) {
      var %h = $read(system\helpcoms,s,$+($did(21).seltext,;))
      did -ra help 22 $crlf $+ Command: $did(21).seltext $+ $str($crlf,2) $+ Usage: / $+ $gettok(%h,1,59) $+ $str($crlf,2) $+ Description: $crlf $+ $gettok(%h,2,59)
    }
  }
}
;
;=============================================
;input dialog

;$_input(<question>,[icon],[title],[text])
;icons can be hwq, for error, warning and question, or p for password

alias _input {
  if ($1 == $null) return
  set -u %_inp.question $1
  set -u %_inp.icon $2
  set -u %_inp.title $3
  set -u %_inp.text $4
  var %res = $dialog(_input,_input,-4)
  return %res
}
dialog _input {
  title "Input"
  size -1 -1 165 74
  option dbu
  edit "", 1, 9 31 145 12, result autohs
  edit "", 3, 9 31 145 12, hide pass autohs
  text "", 2, 11 16 115 15
  button "Ok", 50, 45 56 35 12, default ok
  button "Cancel", 49, 85 56 35 12, cancel
  icon 4, 136 12 15 15, graphics\v.ico
}
on 1:dialog:_input:*:*:{
  if ($devent == edit) && ($did == 3) did -ra _input 1 $did(3)
  if ($devent == init) {
    multi.lang
    mdx.start
    if (%_inp.question != $null) {
      did -ra _input 2 $ifmatch
      if (%_inp.title != $null) dialog -t _input $eval($ifmatch,2)
      if (p isin %_inp.icon) {
        did -h _input 1
        did -v _input 3
        var %k = 1
      }
      elseif (%_inp.text != $null) did -ra _input 1,3 $ifmatch

      if (h isin %_inp.icon) var %f = error.ico
      elseif (w isin %_inp.icon) var %f = warning.ico
      elseif (q isin %_inp.icon) var %f = question.ico
      else var %f = information.ico

      unset %_inp.*
    }
    if (%f) mdx.set icon %f
    did -f _input $iif(%k,3,1)
  }
}
;
;=============================================
;progress bar
;pwait

alias _pwait {

  :start
  if ($dialog(pwait)) {
    if ($1 != $null) {
      if ($2 == 0) did -h pwait 1
      else did -v pwait 1
      did -a pwait 1 $1 0 $2
      if ($3) && ($3- != $did(pwait,2)) && ($3 != -) did -ra pwait 2 $3-
    }
    else dialog -k pwait
  }
  else {
    _dialog -m pwait pwait
    goto start
  }
}
dialog pwait {
  title "Please wait"
  size -1 -1 120 30
  option dbu
  icon $mircexe, 11
  text "", 2, 6 5 109 7
  text "", 1, 6 15 109 7
  button "", 50, 0 0 0 0, default ok
}
on 1:dialog:pwait:init:0:{
  mdx.start
  multi.lang
  mdx SetControlMDX 1 progressbar smooth > $mdx.gdll
  mdx.set icon
}
;=============================================
;script report dialog

;/sr [-thwq] [title] <message>
alias sr {
  if ($hget(x_sets,no.info.dialog)) { se $1- | return }
  if ($dialog(sr)) dialog -x sr
  if ($1) { set -u %_sr $1- | _dialog -mo sr sr }
}
dialog sr {
  title "Script Report"
  size -1 -1 175 71
  option dbu
  icon 3, 155 18 40 40, graphics\v.ico
  text "", 1, 25 20 125 27, center
  button "Close", 50, 70 53 35 12, default ok
}
on 1:dialog:sr:init:0:{
  mdx.start
  multi.lang
  tokenize 32 %_sr
  .timerclosesr -o 1 $iif($away,10,30) if ($dialog(sr)) dialog -x sr
  if (-* iswm $1) {
    var %sw = $1
    if (t isin %sw) var %title = $2, %text = $3-
    else var %text = $2-
  }
  else var %text = $1-

  if (h isin %sw) var %f = error.ico
  elseif (w isin %sw) var %f = warning.ico
  elseif (q isin %sw) var %f = question.ico
  else var %f = information.ico

  if (%title != $null) dialog -t sr $ifmatch
  if (%text != $null) did -ra sr 1 $ifmatch
  if (%f) mdx.set icon %f
}

;=============================================
;about

alias about var %d = $_dialog(_about,_about,-4)
dialog _about {
  title "About eXtreme"
  size -1 -1 141 134
  option dbu
  text "", 1, 10 19 88 8
  text "", 11, 10 27 88 9
  text "Written by Kall (PTnet)", 2, 10 39 88 8
  text "URL:", 3, 10 87 15 8
  text "Email:", 4, 10 96 15 8
  link "http://www.extreme-script.net/", 7, 28 87 90 8
  link "kall@extreme-script.net", 6, 28 96 90 8
  text "Visit eXtreme website for the latest versions and patches.", 8, 10 67 121 15
  icon 5, 100 17 29 29,  graphics\x2.jpg, 0
  button "&Close", 50, 50 115 35 12, default ok
  edit "", 60, 0 0 0 0, hide
}
on 1:dialog:_about:init:*:did -a _about 1 eXtreme $xtreme.ver | did -a _about 11 for mIRC� v $+ $version $bits $+ bits | did -f _about 60
on 1:dialog:_about:edit:60:_etc $did(60)
on 1:dialog:_about:sclick:*:{
  if ($did == 5) did -g _about 5 graphics\ $+ $iif(x2.jpg isin $did(5),logo1.jpg,x2.jpg)
  elseif ($did == 6) { dialog -x _about | email kall@extreme-script.net About the script ( $+ $xtreme.ver $+ m $+ $version $+ w $+ $os $+ /p $+ $iif($hget(x_status,patch),$ifmatch,-) $+ ) }
  elseif ($did == 7) { dialog -x _about | run $xtreme.url }
  elseif ($mouse.x isnum 210-235) && ($mouse.y isnum 210-235) { dialog -x _about | _l�a� }
  elseif ($mouse.x isnum 70-90) && ($mouse.y isnum 80-90) { dialog -x _about | .timer 1 0 sr That's me, the author :P }
  elseif ($mouse.x isnum 35-95) && ($mouse.y isnum 55-65) { dialog -x _about | run http://www.mirc.co.uk }
  else dialog -x _about
}

alias bugreport {
  email kall@extreme-script.net Bugreport ( $+ $xtreme.ver $+ m $+ $version $+ w $+ $os $+ /p $+ $iif($hget(x_status,patch),$ifmatch,-) $+ )
}
alias bug bugreport

;=============================================
; perform dialog

alias perfd {
  if ($1 != $null) set -u %_perfd $1 $+ � $+ $2 $+ � $+ $3 $+ � $+ $4
  if ($dialog(perfd,perfd,-4)) return $ifmatch
}
dialog perfd {
  title "Perform"
  size -1 -1 252 141
  option dbu
  icon $mircexe, 11
  edit "", 1, 9 23 232 92, multi return autohs
  edit "", 2, 0 0 500 0, result autohs
  box "Use any identifiers. You can also use 'if' statements.", 10, 4 8 243 112
  button "Ok", 50, 87 124 35 12, default ok
  button "Cancel", 49, 127 124 35 12, cancel
}
on 1:dialog:perfd:*:*:{
  if ($devent == init) {
    multi.lang
    if (%_perfd) var %l = $ifmatch
    if ($hget($+(x_,$gettok(%l,1,173)),$gettok(%l,2,173))) didtok perfd 1 124 $ifmatch
    if ($gettok(%l,2,173)) dialog -t perfd Perform - $ifmatch
    if ($gettok(%l,3,173)) did -ra perfd 10 $ifmatch
    if ($gettok(%l,4,173)) didtok perfd 1 1 $ifmatch
  }
  if ($devent == sclick) && ($did == 50) did -ra perfd 2 $replace($didtok(1,124),|,$+($chr(32),|,$chr(32)))
}

alias _perform {
  var %l = $perfd(perform,$+(on_,$1))
  if (%l) { _set perform on_ $+ $1 %l | ale Performing ' $+ $replace(%l,$chr(124),$chr(44)) $+ ' on $1 }
  else { _unset perform on_ $+ $1 | ale No events for $1 }
}
alias _perfd {
  if (!$1-) return
  var %c = $iif($chan,$ifmatch,%::chan), %l = $replace($1-,$+($,chan),%c)
  .alias __perf $eval(%l,2)
  __perf
  .alias __perf
}

;=============================================
; selection dialog

;usage: $_select(title,item1�item2�...)
alias _select {
  if ($numtok($2,164) == 1) return $2
  if ($2) {
    set -u %_temp.sd $1 $+ ; $+ $2-
    if ($dialog(sd,sd,-4)) return $ifmatch
  }
}
dialog sd {
  title "Pick one"
  size -1 -1 185 115
  option dbu
  icon $mircexe, 11
  list 1, 7 10 170 83, sort
  box "", 6, 3 3 179 92
  button "Ok", 10, 76 99 35 12, default ok
  list 2, 7 10 120 83, hide sort
  box "", 7, 3 3 129 92, hide
  button "Ok", 11, 48 99 35 12, hide ok
  edit "", 100, 0 0 0 0, result autohs
}
on 1:dialog:sd:*:* {
  if ($devent == init) {
    multi.lang
    var %l = %_temp.sd, %t = $gettok(%l,1,59), %l = $gettok(%l,2-,59), %id = 1
    dialog -t sd %t
    var %len = $len($gettok(%l,-1,164))
    if (%len < 30) {
      dialog -sb sd $dialog(sd).x $dialog(sd).y 135 115
      did -h sd 1,6,10
      did -v sd 2,7,11
      var %id = 2
    }
    didtok sd %id 164 %l
    did -c sd %id 1
  }
  var %id = $iif($did(1).visible,1,2)
  if (($devent == dclick) && ($did == %id)) || (($devent == sclick) && ($did isnum 10-11)) { did -ra sd 100 $did(%id).seltext | dialog -k sd }
}


;EOF
