;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; events section
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
on *:EXIT:{
  _uptime.record
  if ($timestampfmt) _-set display timestamp $ifmatch
  var %n = $script(0)
  while (%n) {
    var %file = $script(%n)
    if (*.srv iswm %file) .unload -rs " $+ %file $+ "
    if (%n < 25) break
    dec %n
  }
  saveallhash
}
on *:CONNECT:{

  if ($hget(x_ctcps,motfv)) .dll dlls\motfv3.dll motfv Sync
  _set ctcps actual-fv $_fversion

  event.sound connect
  .fsend on
  .enable #extreme.*

  .remove $+(",$logdirspamlog�,$_network,.log")
  if ($hget(x_wins,save.tome.reset)) _remove $+(logs\@*�,$_network,.txt)

  addnewserver $server $port

  .timermask. $+ $cid 0 1 _echo.myaddress

  .signal connect $cid

  if ($hget(x_sets,get.news)) && ($hget(x_vars,get.news)) {
    .timer 1 2 news
    _unset vars get.news
  }

  if ($hget(x_sets,blocked.keep.settings)) {
    set $_i(blockpvt) $ifmatch
    ale Still blocking privates (from previous sessions)
  }

  if ($hget(x_sets,alarm)) {
    var %a = $ifmatch
    if (%a == 1) && (!$timer(alarm1)) .timeralarm1 $+($iif($gettok($time,1,58) == 24,1,$calc($gettok($time,1,58) +1)),:00) 1 0 alarm1 -
    elseif (%a == 2) && (!$timer(alarm2)) .timeralarm2 $find30min 1 0 alarm1
  }

  if ($_net(usermodes)) .raw MODE $me $ifmatch
  if ($_net(chan.ajoin)) .timer 1 5 joinall 1

  _update.aircdll
  lag.on
}

on *:DISCONNECT:{
  event.sound disconnect
  .plisten close
  linesep -s
  if ($__i(starttime)) && ($__i(network)) {
    var %q = $_c(1) $+ (Quit: $__i(quit.msg) $+ $_c(1) $+ ), %t = $duration($calc($ctime - $__i(starttime))), %nl = $iif($__i(numberlines),$ifmatch,0), %nc = $iif($__i(numberchars),$ifmatch,0)
    sle $_c(1) $+ You wrote a total of %nl $_c(1) $+ lines ( $+ $_fcolor(normal) $+ %nc $_c(1) $+ chars), with an average of $iif(%nc,$round($calc(%nc / ($ctime - $__i(starttime))),2),0) $_c(1) $+ chr/s.
    sle $_c(1) $+ Connected for $+ $_c(3) %t %q
    hadd -m x_status total-lines $calc($hget(x_status,total-lines) + %nl)
    hadd -m x_status total-chars $calc($hget(x_status,total-chars) + %nc)
  }
  lagbar.upd disconnected
  _reset
}


on ^*:NOTIFY:{
  haltdef

  set -u %::nick $nick
  set -u %::address $iif($address,$ifmatch,n/a)

  if ($istok($__i(notify.online),$nick,44)) halt
  set $_i(notify.online) $addtok($__i(notify.online),$nick,44)


  ;using login time given by watch raw
  var %time = $__i(notify.time.,$nick)
  unset $_i(notify.time.,$nick)

  ;check if user belongs to this network
  if ($wildtok($notify($nick).note,net:*,1,32)) && (!$istok($gettok($ifmatch,2-,58),$__i(network),44)) halt

  ;retrieve nick routine
  if ($nick == $__i(ret.nick)) || ($nick == $me) halt

  ;detect services
  if ($nick == chanserv) {
    if (!$__i(connecting)) ae $_c(4) $+ Services are back online
    halt
  }

  ;add to seen list
  _addseen $nick notify

  if ($nnotifyonly) {

    ;normal notify, no watch system
    if (!$__i(watchsys)) && (!$hget(x_sets,no.notify.userhost)) {
      set -u30 $_i(notify.,$nick) 1
      set -u30 $_i(notify.sound) 1
      .raw USERHOST $nick
    }

    else {
      if ($isfile($notify($nick).sound)) splay.event $notify($nick).sound
      else event.sound notify
      set -u %:comments $_notify.comments($nick,$address)
      if (%time isnum 1-) {
        %time = $iif($asctime(%time,dd) != $asctime(dd),$asctime(%time,mmm d) at) $asctime(%time,HH:nn:ss)
        set -u %:comments $_c(1) $+ [since %time $+ $_c(1) $+ ] %:comments
      }
      set -u %:echo echo $color(notify) -st
      theme.text notify
      if ($__i(connecting) == $null) && ($notifyactive) && ($ircwin2) && (($activecid != $cid) || ($active != Status Window)) {
        if ($activecid != $cid) set -u %:comments %:comments $_c(4) $+ ( $+ $__i(network) $+ $_c(4) $+ )
        set -u %:echo echo $color(notify) -at
        theme.text notify
      }
    }
  }
  if ($notify($nick).whois) wi $nick
  if ($hget(x_perform,on_notify)) _perfd $ifmatch
}

alias _notify.comments {
  var %note = $notify($1).note, %add = $iif(@ isin $2,$2,$+(@,$2))

  ;remove network, if available
  if ($wildtok(%note,net:*,1,32)) %note = $remtok(%note,$ifmatch,1,32)

  if ($2) && ($wildtok(%note,*!*@*,1,32)) {
    var %mask = $ifmatch, %2 = $strip($+($1,!,%add)), %note = $remtok(%note,%mask,1,32)
    if (%mask iswm %2) var %h = $_c(4) $+ [host confirmed $+ $_c(4) $+ ]
    else var %h = $_c(2) $+ [ $+ host not confirmed $+ $_c(2) $+ ]
  }
  if (%note) set -u %::text %note
  return %h
}

on ^*:UNOTIFY:{
  haltdef

  ;check if user belongs to this network
  if ($wildtok($notify($nick).note,net:*,1,32)) && ($gettok($ifmatch,2-,58) != $__i(network)) halt

  set $_i(notify.online) $remtok($__i(notify.online),$nick,1,44)

  ;check if it's myself
  if ($nick == $me) || ($nick == $__i(/nick)) halt

  ;retrieve nick
  if ($nick == $__i(ret.nick)) { _getnick $nick | halt }

  ;service detection
  if ($nick == chanserv) {
    ae $_c(2) $+ Services DOWN
    halt
  }

  ;add to seen list
  _addseen $nick unotify

  if ($nnotifyonly) $iif($chan(0),.timer 1 0) _echounotifies $cid $nick $iif($address,$ifmatch,n/a)

  if ($hget(x_perform,on_unotify)) _perfd $ifmatch
}

alias _echounotifies {
  if ($__i(nickchange.,$2)) {
    var %nc = $ifmatch
  }
  else event.sound unotify
  unset $_i(nickchange.,$2)
  set -u %::nick $2
  set -u %::address $3
  var %note = $notify($2).note
  if ($wildtok(%note,net:*,1,32)) %note = $remtok(%note,$ifmatch,1,32)
  if ($wildtok(%note,*!*@*,1,32)) %note = $remtok(%note,$ifmatch,1,32)
  if (%note) set -u %::text %note
  set -u %:echo echo $color(notify) -st
  if (%nc) set -u %:comments $_c(1) $+ [changed nick to %nc $+ $_c(1) $+ ]
  theme.text unotify
  if ($notifyactive) && ($ircwin2) && (($activecid != $1) || ($active != Status Window)) {
    if ($activecid != $1) set -u %:comments %:comments $_c(4) $+ ( $+ $__i(network) $+ $_c(4) $+ )
    set -u %:echo echo $color(notify) -at
    theme.text unotify
  }
}

#extreme.dns on
on *:DNS:{
  var %nick, %add = $iif($naddress,$iif($naddress == $raddress,$iaddress,$naddress),$iaddress), %dns = $__i(/dns)

  set -u %::nick $nick
  set -u %::address %add
  set -u %::naddress $naddress
  set -u %::iaddress $iaddress
  set -u %::raddress $raddress

  if (%dns) {
    set -u %:echo echo $iif(@* iswm $active,-s,-a)
    if ($raddress) theme.text dnsresolve 
    else theme.text dnserror
    unset $_i(/dns)
    halt
  }

  if ($server) && ($__i(iptrace.ip)) && (($__i(iptrace.ip) == $iaddress) || ($__i(iptrace.ip) == $naddress)) {
    if ($nick) %nick = $nick
    elseif ($ial($+(*!*@,%add),1).nick) %nick = $ifmatch
    elseif ($ial($+(*!*@,$raddress),1).nick) %nick = $ifmatch
    if (%nick) {
      ale A match for $__i(iptrace.ip) has been found: $_c(1) $+ %nick ( $+ $_c(1) $+ %add $+ )
      ale Common channels: $_comchans(%nick)
      unset $_i(iptrace.*)
    }
    else {
      ale Couldn't find user for $_c(1) $+ $__i(iptrace.ip) $+  in IAL. Trying /WHO command.
      if ($raddress) set $_i(iptrace.ip2) $raddress
      .raw WHO $__i(iptrace.ip)
    }
  }
  halt
}
#extreme.dns end

;"smart" paste delayer
alias -l _inpaste.start {
  var %w = @_inpaste, %delay
  if ($line(%w,0) <= 6) %delay = 0
  elseif ($line(%w,0) isnum 7-12) %delay = 750
  else %delay = 1500
  if ($line(%w,0) > 10) && (!$$input(Paste $line(%w,0) lines to $active $+ ?,yw)) {
    window -c %w
    return
  }
  _inpaste $active 1 %delay
}
alias -l _inpaste {
  var %w = @_inpaste, %text = $line(%w,$2)
  if (%text != $null) _say $1 $ifmatch
  if ($2 == $line(%w,0)) window -c %w
  else .timer -m 1 $3 _inpaste $1 $calc($2 +1) $3
}

#extreme.input on
on *:INPUT:*:{
  if ($comchar iswm $1) && ($ctrlenter == $false) {
    if ($_msbug($1)) { sr -t Micro$oft What do you wanna crash today? :P | halt }
    return
  }

  if ($inpaste) && (($ischat($target)) || ($query($target)) || ($target ischan)) && ($1- != $null) {
    var %w = @_inpaste
    if (!$window(%w)) window -lh %w
    if ($target ischan) && (c isincs $gettok($chan($active).mode,1,32)) %line = $strip($1-,c)
    aline %w $iif($1- != $null,$1-,$chr(1))
    .timer_inpaste 1 0 _inpaste.start
    halt
  }

  if ($1 == $null) halt

  if (@* iswm $target) || (($target == memoserv) && ($__i(s^m))) return
  tokenize 32 $_input.replacer($1-)
  var %line = $1-

  if ($away) && ($cancelawayonkp) back

  if ($server) {
    inc $_i(numberlines)
    set $_i(numberchars) $calc($__i(numberchars) + $len($strip($1-)))
  }
  elseif (!$ischat($target)) halt
  if ($hget(x_sets,disable.input)) return

  if ($ischat($target)) || ($query($target)) {
    if ($lock(chat)) echo $iif(@* iswm $active,-s,-a) $_pre Private chats are locked.
    else say $1-
  }
  elseif ($chan) {
    var %ncchar = $iif($hget(x_sets,nickcompleter.char),$ifmatch,$+($chr(44),:))
    ;    set -n %line $1-
    if ($hget(x_sets,nickcompleter)) && ($right($1,1) isin %ncchar) && ($len($1) > 2) && ($count($1,$right($1,1)) == 1) {
      var %nick = $_nickcomp($left($1,-1)).chan
      if (%nick ison #) %line = $_nickcomp.style(%nick) $+ $_nickcomp.ctrl($right($1,1)) $2-
    }
    say %line
  }
  halt
}
#extreme.input end

on *:CLOSE:@:_savecoords $target
on *:ACTIVE:*:{
  tbar
  var %lag = $remove($__i(lag),s)
  lagbar.upd $iif(%lag isnum,%lag,$iif($server,waiting,disconnected))
}

;on ^*:HOTLINK:*xtreme*:#:{
;  if ($1 == extreme) || ($1 == xtreme) return
;  halt
;}
;on *:HOTLINK:*xtreme:*:{
;  sr -t eXtreme Just close this and get on with your chat :P
;}

;
;EOF
