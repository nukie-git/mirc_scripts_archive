;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; multi-language files
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
alias multi.lang {
  var %file = lang\ $+ $hget(x_sets,language)
  if (!$isfile(%file)) return
  var %w = @_tmp.lan
  window -lh %w
  loadbuf -t $+ $dname %w %file
  var %n = 1
  while ($line(%w,%n)) {
    var %line = $ifmatch, %item = $gettok(%line,1,61), %data = $gettok(%line,2-,61)
    if (%data) {
      if (%item == title) dialog -t $dname %data
      elseif (item.* iswm %item) did -o $dname $gettok(%item,2,46) %data
      else did -ra $dname %item %data
    }
    inc %n
  }
  window -c %w
}

alias _mlang {
  return $eval($1,2)
}

alias _lang {
  var %n = 1, %w2 = @lang2, %list = $r.files
  window -c %w2
  write -c default.lan
  window -lh %w2
  aline %w2 ; To create a language pack, just copy this file to another file (drag-drop), and then edit it.
  aline %w2 ; After you're done, save it with <language>.lan (ex: french.lan).
  aline %w2 ; DON'T change the [names] nor the numbers. Only the words after the =.
  aline %w2 ;
  aline %w2 ; NOTE: You don't have to edit ALL items. You can even delete some lines/dialogs that you don't want to change. That will even make it faster.
  aline %w2 -
  while ($gettok(%list,%n,44)) {
    var %file = system\ $+ $ifmatch, %w = @lang1, %i = 1, %wm1 = dialog * $chr(123) $+ *, %f = 0
    window -lh %w
    loadbuf %w %file
    while (%i <= $line(%w,0)) {
      var %line = $line(%w,%i)
      if (%wm1 iswm %line) {
        var %f = $gettok(%line,2,32)
        if (!$istok(about.sd,%f,46)) aline %w2 [[ $+ %f $+ ]]
        else var %f = 0
      }
      if (%f) {
        if (" isin %line) {
          var %item = $gettok(%line,1-2,34), %in = $gettok(%item,2-,32), %id = $remove($gettok($gettok(%line,3-,34),1,44),$chr(32)), %in2 = $remove(%in,"), %itemname = $gettok(%item,1,32)
          if (%in2) && (%in2 != !) && (%in2 !isnum) {
            if (%itemname == title) aline %w2 title $+ = $+ %in2
            elseif (%itemname == item) && (%id isnum) aline %w2 item. $+ %id $+ = $+ %in2
            elseif (%itemname != menu) && (%id isnum) aline %w2 %id $+ = $+ %in2
            elseif (%id) && (;* !iswm $remove(%item,$chr(32))) aline %w2 %id $+ = $+ %in2
          }
        }
        if (%line == $chr(125)) { %f = 0 | aline %w2 - }
      }
      inc %i
    }
    inc %n
    window -c %w
  }
  savebuf %w2 default.lan
  window -c %w2
}
