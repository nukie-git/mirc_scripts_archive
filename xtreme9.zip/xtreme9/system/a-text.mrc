;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; text rotines (input)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
say {
  var %target = $active

  ;to prevent input calcs
  if ($hget(x_sets,text.calculator)) var %text = $1-
  else set -un %text $1-

  if (%text == $null) return

  if ($__i(encrypt)) var %enc = ( $+ $ifmatch $+ )
  .msg %target $_encode(%text).enc

  if ((%target ischan) || ($query(%target)) || ($chat($remove(%target,=)))) && ($show) {
    set -u %:echo echo $color(own) -qti $+ $iif((%target ischan && $hget(x_display,align.text)),$ifmatch,2) %target
    if (!$prefixownmsgs) %:echo > %text
    else {
      set -u %::me $me
      set -u %::nick %target
      set -u %::chan %target
      set -un %::text %text
      set -u %::target %target
      set -u %:comments %enc
      set -u %::lb $hget(x_display,lb)
      set -u %::rb $hget(x_display,rb)
      if (%target ischan) {
        if (!$hget(x_mts)) set -u %::me $_align($_ns($me,%target))
        else {
          if ($showmodeprefix) set -u %::cmode $left($remove($nick(%target,$me).pnick,$me),1)
          set -u %::cnick $nick(%target,$me).color
        }
        theme.text textchanself
      }
      else theme.text textqueryself
    }
  }
  _redir %target $_display($iif(%target ischan,textchanself,textqueryself))
}

;/_say <target> <text> only to be used by routines, it allows to specify target
_say {
  var %target = $1
  set -un %text $2-

  if (%text == $null) return

  if ($__i(encrypt)) var %enc = ( $+ $ifmatch $+ )
  .msg %target $_encode(%text).enc

  if ((%target ischan) || ($query(%target)) || ($chat($remove(%target,=)))) && ($show) {
    set -u %:echo echo $color(own) -qti $+ $iif(($1 ischan && $hget(x_display,align.text)),$ifmatch,2) %target
    if (!$prefixownmsgs) %:echo > %text
    else {
      set -u %::me $me
      set -u %::nick %target
      set -u %::chan %target
      set -un %::text %text
      set -u %::target %target
      set -u %:comments %enc
      set -u %::lb $hget(x_display,lb)
      set -u %::rb $hget(x_display,rb)
      if (%target ischan) {
        if (!$hget(x_mts)) set -u %::me $_align($_ns($me,%target))
        else {
          if ($showmodeprefix) set -u %::cmode $left($remove($nick(%target,$me).pnick,$me),1)
          set -u %::cnick $nick(%target,$me).color
        }
        theme.text textchanself
      }
      else theme.text textqueryself
    }
  }
  _redir %target $_display($iif(%target ischan,textchanself,textqueryself))
}


m msg $1-
msg {
  if ($2- == $null) || ((!$server) && (!$ischat($1))) return
  .!msg $1-

  if ($show) {
    set -u %::me $me
    set -u %::nick $1
    set -u %::target $1
    set -u %::chan $1
    set -un %::text $2-
    set -u %::lb $hget(x_display,lb)
    set -u %::rb $hget(x_display,rb)

    var %indent = $iif(($1 ischan && $hget(x_display,align.text)),$ifmatch,2)
    if ($active != $1) {
      set -u %:echo echo $color(own) $iif(@* iswm $active,-si,-ai) $+ %indent
      theme.text textmsgself
    }
    if (($query($1)) || ($chat($remove($1,=))) || ($1 ischan)) && ($event != input) {
      set -u %:echo echo $color(own) -ti $+ %indent $1
      if (!$prefixownmsgs) %:echo > $2-
      else {
        if ($1 ischan) {
          if (!$hget(x_mts)) set -u %::me $_align($_ns($me,$1))
          else {
            if ($showmodeprefix) set -u %::cmode $left($remove($nick($1,$me).pnick,$me),1)
            set -u %::cnick $nick($1,$me).color
          }
          theme.text textchanself
        }
        else theme.text textqueryself
      }
    }
  }
}

q query $_nickcomp($1) $2-
query {
  if (!$server) return
  if (-* iswm $1) && ($2) {
    var %s = $1, %n = $2
    set -un %t $3-
  }
  else {
    var %n = $1
    set -un %t $2-
  }
  if (!%n) return
  if ($query(%n)) window -ra %n
  else {
    !query %s %n
    var %file = $shortfn($logdir) $+ $mklogfn(%n)
    if ($hget(x_display,loadbuf.query)) && ($isfile(%file)) loadbuf %n %file
    else echo %n Query with %n $+  $iif($address(%n,5),( $+ $gettok($ifmatch,2,33) $+ )) [[ $+ $_network $+ ]]
    echo %n Common channels: $_comchans(%n).pnick
    linesep %n
  }
  if (%t != $null) {
    .msg %n %t
    set -u %::me $me
    set -u %::nick %n
    set -un %::text %t
    set -u %::target %n
    set -u %:echo echo $color(own) -ti2 %n
    set -u %::lb $hget(x_display,lb)
    set -u %::rb $hget(x_display,rb)
    if (!$prefixownmsgs) %:echo > %::text
    else theme.text textqueryself
  }
}

describe {
  if ($2- == $null) || ((!$server) && (!$ischat($1))) return
  var %target = $1
  set -un %text $2-
  if ($__i(encrypt)) var %enc = ( $+ $ifmatch $+ )
  .!describe %target $_encode(%text).enc

  set -u %::me $me
  set -u %::nick $1 
  set -un %::text $2-
  set -u %::target $1
  set -u %::chan $1
  set -u %:comments %enc
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)
  set -u %:echo echo $color(own) -qti $+ $iif(($1 ischan && $hget(x_display,align.text)),$ifmatch,2) $1
  if ($1 ischan) {
    if (!$hget(x_mts)) set -u %::me $_align($_ns($me,$1))
    else {
      if ($showmodeprefix) set -u %::cmode $left($remove($nick($1,$me).pnick,$me),1)
      set -u %::cnick $nick($1,$me).color
    }
    theme.text actionchanself
  }
  elseif ($query($1)) || ($ischat($1)) theme.text actionqueryself
  else ae -> * $+ $1 $+ * $2-

  _redir $1 $_display($iif($1 ischan,actionchanself,actionqueryself))
}
action {
  if ($1 ischan) $iif($show,describe,.describe) $1-
  else me $1-
}
me if ($ircwin) && ($1-) describe $active $1-

ame {
  ;  if ($network == ptnet) _acommandsd action $1-
  _acommands action $1-
}
amsg {
  if ($network == ptnet) _acommandsd msg $1-
  else _acommands msg $1-
}
anotice {
  if ($network == ptnet) _acommandsd notice $1-
  else _acommands notice $1-
}
_acommands {
  if ($_nochans) || ($2- == $null) return
  if ($1 == action) {
    !.ame $2-
    var %event = actionchanself
  }
  elseif ($1 == msg) {
    !.amsg $2-
    var %event = textchanself
  }
  elseif ($1 == notice) var %event = noticechanself
  if (!$show) return
  set -un %::text $2-
  set -u %::me $me
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)
  var %i = 1
  while ($chan(%i)) {
    var %c = $ifmatch
    if ($1 == notice) .notice %c $2-
    set -u %::target %c
    set -u %::chan %c
    set -u %:echo echo $color(own) -ti $+ $iif($hget(x_display,align.text),$ifmatch,2) %c
    if (!$hget(x_mts)) set -u %::me $_align($_ns($me,%c))
    else {
      if ($showmodeprefix) set -u %::cmode $left($remove($nick(%c,$me).pnick,$me),1)
      set -u %::cnick $nick(%c,$me).color
    }
    if (!$prefixownmsgs) %:echo > %::text
    else theme.text %event
    inc %i
  }
}
;delayed acommands, for some networks (/anotice, /amsg, /ame)
_acommandsd {
  if ($_nochans) || ($2- == $null) return
  if ($2 isnum) {
    var %d = $2
    set -un %t $3-
  }
  else {
    var %d = 1
    set -un %t $2-
  }
  if ($1 == msg) var %com = _say
  elseif ($1 == action) var %com = describe
  elseif ($1 == notice) var %com = notice
  var %x = 1
  while ($chan(%x)) {
    var %c = $ifmatch
    .timer -m 1 $calc($calc(%x -1) * %d) %com %c %t
    inc %x
  }
}

apvt {
  if ($1- == $null) return
  var %i = $query(0)
  set -un %::text $1-
  set -u %::me $me
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)
  while (%i) {
    var %n = $query(%i)
    .msg %n %::text
    if ($show) {
      set -u %::target %n
      set -u %::nick %n
      set -u %:echo echo $color(own) -ti2 %n
      if (!$prefixownmsgs) %:echo > %::text
      else theme.text textqueryself
    }
    dec %i
  }
}


;=================
; notices

;/nw <target> notice window
nw {
  if ($1) var %n = $1
  elseif ($active ischan) || ($query($active)) var %n = $active
  else return
  var %w = $+(@Notice�,%n,�,$_@network)
  if (!$window(%w)) {
    window -ke %w $_gcoord(notice,-1 -1 350 280) @nw
    echo %w *** Whatever you type will be sent as notice to %n $iif($address(%n,1), ( $+ $ifmatch $+ ) )
    linesep %w
  }
}
rawnotice .raw NOTICE $1 : $+ $2-
notice {
  set -un %msg $iif($2 != $null,$2-,$$_input(What notice?,e,Notices))
  set -un %::text %msg
  set -u %::me $me
  set -u %::nick $1
  set -u %::target $1

  if ($_chan.name($1) ischan) {
    var %tn = $_chan.name($1), %flags = $remove($1,%tn)
    set -u10 $_i(lastnoticed.,$1) %msg
    rawnotice $1 %msg
    set -u %::chan %tn
  }
  else {
    var %tn = $1
    rawnotice %tn %msg
    set -u %::nick %tn
    set -u %::target %tn
  }
  set -u %:echo echo $color(own) -qa
  theme.text noticeself

  _redir %tn $_display(noticeself)
}

n {
  if (($left($1,1) isin #&%) && (!$2)) || ((!$1) && (#)) names $iif($1,$1,#)
  elseif ($2 != $null) notice $1-
  else notify $1
}

onotice $iif($show,notice,.notice) @ $+ # $1-
on $iif($show,notice,.notice) @ $+ # $1-
ovnotice $iif($show,notice,.notice) @+ $+ # $1-
ovn $iif($show,notice,.notice) @+ $+ # $1-
_ovn.manual {
  if (!$2-) return
  var %c = $_chan.name($1)
  if (@ isin $1) var %f = o
  :start
  if (%f) {
    var %i = 1
    while ($nick(%c,%i,%f)) {
      var %n = $ifmatch
      if (%n != $me) .notice %n ( $+ $1 $+ ) $2-
      inc %i
    }
  }
  if (+ isin $1) && (%f2 != 1) { var %f = v, %f2 = 1 | goto start }
}

vn $iif($show,notice,.notice) + $+ # $1-
cn $iif($show,notice,.notice) # $1-

cnotice {
  if (# !ischan) || (- !isin $1) return
  if ($nick(#,0,a) == 1) { ale You're alone on # $+ ... | return }

  if ($2) set -un %msg $2-
  else set -un %msg $$_input(What notice?,e,Notices)

  var %1 = $remove($1,-) | :s
  if (a isin %1) var %tm = a, %1 = $remove(%1,a)
  elseif (o isin %1) && (v isin %1) var %mn = @+, %1 = $remove(%1,o,w)
  elseif (o isin %1) var %mn = @, %1 = $remove(%1,o,w)
  elseif (v isin %1) { var %tm = v, %1 = $remove(%1,v) | if (!%mn) var %mn = + }
  elseif (n isin %1) var %tm = r, %mn = nonops:, %1 = $remove(%1,n)

  :n
  var %m = $+($chr(40),%mn,#,$chr(41))
  if ($show) && (!%ov) {
    set -u %:echo echo $color(own) -a
    set -u %::me $me
    set -u %::nick %mn $+ #
    set -u %::chan #
    set -u %::text %msg
    theme.text noticeself
    var %ov = 1
  }
  if (%mn == @+) {
    rawnotice @+ $+ # %msg
    var %1 = $remove(%1,v)
  }
  elseif (@ isin %mn) && (($nick(#,0,o) > 1) || ($me !isop #)) rawnotice @ $+ # %m %msg
  elseif (%tm == a) rawnotice # %msg
  else {
    var %_n = 1
    while ($nick(#,%_n, [ %tm ] )) {
      var %ni = $ifmatch
      if ($len(%l) <= 920) && (%ni != $me) var %l = $addtok(%l,%ni,44)
      inc %_n
    }
    if (%l) mass.stuff %l .raw NOTICE <item> : $+ %m %msg
  }
  set -u10 $_i(lastnoticed.,$+(%mn,#)) %msg
  unset %mn | if (%1) goto s
}

selnotice {
  mass.stuff $1 rawnotice <item> [snicks: $+ # $+ ] $2-
  set -u %::me $me
  set -u %::nick snicks: $+ #
  set -u %::target snicks: $+ #
  set -u %::chan snicks: $+ #
  set -un %::text $2-
  set -u %:echo ae
  theme.text noticeself
}
excnotice {
  var %i = 1
  while (%i <= $nick(#,0)) {
    var %n = $nick(#,%i)
    if (%n != $me) && (!$istok($1,%n,44)) var %l = $addtok(%l,%n,44)
    inc %i
  }
  if (%l) mass.stuff %l rawnotice <item> [except: $+ # $+ ] $2-
  set -u %::me $me
  set -u %::nick except: $+ #
  set -u %::target except: $+ #
  set -u %::chan except: $+ #
  set -un %::text $2-
  set -u %:echo ae
  theme.text noticeself
}
fnotice {
  if ($1 ischan) {
    var %c = $1, %m = $2
    set -un %r $3-
  }
  else {
    var %c = $active, %m = $1
    set -un %r $2-
  }
  var %i = $ialchan(%m,%c,0)
  while (%i) {
    if ($ialchan(%m,%c,%i).nick != $me) var %l = $addtok(%l,$ifmatch,44)
    dec %i
  }
  if (%l) mass.stuff %l rawnotice <item> %r
}

fcommand {
  var %chan = $1, %mask = $wildtok($2-,*@*,1,32), %command = $replace($2-,%mask,<item>), %i = 1
  if ($1 !ischan) return
  while ($ialchan(%mask,%chan,%i)) {
    var %add = $ifmatch, %nick = $ialchan(%mask,%chan,%i).nick
    if (%nick != $me) var %list = $addtok(%list,$ifmatch,44)
    inc %i
  }
  if (%list) mass.stuff %list %command
}

mass.stuff {
  var %i = 1
  while ($gettok($1,%i,44)) {
    var %n = $ifmatch, %l = $addtok(%l,%n,44)
    if ($numtok(%l,44) == $__i(nets-max.events)) {
      _ffq $replace($2-,<item>,%l)
      unset %l
    }
    if ($len(%l) > 920) break
    inc %i
  }
  if (%l) _ffq $replace($2-,<item>,%l)
}

;=================
;encryption stuff

encrypt {
  if ($istok(rot127.rot13.enc,$1,46)) {
    set $_i(encrypt) $1
    sr All text, except chats, is now being encrypted ( $+ $1 $+ )!!!
  }
  elseif ($1 == off) unset $_i(encrypt*)
  echo -qa $_pre Encryption mode is $iif($__i(encrypt),on,off)
}

_validate return $int($calc((($asc($left($1,1)) + $asc($right($1,1))) / $len($2-)) * $len($1)))

;$_encode(text)
_encode {
  var %enc = $__i(encrypt)
  if (%enc) && (!$ischat($active)) {
    if (127 isin %enc) {
      var %text = $_rot($1-,127).enc
      return $chr(185) $+ � $+ $_validate($me,%text) %text
    }
    if (13 isin %enc) {
      var %text = $_rot($1-,13).enc
      return $chr(179) $+ � $+ $_validate($me,%text) %text
    }
    else {
      var %text = $_enc($1-).enc
      return $chr(178) $+ � $+ $_validate($me,%text) $iif($__i(encrypt.key),�) %text
    }
  }
  return $1-
}
_decode {
  if (� !isin $1) return $1-
  tokenize 32 $1-
  var %1 = $left($1,1), %text = $remtok($2-,�,32)
  if (%1 isin ���) && ($gettok($1,2,173) == $_validate($nick,%text)) {
    if (%1 == $chr(178)) return $_enc($2-).dec (enc)
    if (%1 == $chr(179)) return $_rot($2-,13).dec (rot13)
    return $_rot($2-,127).dec (rot127)
  }
  return $1-
}
_setkey {
  if ($1) {
    if ($1 isnum 1-50) {
      set $_i(encrypt.key) -k $+ $calc(160 + $1)
      ale Enc key set to $1
    }
    else ale Invalid key number (1-50)
  }
  else unset $_i(encrypt.key)
}

;$_pwd(word) this is intended to work with a single word (without spaces), use $_enc(string) for strings
_pwd {
  if (-k* iswm $1) && ($right($1,-2) isnum 160-210) var %k = $ifmatch, %tx = $2-
  else var %k = 160, %tx = $1-
  var %l = $len(%tx)
  while (%l) { var %p = %p $+ $chr($calc(%k - $asc($mid(%tx,%l,1)))) | dec %l }
  return %p
}
;$_enc(text) encrypts an whole line of text
_enc {
  var %op = $prop, %string = $1-
  tokenize 32 $1-
  if (%op == dec) && ($1 == �) {
    var %string = $2-, %key = 1
    if (!$__i(encrypt.key)) var %km = (key needed)
  }
  var %nw = $numtok(%string,32), %ek = $iif($__i(encrypt.key),$ifmatch,-k160), %n = 1
  while (%n <= %nw) {
    var %result = %result $_pwd(%ek,$gettok(%string,%n,32))
    inc %n
  }
  if ($prop == dec) return %result %km
  if ($prop == enc) return %result
  return %result
}

;$_rot(text,method) rot encryption, method can be 13 or 127 (you can use others, but it won't be as easy to decode)
_rot {
  var %string = $1, %n = 1, %nw = $numtok(%string,32), %res, %2 = $iif($2 isnum,$2,13)
  while (%n <= %nw) {
    var %word = $strip($gettok(%string,%n,32)), %n2 = 1
    while (%n2 <= $len(%word)) {
      var %l = $mid(%word,%n2,1)
      if (%l isletter) || (%2 == 127) {
        if (%2 == 13) {
          if (%l === $upper(%l)) var %lower = 64, %upper = 90
          else var %lower = 96, %upper = 122
        }
        else var %lower = 0, %upper = 254
        var %l2 = $calc($asc(%l) + %2)
        if (%l2 > %upper) %l = $chr($calc((%l2 - %upper) + %lower))
        else %l = $chr(%l2)
      }
      %res = %res $+ %l
      inc %n2
    }
    %res = %res $+ $chr(1)
    inc %n
  }
  return $replace(%res,$chr(1),$chr(32))
}

;=====================
;chan buffer stuff (on kick)

_save.chan.buf {
  if ($keepchansopen) || ($1 !ischan) return
  var %file = $mkfn($1) $+ .buf
  if (!$isfile($+(tmp\,%file))) {
    savebuf $1 tmp\ $+ %file
    .timerbuf.cid $+ $cid $+ . $+ $1 1 60 _rem.buf %file
  }
}
_restore.chan.buf {
  if ($keepchansopen) || ($1 !ischan) return
  var %file = $mkfn($1) $+ .buf
  .timerbuf.cid $+ $cid $+ . $+ $1 off
  if ($isfile($+(tmp\,%file))) {
    if ($input(Restore $1 buffer?,yq,Buffer)) {
      var %w = @ $+ $_rand6
      window -h %w
      filter -ww $1 %w
      clear $1
      loadbuf $1 tmp\ $+ %file
      echo $1 ...
      var %n = 1
      while (%n <= $line(%w,0)) {
        var %l = $line(%w,%n)
        echo $1 $iif(%l != $null,%l,$linesep)
        inc %n
      }
      window -c %w
    }
    _rem.buf %file
  }
}
_rem.buf if ($isfile($+(tmp\,$1))) .remove tmp\ $+ $1

;---------------------
;kick and dcc history (logs)

kicks kickh
kicklog kickh

dcclog dcch
kickh {
  var %w = @Kick�History, %w2 = @_kh $+ $_rand6, %file = $logdirkicklog.txt, %bc = $chr(160)
  if (!$isfile(%file)) {
    sr -th Error Log file doesn't exist
    return
  }
  window -lh %w2
  loadbuf %w2 " $+ %file $+ "
  window -c %w
  window -lkn -t10 %w $_gcoord(kick,-1 -1 700 400) @loghistory $_@font
  aline %w %bc
  aline %w $_c(1) $+ Date $+ $chr(9) $+ $_c(1) $+ Event
  aline %w %bc
  var %n = 1, %kick.k = 0, %kick.n = 0
  while ($line(%w2,%n)) {
    var %line = $ifmatch
    tokenize 32 %line
    aline %w $asctime($1,dd/mmm/yyyy HH:nn:ss)) $chr(9) $2-
    if (kicked* iswm $2-) inc %kick.k
    else inc %kick.n
    inc %n
  }
  aline %w %bc
  titlebar %w - Stats: You kicked %kick.n times, and been kicked %kick.k times.
  window -c %w2
  window -ab %w
}
dcch {
  var %w = @DCC�History, %w2 = @_dh $+ $_rand6, %file = $logdirdcclog.txt, %bc = $chr(160)
  if (!$isfile(%file)) {
    sr -th Error Log file doesn't exist
    return
  }
  window -lh %w2
  loadbuf %w2 " $+ %file $+ "
  window -c %w
  window -lkn -t4,15,23,28 %w $_gcoord(dcc,-1 -1 700 400) @loghistory $_@font
  aline %w %bc
  aline %w $_c(1) $+ Type $+ $chr(9) $+ $_c(1) $+ Date $+ $chr(9) $+ $_c(1) $+ Nick $+ $chr(9) $+ $_c(1) $+ Size $+ $chr(9) $+ $_c(1) $+ File
  aline %w %bc
  var %n = 1, %dcc.s = 0, %dcc.g = 0, %dcc.sb, %dcc.gb
  while ($line(%w2,%n)) {
    var %line = $ifmatch
    tokenize 9 %line
    if (sent* iswm $1) {
      inc %dcc.sb $4
      inc %dcc.s
    }
    else {
      inc %dcc.gb $4
      inc %dcc.g
    }
    var %date = $asctime($2,dd/mmm/yyyy HH:nn:ss)), %size = $bytes($4,3).suf
    aline %w $1 $+ $chr(9) $+ %date $+ $chr(9) $+ $3 $+ $chr(9) $+ %size $+ $chr(9) $+ $5
    inc %n
  }
  aline %w %bc
  titlebar %w - Stats: %dcc.s sent ( $+ $bytes(%dcc.sb,3).suf $+ ), %dcc.g received ( $+ $bytes(%dcc.gb,3).suf $+ )
  window -c %w2
  window -ab %w
}

;
;EOF
