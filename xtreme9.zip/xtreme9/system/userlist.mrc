;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; userlist dialogs and stuff
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

alias loadallusr {
  var %n = $findfile(config\,*.usr,0,0,_loadusr $1-)
}
alias -l _loadusr {
  var %file = $remove($1-,$mircdir), %net = $remove($gettok(%file,-1,92),.usr), %net = $iif(%net != global,%net,-)
  if (%net != -) _aul UserNetwAdd %net
  _aul UserLoad %net %file
}

alias ignores ul ignores

alias userlist ul $1-
alias ul {
  if ($dialog(userlist)) dialog -v userlist
  else {
    if ($1) {
      if ($1 == ignores) {
        set -u %_ul.ignores 1
        if ($_network) set -u %_ul $ifmatch
      }
      else set -u %_ul $1-
    }
    elseif ($_network) set -u %_ul $ifmatch
    dialog -m userlist userlist
  }
}

dialog userlist {
  title "Users"
  size -1 -1 351 174
  option dbu
  button "Ok", 9, 272 160 32 12, default ok
  button "Cancel", 10, 306 160 32 12, cancel

  tab "Users list", 11, 8 9 335 147
  box "Users", 6, 95 29 240 117, tab 11
  box "Networks", 5, 17 29 74 117, tab 11
  list 1, 26 40 55 90, tab 11 size
  button "Add net", 2, 27 132 25 11, tab 11
  button "Del net", 3, 55 132 25 11, tab 11
  button "Add user", 7, 233 131 30 10, tab 11
  button "Edit user", 14, 264 131 30 10, tab 11
  button "Del user", 8, 295 131 30 10, tab 11
  button "Copy to", 12, 105 131 30 10, tab 11
  ;  button "Ren user", 15, 136 131 30 10, tab 11
  list 4, 102 40 225 90, tab 11 size

  tab "Ignores list", 13
  box "Ignores", 130, 17 29 318 117, tab 13
  list 101, 37 56 225 80, tab 13
  edit "", 105, 37 43 130 10, tab 13 autohs
  check "Private", 111, 271 57 35 8, tab 13
  check "Channel", 112, 271 66 35 8, tab 13
  check "Notice", 113, 271 75 35 8, tab 13
  check "Ctcp", 114, 271 84 35 8, tab 13
  check "Dcc", 117, 271 93 35 8, tab 13
  check "Invite", 115, 271 102 35 8, tab 13
  check "Codes", 116, 271 111 35 8, tab 13
  check "All Networks", 118, 271 123 40 8, tab 13
  button "Add", 140, 171 42 30 11, tab 13
  button "Update", 142, 201 42 30 11, disable tab 13
  button "Remove", 141, 231 42 30 11, disable tab 13
  button "Clear list", 143, 231 131 30 11, tab 13
}

alias -l updig {
  var %it = -
  if ($did(111).state) %it = %it $+ p
  if ($did(112).state) %it = %it $+ c
  if ($did(113).state) %it = %it $+ n
  if ($did(114).state) %it = %it $+ t
  if ($did(115).state) %it = %it $+ i
  if ($did(116).state) %it = %it $+ k
  if ($did(117).state) %it = %it $+ d
  if (%it != -) && ($did(105)) {
    if ($1) && ($gettok($gettok($did(101).seltext,1,9),6,32)) {
      var %mask = $ifmatch
      if (!$ignore(%mask).network) .ignore -rw %mask
      else .ignore -r %mask
    }
    if ($did(118).state) .ignore %it $+ w $did(105)
    else .ignore %it $did(105)
    loadigs
    did -c userlist 101 $did(101).lines
    loadig
  }
}
alias -l loadigs {
  did -r userlist 101,105
  var %i = 1
  while ($ignore(%i)) {
    did -a userlist 101 $ignore(%i) $+ $_tab $+ 0 $replace($remove($ignore(%i).type,rivate,hannel,otice,nvite,cc),ctcp,t,codes,k) $+ $_tab $+ 0 $iif($ignore(%i).network,$ifmatch,All)
    inc %i
  }
  var %i = 1
  while ($var(*.notext.*.*,%i)) {
    var %var = $ifmatch, %chan = $gettok(%var,4,46), %nick = $gettok(%var,5,46), %cid = $remove($gettok(%var,2,46),cid)
    did -a userlist 101 %nick $+ $_tab $+ 0 %chan $+ $_tab $+ 0 $scid(%cid).network
    inc %i
  }
}
alias -l loadig {
  var %mask = $gettok($gettok($did(101).seltext,1,9),6-,32)
  did -e userlist 141
  var %il = $gettok($did(101).seltext,10,32)
  did -u userlist 111,112,113,114,115,116,117,118
  did -ra userlist 105 %mask
  if (*!*@* !iswm %mask) {
    did -b userlist 141,142
    return
  }
  did -e userlist 141,142
  if (p isin %il) did -c userlist 111
  if (c isin %il) did -c userlist 112
  if (n isin %il) did -c userlist 113
  if (t isin %il) did -c userlist 114
  if (i isin %il) did -c userlist 115
  if (k isin %il) did -c userlist 116
  if (d isin %il) did -c userlist 117
  if (%mask) && (!$ignore(%mask).network) did -c userlist 118
}

on 1:dialog:userlist:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    mdx SetControlMDX 4,101 listview grid rowselect flatsb single showsel headerdrag report nosortheader > $mdx.vdll
    did -i $dname 101 1 headerdims 240 100 100
    did -i $dname 101 1 headertext 0 Mask $_tab Type $_tab Network
    did -i $dname 4 1 headerdims 90 80 150 150 140
    did -i $dname 4 1 headertext 0 Handle $_tab Flags $_tab Channels $_tab Comments $_tab Last seen
    loadigs
    did -a userlist 1 Global
    didtok userlist 1 44 $_ul.getnets
    if (%_ul) && ($didwm(1,%_ul)) did -c userlist 1 $ifmatch
    else did -c userlist 1 1
    if (%_ul.ignores) .timer 1 0 did -f userlist 13
    _ul.loadusers $did(1).seltext
  }

  if ($did(1).seltext) var %net = $ifmatch
  else var %net = -
  if (%net == global) %net = -
  var %hand = $gettok($gettok($did(4).seltext,1,9),-1,32)

  if ($devent == dclick) {
    if ($did == 4) && ($did(4).sel) {
      _ul.edituser %net %hand
    }
  }
  if ($devent == sclick) {
    var %mask = $gettok($gettok($did(101).seltext,1,9),6-,32)
    if ($did == 140) updig
    if ($did == 141) {
      if ($did(101).seltext) {
        if (*!*@* !iswm %mask) unset $eval($+(%,�.cid*.notext.,$gettok($gettok($did(101).seltext,2,9),5,32),.,%mask),1)
        elseif ($did(118).state) .ignore -rw %mask
        else .ignore -rw %mask
        did -d userlist 101 $did(101).sel
        did -u userlist 111,112,113,114,115,116,117,118
        did -r userlist 105
      }
    }
    if ($did == 142) updig 1
    if ($did == 143) && ($did(101).lines) {
      .unignore
      loadigs
    }
    if ($did == 101) {
      loadig
    }

    ;add net
    if ($did == 2) {
      var %net = $$_input(Enter network name,eq,Userlist)
      if (!$didwm(1,%net)) {
        did -a userlist 1 %net
        did -c userlist 1 $did(1).lines
        did -r userlist 4
        _aul UserNetwAdd %net
      }
      else sr -th Userlist Network already exists
    }
    ;del net
    if ($did == 3) && ($did(1).sel) && ($did(1).sel != 1) {
      if (!$$input(Are you sure you want to remove ' $+ $did(1).seltext $+ '?,yq,Userlist)) return
      did -d userlist 1 $did(1).sel
      _aul UserNetwDel %net
    }
    if ($did == 1) {
      _ul.loadusers $did(1).seltext
    }
    ;add user
    if ($did == 7) {
      var %hand = $$_input(Enter handle for new user,eq,Userlist)
      if ($_aul(UserIs,%net,%hand)) {
        sr -th Userlist That handle ' $+ %hand $+ ' is already taken
        return
      }
      _aul UserAdd %net %hand
      did -a userlist 4 %hand
      did -c userlist 4 $did(4).lines
      did -ra userlist 6 Users ( $+ $did(1).seltext $+ ): $calc($did(4).lines -1)
      _ul.edituser %net %hand
    }
    ;edit user
    if ($did == 14) && ($did(4).sel) {
      _ul.edituser %net %hand
    }
    ;del user
    if ($did == 8) && ($did(4).sel) {
      if (!$$input(Are you sure you want to remove ' $+ %hand $+ '?,yq)) return
      _aul UserDel %net %hand
      did -d userlist 4 $did(4).sel
      did -ra userlist 6 Users ( $+ $did(1).seltext $+ ): $calc($did(4).lines -1)
    }

    ;rename
    if ($did == 15) && ($did(4).sel) {
      var %nhand = $$_input(Enter new handle for ' $+ %hand $+ ',eq,Userlist)
      if ($_aul(UserIs,%net %nhand)) {
        sr -th Userlist That handle ' $+ %hand $+ ' is already taken
        return
      }
      _aul UserRen %net %hand %nhand
      var %line = $did(4).seltext, %sel = $did(4).sel
      did -o userlist 4 %sel %nhand $+ $chr(9) $+ $gettok(%line,2-,9)
      did -c userlist 4 %sel
    }
    ;copy to
    if ($did == 12) && ($did(4).sel) {
      if ($_aul(UserNetwCount) > 1) var %nnet = $$_input(Enter target network for ' $+ %hand $+ ',eq,Userlist,%net)
      else var %nnet = -
      var %nnet = $iif(%nnet != global,$ifmatch,-)
      if (!$_aul(UserNetwGet,%nnet)) {
        sr -th Userlist Network ' $+ %nnet $+ ' does not exist
        return
      }
      var %nhand = $$_input(Enter target handle for ' $+ %hand $+ ',eq,Userlist,%hand)
      if (%nnet == %net) && ($_aul(UserIs,%net %nhand)) var %f = 1
      _aul UserCopy %net %hand %nnet %nhand +o
      if (%nnet == %net) && (!%f) {
        var %line = $did(4).seltext
        did -a userlist 4 %nhand $+ $chr(9) $+ $gettok(%line,2-,9)
        did -c userlist 4 $did(4).lines
        did -ra userlist 6 Users ( $+ $did(1).seltext $+ ): $calc($did(4).lines -1)
      }
      else _ul.loadusers $did(1).seltext
    }

    ;ok
    if ($did == 9) {
      _aul UserSave - config\global.usr
      var %n = 2
      while ($did(1,%n)) {
        var %l = $ifmatch
        _aul UserSave %l config\ $+ %l $+ .usr
        inc %n
      }
      if ($server) _process.ul.all
    }

  }
}
alias -l _ul.getnets {
  var %n = 2, %total = $_aul(UserNetwCount,-)
  while (%n <= %total) {
    var %net = $_aul(UserNetwGet,%n)
    if (%net) var %list = $addtok(%list,%net,44)
    inc %n
  }
  return %list
}

alias -l _ul.loadusers {
  if ($1 == Global) var %net = -
  else var %net = $1
  var %n = 1, %total = $_aul(UserCount,%net)
  did -r userlist 4
  while (%n <= %total) {
    _ul.loaduser %net %n
    inc %n
  }
  did -ra userlist 6 Users ( $+ $did(userlist,1).seltext $+ ): $calc($did(userlist,4).lines -1)
}
alias -l _ul.loaduser {
  var %net = $1, %n = $2
  var %hand = $_aul(UserGet,%net %n), %i = 1, %total2 = $_aul(UserChrecGet,%net %hand 0)
  while (%i <= %total2) {
    var %chans = $addtok(%chans,$_aul(UserChrecGet,%net %hand %i),44)
    inc %i
  }
  if ($numtok(%chans,44) == 1) var %flags = $_aul(UserFlagsGetd,%net %hand %chans)
  else var %flags = $_aul(UserFlagsGet,%net %hand)
  var %comment = $_aul(UserEntryGet,%net %hand COMMENT)
  if ($_aul(UserEntryGet,%net %hand LASTON) isnum > 0) var %laston = $asctime($ifmatch,HH:nn:ss dd/mmm/yyyy)
  did -a userlist 4 %hand $+ $chr(9) $+ + + $+ %flags $+ $chr(9) $+ $iif(%chans,$ifmatch,All) $+ $chr(9) $+ %comment $+ $chr(9) $+ $iif(%laston,$ifmatch,No info)

}
alias _aul {
  if ($1) var %res = $dll(dlls\aircdll.dll, $1, $2-)
  if (+* iswm %res) return $gettok(%res,2-,32)
}
alias _aul2 {
  if ($1) return $dll(dlls\aircdll.dll, $1, $2-)
}

dialog edituser {
  title "Userlist"
  size -1 -1 227 204
  option dbu
  text "Hostmasks", 33, 6 15 35 8, right
  combo 34, 43 13 116 50, edit drop
  button "Add", 35, 163 13 25 10
  button "Del", 36, 188 13 25 10
  list 8, 19 42 50 60, size
  button "Add", 9, 19 103 25 10
  button "Del", 10, 44 103 25 10
  box "Channels and Flags", 11, 8 30 212 90
  check "+F: Friend", 12, 86 43 60 10
  check "+E: Enemy", 14, 86 53 60 10
  check "+B: Bot", 13, 86 63 60 10
  check "+A: Allow DCC", 15, 86 73 60 10
  check "+b: Banned", 17, 149 43 60 10
  check "+o: Auto-Op", 18, 149 53 60 10
  check "+v: Auto-Voice", 19, 149 63 60 10
  check "+n: No-Op", 20, 149 73 60 10
  check "+e: Exempt", 16, 149 83 60 10
  text "Info", 23, 87 94 30 8
  edit "", 24, 86 102 125 10, autohs
  text "Nick color", 21, 163 129 35 8, right
  icon 22, 201 127 10 10,  graphics\20.bmp, 0
  text "Comments", 25, 6 129 35 8, right
  edit "", 26, 43 128 115 10, autohs
  text "Bot Address", 29, 6 144 35 8, right
  edit "", 30, 43 143 85 10, autohs
  text "Pass", 27, 6 155 35 8, right
  edit "", 28, 43 154 85 10, pass autohs
  text "Extra", 37, 6 171 35 8, right
  combo 40, 43 169 116 50, edit drop
  button "Add", 38, 163 169 25 10
  button "Del", 39, 188 169 25 10
  edit "", 3, 0 0 0 0, hide autohs
  edit "", 4, 0 0 0 0, hide autohs
  edit "", 5, 0 0 0 0, hide autohs
  button "Ok", 31, 78 189 32 12, default ok
  button "Cancel", 32, 112 189 32 12, cancel
}

;/_ul.edituser <net> <handle> [chan]
alias _ul.edituser {
  set -u %_edituser $1-
  var %a = $dialog(edituser,edituser,-4)
}

on 1:dialog:edituser:*:*:{
  if ($devent == init) {
    if (%_edituser) {
      tokenize 32 $ifmatch
      _eu.load $1-
    }
    var %net = $1, %hand = $2
    dialog -t edituser Userlist - Handle: %hand ( $+ $iif(%net == -,Global,%net) $+ )
    did -ra edituser 3 %net
    did -ra edituser 4 %hand
    if ($3) && ($didwm(8,$3)) { did -c edituser 8 $ifmatch | _eu.loadflags %net %hand $3 }
  }

  if ($devent == sclick) {
    var %net = $did(3), %hand = $did(4), %chan = $did(8).seltext, %lastchan = $did(5)

    ;add chan
    if ($did == 9) {
      var %chan = $_chan($$_input(Enter new channel,eq,Userlist))
      if ($didwm(8,%chan)) {
        sr -th Channel is already on list
        return
      }
      _aul UserChrecAdd %net %hand %chan
      did -a edituser 8 %chan
      did -c edituser 8 $did(8).lines
      did -ra edituser 5 %chan
      _eu.loadflags %net %hand %chan
    }
    ;del chan
    if ($did == 10) && ($did(8).sel) && ($did(8).sel != 1) {
      if (!$$input(Are you sure you want to remove ' $+ %chan $+ '?,yq)) return
      _aul UserChrecDel %net %hand %chan
      did -d edituser 8 $did(8).sel
      did -c edituser 8 1
      _eu.loadflags %net %hand
      did -r edituser 5
    }
    if ($did == 8) && ($did(8).sel) {
      _eu.saveflags %net %hand %lastchan
      did -ra edituser 5 %chan
      _eu.loadflags %net %hand %chan
    }
    if ($did == 35) && ($did(34)) {
      if (!$_isnotinlist(edituser,34,$did(34))) || (*!*@* !iswm $did(34)) return
      did -a edituser 34 $did(34)
      did -d edituser 34 0
    }
    if ($did == 36) && ($did(34).sel) {
      did -d edituser 34 $did(34).sel
      did -c edituser 34 1
    }

    if ($did == 38) && ($numtok($did(40),32) > 1) {
      if (!$_isnotinlist(edituser,40,$did(40))) return
      did -a edituser 40 $did(40)
      did -d edituser 40 0
    }
    if ($did == 39) && ($did(40).sel) {
      did -d edituser 40 $did(40).sel
      did -c edituser 40 1
    }

    if ($did == 22) did -g edituser 22 graphics\ $+ $_cf($$scolors) $+ .bmp
    if ($did isnum 12-20) _eu.procflags

    ;ok, save
    if ($did == 31) {
      _eu.saveflags %net %hand $iif($did(8).seltext != all,$ifmatch)
      _eu.delsets %net %hand
      var %n = 1
      while ($did(34,%n)) {
        var %line = $ifmatch
        _aul UserEntrySetW %net %hand HOSTS %line
        inc %n
      }
      if ($did(34).lines == 0) _aul UserEntrySetW %net %hand HOSTS %hand $+ !*@*
      var %n = 1
      while ($did(40,%n)) {
        var %line = $ifmatch
        _aul UserEntrySetW %net %hand XTRA %line
        inc %n
      }
      var %ncol = $remove($gettok($did(22),-1,92),.bmp)
      if (%ncol isnum 0-15) _aul UserEntrySetW %net %hand XTRA Nickcolor %ncol
      _aul UserEntrySet %net %hand COMMENT $did(26)
      _aul UserEntrySet %net %hand PASS $did(28)
      _aul UserEntrySet %net %hand BOTADDR $did(30)
      if ($dialog(userlist)) {
        var %sel = $did(userlist,4).sel
        _ul.loadusers $did(userlist,1).seltext
        did -c userlist 4 %sel
      }
    }
    if ($did == 32) {
      if ($_aul(UserFlagsGet,%net %hand $_aul(UserChrecGet,%net %hand 1)) == $null) _aul UserDel %net %hand
      if ($dialog(userlist)) {
        _ul.loadusers $did(userlist,1).seltext
      }
    }
  }
}

alias _eu.load {
  var %net = $1, %hand = $2
  var %n = 1, %total = $iif($_aul(UserEntryGet,%net %hand HOSTS 0) isnum,$ifmatch,0)
  while (%n <= %total) {
    did -a edituser 34 $_aul(UserEntryGet,%net %hand HOSTS %n)
    inc %n
  }
  did -c edituser 34 1

  var %n = 1, %total = $iif($_aul(UserEntryGet,%net %hand XTRA 0) isnum,$ifmatch,0)
  while (%n <= %total) {
    var %line = $_aul(UserEntryGet,%net %hand XTRA %n)
    if (nickcolor * !iswm %line) did -a edituser 40 %line
    inc %n
  }
  did -c edituser 40 1

  if ($_aul(UserEntryGetW,%net %hand XTRA nickcolor) isnum) {
    var %col = $ifmatch
    did -g edituser 22 graphics\ $+ $_cf(%col) $+ .bmp
  }
  if ($_aul(UserEntryGet,%net %hand COMMENT)) did -ra edituser 26 $ifmatch
  if ($_aul(UserEntryGet,%net %hand PASS)) did -ra edituser 28 $ifmatch
  if ($_aul(UserEntryGet,%net %hand BOTADDR)) did -ra edituser 30 $ifmatch
  var %n = 1, %total = $iif($_aul(UserChrecGet,%net %hand 0) isnum,$ifmatch,0)
  while (%n <= %total) {
    var %chan = $_aul(UserChrecGet,%net %hand %n), %chans = $addtok(%chans,%chan,44)
    inc %n
  }
  did -r edituser 8
  didtok edituser 8 44 All, $+ %chans
  did -c edituser 8 1
  did -f edituser 31
  _eu.loadflags %net %hand $did(edituser,8).seltext
}

alias -l _eu.delsets {
  ;resets data fields
  var %net = $1, %hand = $2
  var %n = 1, %total = $iif($_aul(UserEntryGet,%net %hand HOSTS 0) isnum,$ifmatch,0)
  while (%n <= %total) {
    _aul UserEntryDelW %net %hand HOSTS $_aul(UserEntryGet,%net %hand HOSTS %n)
    inc %n
  }
  var %n = 1, %total = $iif($_aul(UserEntryGet,%net %hand XTRA 0) isnum,$ifmatch,0)
  while (%n <= %total) {
    _aul UserEntryDelW %net %hand XTRA $gettok($_aul(UserEntryGet,%net %hand XTRA %n),1,32)
    inc %n
  }
}

alias -l _eu.loadflags {
  var %net = $1, %hand = $2, %chan = $iif($3 != all,$3)
  did -r edituser 24
  did -u edituser 16,17,18,19,20
  var %flags = $_aul(UserFlagsGet,%net %hand %chan)
  if (%chan) {
    if ($_aul(UserGetChanInfo,%net %hand %chan)) did -a edituser 24 $ifmatch
    did -b edituser 12,13,14,15
  }
  else {
    if ($_aul(UserEntryGet,%net %hand INFO)) did -a edituser 24 $ifmatch
    did -e edituser 12,13,14,15
  }

  if (!%chan) {
    if (F isincs %flags) did -c edituser 12
    if (B isincs %flags) did -c edituser 13
    if (E isincs %flags) did -c edituser 14
    if (A isincs %flags) did -c edituser 15
  }
  if (e isincs %flags) did -c edituser 16
  if (b isincs %flags) did -c edituser 17
  if (o isincs %flags) did -c edituser 18
  if (v isincs %flags) did -c edituser 19
  if (n isincs %flags) did -c edituser 20
  _eu.procflags
}
alias -l _eu.procflags {
  if ($did(8).seltext == all) did -e edituser 12,13,14,15,16,17,18,19,20
  else {
    did -e edituser 16,17,18,19,20
    did -b edituser 12,13,14,15
  }
  if ($did(13).state) {
    did -bc edituser 15,16
    did -bu edituser 12,14,17,20
    return
  }
  if ($did(12).state) {
    did -bc edituser 15,16
    did -bu edituser 13,14,17,20
    return
  }
  if ($did(14).state) {
    did -bc edituser 17
    did -bu edituser 12,13,15,16,18,19,20
    return
  }
  if ($did(17).state) {
    did -bu edituser 16,18,19,20
  }
  if ($did(18).state) {
    did -bu edituser 17,19,20
  }
  if ($did(19).state) {
    did -bu edituser 17,18
  }
  if ($did(20).state) {
    did -bu edituser 18
  }
  if ($did(16).state) {
    did -bu edituser 17
  }
}
alias -l _eu.saveflags {
  var %net = $1, %hand = $2, %chan = $iif($3 != all,$ifmatch), %flags
  if (!%chan) {
    if ($did(12).state) %flags = F
    if ($did(13).state) %flags = %flags $+ B
    if ($did(14).state) %flags = %flags $+ E
    if ($did(15).state) && ($did(15).enabled) %flags = %flags $+ A
  }
  if ($did(16).state) && ($did(16).enabled) %flags = %flags $+ e
  if ($did(17).state) && ($did(17).enabled) %flags = %flags $+ b
  if ($did(18).state) && ($did(18).enabled) %flags = %flags $+ o
  if ($did(19).state) && ($did(19).enabled) %flags = %flags $+ v
  if ($did(20).state) && ($did(20).enabled) %flags = %flags $+ n
  var %info = $did(24)
  if (%chan) {
    _aul UserSetChanInfo %net %hand %chan %info
  }
  else _aul UserEntrySet %net %hand INFO %info
  _aul UserFlagsSet %net %hand $+(+,%flags) %chan
}

;-----------------------------

;$_getuser(fulladdress,chan) returns net, handle and flags for chan (or global)
alias _getuser {
  if ($_aul(UserHost2Flags,$__i(network),$1 $2) != $null) return $_network $ifmatch
  if ($_aul(UserHost2Flags,-,$1 $2)) return - $ifmatch
}

;$_getflagsh(fulladdress,chan) returns handle and flags for chan (or global)
alias _getflagsh {
  if ($_aul(UserHost2Flags,$__i(network),$1 $2) != $null) return $ifmatch
  return $_aul(UserHost2Flags,-,$1 $2)
}

;$_getflagshd(fulladdress,chan) returns handle and flags for chan (or global)
alias _getflagshd {
  if ($_aul(UserHost2FlagsD,$__i(network),$1 $2) != $null) return $ifmatch
  return $_aul(UserHost2FlagsD,-,$1 $2)
}

;$_getflags(fulladdress,chan) returns flags for chan
alias _getflags {
  if ($_aul(UserHost2Flags,$__i(network),$1 $2) != $null) return $gettok($ifmatch,2,32)
  return $gettok($_aul(UserHost2Flags,-,$1 $2),2,32)
}

;$_getflagsd(fulladdress,chan) returns flags for chan AND global
alias _getflagsd {
  if ($_aul(UserHost2FlagsD,$__i(network),$1 $2) != $null) return $gettok($ifmatch,2,32)
  return $gettok($_aul(UserHost2FlagsD,-,$1 $2),2,32)
}

;$_ischanrec(handle,chan)
alias _ischanrec {
  var %net = $__i(network)
  if ($_aul(UserIs,%net,$1)) && ($_aul(UserChrecIs,%net,$1 $2)) return 1
  return $_aul(UserChrecIs,-,$1 $2)
}

;$_ul(nick) using this in popups
alias _ul {
  if ($1 == $me) return Yourself
  var %add = %_add, %flags = %_flags
  if (B isincs %flags) return Bot ( $+ %flags $+ )
  if (F isincs %flags) return Friend ( $+ %flags $+ )
  if (E isincs %flags) return Enemy ( $+ %flags $+ )
  if (%flags) return %_hand ( $+ %flags $+ )
  return None
}
alias _tmpuserlist {
  var %nick = $1, %add = $iif($address(%nick,5),$ifmatch,$+(%nick,!*@*)), %f = $_getflagshd(%add,#)
  if (!%f) || ($snick(#,0) > 1) || ($snick(#,1) == $me) return
  var %hand = $gettok(%f,1,32), %flags = $gettok(%f,2,32)
  set -u1 %_nick %nick
  set -u1 %_add %add
  set -u1 %_hand %hand
  set -u1 %_flags + $+ %flags
}
alias _isuser {
  var %add = $address($1,5), %hand = $_getflagsh(%add,#)
  if (%hand) return $true
  return $false
}
;$_isflag(fulladdress,flag) returns <flags> if <flag> is in them
alias _isflag {
  var %add = $1, %flags = $_getflagsd(%add,#)
  if ($2 isincs %flags) return %flags
}

alias _process.ul.all {
  var %n = 1
  while ($chan(%n)) {
    var %c = $ifmatch
    if ($me isop %c) _process.ul %c
    inc %n
  }
}
alias _process.ul {
  if ($1 !ischan) || ($me !isop $1) return
  var %t = $nick($1,0), %network = $__i(network)
  _chan.idle $1
  if ($2 == prot) && (!$_prot.disable($1)) var %prot = 1
  while (%t) {
    var %nick = $nick($1,%t)
    if (%nick != $me) _process.ul.nick $1 %nick %network %prot
    dec %t
  }
}

;/_process.ul.nick <chan> <nick> <network> [prot]
alias _process.ul.nick {
  var %nick = $2, %add = $address(%nick,5), %net = $3

  if ($_aul(UserHost2Flags,%net %add $1)) var %lev = $ifmatch
  else var %lev = $_aul(UserHost2Flags,- %add $1), %net = -

  if (!%lev) return
  var %hand = $gettok(%lev,1,32), %flagsd = $_aul(UserFlagsGetd,%net %hand)

  if ($_aul(UserChrecIs,%net %hand $1)) var %flags = $_aul(UserFlagsGet,%net %hand $1), %info = $_aul(UserGetChanInfo,%net %hand $1)
  else var %info = $_aul(UserEntryGet,%net %hand INFO), %flags = %flagsd

  var %color = $_aul(UserEntryGetW,%net %hand XTRA Nickcolor)
  if (%color isnum 0-15) _cline %color %nick

  if (E isincs %flagsd) {
    set -u %::reason %info
    qkickb $1 %nick $_kickmsg(blacklist)
    return
  }

  if (b isincs %flags) {
    set -u %::reason %info
    qkickb $1 %nick $_kickmsg(banned,$1)
    return
  }
  elseif (o isincs %flags) && (%nick !isop $1) .raw mode $1 +o %nick
  elseif (v isincs %flags) && (%nick !isvoice $1) && (%nick !isop $1) .raw mode $1 +v %nick
  elseif (n isincs %flags) && (%nick isop $1) .raw mode $1 -o %nick
  elseif ($me isowner $1) && (q isincs %flags) && (%nick !isowner $1) .raw mode $1 +q %nick

  ;enforce protections
  elseif ($4) && (!$_exempt.status(%nick,$1)) && (e !isincs %flags) {
    if ($_protset(badhostmask,$1)) {
      if ($hget(x_prot,only.badnick)) {
        if ($_check.badhostmask(%nick)) set -u %_badhost $ifmatch
      }
      elseif ($_check.badhostmask($replace($remove($gettok(%add,1,64),~),!,$chr(32)))) set -u %_badhost $ifmatch
      if (%_badhost) penalty badhostmask %nick $1 $_kickmsg(badhostmask,$1)
    }
    elseif (guest* iswm %nick) && ($remove(%nick,guest) isnum) && ($_protset(guests,$1)) penalty guests %nick $1 $_kickmsg(guests,$1)
  }
}

;/_auser <nick/handle> <flags> <chan> <info>
alias _auser {
  var %hand = $1, %flags = $2, %chan = $iif(($3 != $null && $3 != -),$_chan($3)), %info = $4-, %net = $iif($__i(network),$ifmatch,-)
  if (!$_aul(UserNetwGet,%net)) _aul UserNetwAdd %net
  if (!$_aul(UserIs,%net %hand)) _aul UserAdd %net %hand
  if (%chan) && (!$_aul(UserChrecIs,%net %hand %chan)) _aul UserChrecAdd %net %hand %chan
  if (+ isin %flags) || (- isin %flags) var %oflags = $_aul(UserFlagsGet,%net %hand %chan), %flags = $_upd.flags(%oflags,%flags)
  _aul UserFlagsSet %net %hand $+(+,%flags) %chan
  if (%info) {
    if (%chan) _aul UserSetChanInfo %net %hand %chan %info
    else _aul UserEntrySet %net %hand INFO %info
  }
  if ($address(%hand,6)) var %add = $gettok($ifmatch,1,64) $+ @*
  elseif (@ isin %hand) var %add = %hand
  elseif (.*.*. iswm %hand) var %add = *!*@ $+ %hand
  else var %add = %hand $+ !*@*
  _aul UserEntrySetW %net %hand HOSTS %add
}
alias -l _upd.flags {
  var %of = $remove($1,+,-), %nf = $2, %+ = 1, %n = 1
  while (%n <= $len(%nf)) {
    var %l = $mid(%nf,%n,1)
    if (%l == +) var %+ = 1, %- = 0
    elseif (%l == -) var %- = 1, %+ = 0
    else {
      if (%+) && (%l !isincs %of) %of = %of $+ %l
      elseif (%-) %of = $removecs(%of,%l)
    }
    inc %n
  }
  return %of
}

on *!:JOIN:#:{
  var %net = $__i(network)


  if ($_aul(UserHost2Flags,%net $fulladdress #)) var %lev = $ifmatch
  else var %lev = $_aul(UserHost2Flags,- $fulladdress #), %net = -

  if (!%lev) return
  var %hand = $gettok(%lev,1,32), %flagsd = $_aul(UserFlagsGetd,%net %hand)

  if ($_aul(UserChrecIs,%net %hand #)) var %flags = $_aul(UserFlagsGet,%net %hand #), %info = $_aul(UserGetChanInfo,%net %hand #)
  else var %info = $_aul(UserEntryGet,%net %hand INFO), %flags = %flagsd

  var %warn = $_aul(UserEntryGetW,%net %hand XTRA JOINWARN)
  var %color = $_aul(UserEntryGetW,%net %hand XTRA Nickcolor)
  if (%color isnum 0-15) _cline %color $nick

  if (B isincs %flagsd) set $_i(bots.on.,#) $addtok($__i(bots.on.,#),$nick,44)
  if (%warn) || ((F isincs %flagsd) && ($hget(x_display,show.warnfriendjoin))) {
    $iif($active != #,ale,sle) $replace($_echo(joinwarn),<nick>,$nick,<address>,$address,<chan>,#,<text>,%warn)
    event.sound joinwarn
  }

  if ($me !isop #) return

  if (E isincs %flagsd) {
    set -u %::reason %info
    qkickb # $nick $_kickmsg(blacklist,#)
  }

  if (b isincs %flags) {
    set -u %::reason %info
    qkickb # $nick $_kickmsg(banned,#)
    return
  }
  elseif (o isincs %flags) .pop $rand(2,7) # $nick
  elseif ($me isowner #) && (q isincs %flags) .raw mode # +q $nick
  elseif (v isincs %flags) .pvoice $rand(2,7) # $nick
}

alias shit blacklist $1-
alias unshit unblack $1-
alias blacklist {
  if (!$1) return
  _auser $1 E
  if ($server) _process.ul.all
  if ($show) ale Added  $+ $1 to blacklist (enemy level).
}
alias unblack {
  var %m = $iif(@ isin $1,$1,$address($1,5))
  var %f = $_getuser(%m), %net = $gettok(%f,1,32), %hand = $gettok(%f,2,32), %flags = $gettok(%f,3,32)
  if (%hand) && (E isincs %flags) {
    _aul UserDel %net %hand
    ale Removed $1 from blacklist.
  }
  elseif ($show) ale User/mask not found, or not blacklisted
}

alias ulevel {
  if ($isid) return
  var %a = $address($1,5), %flags = $_getflags(%a,#)
  if (!%a) {
    ale Cannot retrieve user flags for $1
    return
  }
  ale User flags for $1 $_c(1) $+ ( $+ $gettok(%a,2-,33) $+ $_c(1) $+ ): $iif($1 == $me,Yourself,+ $+ $u%flags)
}

;$_islev(level,fulladdress) check if level is in userlevel
alias _islev {
  if ($istok($remove($level($ulist($2)),=),$1,44)) return $1
}


;$_botpass(botnick) returns pass on bot
alias _botpass {
  if ($_aul(UserIs,$__i(network) $1)) var %net = $__i(network), %hand = $1
  elseif ($_aul(UserIs,- $1)) var %net = -, %hand = $1
  if (!%hand) || (B !isincs $_aul(UserFlagsGet,%net %hand)) return
  if ($_aul(UserEntryGet,%net %hand PASS)) return $ifmatch
  return $_input(Enter your password on ' $+ $1 $+ ',pq,Bot)
}

;$_findbot(chan) returns the first bot it finds on channel, if any
alias _findbot {
  unset %�._findbot
  var %n = 1
  while ($gettok($__i(bots.on.,$1),%n,44)) {
    var %bn = $ifmatch
    ;    if (%bn isop $1) && ($_botpass(%bn)) {
    if (%bn isop $1) {
      set -u1 %�._findbot %bn
      return %bn
    }
    inc %n
  }
}


;-------------------------------

on *:TEXT:*:#:{
  var %utc = $iif($hget(x_sets,userlist.text.char),$ifmatch,.), %1 = $remove($1,%utc)
  if ($left($1,1) != %utc) || (!$islev+(10,$fulladdress,1)) || ($istok(access.invite.pingme.help.voiceme.opme.kick.kb.ownerme,%1,46) == $false) || ($__i(comms.,$nick)) return
  set -u10 $_i(comms.,$nick) 1
  if ($target == $me) {
    if ($_chan($2) ischan) { var %ch = $2 | if ($4) var %m = ( $+ $4- $+ ) }
    elseif ($comchan($nick,1)) { var %ch = $ifmatch | if ($3) var %m = ( $+ $3- $+ ) }
    else { rawnotice $nick (eXtreme) No channel in common. | return }
  }
  else { var %ch = # | if ($3) var %m = ( $+ $3- $+ ) }
  if ((%1 == pingme) && ($_check(%ch,0,$fulladdress))) {
    set -120 $_i(pingme.,$nick) $calc($ticks / 1000)
    .ctcp $nick ping
    set -u15 $_i(comms.,$nick) 1
    var %o = 1
  }
  if ((%1 == access) && ($_check(%ch,1,$fulladdress))) { rawnotice $nick (eXtreme) Your level for %ch is $getlevel($level($ulist($fulladdress))) | var %o = 1 }
  if ((%1 == help) && ($_check(%ch,1,$fulladdress))) {
    var %ll = $getlevel($level($ulist($fulladdress)))
    rawnotice $nick (eXtreme) You have level %ll $+ , these are the commands: %utc $+ pingme, %utc $+ invite, %utc $+ access, %utc $+ help, %utc $+ voiceme $+ $iif((%ll == 13 || %ll == 15),$t($+(%utc,kick))) $+ $iif((%ll == 13 || %ll == 15),$t($+(%utc,kb))) $+ $iif(%ll >= 14,$t($+(%utc,opme))) $+ $iif((%ll == 15 && $ircx),$t($+(%utc,ownerme)))
    var %o = 1
  }
  if ($me !isop %ch) goto end
  if ((%1 == invite) && ($_check(%ch,0,$fulladdress)) && ($target == $me)) { if (i !isin $channel(%ch).mode) rawnotice $nick (eXtreme) That channel isn't "invite only" :P | else .raw INVITE $nick %ch | var %o = 1 }
  if ((%1 == kick) && ($_check(%ch,2,$fulladdress)) && ($2)) {
    var %tn = $iif($2 ischan,$3,$2)
    if (%tn !ison %ch) rawnotice $nick (eXtreme) %tn is not on %ch
    elseif (%tn == $me) || ($islev(10,$address(%tn,5))) qkick %ch $nick very funny
    elseif (%tn == $nick) qkick %ch %tn requested by yourself %m
    else qkick %ch %tn requested by $nick %m
    var %o = 1
  }
  if ((%1 == kb) && ($_check(%ch,2,$fulladdress)) && ($2)) {
    var %tn = $iif($2 ischan,$3,$2)
    if (%tn !ison %ch) rawnotice $nick (eXtreme) %tn is not on %ch
    elseif (%tn == $me) || ($islev(10,$address(%tn,5))) qkick %ch $nick very funny
    elseif (%tn == $nick) qkickb %ch %tn requested by yourself %m
    else qkickb %ch %tn requested by $nick %m
    var %o = 1
  }
  if ((%1 == voiceme) && ($_check(%ch,1,$fulladdress))) { if ($nick isvoice %ch) rawnotice $nick (eXtreme) You already have voice on %ch | else .raw mode %ch +v $nick | var %o = 1 }
  if ((%1 == opme) && ($_check(%ch,3,$fulladdress))) { if ($nick isop %ch) rawnotice $nick (eXtreme) You already have ops on %ch | else .raw mode %ch +o $nick | var %o = 1 }
  if ((%1 == ownerme) && ($_check(%ch,4,$fulladdress)) && ($me isowner %ch)) { if ($nick isowner %ch) rawnotice $nick (eXtreme) You're already an owner on %ch | else .raw mode %ch +q $nick | var %o = 1 }
  :end
  if (%o) echo $target $_c(1) $+ * Accepted $nick $+ 's $1 request
}
alias -l getlevel {
  var %1 = $remove($1,=)
  if ($istok(%1,15,44)) return 15
  if ($istok(%1,14,44)) return 14
  if ($istok(%1,13,44)) return 13
  if ($istok(%1,12,44)) return 12
  return none
}
alias -l t return , $1
alias -l _check {
  if ($istok($+($ulist($3).info),$1,44) == $false) && ($left($ulist($3).info,1) isin #%&) return
  if (($2 == 0) && (($islev+(11,$3,1)) || ($islev(10,$3)))) return $ifmatch
  elseif (($2 == 1) && ($islev+(12,$3,1))) return $ifmatch
  elseif (($2 == 2) && (($islev(13,$3,1)) || ($islev(15,$3,1)))) return 1
  elseif (($2 == 3) && ($islev+(14,$3))) return 1
  elseif (($2 == 4) && ($islev(15,$3))) return 1
}
alias islev+ {
  var %tlev = $remove($level($ulist($2)),=), %h = $numtok(%tlev,44)
  while (%h) {
    var %b = $gettok(%tlev,%h,44)
    if (%b isnum) && (%b >= $1) {
      if (($3) && (%b <= 15)) || (!$3) return %b
    }
    dec %h
  }
}


;=============================================
;ignore routines

alias unig unignore $1-
alias unignore {
  if ($1) {
    if ($ignore($1).network) .ignore -r $1
    else .ignore -rw $1
    if ($show) ale Removing ignore from $1
    return
  }
  if ($input(Remove all ignores? (all networks),yw)) {
    .ignore -rw
    unset $eval($+(%,�.cid*.notext.*),1)
    if ($show) ale All ignores have been removed.
  }
}
alias ignore { 
  if ($isid) return
  if (!$1) {
    ignores
    return
  }
  if ($1 == on) || ($1 == off) { .ignore $1 | ale Ignore is now $upper($1) | return }
  if (!$show) goto end
  if (-*r !iswm $1) && (@ !isin $1-2) && (!$istok($1-,*,32)) var %mask = $hget(x_pprot,pflood.ignore_mask)

  if (-* !iswm $1) {
    if ($address($1,$iif($2 isnum,$2,$hget(x_pprot,pflood.ignore_mask)))) var %add = ( $+ $ifmatch $+ )
    if ($2 isnum) ale Ignoring all from %add
    elseif (@ isin $1) ale Ignoring all from $1
    else ale Ignoring all from $1 %add
  }
  else { 
    if ($1 == -l) {
      .ignore -l
      return
    }
    if ($1 == -r) && (!$2) ale Ignore list has been cleared.
    elseif (-*r* iswm $1) { if ($2 isignore) ale Removed $2 from ignore list. | else ale No such ignore }
    else {
      var %igt, %vic, %it = $gettok($1,2,117)
      if (p isin $1) %igt = private
      if (c isin $1) %igt = $addtok(%igt,channel,44)
      if (n isin $1) %igt = $addtok(%igt,notice,44)
      if (t isin $1) %igt = $addtok(%igt,ctcp,44)
      if (i isin $1) %igt = $addtok(%igt,invite,44)
      if (k isin $1) %igt = $addtok(%igt,codes,44)
      if (d isin $1) %igt = $addtok(%igt,dcc,44)
      if (!%igt) %igt = everything
      if (w isin $1) var %net = All networks
      else var %net = $_network
      if (*@* iswm $2) %vic = $replace($2,localhost,*)
      elseif ($3 isnum) %vic = $address($2,$3)
      else %vic = $address($2,$hget(x_pprot,pflood.ignore_mask))
      if ($2 == *) %vic = everyone
      ale Added %vic to ignore list ( $+ %igt $+ ) $iif(u isin $1,for %it $+ secs) ( $+ %net $+ )
    }
  }
  :end
  .ignore $1- $iif(%mask isnum 0-20,%l)
  var %it = $gettok($1,2,117)
  if ((%it > 10) || (%it !isnum)) && (-*r* !iswm $1) .timer 1 0 _checkownignore
}


alias silence {
  if ($2) var %o = $1, %m = $left($2,1), %h = $iif($left($2,1) isin +-,$right($2,-1),$2)
  else var %m = $left($1,1), %h = $remove($1,+,-)
  if (%h) && (@ !isin %h) {
    if ($address(%h,$hget(x_pprot,pflood.ignore_mask))) %h = $ifmatch
    else %h = %h $+ !*@*
  }
  if ($_issilence(%h)) && (%m != -) return
  if (!$show) set -u10 $_i(silence.notshow) $addtok($__i(silence.notshow),%h,44)
  if (!%o) || (!$1) .raw SILENCE $iif(%h,$iif(%m isin +-,%m,+)) $+ %h
  else {
    if (-* iswm %o) var %t = $remove($1,-,u,n,t,p,c,k,i,d)
    if (%t isnum) .timersilence. $+ $rand(100,999) 1 %t ._unsilence %h
    .raw SILENCE + $+ %h
    set -u10 $_i(lastsilence) $1-
    .ignore -u10 %h
  }
}

alias _unsilence {
  if ($_issilence($1)) {
    set -u5 $_i(silence.notshow) $addtok($__i(silence.notshow),$1,44)
    .raw SILENCE - $+ $1
  }
}
alias _issilence {
  var %n = 1, %l = $hget(x_vars,$+(silence.cid,$cid))
  while ($gettok(%l,%n,32)) {
    var %i = $ifmatch
    if (%i iswm $1) || (%i == $1) return %n
    inc %n
  }
}

;/_checkownignore checks if your address is on ignore list
alias _checkownignore {
  var %i = $ignore(0), %h = $__i(myaddress)
  while (%i) {
    var %g = $ignore(%i)
    if (%g iswm %h) && (%g != *!*@*) {
      if ($away) || ($1 == reset) .timer 1 $rand(10,15) ignore -r %g
      elseif (!$input(This ignore mask includes you $+ $crlf %g $crlf $+ Keep it anyway?,yw)) ignore -r %g
    }
    dec %i
  }
}

;===================
;qignore

alias qi qignore $1-
alias qignore {
  if ($1) && (!$dialog(qignore)) {
    set -u %_qi.string $iif($2,$1,-pnti) 
    if ($address($iif($2,$2,$1),5)) set -u %_qi.string %_qi.string $ifmatch
    else set -u %_qi.string %_qi.string $iif($2,$2,$1) 
    _dialog -m qignore qignore
  }
}
dialog qignore {
  title "Ignore user"
  size -1 -1 165 90
  option dbu
  combo 1, 36 12 120 95, edit drop
  text "Mask", 2, 7 14 25 8, right
  radio "Permanent", 3, 27 48 45 7
  radio "Temporary", 4, 27 39 45 7
  radio "Clear on disconnect", 5, 27 30 70 7
  edit "30", 6, 73 38 20 10, disable autohs
  text "seconds", 7, 95 40 30 7
  check "Notify user that he/she's being ignored", 8, 20 61 130 7
  box "", 10, 5 3 155 69
  edit "", 20, 0 0 0 0, autohs
  edit "", 21, 0 0 0 0, autohs
  button "Ok", 250, 53 75 30 12, default ok
  button "Cancel", 249, 85 75 30 12, cancel
}
on 1:dialog:qignore:*:*:{
  if ($devent == init) {
    multi.lang
    if ($hget(x_sets,ignore.warnem)) did -c qignore 8
    if (%_qi.string) {
      did -ra qignore 20 $gettok(%_qi.string,1,32)
      did -ra qignore 21 $gettok(%_qi.string,2,32)
      unset %_qi.string
    }
    if (@ isin $did(21)) {
      var %i = 0
      did -a $dname 1 $gettok($did(21),1,33) $+ !*@*
      while (%i <= 9) {
        did -a $dname 1 $mask($did(21),%i)
        inc %i
      }
      did -a $dname 1 $_mask($did(21),20)
      did -c $dname 1 $iif($hget(x_pprot,pflood.ignore_mask) == 20,12,$calc($hget(x_pprot,pflood.ignore_mask) +2))
    }
    else {
      did -a $dname 1 $did(21) $+ !*@*
      did -c $dname 1 1
    }
    if ($hget(x_sets,ignore.time)) did -ra $dname 6 $ifmatch
    did -c $dname 5
  }
  if ($devent == sclick) {
    if ($did == 3) || ($did == 5) did -b $dname 6
    if ($did == 4) did -e $dname 6
    if ($did == 250) {
      if ($did(8).state) {
        var %n = $gettok($did(21),1,33)
        _set sets ignore.warnem 1
        if (%n) rawnotice %n $_echo(ignored)
      }
      else _unset sets ignore.warnem
      if ($did(5).state) set $_i(clearthis) $addtok($__i(clearthis),$did(1),32)
      ignore $iif($did(4).state,$+($did(20),u,$did(6)),$did(20)) $did(1)
      if ($did(6) isnum 1-3600) _set sets ignore.time $did(6)
      if ($query($active)) && (p isin $did(20)) .timer 1 2 close -m $active
    }
  }
}

;
;EOF
