;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; games (trivia and scramble)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
; trivia game

alias triv {
  if (%�.triv.chan ischan) {
    sr -th Error You're already playing Trivia on %�.triv.chan
    return
  }
  unset %�.triv*
  elseif ($server) {
    set %�.trivia Trivia
    sr Trivia is active (channel menu)
  }
}
alias trivia {
  if (!$1) { sr Usage: /trivia <#channel> | return }
  if (%�.triv.chan) && (%�.triv.chan != $1) {
    sr You're already playing Trivia on %�.triv.chan
    return
  }
  var %f1 = $iif($hget(x_trivia,file-q),$+(",$ifmatch,"),system\triv-q.txt), %f2 = $iif($hget(x_trivia,file-a),$+(",$ifmatch,"),system\triv-a.txt)
  if ($isfile(%f1) == $false) || ($isfile(%f2) == $false) { sr File error | return }
  set %�.triv.chan $1
  if ($hget(x_trivia,n)) && (!%�.triv.num) set %�.triv.num $hget(x_trivia,n)
  if (%�.triv.num == 5) triv.msg -Trivia- Only 5 questions left...
  if (%�.triv.num == 0) { sr -t Trivia This session is over | triv.score -end | return }
  if ($numtok(%�.triv.lns,44) == $lines(%f1)) {
    sr -th Error Ran out of questions. $+ $crlf $+ Game over
    triv.score -end
    return
  }
  if ($len(%�.triv.lns) > 940) unset %�.triv.lns
  :a
  var %ln = $rand(1,$lines(%f1))
  if ($istok(%�.triv.lns,%ln,44)) goto a
  set %�.triv.lns $qtok(%�.triv.lns,%ln,250,44)
  var %q = $read(%f1,%ln), %a = $read(%f2,%ln)
  set %�.triv.q $gettok(%q,2-,32)
  set %�.triv.a $gettok(%a,2-,32)
  if (%�.triv.num isnum) set %�.triv.num $calc(%�.triv.num -1)
  triv.msg [Question]: %�.triv.q
  .timertriv 1 $iif($hget(x_trivia,time),$hget(x_trivia,time),90) triv.giveup
}
alias -l _mtriv if (%�.trivia) && ((%�.triv.chan == #) || (!%�.triv.chan)) return Trivia
alias -l triv.msg if ($1 ischan) || (%�.triv.chan) { var %c = $iif($1 ischan,$1,%�.triv.chan), %m = $iif($1 ischan,$2-,$1-) | _say %c %m }
alias -l triv.hint {
  if ($1 == -c) triv.msg [Hint]: $$input(Hint?,ei)
  elseif ($1 == w) {
    inc %�.triv.w
    if (%�.triv.w < $numtok(%�.triv.a,32)) var %l = 1- $+ %�.triv.w, %r = $gettok(%�.triv.a,%l,32)
    else triv.giveup
  }
  else {
    inc %�.triv.h $iif($1 isnum,$1)
    if (%�.triv.h < $len(%�.triv.a)) var %r = $left(%�.triv.a,%�.triv.h)
    else triv.giveup
  }
  if (%r) triv.msg [Hint]: The answer starts with %r
}
alias -l triv.giveup {
  triv.msg -Trivia- The answer was %�.triv.a $+ !! No winner.
  unset %�.triv.?
  .timertriv off
  .timerscrt 1 10 trivia %�.triv.chan
}
alias -l triv.reset .timerscrt off | .timertriv off
alias -l _triv.eof {
  triv.msg -Trivia- Game Over
  unset %�.triv*
  triv.reset
}
alias triv.score {
  var %nick = $iif($1 != -end,$1)
  if ($__v(triv.ign.,%nick)) return
  if (%�.triv.score) && (%nick) { .msg %nick Wait a few more seconds... | set -u10 $_v(triv.ign.,%nick) 1 | return }
  if (!%�.triv.pont.lst) { $iif(%nick,.msg %nick,sr) No scores yet | return }
  window -hl @triv 10 10 200 450 | $iif(%nick,.msg %nick,triv.msg) - Scores -
  var %i = $numtok(%�.triv.pont.lst,32), %delay = 0
  while (%i) {
    aline @triv $__v(triv.pont.,$gettok(%�.triv.pont.lst,%i,32)) $gettok(%�.triv.pont.lst,%i,32)
    dec %i
  }
  while ($line(@triv,0)) {
    var %i = $line(@triv,0), %max = 0
    while (%i) { if ($gettok($line(@triv,%i),1,32) > %max) { var %max = $gettok($line(@triv,%i),1,32), %maxline = %i } | dec %i }
    if (%maxline) {
      .timer -m 1 $calc(%delay * 700) $iif(%nick,.msg %nick,triv.msg) [ $+ $gettok($line(@triv,%maxline),2,32) $+ ]: $gettok($line(@triv,%maxline),1,32) points
      dline @triv %maxline
      inc %delay
    }
  }
  window -c @triv
  if ($1 == -end) .timer -m 1 $calc(%delay * 710) _triv.eof
}
on *:PART:$__i(triv.chan):if ($nick == $me) triv.reset
on *:TEXT:*:%�.triv.chan:{
  if ($1- == %�.triv.a) {
    triv.msg Congratulations, $nick $+ , you got the right answer ( $+ %�.triv.a $+ )
    inc $_v(triv.pont.,$nick)
    triv.msg [ $+ $nick $+ ]: $__v(triv.pont.,$nick) points
    set %�.triv.pont.lst $addtok(%�.triv.pont.lst,$nick,32)
    unset %�.triv.?
    .timertriv off
    .timerscrt 1 10 trivia %�.triv.chan
  }
  elseif ($1- == !score) { if ($__v(triv.pont.,$nick)) var %m = [Score for $nick $+ ] $ifmatch | else var %m = [No score for $nick $+ ] | .msg $nick %m | set -u15 %�.triv.score 1 }
  elseif ($1- == !scores) { triv.score $nick | set -u30 %�.triv.score 1 }
}

;=============================================
; scramble game

alias scramb {
  if (%�.scramb.chan ischan) {
    sr -th Error You're already playing Scramble on %�.scramb.chan
    return
  }
  if (%�.scramble) unset %�.scramb*
  elseif ($server) {
    set %�.scramble Scramble
    sr Scramble is active (channel menu)
  }
}
alias scramble {
  if ($1 != w) && ($1 != f) goto err
  if ($1 == w) { if ($2) && ($3) { set %�.scramb.chan $2 | set %�.scramble.word $3- | set %�.scramble.hint $$_input(Enter hint,e,Scramble) | unset %�.scramb.type } | else goto err }
  if ($1 == f) {
    if ($2) {
      inc %�.scramb.ln
      set %�.scramb.type 1
      set %�.scramb.chan $2
      var %l = $read($scriptdirscramble.txt,%�.scramb.ln)
      if (%l) { set %�.scramble.word $gettok(%l,1,59)
        set %�.scramble.hint $gettok(%l,2,59)
      }
      else {
        sr End of file or file error
        halt
      }
    }
    else goto err
  }
  if (%�.scramb.chan != $2) { sr You're already playing Scramble on %�.scramb.chan | halt }
  var %i = 1 | while ($gettok(%�.scramble.word,%i,32)) { var %s = %s $_scramb($ifmatch) | inc %i } | set %�.scramble.w %s
  scramb.msg [Word]: %s
  scramb.msg [Hint]: $iif(%�.scramble.hint,%�.scramble.hint,<none>)
  if (%�.scramb.type) .timerscramb 1 90 scramb.giveup | return
  :err | sr Usage: /scramble <w/f> <#channel> <word>
}
alias -l _mscramble if (%�.scramble) && ((%�.scramb.chan == #) || (!%�.scramb.chan)) return Scramble
alias -l _scramb {
  var %i = 1, %total = $len($1)
  while (%i <= %total) { var %w = $instok(%w,$mid($1,%i,1),$calc($numtok(%w,165) +1),165) | inc %i }
  while (%total) { var %rand = $rand(1,%total), %word = %word $+ $gettok(%w,%rand,165), %w = $deltok(%w,%rand,165) | dec %total }
  return %word
}
alias -l scramb.msg if ($1 ischan) || (%�.scramb.chan) { var %c = $iif($1 ischan,$1,%�.scramb.chan), %m = $iif($1 ischan,$2-,$1-) | _say %c %m }
alias -l scramb.hint {
  if ($1 == -c) scramb.msg [Hint]: $$_input(Hint?,e,Scramble)
  else {
    inc %�.scramble.h $iif($1 isnum,$1)
    if (%�.scramble.h < $len(%�.scramble.word)) scramb.msg [Hint]: The word starts with $left(%�.scramble.word,%�.scramble.h)
    else scramb.giveup
  }
}
alias -l scramb.giveup scramb.msg -Scramble- The word was %�.scramble.word $+ !! No winner. | unset %�.scramble.* | if (%�.scramb.type) { .timerscramb off | .timerscr 1 5 scramble f %�.scramb.chan }
alias -l scramb.reset .timerscr off | .timerscramb off
alias -l scramb.new var %tnw $_input(Theme?,e,Scramble) | scramb.msg # -Scramble- Next word in about 10secs ( $+ $iif(%tnw,%tnw,-) $+ ) | scramble w # $$_input(Word?,e,Scramble)
alias -l scramb.score { 
  if ($__i(scramb.ign.,$1)) return
  if (%�.scramb.!score) && ($1) { .msg $1 Wait a few more seconds... | set -u10 $_i(scramb.ign.,$1) 1 | return }
  if (!%�.scramb.pont.lst) { $iif($1,.msg $1,sr) No scores yet | return }
  window -hl @scramb 10 10 200 450
  $iif($1,.msg $1,scramb.msg) - Scores -
  var %i = $numtok(%�.scramb.pont.lst,32), %delay = 0
  while (%i) { aline @scramb %�.scramb.pont. [ $+ [ $gettok(%�.scramb.pont.lst,%i,32) ] ] $gettok(%�.scramb.pont.lst,%i,32) | dec %i }
  while ($line(@scramb,0)) {
    var %i = $line(@scramb,0), %max = 0
    while (%i) {
      if ($gettok($line(@scramb,%i),1,32) > %max) { var %max = $gettok($line(@scramb,%i),1,32), %maxline = %i }
      dec %i
    }
    if (%maxline) {
      .timer -m 1 $calc(%delay * 700) $iif($1,.msg $1,scramb.msg) [ $+ $gettok($line(@scramb,%maxline),2,32) $+ ]: $gettok($line(@scramb,%maxline),1,32) points
      dline @scramb %maxline
      inc %delay
    }
  }
  window -c @scramb
}
on *:PART:%�.scramb.chan:if ($nick == $me) scramb.reset
on *:TEXT:*:%�.scramb.chan:{
  if ($1- == %�.scramble.word) {
    scramb.msg Congratulations, $nick $+ , you got the right word ( $+ %�.scramble.word $+ )
    inc %�.scramb.pont. [ $+ [ $nick ] ]
    scramb.msg [ $+ $nick $+ ]: %�.scramb.pont. [ $+ [ $nick ] ] points
    set %�.scramb.pont.lst $addtok(%�.scramb.pont.lst,$nick,32)
    unset %�.scramble.*
    if (%�.scramb.type) { .timerscramb off | .timerscr 1 10 scramble f %�.scramb.chan }
  }
  elseif ($1- == !score) { if ($__i(scramb.pont.,$nick)) var %m = [Score for $nick $+ ] $ifmatch | else var %m = [No score for $nick $+ ] | .msg $nick %m | set -u15 %�.triv.score 1 }
  elseif ($1- == !scores) { scramb.score $nick | set -u20 %�.scramb.!score 1 }
  elseif ($1- == !hint) && (!%�.scramb.!hint) { scramb.hint | set -u30 %�.scramb.!hint 1 }
}
;
menu channel {
  -
  $_mscramble
  .$iif(%�.scramble.word,Actual)
  ..- %�.scramble.word -:return
  ..-
  ..Hint
  ...$iif(%�.scramble.w,Repeat word):scramb.msg [Word]: %�.scramble.w | scramb.msg [Hint]: %�.scramble.hint
  ...-
  ...1 letter more:scramb.hint
  ...$iif($len(%�.scramble.word) > 3,3 letters more):scramb.hint 3
  ...$iif($len(%�.scramble.word) > 5,5 letters more):scramb.hint 5
  ...-
  ...Custom:scramb.hint -c
  ..Abort:unset %�.scramble.* | sr Word aborted!!
  .-
  .$iif(%�.scramble.word == $null,Start)
  ..Enter word:scramb.new
  ..From file:scramble f #
  .-
  .$iif(%�.scramble.word,Giveup):scramb.giveup
  .-
  .$iif(%�.scramb.pont.lst,Scores):scramb.score
  .$iif(%�.scramb.pont.lst,Reset scores):scramb.msg -Scramble- Scores cleared | unset %�.scramb.pont.*
  .-
  .End:if (%�.scramb.chan) scramb.msg -Scramble- Game over | unset %�.scramb* | scramb.reset
  -
  $_mtriv
  .$iif(%�.triv.a,Actual)
  ..- %�.triv.a -:return
  ..-
  ..Hint
  ...$iif(%�.triv.q,Repeat question):triv.msg [Question]: %�.triv.q
  ...-
  ...1 letter more:triv.hint
  ...3 letters more:triv.hint 3
  ...-
  ...1 word more:triv.hint w
  ...-
  ...Custom:triv.hint -c
  ..-
  ..$iif(%�.triv.a,Giveup):triv.giveup
  .-
  .$iif(%�.triv.chan == $null,Start):trivia #
  .$iif(%�.triv.a && !%�.triv.paused,Pause):.timertriv -p | set %�.triv.paused 1 | triv.msg -Trivia- The game is paused
  .$iif(%�.triv.paused,Resume):.timertriv -r | unset %�.triv.paused | triv.msg -Trivia- The game will now go on. | triv.msg [Question]: %�.triv.q
  .-
  .$iif(%�.triv.pont.lst,Scores):triv.score
  .$iif(%�.triv.pont.lst,Reset scores):triv.msg -Trivia- Scores cleared | unset %�.triv.pont.*
  .-
  .Sets
  ..Time to answer ( $+ $iif($hget(x_trivia,time),$ifmatch,90) $+ s):_set trivia time $$input(How much time for players to answer?,ei)
  ..-
  ..Questions per session ( $+ $iif($hget(x_trivia,n),$ifmatch,eof) $+ ):_set trivia n $$input(How many questions before ending?,ei)
  ..-
  ..Questions file ( $+ $iif($hget(x_trivia,file-q),$nopath($ifmatch),triv-q.txt) $+ ):_set trivia file-q $$file="What file to use for questions?"
  ..Answers file ( $+ $iif($hget(x_trivia,file-a),$nopath($ifmatch),triv-a.txt) $+ ):_set trivia file-a $$file="What file to use for answers?"
  .-
  .End:if (%�.triv.chan) triv.msg -Trivia- Game over | unset %�.triv* | triv.reset
}

;EOF
