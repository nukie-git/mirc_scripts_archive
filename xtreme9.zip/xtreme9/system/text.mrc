;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; general events section (2)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

;$_input.replacer <text>: internal command
; very, VERY bad code... but i don't think anyone will use this anyway :p
alias _input.replacer {
  if (!$hget(x_input.replacer)) || ($hget(x_input.replacer,0).item == 0) || ($hget(x_sets,input.replacer) == 0) return $1-
  var %i = 1, %line1 = $replace($1-,$chr(32),$chr(1)), %line2 = %line1
  while ($gettok(%line1,%i,1)) {
    var %w1 = $ifmatch
    if (:* iswm %w1) || (=* iswm %w1) var %w2 = %w1
    else var %w2 = $remove(%w1,$chr(44),.,!,",$chr(40),$chr(41),?,=,�,�,<,>,;,:,_)
    if ($hget(x_input.replacer,%w2)) var %line2 = $puttok(%line2,$replace(%w1,%w2,$ifmatch),%i,1)
    inc %i
  }
  return $replace(%line2,$chr(1),$chr(32))
}

;==========================
; nickcompleter

alias _nickcomp {
  if ($len($1) < 3) || ($hget(x_sets,nickcompleter.stat) == 0) return $1
  if ($active ischan) || ($prop == chan) {
    if (!$chan(#).ial) {
      var %i = 1, %nicks
      while ($nick(#,%i)) {
        var %nick = $ifmatch
        if ($1* iswm %nick) && (%nick != $me) %nicks = $addtok(%nicks,%nick,44)
        inc %i
      }
    }
    else {
      var %x = $ialchan($1*,#,0), %n, %nicks
      while (%x) {
        %n = $ialchan($1*,#,%x).nick
        if (%n != $me) %nicks = $addtok(%nicks,%n,44)
        dec %x
      }
    }
    var %nick = $iif(%nicks,%nicks,$1)
    if (%nick == $1) {
      if ($prop != chan) goto ial
      elseif ($2) && ($1 !ison #) halt
    }
    goto end
  }

  :ial
  var %x = $ial($1*,0), %n, %nicks
  while (%x) {
    %n = $ial($1*,%x).nick
    if (%n != $me) %nicks = $addtok(%nicks,%n,44)
    dec %x
  }
  var %nick = $iif(%nicks,%nicks,$1)
  if (%nick == $1) return %nick

  :end
  if ($numtok(%nick,44) > 1) {
    if ($_select(Nick Selection,$replace(%nick,$chr(44),$chr(164)))) return $ifmatch
    elseif ($2) halt
  }
  return %nick
}

;$_nickcomp.ctrl(word): returns the word between two control codes
alias _nickcomp.ctrl {
  var %c = $hget(x_sets,nickcompleter.code)
  if (%c) return %c $+ $1 $+ %c
  return $1
}

;$_nickcomp.style(nick)
alias _nickcomp.style {
  var %style = $iif($2,$2,$hget(x_sets,nickcompleter.style)), %len = $len($1), %first = $left($1,1), %last = $right($1,1), %mid = $iif(%len > 2,$left($right($1,-1),-1))
  ;  if ($len($1) < 3) && (%a isin 2457) goto 1
  goto $iif(%style isnum 1-7,%style,custom)
  :1 | return $1
  :2 | return %first $+  $+ %mid $+  $+ %last
  :3 | return  $+ $1 $+ 
  :4 | return  $+ %first $+  $+ %mid $+  $+ %last $+ 
  :5 | return  $+ %first $+  $+ %mid $+  $+ %last $+ 
  :6 | return  $+ $1 $+ 
  :7 | return  $+ %first $+  $+ %mid $+  $+ %last $+ 
  :custom
  if (%style) return $replace(%style,<nick>,$1,<first>,%first,<mid>,%mid,<last>,%last,<c1>,$_c(1),<c2>,$_c(2),<c3>,$_c(3),<c4>,$_c(4)) $+ 
  return $1
}
alias _set.nc.style if ($1) _set sets nickcompleter.style $'repcolor($1-)


;=================

;$_text.grab <text/action/notice> <text>: internal command
alias _text.grab {
  if (!$hget(x_text.grab)) || ($hget(x_text.grab,0).item == 0) || ($hget(x_sets,text.grab) == 0) return

  var %det = $hget(x_sets,text.grab.where)
  if ($1 == text) && (%det !isin 1.3) return
  if ($1 == action) && (%det !isin 2.3) return

  if ($hmatch(x_text.grab,$1-,1).data) {
    var %w = @TextGrabber
    if (!$window(%w)) window -nk %w $_gcoord(textgrabber,-1 -1 600 300) $_@font
    if ($1 == text) var %line = < $+ $nick $+ > $2-
    elseif ($1 == action) var %line = ! $+ $nick $2-
    else var %line = - $+ $nick $+ - $2-
    aline %w [[ $+ $time $+ ]] [[ $+ # $+ ]] %line
    window -g1 %w
    return 1
    ;if return 'hide', it won't display the line on channel
  }
}

;=================

; /_query.blocker <text>: internal command (called ON OPEN:?:)
alias _query.blocker {

  if ($hget(x_sets,query.blocker)) var %qb = $hget(x_sets,query.blocker.allow)
  if (%qb) goto $ifmatch
  return

  :friends
  if ($_isflag($fulladdress,F)) return
  goto no

  :known
  var %flags = $_getflagsd($fulladdress,-)
  if ($nick isnotify) || (F isincs %flags) || (o isincs %flags) || (v isincs %flags) return
  goto no

  ;  :known2 | if ($nick isnotify) return | goto no
  ;  :known3| if ($ulist($fulladdress)) return | goto no

  :operators
  var %n = $comchan($nick,0)
  while (%n) {
    if ($nick isop $comchan($nick,%n)) return
    dec %n
  }
  goto no

  :no
  var %w = @Blocked
  if (!$window(%w)) window $iif($hget(x_sets,query.blocker.window),-kn,-knh) %w $_gcoord(blocked,-1 -1 400 200) $_@font
  echo %w $timestamp < $+ $iif($nick isnotify,$+($_c(1),$nick),$nick) $+ > $iif($hget(x_sets,blocked.hide.text),<hidden>,$1-)
  window -g1 %w
  if ($hget(x_sets,query.blocker.warn)) && (!$istok($__i(lastblocks),$nick,44)) {
    $iif($hget(x_sets,query.blocker.warn) == 2,.rawnotice,.msg) $nick $_echo(pvtblocked)
    set -u120 $_i(lastblocks) $addtok($__i(lastblocks),$nick,44)
  }
  halt

  :%qb
  return
}
