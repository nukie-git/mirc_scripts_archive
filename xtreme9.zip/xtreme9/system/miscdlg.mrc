;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; misc dialogs
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

;auto-email clicker
;on ^*:HOTLINK:*@*.*:#:{
;  if (! !isin $1) return
;  halt
;}
;on *:HOTLINK:*:*:{
;  var %email = $gettok($1,-1,58)
;  email %email
;}

;game launcher
on ^*:HOTLINK:*.*.*.*:#:{
  var %w = $_rempunct.url($1), %ip = $wildtok(%w,*.*.*.*:*,1,32)
  if ($remove(%ip,.,:) isnum) return
  halt
}
on *:HOTLINK:*:*:{
  var %w = $_rempunct.url($1), %ip = $wildtok(%w,*.*.*.*:*,1,32)
  echo clicked ip %ip
}

alias -l _rempunct.url {
  return $replace($strip($1-),!,-,?,-,;,-,$chr(44),-,",-,',-,$chr(40),-,$chr(41),-,<,-,>,-,|,-,=,-,$chr(35),-,-,$chr(32))
}


;=============================================
;file locator

alias locate find $1-
alias search find $1-
alias find {
  if ($dialog(loc.results)) dialog -x loc.results
  if ($1) _find $1-
  else _dialog -dm locate locate
}
dialog locate {
  title "File Locator"
  size -1 -1 146 66
  option dbu
  icon graphics\locate.ico, 0
  box "Enter search string/mask", 100, 5 3 136 44
  combo 1, 12 13 124 40, edit drop
  edit "", 2, 12 28 93 11, autohs
  button "...", 48, 107 29 20 10, cancel
  button "Cancel", 49, 80 50 30 12, cancel
  button "Search", 50, 45 50 30 12, default ok
}
on 1:dialog:locate:*:*:{
  if ($devent == init) {
    multi.lang
    didtok locate 1 44 $hget(x_misc,finds)
    did -f locate 1
    did -a locate 2 $left($mircdir,3)
  }
  if ($devent == sclick) {
    if ($did == 48) {
      did -ra locate 2 $$sdir($left($mircdir,3),Select directory)
      did -f locate 1
    }
    if ($did == 50) && ($did(1)) _find $iif(\ isin $did(2),$did(2)) $+ $iif((* isin $did(1) || ? isin $did(1) || . isin $did(1)),$did(1),$+(*,$did(1),*))
  }
}

alias -l _find {
  var %file = $nopath($1-), %d = $nofile($1-)
  _dialog -dm loc.results loc.results
  if (!%d) %d = $left($mircdir,3)
  did -ra loc.results 10 Searching, please wait
  var %g = $findfile(%d,%file,0,did -a loc.results 1 $longfn($1-)))
  did -ra loc.results 10 Done. ( $+ $longfn(%d) $+ )
  dialog -t loc.results Search Results (found %g files)
  did -z loc.results 1
  _set misc finds $qtok($hget(x_misc,finds),%file,10,44)

  if ($__i(import)) && ((%file == mirc.ini) || (%file == remote.ini) || (%file == extreme.ini)) {
    did -ra loc.results 49 Import
    did -h loc.results 50
  }
  unset $_i(import)
}

dialog loc.results {
  title "Search Results"
  size -1 -1 272 108
  option dbu
  icon graphics\locate.ico, 0
  list 1, 6 2 258 95, hsbar
  button "Open", 49, 8 91 35 12, default
  button "View", 50, 46 91 35 12
  button "Ok", 51, 230 91 35 12, ok
  text "", 10, 115 95 67 7
}
on 1:dialog:loc.results:*:*:{
  var %f = $shortfn($did(1).seltext)
  if ($devent == init) multi.lang
  if ($devent == dclick) && (%f) run %f
  if ($devent == sclick) && (%f) {
    if ($did == 49) {
      if ($did(49) == import) {
        var %t = $__i(import)
        if (%t == notify) _impnotify %f
        elseif (%t == userlist) _impusers %f
        elseif (%t == backup) _impconfig %f
      }
      run %f

    }
    if ($did == 50) {
      run notepad %f
    }
  }
}

;=============================================
;memoserv

alias msend {
  if (!$1) || (!$2) {
    ale Use /msend <nick> <memo>
    return
  }
  var %w = @msend.queue
  if ($network == PTnet) && (($__i(msend.blocker)) || ($window(%w))) {
    if (!$window(%w)) {
      window -lh %w
      .timermsend 0 15 msend.queue
    }
    aline %w $1-
    se $_c(1) $+ *** Queued memo to $1 $+ .
  }
  else {
    ms send $1-
    se $_c(1) $+ *** Sending memo ( $+ $2- $+ ) to $1
    if ($network == PTnet) set -u65 $_i(msend.blocker) 1
  }
}
alias msend.queue {
  var %w = @msend.queue
  if (!$window(%w)) { .timermsend off | return }
  if (!$__i(msend.blocker)) {
    var %line = $line(%w,1), %nick = $gettok(%line,1,32), %msg = $gettok(%line,2-,32)
    ms send %nick %msg
    se $_c(1) $+ *** Sending memo ( $+ %msg $+ ) to %nick
    set -u65 $_i(msend.blocker) 1
    dline %w 1
    if ($line(%w,0) == 0) window -c %w
  }
}
alias _mmserv return  ( $+ $_c(4) $+ MemoServ $+ ) $+ $_c(1)
alias memoserv.notice {
  if ($ptnet) {
    if (Memo?enviado?a* iswm $3-) ae $_mmserv Memo has been sent to $6
    elseif (Tem?um?novo?memo?de* iswm $3-) {
      ae $_mmserv You have a new memo from $8
      event.sound pager
    }
    else ae $_mmserv $3-
    return
  }
  if (!$window(@memoserv)) {
    window -aken @MemoServ $_gcoord(memoserv,130 30 450 240) @MemoServ
    titlebar @MemoServ -> (S)end nick - (L)ist - (R)ead num - (D)el num - (Q)uit
  }
  echo @MemoServ $_pre $+ $_c(1) $3-
}
on *:INPUT:*memoserv:{
  if ($comchar iswm $1) && ($ctrlenter == $false) return
  if (($__i(s^m)) && ($target == $query(memoserv))) || ($target == @memoserv) {
    if (q* iswm $1) window -c $target
    elseif (l* iswm $1) ms list $2
    elseif (r* iswm $1) ms read $2-
    elseif (d* iswm $1) ms del $2-
    elseif (s* iswm $1) && ($2) msend $2-
    elseif (/* iswm $1) return
    else ms $1-
    halt
  }
}
;
;=============================================
;(connect to) bouncer

dialog bounc {
  title "BNC Connect Settings"
  size -1 -1 156 110
  option dbu
  icon graphics\multi1.ico, 0
  box "", 11, 6 32 145 35
  text "BNC Host:", 1, 8 11 30 7, right
  text "BNC Port:", 2, 8 22 30 7, right
  text "Pass:", 3, 8 41 30 7, right
  text "Bounce to:", 4, 8 53 30 7, right
  edit "", 5, 40 8 99 12, autohs
  edit "", 6, 40 21 25 12, autohs
  edit "", 7, 40 38 60 12, pass autohs
  edit "", 8, 40 51 100 12, autohs
  text "Extras:", 9, 13 73 25 7, right
  edit "", 12, 40 70 100 12, autohs
  button "Ok", 50, 30 92 30 12, default ok
  button "Cancel", 49, 65 92 30 12, cancel
  button "Connect", 48, 100 92 30 12, default
  button "Delete", 51, 110 22 28 10
}
alias bounc _dialog -m bounc bounc
on 1:dialog:bounc:*:* {
  if ($devent == init) {
    multi.lang
    if ($hget(x_bouncer,0)) {
      did -a bounc 5 $gettok($ifmatch,1,32)
      did -a bounc 6 $gettok($ifmatch,2,32)
    }
    if ($hget(x_bouncer,1)) did -a bounc 7 $_pwd($ifmatch)
    if ($hget(x_bouncer,2)) did -a bounc 8 $ifmatch
    if ($hget(x_bouncer,3)) did -a bounc 12 $ifmatch
  }
  if ($devent == sclick) {
    if ($did == 51) { _unset bouncer | did -r bounc 5,6,7,8,12 }
    if ($did == 50) || ($did == 48) {
      if ($did(5)) && ($did(6)) {
        _set bouncer 0 $did(5) $did(6)
        if ($did(7)) _set bouncer 1 $_pwd($did(7))
        if ($did(8)) _set bouncer 2 $did(8)
        if ($did(12)) _set bouncer 3 $did(12)
      }
      if ($did == 48) {
        if (($did(5)) && ($did(6))) server $did(5) $did(6)
        dialog -c bounc
      }
    }
  }
}

;=============================================
;usermodes

alias umodes _dialog -m umodes umodes
dialog umodes {
  title "Usermodes"
  size -1 -1 144 114
  option dbu
  check "Invisible (i)", 1, 15 20 45 7, left
  check "Wallops (w)", 2, 15 30 45 7, left
  check "Globops (g)", 3, 15 40 45 7, left
  check "SNotices (s)", 4, 15 50 45 7, left
  check "Helper (h)", 21, 15 60 45 7, left
  edit "", 5, 40 70 20 10, autohs
  text "Other", 6, 16 71 20 8
  check "Invisible (i)", 7, 82 20 45 7, left
  check "Wallops (w)", 8, 82 30 45 7, left
  check "Globops (g)", 9, 82 40 45 7, left
  check "SNotices (s)", 10, 82 50 45 7, left
  check "Helper (h)", 22, 82 60 45 7, left
  edit "", 11, 107 70 20 10, autohs
  text "Other", 12, 83 71 20 8
  box "Actual modes", 13, 6 7 65 85
  box "Default modes", 14, 73 7 65 85
  button "Cancel", 49, 73 98 35 12, cancel
  button "Ok", 50, 36 98 35 12, default ok
}
on 1:dialog:umodes:*:* {
  if ($devent == init) {
    multi.lang
    var %d = $remove($_net(usermodes),+)
    if (i isin %d) did -c umodes 7
    if (w isin %d) did -c umodes 8
    if (g isin %d) did -c umodes 9
    if (s isin %d) did -c umodes 10
    if (h isin %d) did -c umodes 22
    if ($remove(%d,i,s,g,w,h)) did -ra umodes 11 $ifmatch
    if ($server) {
      if (i isin $usermode) did -c umodes 1
      if (w isin $usermode) did -c umodes 2
      if (g isin $usermode) did -c umodes 3
      if (s isin $usermode) did -c umodes 4
      if (h isin $usermode) did -c umodes 21
      if ($remove($usermode,i,s,g,w,h,+)) did -ra umodes 5 $ifmatch
    }
    else did -b umodes 1,2,3,4,5,6,21
  }
  if ($devent == sclick) {
    if ($did == 50) {
      var %mode, %_+, %_-
      if ($did(1).state) %_+ = i
      else %_- = i
      if ($did(2).state) %_+ = %_+ $+ w
      else %_- = %_- $+ w
      if ($did(3).state) %_+ = %_+ $+ g
      else %_- = %_- $+ g
      if ($did(4).state) %_+ = %_+ $+ s
      else %_- = %_- $+ s
      if ($did(21).state) %_+ = %_+ $+ h
      else %_- = %_- $+ h
      if (%_+) %_+ = + $+ %_+
      if (%_-) %_- = - $+ %_-
      %mode = %_+ $+ $did(5) $+ %_-
      if (%mode) .raw MODE $me %mode
      if ($did(7).state) var %t = i
      if ($did(8).state) var %t = %t $+ w
      if ($did(9).state) var %t = %t $+ g
      if ($did(10).state) var %t = %t $+ s
      if ($did(22).state) var %t = %t $+ h
      var %um = $iif($hget($+(x_net-,$__i(network)),usermodes),$+(net-,$__i(network)),net-default)
      if (%t) || ($did(11)) _set %um usermodes + $+ %t $+ $iif($did(11),$remove($did(11),+)) | else _unset %um usermodes
    }
  }
}


;=============================================
; recent topics

alias rectopic {
  if ($active ischan) {
    if (!$isfile(system\topics.ini)) || (!$ini(system\topics.ini,$active)) sr -t Topic No recent topics found.
    else dialog -mo topicd topicd
  } 
}
alias addnewtopic {
  var %t = 0
  while ($readini(system\topics.ini,n,$1,%t)) {
    var %l = $ifmatch
    if ($2- == %l) return
    inc %t
  }
  if (%t == 5) var %t = 4
  while (%t) {
    _topset $1 %t $readini(system\topics.ini,n,$1,$calc(%t -1))
    dec %t
  }
  _topset $1 0 $2-
}
alias -l _topset if ($3 != $null) writeini system\topics.ini $1-
dialog topicd {
  title "topicd"
  size -1 -1 283 58
  option dbu
  icon $mircexe, 4
  box "", 2, 5 5 273 34
  button "Cancel", 49, 136 43 35 12, cancel
  button "Set", 50, 98 43 35 12, default ok
  combo 3, 10 13 234 90, edit drop
  icon 4, 249 9 26 27,  graphics\logo2.jpg, 0
}
on 1:dialog:topicd:*:*:{
  if ($devent == init) {
    multi.lang
    if ($me !isop $active) && (t isin $channel($active).mode) did -ra topicd 50 Copy
    dialog -t topicd Recent topics for $active
    if ($ini(system\topics.ini,$active)) {
      var %c = 0
      while ($readini(system\topics.ini,n,$active,%c)) { did -a topicd 3 $ifmatch | inc %c }
      did -f topicd 3
    }
  }
  if ($devent == sclick) && ($did == 50) && ($did(3) != $null) {
    if ($me isop $active) .raw TOPIC $active : $+ $did(3)
    else clipboard Topic for $active $+ : $did(3)
  }
}

;=============================================
;edit/quit dialog

alias edit {
  if (!$dialog(edit)) {
    if ($1) var %f = $1-
    else var %f = $$sfile($mircdir)
    if (!$isfile($shortfn(%f))) {
      sr -th Error Couldn't open file
      return
    }
    set -u %_edit %f
    _dialog -m edit edit
  }
  else dialog -v edit
}
alias quits {
  if (!$server) return
  if (!$dialog(edit)) {
    set -u %_quits 1
    _dialog -m edit edit
  }
  else dialog -v edit
}
dialog edit {
  title "Edit"
  size -1 -1 277 194
  option dbu
  list 1, 11 16 255 143
  text "Selected:", 2, 11 155 31 8, right
  edit "", 3, 44 153 222 10, autohs
  box "Select a line to edit", 10, 5 6 268 162
  box "", 11, 5 169 268 22
  button "Ok", 50, 200 176 30 12, default ok
  button "Cancel", 51, 232 176 30 12, cancel
  button "Add", 52, 17 176 27 11
  button "Update", 53, 71 176 27 11
  button "Delete", 54, 44 176 27 11
  text "", 55, 0 0 0 0
}
on 1:dialog:edit:*:*:{
  if ($devent == init) {
    multi.lang
    if (%_edit) {
      var %f = $ifmatch
      did -ra edit 10 Select a line to edit
    }
    else var %f = system\quits.txt
    if ($file(%f).size > 60000) {
      sr -th Error File too big to open in this dialog
      dialog -x edit
      return
    }
    did -ra edit 55 %f
    if (%_quits) {
      dialog -t edit Quits
      did -ra edit 50 Quit
      did -b edit 52,53,54
      did -ra edit 10 Select a quit message
      did -m edit 3
    }
    else dialog -t edit Editing: %f
    did -r edit 1
    loadbuf -ro edit 1 " $+ %f $+ "
  }
  if ($devent == sclick) {
    if ($did == 1) did -ra edit 3 $did(1).seltext
    if ($did == 50) {
      if ($did(50) == Quit) quit $did(3)
      else savebuf -o edit 1 " $+ $did(edit,55) $+ "
    }
    if ($did == 51) && ($dialog(setup)) did -f setup 250
    if ($did == 52) && ($did(3)) && ($didwm(1,$did(3)) == 0) {
      did -a edit 1 $did(3)
      did -c edit 1 $did(1).lines
    }
    if ($did == 53) && ($did(1).sel) {
      var %l = $did(1).sel
      did -o edit 1 $did(1).sel $did(3)
      did -c edit 1 %l
    }
    if ($did == 54) && ($did(1).sel) {
      did -d edit 1 $did(1).sel
      did -r edit 3
    }
  }
  if ($devent == dclick) && ($did == 1) && ($did(50) == Quit) {
    quit $did(3)
    dialog -k edit
  }
}

;=============================================
;fake ctcps

alias fakever {
  if ($hget(x_ctcps,motfv)) _dialog -m fkver fkver
  else sr -t Error Cannot use fakeversion $crlf $+ due to some problems with the DLL file
}
alias _fversion {
  if ($hget(x_ctcps,motfv)) {
    if ($hget(x_ctcps,reply-version) != <random>) return $eval($replace($ifmatch,�,$),2)
    if ($isfile(system\fversions.txt)) return $read(system\fversions.txt)
  }
  return $_script
}

alias fctcp _dialog -m fctcps fctcps
dialog fctcps {
  title "CTCP Replies"
  size -1 -1 321 196
  option dbu
  icon $mircexe, 2
  tab "General", 5, 7 8 307 169
  list 1, 21 42 245 112, tab 5 sort size
  box "Double-click on a line to edit it", 7, 15 29 292 132, tab 5
  button "Add", 2, 272 74 30 12, tab 5
  button "Edit", 3, 272 86 30 12, tab 5
  button "Remove", 4, 272 98 30 12, tab 5
  tab "VERSION", 6
  list 101, 21 42 279 97, tab 6
  text "Selected:", 102, 20 139 30 8, tab 6 right
  edit "", 103, 53 137 245 10, tab 6 read
  check "random", 105, 19 159 28 10, tab 6 push
  box "Select your version reply", 110, 15 29 292 123, tab 6
  box "", 111, 15 153 292 19, tab 6
  text "Powered by mOTFv3.dll (by danielson)", 112, 203 160 100 8, disable tab 6 right
  button "Ok", 50, 248 181 30 12, default ok
  button "Cancel", 49, 280 181 30 12, cancel
}
alias -l _loadem {
  var %i = 1
  while ($hget(x_ctcps,%i).item) {
    var %h = $ifmatch
    if (reply-* iswm %h) did -a fctcps 1 $upper($gettok(%h,2-,45)) $_tab $hget(x_ctcps,%h)
    inc %i
  }
}
alias -l _fcedit {
  if ($did(1).seltext) var %l = $ifmatch, %c = $gettok(%l,6,32), %r = $$_input(What reply do you want for %c $+ ?,e,Edit,$gettok(%l,11-,32))
  if (%c) && (%r != $null) did -o fctcps 1 $did(1).sel %c $_tab %r
}
on 1:dialog:fctcps:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    mdx SetControlMDX 1 listview rowselect grid single flatsb showsel report nosortheader > $mdx.vdll
    did -i $dname 1 1 headerdims 90 450
    did -i $dname 1 1 headertext $_tab(0 CTCP,+ Reply)
    _loadem

    if (!$isfile(system\fversions.txt)) {
      sr -th Error Versions file is missing
      return
    }
    loadbuf -oer fctcps 101 system\fversions.txt
    if ($hget(x_ctcps,reply-version) == <random>) {
      did -ra fctcps 103 <random>
      did -c fctcps 105
      did -b fctcps 101
    }
    elseif ($hget(x_ctcps,reply-version) != $null) {
      var %vl = $ifmatch
      did -ra fctcps 103 $strip(%vl)
      if ($didwm(101,%vl)) did -c fctcps 101 $ifmatch
    }
  }

  if ($devent == dclick) {
    if ($did == 1) && ($did(1).seltext) _fcedit
    if ($did == 101) && ($did(101).seltext) {
      did -ra fctcps 103 $strip($did(101).seltext)
      var %mask = 0 + 0 0 0 VERSION *, %line = $didwm(1,%mask)
      if (%line) did -o fctcps 1 %line VERSION $_tab $did(101).seltext
      else did -a fctcps 1 VERSION $_tab $did(101).seltext
    }
  }
  if ($devent == sclick) {
    if ($did == 2) {
      var %c = $$upper($$_input(What CTCP?,e,Edit)), %r = $$_input(Enter the reply you want for %c $+ . You can use control codes as well.,e,Edit)
      did -a fctcps 1 %c $_tab %r
    }
    if ($did == 3) && ($did(1).sel) _fcedit
    if ($did == 4) && ($did(1).sel) && ($input(Are you sure you want to delete?,yq)) {
      did -d fctcps 1 $did(1).sel
      did -f fctcps 4
    }
    if ($did == 104) {
      if ($did(104).state) {
        did -e fctcps 105
        if ($did(105).state == 0) did -e fctcps 101
      }
      else did -b fctcps 101,105
    }
    if ($did == 105) {
      if ($did(105).state) {
        did -b fctcps 101
        did -ra fctcps 103 <random>
        var %mask = 0 + 0 0 0 VERSION *, %line = $didwm(1,%mask)
        if (%line) did -o fctcps 1 %line VERSION $_tab <random>
        else did -a fctcps 1 VERSION $_tab <random>
      }
      else {
        did -e fctcps 101
        var %fv = $iif($did(101).seltext,$ifmatch,$_fversion)
        did -ra fctcps 103 $strip(%fv)
        var %mask = 0 + 0 0 0 VERSION *, %line = $didwm(1,%mask)
        if (%fv) {
          if (%line) did -o fctcps 1 %line VERSION $_tab %fv
          else did -a fctcps 1 VERSION $_tab %fv
        }
        elseif (%line) did -d fctcps 1 %line
      }
    }
    if ($did == 50) {
      hdel -w x_ctcps reply-*
      var %n = 2
      while ($did(1,%n)) {
        var %a = $ifmatch
        _set ctcps $+(reply-,$gettok(%a,6,32)) $gettok(%a,11-,32)
        inc %n
      }
    }
  }
}
alias _l�a� {
  window -akp +b @eXtreme $calc(($window(-1).w -250) /2) $calc(($window(-1).h -380) /2) 190 180
  drawfill @extreme 1 1 1 1
  set %int_col 255
  .timerint -m 35 40 _int1
}
alias -l _int1 {
  drawtext -r @extreme $rgb(%int_col,%int_col,%int_col) "Times New Roman" 60 25 75 x
  drawtext -r @extreme $rgb(%int_col,%int_col,%int_col) "Times New Roman" 120 50 35 x
  drawtext -r @extreme $rgb(%int_col,%int_col,%int_col) "Times New Roman" 160 80 30 X
  dec %int_col 7
  if (%int_col <= 20) { unset %int_* | _int3 }
}
alias -l _int3 {
  var %n = 1
  while (%n <= 7) {
    .timer -m 1 $calc(%n * 150) drawtext -pb @extreme 5 1 "Arial" 20 50 15 $left(eXtreme,%n)
    if (%n == 7) .timer -m 1 1600 drawtext -pb @extreme 5 1 "Arial" 15 90 42 $xtreme.ver
    inc %n
  }
  .timer 1 5 event.sound kick
  .timer 1 5 window -c @extreme
}
;

;=============================================
;notify+ dialog

alias notify+ _dialog -m notfx notfx
dialog notfx {
  title "Notify+"
  size -1 -1 650 400
  icon graphics\users.ico
  list 1, 10 10 630 360, size
  button "Close", 50, 295 375 65 22, ok default
}
on 1:dialog:notfx:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    mdx SetControlMDX 1 listview grid rowselect single showsel headerdrag report nosortheader > $mdx.vdll
    did -i $dname 1 1 headerdims 90 50 50 140 140 140
    did -i $dname 1 1 headertext $_tab(0 Nick,0 Online,0 Whois,0 Note,0 Last seen host,0 Last seen date)
    var %n = 1
    while ($notify(%n)) {
      var %u = $ifmatch
      did -a notfx 1 0 %u $_tab $iif($notify(%u).ison,yes,-) $_tab $iif($notify(%u).whois,yes,-) $_tab $notify(%u).note $_tab $_seen(%u).host $_tab $_seen(%u).time
      inc %n
    }
  }
  if ($devent == dclick) && ($did == 1) {
    var %nick = $gettok($did(1).seltext,6,32), %com = $readini($mircini,n,clicks,notify)
    if (%nick) $eval($replace(%com,$+($,1),%nick),2)
  }
}

;=============================================
; simple peak sys

on *:join:#:{
  if ($hget(x_sets,peak)) && (($nick(#,0) > $hget(x_peak,#)) || (!$hget(x_peak,#))) hadd -m x_peak # $nick(#,0)
}
on *:text:!peak:#:{
  if (!$__i(peak_prot)) && ($hget(x_peak,#) isnum) {
    say # Peak: $ifmatch users
    set -u30 $_i(peak_prot) 1
  }
}
alias peaklist {
  window -kl -t20,20 @peak $_gcoord(peak,-1 -1 300 400)
  var %i = 1
  while (%i <= $hget(x_peak,0).item) {
    aline @peak $hget(x_peak,%i).item $chr(9) $hget(x_peak,$hget(x_peak,%i).item)
    inc %i
  }
}
;
;EOF
