;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; events section (channel)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

on *:JOIN:#:{

  if ($nick == $me) {
    event.sound join
    set $_i(just.joined.,#) 1
    set $_i(synch.time.,#) $ticks
    if ($timer($+(retry.,#,.cid,$cid))) .timerretry. $+ # $+ .cid $+ $cid off
    hadd -m x_misc recchannels $qtok($hget(x_misc,recchannels),#,10,44)
    return
  }

  if ($hget(x_display,whoisonjoin)) {
    if ($hget(x_display,show.whoisonjoin.on.chan)) set -u30 $_i(whois.on.join.,$nick) #
    whois $nick
  }
  if ($hget(x_sets,ircopsonjoin)) {
    if ($__i(ircops.onjoin.flood) <= 5) {
      set -u30 $_i(ircops.on.join.,$nick) #
      .raw USERHOST $nick
    }
    inc -u3 $_i(ircops.onjoin.flood)
  }
  _addseen $nick join #
  set -u30 $_i(lastjoin.,#) $nick

  if (!$__i(performed.on.join)) && ($hget(x_onjoin,#)) {
    var %perf = $ifmatch
    set -u3 $_i(performed.on.join) 1
    _perfd %perf
  }
}

on *:PART:#:{
  if ($nick == $me) {
    event.sound part
    if ($__i(just.cycled.,#)) var %cycle = 1
    unset $_i(*,#,.*) $_i(*,#)
    if (%cycle) set -u15 $_i(just.cycled.,#) 1
    if ($hget(x_display,part.format)) {
      var %echo = $ifmatch, %echo = $eval($replace(%echo,<chan>,#,<nick>,$me,<me>,$me),2)
      set -u15 $_i(just.parted.,#) 1
      .raw PART # : $+ %echo
    }
    return
  }
  if (!$_net($__i(network),serv.sites)) && ($_islev(20,$fulladdress)) .ruser 20 $mask($fulladdress,1)

  set -u120 $_i(part.mask.,#) $fulladdress

  if (!$__i(performed.on.part)) && ($hget(x_onpart,#)) {
    var %perf = $ifmatch
    set -u3 $_i(performed.on.part) 1
    _perfd %perf
  }
}

on *:KICK:#:{

  _addseen $nick kicking # $knick

  if ($knick == $me) {
    unset $_i(*,#,.*) $_i(*,#)
    if ($nick != $me) {
      event.sound warning
      set -u10 $_i(just.kicked.,#) 1
      set -u120 $_i(revkick.,#) $nick
    }
    else _nkupd
    return
  }

  if ($nick == $me) {
    event.sound kick
    if ($hget(x_sets,ignore.after.kick)) .ignore -u $+ $ifmatch $knick $+ !*@*
    _nkupd
    return
  }
  if (!$istok($__i(banned.nicks.,#),$knick,32)) set -u120 $_i(kick.mask.,#) $address($knick,5)
}

on ^*:TEXT:*:#:{
  haltdef

  if ($_string(# appears as &) iswm $1-) || ($__i(notext.,#,.,$nick)) halt

  var %grab = $_text.grab(text,$1-)
  if (%grab == hide) return

  if ($_flashing.chan(#)) flash $iif(!$window(#).mdi,#) ( $+ # $+ )
  if ($beepchanmsg(#)) beep 1

  if ($hget(x_sets,text.calculator)) var %tm = $_decode($strip($1-,mo))
  else set -un %tm $_decode($strip($_text,mo))

  if (!$hget(x_mts)) {
    set -u %::nick $_align($_ns($nick,#))
    if (@* iswm $target) set -u %::nick %::nick $+ : $+ $target
  }
  else {
    set -u %::nick $nick
    if ($showmodeprefix) set -u %::cmode $left($remove($nick($chan,$nick).pnick,$nick),1)
    set -u %::cnick $nick($chan,$nick).color
  }
  set -u %::address $address
  set -u %::target $target
  set -u %::chan #
  set -un %::text %tm
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)

  var %tmp.nick %::nick 
  _addseen $nick msg on #

  var %indent = $iif($hget(x_display,align.text),$ifmatch,2)

  if (%tm !isnum) && ($highlight) && (($highlight(%tm)) || ($highlight($nick).nicks)) {
    if ($away) {
      if ($hget(x_away,highlight.warn)) && (!$__i(away.warned)) {
        .timer 1 0 describe # $_away.advert.msg
        set -u600 $_i(away.warned) 1
      }
      if ($hget(x_away,highlight.log)) _addawaylog # < $+ $nick $+ > $strip(%tm,c)
    }
    var %highcol = $iif($highlight(%tm).color,$calc($ifmatch -1),$color(highlight))

    ;highlight on active
    if (($appactive) && ($active != #) && ($ircwin) && ($hget(x_display,show.highlightonactive))) {
      set -u %:echo echo %highcol -ltai $+ %indent $_c(1) $+ [ $+ # $+ $_c(1) $+ ]
      theme.text textchan
    }

    ;normal highlight text on chan
    set -u %::nick %tmp.nick
    set -u %:echo echo %highcol -lti $+ %indent #
    theme.text textchan

    ;flash
    var %hlm = $highlight(%tm).message
    if ((!%hlm) || (%hlm == $chr(35))) flash $iif(!$window(#).mdi,#) ( $+ # $+ )
  }

  else {

    if ($away) && ($hget(x_away,highlight.words)) && (!$__i(away.warned)) {
      var %list = $hget(x_away,highlight.words.list), %n = 1
      if ($_matchtok(%list,$_rempunct($1-))) {
        .timer 1 0 describe # $_away.advert.msg
        set -u600 $_i(away.warned) 1

        if ($hget(x_away,highlight.log)) _addawaylog # < $+ $nick $+ > $strip(%tm,c)
      }
    }

    ;normal text on chan
    set -u %:echo echo $color(normal) -mti $+ %indent #
    theme.text textchan
  }
  _redir # $_display(textchan)
}

on ^*:ACTION:*:#:{
  haltdef
  if ($__i(notext.,#,.,$nick)) halt

  var %grab = $_text.grab(action,$1-)
  if (%grab == hide) return

  if ($_flashing.chan(#)) flash $iif(!$window(#).mdi,#) ( $+ # $+ )
  if ($beepchanmsg(#)) beep 1

  set -un %am $_decode($strip($1-,mo))

  if (!$hget(x_mts)) {
    set -u %::nick $_align($_ns($nick,#))
    if (@* iswm $target) set -u %::nick %::nick $+ : $+ $target
  }
  else {
    set -u %::nick $nick
    if ($showmodeprefix) set -u %::cmode $left($remove($nick($chan,$nick).pnick,$nick),1)
    set -u %::cnick $nick($chan,$nick).color
  }
  set -u %::address $address
  set -u %::target $target
  set -u %::chan #
  set -un %::text %am
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)

  var %tmp.nick %::nick 
  _addseen $nick action #

  var %indent = $iif($hget(x_display,align.text),$ifmatch,2)
  if ($1- !isnum) && ($highlight) && (($highlight(%am)) || ($highlight($nick).nicks)) {
    if ($away) {
      if ($hget(x_away,highlight.warn)) && (!$__i(away.warned)) {
        describe # $_away.advert.msg
        set -u60 $_i(away.warned) 1
      }
      if ($hget(x_away,highlight.log)) _addawaylog # ! $+ $nick $strip(%tm,c)
    }

    ;highlight on active
    if (($appactive) && ($active != #) && ($ircwin) && ($hget(x_display,show.highlightonactive))) {
      set -u %:echo echo $color(highlight) -ltai $+ %indent $_c(1) $+ [ $+ # $+ $_c(1) $+ ]
      theme.text actionchan
    }

    ;normal highlight action on chan
    set -u %::nick %tmp.nick
    set -u %:echo echo $iif($highlight(%am).color,$calc($ifmatch -1),$color(highlight)) -lti $+ %indent #
    theme.text actionchan

    ;flash
    var %hlm = $highlight(%am).message
    if ((!%hlm) || (%hlm == $chr(35))) flash $iif(!$window(#).mdi,#) ( $+ # $+ )
  }
  else {
    set -u %:echo echo $color(action) -mlti $+ %indent #
    theme.text actionchan
  }
  _redir # $_display(actionchan)
}

on ^*:NOTICE:*:#:{
  haltdef

  _addseen $nick notice $target

  var %grab = $_text.grab(notice,$1-)
  if (%grab == hide) return

  var %nw = $+(@Notice�,$target,�,$_@network)
  set -un %1 $strip($1-,mo)

  set -u %::nick $nick
  set -u %::address $iif($address,$ifmatch,n/a)
  set -un %::text %1
  set -u %::target $target
  set -u %::chan #

  ;*** SPAM detector (chan/notice)

  if (!$_isknown($fulladdress,F)) && ($nick !isop #) && (!$_isservice($nick,$site)) && ($_check.spam($1-)) {
    var %t = - ShiftF3 to view log, %i = 1
    if (!%exempt) && ($me isop #) {
      var %chan = #
      if ($_protset(spam,%chan)) && (!$_prot.disable(%chan)) && (!$_exempt.status($nick,%chan)) && (!$_exempt.ul($fulladdress,%chan)) {
        penalty spam $nick %chan $_kickmsg(spam,%chan)
      }
      else {
        set -u60 $_i(spammer) # $nick
        var %t = %t or CtrlF2 to kickban
      }
    }
    $iif($hget(x_display,spam_on_status),se,ae) $_warn Possible notice spamming from $nick ( $+ $address $+ ), halted. (ShiftF3 to view log)
    .write $+(",$logdirspamlog�,$_network,.log") $timestamp - $+ $fulladdress $+ - $strip($1-,c)
    halt
  }

  if ($_flashing.chan(#)) flash $iif(!$window(#).mdi,#) ( $+ # $+ )
  if ($beepchanmsg(#)) beep 1

  if ($window(%nw)) {
    set -u %::lb $hget(x_display,lb)
    set -u %::rb $hget(x_display,rb)
    set -u %::nick $nick(#,$nick).pnick
    if ($hget(x_display,nw.asquery)) {
      set -u %:echo echo $color(normal) -mti5 %nw
      theme.text textquery
    }
    else {
      set -u %:echo echo $color(notice) -mti5 %nw
      theme.text noticechan
    }
    return
  }

  if ($hget(x_wins,noticechan) == window) set -u %:echo _custom.echo.win $color(notice) $+(Notices�,$target) $_timestamp
  elseif ($hget(x_wins,noticechan) == channel) set -u %:echo echo $color(notice) -lmti5 #
  else set -u %:echo echo $color(notice) $iif((@* !iswm $active && $notonact),-lati5,-stlmi5)

  theme.text noticechan

  if ($away) && ($_awaylog) && ($hget(x_away,highlight.log)) && (%1 !isnum) && ($highlight) && ($highlight(%1)) {
    var %nic = $nick $+ : $+ $target
    _addawaylog # - $+ %nic $+ - $strip(%1,c)
  }

  _redir # $_display(noticechan)
}

on *:TOPIC:#:{
  if ($__i(lock.topic.,#)) {
    if ($nick != $me) {
      topic $__i(lock.topic.,#)
      rawnotice $nick (eXtreme) That topic is locked.
    }
    else {
      if ($1- != $null) set $_i(lock.topic.,#) $1-
      else unset $_i(lock.topic.,#)
    }
  }
  elseif ($1- != $null) addnewtopic # $strip($1-)
  _addseen $nick topic #
}

on *:INVITE:#:{
  event.sound invite
  if ($ajoininvite) || ($__i(invite.req.,#)) || ($istok($__i(invite.req),#,44)) || (($hget(x_sets,ajoininviteknown)) && ($_isknown($fulladdress))) var %aji = 1
  else set -u90 $_i(invited) #
  if ($istok($__i(invite.only),#,44)) set $_i(invite.only) $remtok($__i(invite.only),#,1,44)
  if (%aji) join -n #
  if ($hget(x_perform,on_invite)) _perfd $ifmatch
}

on *:OWNER:#:{
  if ($opnick == $me) {
    if ($hget(x_perform,on_ownerme)) _perfd $ifmatch
  }
  else {
    var %lev = $remove($level($ulist($address($opnick,5))),=)
    nickcol $opnick # $_getcol($opnick,%lev,#)
  }
}
on *:OP:#:{
  if ($opnick == $me) {
    if ($hget(x_perform,on_opme)) _perfd $ifmatch
  }
  else {
    var %lev = $remove($level($ulist($address($opnick,5))),=)
    nickcol $opnick # $_getcol($opnick,%lev,#)
  }
}
on *:VOICE:#:{
  if ($vnick == $me) {
    if ($hget(x_perform,on_voiceme)) _perfd $ifmatch
  }
}
on *:DEOWNER:#:{
  if ($opnick == $me) {
    if ($hget(x_perform,on_deownerme)) _perfd $ifmatch
  }
}
on *:DEOP:#:{
  if ($opnick == $me) {
    if ($hget(x_perform,on_deopme)) _perfd $ifmatch
  }
}

on *:QUIT:{
  if (!$_net($__i(network),serv.sites)) && ($_islev(20,$fulladdress)) .ruser 20 $mask($fulladdress,3)
  _addseen $nick quit
}

on *:NICK:{
  if ($nick == $me) {
    set $_i(myaddress) $puttok($__i(myaddress),$newnick,1,33)
    _set misc recnicks $qtok($hget(x_misc,recnicks),$nick,10,44)
    if ($newnick == $__i(away.mynick)) unset $_i(away.mynick)
    if ($newnick == $__i(ret.nick)) {
      if (!$__i(ret.nick.notify)) .notify -r $__i(ret.nick)
      unset $_i(ret.nick*)
    }
    if (guest* iswm $newnick) && ($hget(x_sets,recover.nick)) && (!$__i(/nick)) .timernick 1 2 nick $nick
    _--unset vars /nick
    tbar
  }
  _addseen $nick nick -> $newnick
}

;
; EOF
