;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; profiles
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

;*** profiles, unfinished

alias _rem.profile {
  var %prof = $+(config\profiles\,$1,\)
  if (%prof isin %profile) { sr -th Error You can't remove the profile you're using | halt }
  if ($isdir(%prof)) { _remove $+(%prof,*) | rmdir %prof }
  if ($show) sle Profile $1 removed.
}

alias _create.profile {
  var %prof = $+(config\profiles\,$1,\)
  ._rem.profile $1
  mkdir %prof
  if ($hget(x_display,theme)) .unload -a $ifmatch
  .ini2hash system\default.ini %prof
  if ($hget(x_display,theme)) {
    .load -a $+(thm\,$ifmatch)
    var %sch = $hget(x_display,scheme)
    set.rgbcolors $iif($_thmset(rgbcolors,%sch),$ifmatch,-) 1
    if ($_thmset(colors,%sch)) set.colors $ifmatch
  }
  else theme.unload 1
  setservices
  sle Profile $1 created
}
alias _change.profile {
  if ($1) {
    var %prof = $+(config\profiles\,$1,\)
    if (!$isdir(%prof)) { se *** Profile doesn't exist. | return }
  }
  if (%prof isin %profile) { sr -th Error You're already using that profile | halt }
  if (%prof) set %profile $ifmatch | else unset %profile
  if ($hget(x_display,theme)) .unload -a $ifmatch
  loadallhash
  if ($hget(x_display,theme)) {
    .load -a $+(thm\,$ifmatch)
    var %sch = $hget(x_display,scheme)
    set.rgbcolors $iif($_thmset(rgbcolors,%sch),$ifmatch,-) 1
    if ($_thmset(colors,%sch)) set.colors $ifmatch
  }
  else theme.unload 1
  setservices
  sle Changed to profile $iif($1,$1,default) $+ .
}
alias _getprofile {
  if ($1 isin begin.end) return -
  if (!$__i(tmp.profiles)) var %a = $finddir(config\profiles\,*,0,1,set -u2 $_i(tmp.profiles) $addtok($__i(tmp.profiles),$nopath($1-),44))
  if ($gettok($__i(tmp.profiles),$1,44)) {
    var %d = $ifmatch
if ($prop == rem) return $1 $+ . %d $+ :_rem.profile %d
    return $1 $+ . %d $+ :_change.profile %d
  }
}

;EOF
