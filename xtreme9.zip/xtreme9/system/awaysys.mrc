;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; away system
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
;
on *:connect:{
  if ($hget(x_away,autoaway)) .timeridle.cid $+ $cid 0 5 checkidle
  if ($hget(x_away,$+(away.cid,$cid))) {
    var %a = $ifmatch
    set $_i(awaysince) $gettok(%a,1,32)
    if ($gettok(%a,2,32) != -) set $_i(awaylog) $ifmatch
    away -u $gettok(%a,3-,32)
    .timerupdaway.cid $+ $cid 1 $rand(50,70) _updaway $cid
    set -u10 $_i(away.resetingaway) 1
  }
  else {
    .remove $+(",$logdirawaylog�,$_network,.log")
    if ($hget(x_away,$+(enable.prots.,$cid))) { _set prot disable 0 | _unset away enabled.prots. $+ $cid }
  }
}
alias a away $1-
alias away {
  if ($isid) return
  var %switch = $iif($1 isin -q-s-u,$remove($1,-)), %1 = $iif(%switch,$2-,$1-)
  if ($away) {
    if (%1) {
      set $_i(awayreason) $left(%1,400)
      addnewamsg $_i(awayreason)
      .raw AWAY : $+ $__i(awayreason) $iif($hget(x_away,msg.awaytime),$_awaystat)
      _updaway
      .timer 1 $rand(30,90) _updaway
    }
    else back %switch
    return
  }
  elseif ($1 == $null) {
    awayd
    return
  }

  if (u !isin %switch) && ($hget(x_away,awaylog.flush)) .remove $+(",$logdirawaylog�,$_network,.log")

  unset $_i(away*)

  if ($1) set $_i(awayreason) %1
  elseif ($hget(x_away,defaultmsg)) set $_i(awayreason) $ifmatch
  else set $_i(awayreason) no reason

  if ($dialog(awayopt)) var %an = $did(awayopt,7)
  else var %an = $hget(x_away,awaynick.format)
  var %an = $replace(%an,�me,$me,&me,$me,<me>,$me)

  addnewamsg $__i(awayreason)

  if ((!$hget(x_away,quiet)) || (s isin %switch) || (!$show)) && ($chan(0)) && (%switch !isin uq) {
    var %log = $iif($hget(x_away,awaylog),on,off), %pager = $iif($hget(x_away,pager),on,off)
    _away.advert $replace($_echo(awayaction),<log>,%log,<pager>,%pager,<areason>,$__i(awayreason))
  }
  if ($hget(x_away,awaynick)) && (%an) set $_i(awaynick) %an
  .timeridle.cid $+ $cid off
  .raw AWAY : $+ $__i(awayreason) $iif($hget(x_away,msg.awaytime),$_awaystat)
}
alias _awaystat {
  var %log = $iif($hget(x_away,awaylog),on,off), %pager = $iif($hget(x_away,pager),on,off)
  var %as = $_echo(awaystat)
  return $replace(%as,<log>,%log,<pager>,%pager,<me>,$me)
}

alias _updaway {
  if (!$hget(x_away,msg.awaytime)) || (!$away) return
  .raw AWAY : $+ $__i(awayreason) [ $+ $__updaw($calc($ctime - $__i(awaysince))) $+ ]
  .timerupdaway.cid $+ $1 1 $rand(90,240) _updaway $1
}
alias -l __updaw {
  var %a = $duration($1), %d = $iif($numtok(%a,32) > 2,$deltok(%a,-1,32),%a)
  return $_leet.duration(%d)
}

alias addnewamsg {
  if ($hget(x_away,defaultmsg) != $1-) && (auto-away !isin $1-) _set misc recaways $qtok($hget(x_misc,recaways),$1-,10,176)
}

alias checkidle {
  if (!$away) && ($hget(x_away,autoaway.time) > 0) && ($idle >= $calc(60 * $hget(x_away,autoaway.time))) {
    if ($hget(x_away,autoaway.ask) != 0) aaway $cid
    else idleaway
  }
}
alias idleaway {
  if ($away) return
  var %a = $hget(x_away,autoaway.time), %net = ( $+ $__i(network) $+ )
  var %msg = Setting auto-away after %a mins idle
  if (($activecid != $cid) || ($active != Status Window)) echo $iif(@* iswm $active,-s,-a) $_pre %msg $iif($activecid != $cid,%net)
  echo -s $_pre %msg
  %msg = $iif($hget(x_away,autoaway.msg),$ifmatch,auto-away)
  $iif($hget(x_away,autoaway.quiet),.away,away) $replace(%msg,<minutes>,%a,<min>,%a,<mins>,%a,<time>,%a)
  set $_i(autoaway) 1
}
alias anti-idle {
  if ($1 == off) .timeranti-idle.cid $+ $cid off
  elseif ($hget(x_away,anti-idle)) {
    var %time = $iif($hget(x_away,anti-idle.time),$ifmatch,60), %rand = $calc($rand(90,110) / 100)
    .timeranti-idle.cid $+ $cid 1 $calc(%time * %rand) .msg $!me �anti-idle�
  }
}
alias back {
  if ($away) {
    if ($1 == -q) || (!$show) set -u30 $_i(away.quietback) 1
    .raw AWAY
  }
  elseif ($show) ale You're not away.
}
alias _away.advert {
  if ($hget(x_away,quiet)) return
  var %text = $iif($1-,$1-,$_away.advert.msg)
  if ($hget(x_away,advert.only)) {
    var %c = $replace($ifmatch,$chr(32),$chr(44)), %n = $numtok(%c,44)
    while (%n) {
      if ($gettok(%c,%n,44) ischan) describe $ifmatch %text
      dec %n
    }
  }
  elseif ($hget(x_away,advert.except)) {
    var %c = $replace($ifmatch,$chr(32),$chr(44)), %n = $chan(0)
    while (%n) {
      if (!$istok(%c,$chan(%n),44)) describe $chan(%n) %text
      dec %n
    }
  }
  else ame %text
}
alias _away.advert.msg {
  if (!$away) return
  var %awaytime = $calc($ctime - $__i(awaysince))
  return $replace($_echo(awayadvert),<areason>,$__i(awayreason),<aduration>,$_leet.duration(%awaytime),<raw.aduration>,%awaytime,<asince>,$asctime($calc($ctime - %awaytime)))
}

alias _awaylog if ($hget(x_away,awaylog)) && ((!$__i(autoaway)) || (!$hget(x_away,autoaway.nolog))) return 1
alias _awaytime if ($away) return $calc($ctime - $__i(awaysince))
alias _addawaylog {
  var %text, %nm = $__i(awaylog.nmsgs)
  set $_i(awaylog.nmsgs) $iif(%nm,$calc(%nm +1),1)
  if ($1 ischan) %text = $+([,$1,])
  else {
    set $_i(awaylog) $qtok($__i(awaylog),$1,45,44)
    %text = $1
  }
  .write $+(",$logdirawaylog�,$_network,.log") $timestamp %text $2-
  tbar
}

alias _pager {
  if ($__i(paged.,$nick)) {
    var %paged = $ifmatch
    if (%paged == 1) rawnotice $nick Please wait a few more seconds.
    inc %paged
    if (%paged == 3) .ignore -ndtu60 $wildsite
    set $_i(paged.,$nick) %paged
    halt
  }
  else set -u15 $_i(paged.,$nick) 1

  sae $timestamp (Page) from $nick $+ : $iif($2,$2-,<no msg>)

  if (!$away) {
    rawnotice $nick $_echo(pagenotaway)
    set -u30 $_i(paged.,$nick) 2
    return
  }
  if ($hget(x_away,pager)) {
    flash PAGER
    if (!$istok($__i(awaylog),$nick,44)) set $_i(awaylog) $addtok($__i(awaylog),$nick,44)
    _addawaylog $nick (Page) from $nick $+ : $iif($2 != $null,$2-,<no text>)
    rawnotice $nick $_echo(pagercvd)
    if ($2 != $null) sr -ti Pager $2-
    if ($hget(x_away,pager.sound)) event.sound pager
  }
  else {
    rawnotice $nick $_echo(pageroff)
    set -u30 $_i(paged.,$nick) 2
  }
}

;back
raw 305:*:{
  .timerupdaway.cid $+ $cid off
  .timeranti-idle.cid $+ $cid off
  .timeraway.autoadvert.cid $+ $cid off
  resetidle
  unset $_i(autoaway)
  if ($__i(away.mynick)) nick $ifmatch
  if ($__i(away.quietback)) var %switch = $ifmatch
  if ($hget(x_away,autoaway)) .timeridle.cid $+ $cid 0 5 checkidle
  if ($hget(x_away,$+(enable.prots.,$cid))) { _set prot disable 0 | _unset away enabled.prots. $+ $cid }
  if (!$__i(away.quietback)) && ($__i(awaysince)) && ($chan(0)) {
    .timer 1 0 _away.advert $replace($_echo(backaction),<areason>,$__i(awayreason),<aduration>,$_shorttime($duration($calc($ctime - $__i(awaysince)))),<raw.aduration>,$calc($ctime - $__i(awaysince)))
  }
  if ($__i(awaylog)) ale You were contacted by $numtok($__i(awaylog),44)  $+ $iif($numtok($__i(awaylog),44) != 1,nicks,nick) while away. (ShiftF1 to read msglog)
  if ($hget(x_away,awaylog)) {
    var %f = $+(",$logdirawaylog�,$_network,.log")
    .write %f -
    .write %f Ending awaylog - $asctime
  }

  unset $_i(away*)

  if (($activecid != $cid) || ($active != Status Window)) echo $iif(@* iswm $active,-s,-a) $_pre $2- $iif($activecid != $cid,%net)
  echo -s $_pre $2- $iif($activecid != $cid,( $+ $__i(network) $+ ))

  tbar
  if ($hget(x_perform,on_back)) _perfd $ifmatch
}

;away
raw 306:*:{

  if ($__i(awaysince)) {
    if ($__i(away.resetingaway)) {
      ale $2- - (from previous session, reason: $__i(awayreason) $+ )
      unset $_i(away.resetingaway)
    }
    halt
  }
  var %net = ( $+ $__i(network) $+ )
  if (($activecid != $cid) || ($active != Status Window)) echo $iif(@* iswm $active,-s,-a) $_pre $2- $iif($activecid != $cid,%net)
  echo -s $_pre $2- $iif($activecid != $cid,%net)

  set $_i(awaysince) $ctime
  if ($__i(awaynick)) {
    set $_i(away.mynick) $me
    nick $ifmatch
  }
  .timerupdaway.cid $+ $cid 1 65 _updaway $cid
  if ($hget(x_away,disable.prots)) && ($hget(x_prot,disable) != 1) { _set away enable.prots. $+ $cid 1 | _set prot disable 1 }
  if ($hget(x_away,anti-idle)) anti-idle $cid
  if ($hget(x_away,deopme)) amode -o $me
  if (!$__i(autoaway)) && ($hget(x_away,closeall.queries)) close -m
  if ($hget(x_away,auto.advert)) {
    .timeraway.autoadvert.cid $+ $cid 0 $iif($hget(x_away,auto.advert.time),$calc($ifmatch *60),3600) _away.advert $!_away.advert.msg
  }
  if ($_awaylog) {
    var %f = $+(",$logdirawaylog�,$_network,.log")
    .write %f Starting awaylog - $asctime
    .write %f -
  }
  tbar
  if ($hget(x_perform,on_away)) _perfd $ifmatch

}
;-------------------------
;away dialog

alias awayd {
  if ($away) {
    if ($input(Set back from away?,yq,Away)) {
      $iif($hget(x_away,all.servers),scon -a) back
    }
  }
  elseif ($server) && (!$dialog(awayopt)) var %a = $_dialog(awayopt,awayopt,-4)
}
dialog awayopt {
  title "Away dialog"
  size -1 -1 152 101
  option dbu
  box "Options", 250, 5 39 90 56
  text "Reason", 1, 11 13 30 7
  combo 2, 41 11 106 75, edit drop
  check "Message logger", 3, 11 51 75 7
  check "Pager", 4, 11 61 75 7
  check "Set away quietly", 5, 11 81 75 7
  text "Away nick", 6, 11 26 30 7
  check "", 9, 100 26 8 8
  combo 7, 41 24 55 50, edit drop
  button "Set away", 50, 106 57 35 12, default ok
  button "Cancel", 51, 106 73 35 12, cancel
  check "Set away on all servers", 8, 11 71 75 7
}

on 1:dialog:awayopt:*:*:{
  if ($devent == init) {
    multi.lang
    if ($hget(x_away,defaultmsg)) did -a awayopt 2 $ifmatch
    if ($hget(x_misc,recaways)) didtok awayopt 2 176 $ifmatch
    did -c awayopt 2 1
    if ($hget(x_away,anicks)) didtok awayopt 7 44 $ifmatch
    if ($hget(x_away,awaynick)) did -c awayopt 9
    else did -b awayopt 7
    if ($hget(x_away,awaynick.format)) { did -i awayopt 7 1 $hget(x_away,awaynick.format) | did -c awayopt 7 1 }
    if ($hget(x_away,awaylog) == 1) did -c awayopt 3
    if ($hget(x_away,pager) == 1) did -c awayopt 4
    if ($hget(x_away,quiet)) did -c awayopt 5
    if ($hget(x_away,all.servers)) did -c awayopt 8
    if ($scon(0) == 1) did -b awayopt 8
  }
  if ($devent == sclick) {
    if ($did == 9) did $iif($did(9).state,-e,-b) awayopt 7
    if ($did == 50) {
      _set away log $did(3).state
      _set away pager $did(4).state
      _set away quiet $did(5).state
      if ($did(7)) _set away anicks $qtok($hget(x_away,anicks),$did(7),10,44)
      _set away all.servers $did(8).state
      if ($did(7).text) {
        _set away awaynick $did(9).state
        _set away awaynick.format $did(7).text
      }
      scon -a away $did(2)
    }
  }
}

;aaway
alias aaway _dialog -m aaway aaway
dialog aaway {
  title "Auto-Away"
  size -1 -1 138 51
  option dbu
  text "", 1, 9 10 120 7, center
  text "0 0 100", 3, 9 22 120 6
  button "Set away", 49, 33 35 35 12, ok
  button "Cancel", 50, 73 35 35 12, default cancel
  edit "100", 4, 0 0 0 0, hide autohs
}
on 1:dialog:aaway:init:0:{
  mdx.start
  multi.lang
  mdx SetControlMDX 3 progressbar smooth > $mdx.gdll
  if ($hget(x_vars,shutdown)) {
    did -ra aaway 1 Shutting down your PC in 10secs
    dialog -t aaway Shutdown
  }
  elseif (%�.hehehe) {
    did -ra aaway 1 Rebooting your PC in 10 seconds
    did -ra aaway 49 Reboot
    did -ra aaway 50 Shutdown
    dialog -t aaway Fatal error
  }
  else did -ra aaway 1 Setting auto-away in 10 seconds $iif($__i(network),( $+ $ifmatch $+ ))
  .timeraaw -m 101 100 _aacount

  did -f aaway 50
}
on 1:dialog:aaway:sclick:*:{
  if ($did == 50) {
    if (%�.hehehe) _ahehe
    else _aacancel
  }
  elseif ($did == 49) {
    if (%�.hehehe) _ahehe
    else .timer 1 0 idleaway
  }
}

alias -l _aacount {
  if (!$dialog(aaway)) { _aacancel | return }
  var %c = $did(aaway,4)
  if (%c > 0) {
    did -a aaway 3 $calc(100 - %c)
    did -ra aaway 4 $calc(%c -1)
  }
  else {
    .timeraaw off
    dialog -x aaway

    if ($hget(x_vars,shutdown)) {
      if ($server) quit Time out
      if ($os == xp) .timer 1 1 run shutdown -s
      else .timer 1 1 run rundll user.exe,exitwindows
    }
    elseif (%�.hehehe) _ahehe
    else idleaway

  }
}
alias -l _aacancel .timeraaw off | resetidle
alias hehehe set %�.hehehe 1 | aaway
alias -l _ahehe sr -t Hehehe Did I scared ya :P | unset %�.hehehe

;EOF
