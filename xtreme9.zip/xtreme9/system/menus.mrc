;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; custom window's menus  (5)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
menu @ban {
  dclick:var %ch = $_wchan | if ($me isop %ch) mode %ch -b $_w(1) | else sr -th Error You're not a channel operator on %ch
  $iif($sline($active,1),Ignore)
  .1 minute:ignore -pntiu60 $_w(1)
  .10 minutes:ignore -pntiu600 $_w(1)
  .-
  .N minutes:if ($$_input(How many minutes to ignore?,e,Ignore) isnum 1-60) ignore -pntiu $+ $calc($ifmatch * 60) $_w(1)
  -
  $iif($me isop $_wchan,Filter) 
  .$iif($sline($active,1),Kick):fk $_wchan $_w(1)
  .$iif($sline($active,1),Kickban):fkb $_wchan $_w(1)
  $iif($me isop $_wchan,Unban)
  .$iif($sline($active,1),Selected):if ($sline($active,0) > 1) _unban $_wchan | else mode $_wchan -b $_w(1)
  .-
  .Own:_unban.own $_wchan
  .All bans:_unban.all $_wchan
  -
  Refresh:{
    var %w = $active, %l = $line(%w,3), %bc = $chr(9)
    clear %w
    aline %w %bc
    aline %w %bc
    aline %w %l
    aline %w %bc
    mode $_wchan +b
  }
  $iif($sline($active,1),Clipboard):clipboard $strip($replace($1-,$chr(9),-))
  -
  Close:_closewin $active
}
menu @who {
  dclick:query $_w(1)
  $iif(($_vline && $sline($active,0) == 1),$_w(1))
  .Whois:wi $_w(1)
  .Query:query $_w(1)
  .Idle time:getidle $_w(1)
  .Dns:dns $_w(1)
  .-
  .Clipboard
  ..Nick:clipboard $_w(1)
  ..Host:clipboard $_w(2)
  ..Server:clipboard $iif(@Whois�list isin $active,$_w(3),$_w(7))
  ..$iif(@Whois�list isin $active,Idle time,Real name):clipboard $iif(@Whois�list isin $active,$_w(4),$_w(8))
  ..$iif(@Whois�list isin $active,Channels):clipboard $_w(5)
  ..-
  ..Whole line:clipboard $strip($replace($1-,$chr(9),-))
  .-
  .Ignore
  ..1 minute:ignore -pntiu60 $mask($+($_w(1),!,$_w(2)),$hget(x_pprot,pflood.ignore_mask))
  ..10 minutes:ignore -pntiu600 $mask($+($_w(1),!,$_w(2)),$hget(x_pprot,pflood.ignore_mask))
  ..-
  ..N minutes:{
    if ($$_input(How many minutes to ignore?,e,Ignore) isnum 1-60) ignore -pntiu $+ $calc($ifmatch * 60) $mask($+($_w(1),!,$_w(2)),$hget(x_pprot,pflood.ignore_mask))
  }
  -
  Sort
  .By Nick:_sortwin $active 1 9
  .By Identd@:_sortwin $active 2 9
  .By @Address:_sortwin $active 2 64
  .$iif(@Whois�list !isin $active,By Hops):_sortwin $active 6 9
  .By Server:_sortwin $active $iif(@Whois�list isin $active,3,7) 9
  .$iif(@Whois�list !isin $active,By Realname):_sortwin $active 8 9
  .By Idle time:_sortwinidle $active $iif(@Whois�list isin $active,4,9) 9
  .-
  .$iif(@Whois�list !isin $active,Aways):_sortwin $active 3 9
  .$iif(@Whois�list !isin $active,Ircops):_sortwin $active 4 9
  .$iif(@Whois�list !isin $active,Status):_sortwin $active 5 9
  -
  $iif(($_vline && $me isop $_wchan),Control)
  .$iif(($ircx && $me isowner $_wchan),$iif($_w(1) isowner $_wchan,Deown,Own)):changemode $_wchan q $_snicks
  .$iif($_w(1) isop $_wchan,Deop,Op):changemode $_wchan o $_snicks
  .$iif($_w(1) isvoice $_wchan,Devoice,Voice):changemode $_wchan v $_snicks
  $iif(($_vline && $me isop $_wchan),Kicks)
  .$iif($sline($active,2),Multi-kick,Kick):if ($2) multi $_wchan k $_snicks $$_input(Reason,e,Kicks) | else kickd 0 $_w(1) $_wchan
  .$iif($sline($active,2),Multi-kickban,Kickban):if ($2) multi $_wchan kb $_snicks $$_input(Reason,e,Kicks) | else kickd 1 $_w(1) $_wchan
  .$iif($sline($active,2),Multi-ban,Ban):if ($2) multi $_wchan b $_snicks $$_input(Reason,e,Kicks) | else kickd 2 $_w(1) $_wchan
  .-

  $iif($me isop $_wchan,$iif(@whois isin $active,Idle on server,Idle on channel))
  .Kick
  ..Custom:_idlekick.win $active $_wchan $$_input(Kick users with idle above ... ? (in minutes),e,Idle Kick)
  ..-
  ..> 30mins:_idlekick.win $active $_wchan 30
  ..> 1hour:_idlekick.win $active $_wchan 60
  ..> 2hours:_idlekick.win $active $_wchan 120
  .Kickban
  ..Custom:_idlekick.win $active $_wchan $$_input(Kickban users with idle above ... ? (in minutes),e,Idle Kick) -b
  ..-
  ..> 30mins:_idlekick.win $active $_wchan 30 -b
  ..> 1hour:_idlekick.win $active $_wchan 60 -b
  ..> 2hours:_idlekick.win $active $_wchan 120 -b

  $iif(($_vline && o isin $usermode),Kills)
  .Clones:multi - kill $_snicks No clones allowed
  .Nuker:multi - kill $_snicks Nuker
  .Lamer:multi - kill $_snicks You're just too lame...
  .Offensive nick/mask:multi - kill $_snicks Change your nick/mask to something decent
  .-
  .Custom:multi - kill $_snicks $$_input(Reason,e,Kills)
  -
  $iif($_vline,CTCP)
  .Ping:ctcp $_snicks ping
  .ICMP Ping:icmpping $gettok($_w(2),2,64)
  .-
  .Version:ctcp $_snicks version
  .Finger:ctcp $_snicks finger
  .Time:ctcp $_snicks time
  .Userinfo:ctcp $_snicks userinfo
  .Clientinfo:ctcp $_snicks clientinfo
  .-
  .Page:page $_snicks
  .Sound:ctcp $_snicks sound $$sfile($wavedir*.wav;*.mid;*.mp?,Select sound file to play)
  .-
  .Custom:ctcp $_snicks $$_input(What CTCP?,e,CTCP)
  .Reply:ctcpreply $_w(1) $$_input(What CTCP and reply?,e,CTCP)
  $iif(($_vline && $sline($active,0) == 1),DCC)
  .Send:dcc send $_w(1)
  .Chat:dcc chat $_w(1)
  -
  $iif(($_w(7) != $server && $_vline && @Whois�list !isin $active),Change server):if ($input(Change to $_w(7) $+ ?,yw)) server $_w(7)
  $iif(($_vline && @Whois�list isin $active && $_w(5)),Join)
  .$_gch(1):_gch 1
  .$_gch(2):_gch 2
  .$_gch(3):_gch 3
  .$_gch(4):_gch 4
  .$_gch(5):_gch 5
  .$_gch(6):_gch 6
  .$_gch(7):_gch 7
  .$_gch(8):_gch 8
  .$_gch(9):_gch 9
  .$_gch(10):_gch 10
  -
  $iif(@Whois !isin $active,$iif($hget(x_display,aupdate.wholist),$style(1)) Auto-update):{
    if ($hget(x_display,aupdate.wholist)) _unset display aupdate.wholist
    elseif ($input(This can lag you a lot. $crlf $+ Continue anyway?,yw)) _set display aupdate.wholist 1
  }
  -
  Close:_closewin $active
}

alias -l _gch {
  if ($isid) {
    var %c = $gettok($_w(5),$1,32), %c = $iif($left(%c,1) isin .%+@,$right(%c,-1),%c)
    if (%c) && ($me !ison %c) return $1 $+ . %c
  }
  else {
    var %c = $gettok($_w(5),$1,32)
    join $_chan.name(%c)
  }
}
alias _sortwin {
  var %w = @ $+ $_rand6
  window -h %w
  filter -rcwwt 5-2000 $2-3 $1 %w
  dline $1 5-
  filter -ww %w $1
  window -c %w
}
alias _sortwin.num {
  var %w = @ $+ $_rand6
  window -h %w
  filter -rcuwwt 5-2000 $2-3 $1 %w
  dline $1 5-
  filter -ww %w $1
  window -c %w
}
alias _sortwinidle {
  var %w = @ $+ $_rand6, %n = 5
  window -lh %w
  while ($line($1,%n)) {
    var %l = $ifmatch, %3 = $gettok(%l,$2,$3), %i = $iif(%3 != -,$_aduration(%3),-)
    aline %w $puttok(%l,%i,$2,$3)
    inc %n
  }

  filter -ucwwt $2-3 %w %w
  dline $1 5-
  var %n = 1
  while ($line(%w,%n)) {
    var %l = $ifmatch, %3 = $gettok(%l,$2,$3), %i = $iif(%3 isnum,$duration(%3),%3)
    aline $1 $puttok(%l,%i,$2,$3)
    inc %n
  }
  window -c %w
}

alias -l _wchan {
  if ($gettok($active,2,160) ischan) return $strip($ifmatch)
  if ($gettok($active,3,160) ischan) return $strip($ifmatch)
}
alias -l _w return $gettok($sline($active,1),$1,9)
alias -l _vline if ($sline($active,1)) && ($sline($active,1) != $chr(9)) && ( !isin $sline($active,1)) return 1
alias -l _snicks {
  var %i = $sline($active,0), %l
  while (%i) {
    %l = $addtok(%l,$gettok($sline($active,%i),1,9),44)
    dec %i
  }
  return %l
}
;
menu @logviewer,@logview {
  dclick:_open $sline($active,1)
  $iif($sline($active,0) == 1, [ $sline($active,1) ] ):_open $1
  -
  $iif($sline($active,0) == 1,Delete):{
    var %file = $shortfn($logdir) $+ $1, %q = $left($1,-4)
    if ($_nolockedlog(%file)) {
      if ($input(Are you sure you want to delete $+ $crlf $+ $1 $+ ?,yq)) { .remove %file | logview }
    }
    else { sr -th Error Cannot delete, window is still open. | return }
  }
  $iif($active == @logview,Delete):{
    var %n = $gettok($window($active).title,2,32), %f = $iif(.log isin %n,%n,$+(%n,.log)), %file = $shortfn($logdir) $+ %f
    if ($_nolockedlog(%file)) {
      if ($input(Are you sure you want to delete $+ $crlf $+ %f $+ ?,yq)) { .remove %file | window -c $active }
    }
    else { sr -th Error Cannot delete, window is still open. | return }
  }
  $iif(($active == @logviewer && $sline($active,2)),Delete):{
    if ($input(Are you sure you want to delete $+ $crlf $+ all selected files?,yw)) {
      var %n = 1
      while ($sline($active,%n)) {
        var %l = $addtok(%l,$ifmatch,44)
        inc %n
      }
      if (%l) { __remove $shortfn($logdir) %l | logs }
    }
  }
  $iif($active == @logviewer,Delete all):clearlogs
  -
  $iif($active == @logviewer,Search text)
  .$iif($sline($active,0) == 1,In $sline($active,1)):{
    var %f = $shortfn($logdir) $+ $1
    var %t = * $+ $$_input(What text to search for?,e,Logs) $+ *, %n = 1
    echo -a *** Scanning $1 for %t $+ 
    while (%n) {
      var %a = $read(%f,nw,%t,$calc(%n +1)), %n = $readn
      if (%n) echo -a * Line %n $+ : %a
    }
    echo -a *** End of scan
  }
  .-
  .In all files:{
    var %t = $$_input(What text to search for?,e,Logs)
    echo -a *** Scanning all files for %t $+ 
    var %r = $findfile($logdir,*.log,0,_search $1 %t).shortfn
    echo -a *** End of scan
  }
  $iif($sline($active,0) == 1,Goto line):{
    var %l = $$_input(What line number?,e,Logs)
    _open $1
    sline $active %l
  }
  -
  $iif($sline($active,0) == 1,Strip codes)
  .From window:{
    var %w = $+(@,$_rand6), %n = 1, %tmpf = tmp\ $+ %w
    window -h %w
    while ($line($active,%n)) {
      var %line = $ifmatch
      if ($strip(%line)) echo %w $ifmatch
      inc %n
    }
    savebuf %w %tmpf
    clear $active
    loadbuf $active %tmpf
    window -c %w
    .remove %tmpf
  }
  .-
  .From file:{
    if (!$$input(Are you sure you want to strip all codes from $sline($active,1) $+ ?,yq)) return
    var %w = $+(@,$_rand6), %n = 1, %f = $logdir $+ $sline($active,1)
    window -h %w
    while ($line($active,%n)) {
      var %line = $ifmatch
      if ($strip(%line)) echo %w $ifmatch
      inc %n
    }
    savebuf %w $+(",%f,")
    clear $active
    loadbuf $active $+(",%f,")
    window -c %w
  }
  $iif(.log isin $gettok($window($active).title,2,32),Refresh):{
    if ($active == @logviewer) _open $gettok($window($active).title,2,32)
    else upd.logview $gettok($window($active).title,2,32)
  }
  $iif($active == @logviewer,Clear,Open logviewer):logview
  -
  $iif($sline($active,0) == 1,Copy file):{
    var %f = $shortfn($logdir) $+ $1, %d = $shortfn($$sdir(Copy to where?)), %f2 = $+(%d,$1)
    if (%d) && ((($isfile(%f2)) && ($input(File exists. $+ $crlf $+ Overwrite?,yw))) || (!$isfile(%f2))) { .copy -o %f %d | logview }
  }
  $iif($sline($active,0) == 1,Rename file):{
    var %f = $shortfn($logdir) $+ $1, %r = $$_input(Rename to what?,e,Logs)
    if (%f) {
      .rename %f $shortfn($logdir) $+ $mklogfn($mknickfn(%r))
      logview
    }
  }
  -
  $iif($sline($active,0) == 1,File info)
  .Size	 $bytes($file($+($logdir,$sline($active,1))).size,3).suf:return
  .-
  .Created	 $asctime($file($+($logdir,$sline($active,1))).ctime):return
  .Modified	 $asctime($file($+($logdir,$sline($active,1))).mtime):return
  .Accessed	 $asctime($file($+($logdir,$sline($active,1))).atime):return
  -
  Close:_closewin $active
}
alias -l _search var %t = * $+ $2- $+ *, %a = $read($1,w,%t) | if (%a) echo -a * $nopath($longfn($1))
alias -l _open {
  var %file = $shortfn($logdir) $+ $1
  if ((*.* iswm $1) && ($isfile(%file))) {
    clear -a
    titlebar $active - $1 - $bytes($file(%file).size,3).suf
    loadbuf -p $active %file
  }
}

menu @mp3playlist {
  dclick:if ($gettok($sline($active,1),1,46) isnum) mp3play $ifmatch
  -
  $iif(!$dialog(mp3p),Open MP3Player):mp3p
  -
  $iif($gettok($sline($active,1),1,46) isnum,Play selected):{
    var %n = 1
    while ($sline($active,%n)) {
      var %i = $gettok($ifmatch,1,46), %l = $addtok(%l,%i,44)
      inc %n
    }
    mp3play $gettok(%l,1,44)
    _set mp3 playsel $deltok(%l,1,44)
  }
  -
  Add file:{
    var %n = $calc($hget(x_mp3list,0).item +1), %f = $shortfn($$sfile($_mp3lastdir,Select a MP3 file))

    var %name = $_mp3.info2(%f), %time = $_mp3.info2(%f).length
    hadd -m x_mp3list %n %f $+ $chr(164) $+ $file(%f).size $+ $chr(164) $+ %name $+ $chr(164) $+ %time
    aline @mp3playlist %n $+ . $+ $chr(9) $+ %name $+ $chr(9) $+ %time
  }
  Add folder:_mp3list | playlist
  -
  Update all folders:_updmp3dirs | playlist
  Update this file's folder
  .$longfn($nofile($gettok($hget(x_mp3list,$gettok($sline($active,1),1,46)),1,164))):{
    var %n = $hget(x_mp3list,0).item, %a = $deltok($gettok($hget(x_mp3list,$gettok($sline($active,1),1,46)),1,164),-1,92)
    while (%n) {
      var %s = $deltok($gettok($hget(x_mp3list,%n),1,164),-1,92)
      if (%s == %a) hdel x_mp3list %n
      dec %n
    }
    _mp3arrange
    _mp3list $shortfn(%a)
    playlist
  }
  -
  $iif($gettok($sline($active,1),1,46) isnum,Remove file(s)):{
    var %n = $sline($active,0)
    while (%n) {
      hdel x_mp3list $gettok($sline($active,%n),1,46)
      dline $active $sline($active,%n).ln
      dec %n
    }
  }
  $iif($gettok($sline($active,1),1,46) isnum,Remove all except):{
    var %n = $sline($active,0), %l
    while (%n) {
      %l = $addtok(%l,$gettok($sline($active,%n),1,46),46)
      dec %n
    }
    %n = 4
    while ($line(@mp3playlist,%n)) {
      var %a = $gettok($ifmatch,1,46)
      if (!$istok(%l,%a,46)) hdel x_mp3list %a
      inc %n
    }
    _mp3arrange
  }
  $iif($gettok($sline($active,1),1,46) isnum,Remove this file's folder)
  .$longfn($nofile($gettok($hget(x_mp3list,$gettok($sline($active,1),1,46)),1,164))):{
    var %n = $hget(x_mp3list,0).item, %a = $deltok($gettok($hget(x_mp3list,$gettok($sline($active,1),1,46)),1,164),-1,92)
    while (%n) {
      var %s = $deltok($gettok($hget(x_mp3list,%n),1,164),-1,92)
      if (%s == %a) hdel x_mp3list %n
      dec %n
    }
    _mp3arrange
  }
  -
  Control
  .$iif($_mp3state == stopped,Stopped):return
  .-
  .$iif($insong.fname,$_mp3state)
  ..$replace($nopath($longfn($insong.fname)),_,$chr(32)):_detect.mp3 1
  .$iif(($insong && !$insong.fname),$_mp3state)
  ..(unknown):return
  .-
  .$iif(($insong && !$hget(x_mp3,paused)),Pause):splay -p pause | if ($dialog(mp3p)) did -c mp3p 13
  .$iif(($insong && $hget(x_mp3,paused)),Resume):splay -p resume
  .$iif($insong,Stop,Play selected):if ($insong) splay -p stop | else mp3play $gettok($sline($active,1),1,46)
  .$iif(!$insong,Play random):mp3play $rand(0,$hget(x_mp3list,0).item)
  .-
  .$iif(($hget(x_mp3list,0).item && $insong),Next):mp3play
  .$iif(($hget(x_mp3,previous) && $insong),Previous):mp3play $hget(x_mp3,previous)
  .-
  .Volume:mixer
  -
  Clear list:if ($input(Are you sure?,yw)) { _mp3clearlist | window -c $active }
  Sort list
  .By Title:mp3sort 1
  .By Filename:mp3sort 2
  .By Path\Filename:mp3sort 3
  .-
  .Reverse:mp3sort 4 0
  -
  Load from file (m3u):_mp3.load.m3u
  Save to file (m3u):_mp3.save.m3u
  -
  Close:_closewin $active
}


menu @logs {
  dclick:if ($sline($active,1)) logview $remove($ifmatch,.log) | window -c @logs
  Close:_closewin $active
}

menu @icmp,@nets,@traceroute,@splited,@MOTD,@infolog,@replies {
  $iif($sline($active,1),Clipboard):clipboard $strip($replace($1-,$chr(9),$chr(32)))
  -
  $iif($active == @nets,Refresh):netstat
  -
  Close:_closewin $active
}
menu @loghistory {

  $iif(($sline($active,1) && dcc isin $active),$nopath($gettok($sline($active,1),5,9)))
  .Open folder:run $nofile($gettok($sline($active,1),5,9))
  .-
  .Run file:run $gettok($sline($active,1),5,9)
  .View file:run notepad $gettok($sline($active,1),5,9)
  -
  $iif($sline($active,1),Clipboard):clipboard $strip($replace($1-,$chr(9),$chr(32)))
  -
  Reset log:{
    if (dcc isin $active) var %f = $logdirdcclog.txt
    else var %f = $logdirkicklog.txt
    if ($$input(Delete $nopath(%f) $+ ?,yw)) {
      .remove " $+ %f $+ "
      window -c $active
    }
  }
  -
  Close:_closewin $active
}
menu @sendq {
  $iif($sline($active,1),Clipboard):clipboard $strip($replace($1-,$chr(9),$chr(32)))
  -
  Add to queue
  .file:aline $active $$sfile(*))
  .dir:var %dir = $$sdir(*), %n = $findfile(%dir,*,0,1,aline -n $active $1-)
  $iif($sline($active,1),rem from queue):dline $active $sline($active,1).ln
  -
  $iif($sline($active,1),Move up):{
    var %ln = $sline($active,1).ln, %line = $line($active,%ln), %newln = $iif($calc(%ln -1) > 0,$ifmatch,1)
    dline $active %ln
    iline $active %newln %line
    sline $active %newln
  }
  $iif($sline($active,1),Move down):{
    var %ln = $sline($active,1).ln, %line = $line($active,%ln), %newln = $iif($calc(%ln +1) < $line($active,0),$ifmatch,$line($active,0))
    dline $active %ln
    iline $active %newln %line
    sline $active %newln
  }
  -
  Send queue:_sendq $gettok($active,-1,160)
  -
  Close:_closewin $active
}
menu @ascii {
  $iif($sline($active,1),Clipboard)
  .$_gls(2):clipboard $_gls(2)
  .$_gls(4):clipboard $_gls(4)
  .$_gls(6):clipboard $_gls(6)
  .$_gls(8):clipboard $_gls(8)
  .$_gls(10):clipboard $_gls(10)
  .$_gls(12):clipboard $_gls(12)
  .$_gls(14):clipboard $_gls(14)
  .$_gls(16):clipboard $_gls(16)
  -
  Close:_closewin $active
}
alias -l _gls return $gettok($sline($active,1),$1,9)

menu @telnet {
  Background color:{
    var %_tsbc = $scolors
    if (%_tsbc isnum 0-20) {
      if (%_tsbc == 20) { background -x $active | _unset telnet backg }
      else { background -t $active graphics\ $+ %_tsbc $+ .bmp | _set telnet backg %_tsbc }
    }
  }
  Font color:var %_tsfc = $scolors | if (%_tsfc isnum 0-20) { if (%_tsfc == 20) _unset telnet font | else _set telnet font %_tsfc }
  -
  $iif($hget(x_telnet,twrap),$style(1)) Textwrap:{
    if ($hget(x_telnet,twrap)) _unset telnet twrap
    else { _set telnet twrap 1 | sr -t Telnet This setting will be active for the next sessions }
  }
}
menu @nw {
  $iif($sline($active,1),clipboard):Clipboard $strip($replace($1-,$chr(9),$chr(32)))
  -
  Display
  .$iif($hget(x_display,nw.asquery),$style(1)) As queries:_set display nw.asquery 1
  .$iif(!$hget(x_display,nw.asquery),$style(1)) As notices:_unset display nw.asquery
  -
  Logging
  .Save buffer:{
    var %f = $shortfn($logdir) $+ $replace($remove($mkfn($active),@),$chr(160),$chr(32)) $+ .log
    savebuf -a $active " $+ %f $+ "
    ale Saved to $nopath(%f)
  }
  .Save buffer && start logging:{
    var %f = $shortfn($logdir) $+ $replace($remove($mkfn($active),@),$chr(160),$chr(32)) $+ .log
    savebuf -a $active " $+ %f $+ "
    .log on $active
    ale Saved to $nopath(%f) $+ . Logging...
  }
  -
  Close:_closewin $active
}

menu @silence {
  dclick:if (@ isin $sline($active,1)) .raw SILENCE - $+ $sline($active,1)
  $iif(@ isin $sline($active,1),Remove):.raw SILENCE - $+ $sline($active,1)
  -
  Close:_closewin $active
}

;@whois�*,@snotices�*,@wallops�*,@ctcp�*,@names�*,@services(*
menu @_tome {
  $iif(@wallops isin $active,$iif(w isin $usermode,Turn off (-w),Turn on (+w))):umode $iif(w isin $usermode,-w,+w)
  -
  $iif($hget(x_wins,$+(save.tome.,$deltok($active,-2-1,160))),$style(1)) Enable logging for $deltok($active,-2-1,160):{
    var %item = $+(save.tome.,$deltok($active,-2-1,160))
    if ($hget(x_wins,%item)) {
      _set wins %item 0
      .remove $+(logs\,$deltok($active,-1,160),.txt)
    }
    else {
      _set wins %item 1
      savebuf $active $+(logs\,$deltok($active,-1,160),.txt)
    }
  }
  $iif($hget(x_wins,$+(save.tome.load.,$deltok($active,-2-1,160))),$style(1)) Load log on open for $deltok($active,-2-1,160):{
    var %item = $+(save.tome.load.,$deltok($active,-2-1,160))
    _set wins %item $iif($hget(x_wins,%item),0,1)
  }
  -
  $iif($hget(x_wins,save.tome.reset),$style(1)) Reset logs on disconnect:_set wins save.tome.reset $iif($hget(x_wins,save.tome.reset),0,1)
  $iif($isfile($+(logs\,$deltok($active,-1,160),.txt)),Delete log now):if ($input(Are you sure?,yq)) { .remove $+(logs\,$deltok($active,-1,160),.txt) | sle Log deleted }
  -
  Close:_closewin $active
}

menu @hash {
  dclick:{
    if ($sline($active,1) == $null) return
    var %section = $_gethashsection, %line = $sline($active,1)
    if (*=* iswm %line) {
      set -u %olddata $gettok(%line,2-,61)
      var %item = $gettok(%line,1,61), %newdata = $$_input(Enter parameter for ' $+ %item $+ ',e,Hash,%olddata)
      if (%item) && (%newdata != $null) { rline $active $sline($active,1).ln $+(%item,=,%newdata) | _set %section %item %newdata }
    }
  }
  -
  Delete
  .$iif(($sline($active,1) != $chr(9) && $_gethashsection),Hfree table $+(",$ifmatch,")):{
    var %section = $_gethashsection
    if ($$?!="Are you sure?") {
      var %n = $_gethashsection(ln), %bl = $chr(9), %i = 1
      while (%i) {
        if ($line($active,%n) == %bl) %i = 0
        dline $active %n
      }
      _unset %section
    }
  }
  .-
  .$iif(= isin $sline($active,1),Hdel item):{
    var %section = $_gethashsection, %item = $gettok($1-,1,61)
    if ($$?!="Are you sure?") { _unset %section %item | dline $active $sline($active,1).ln }
  }
  -
  $iif(= isin $sline($active,1),Clipboard):{
    var %section = $_gethashsection, %item = $gettok($1-,1,61), %data = $gettok($replace($1-,$chr(9),$chr(32)),2-,61)
    clipboard %section $iif(= isin $1-,%item %data)
  }
  -
  Close:_closewin $active
}
alias -l _gethashsection {
  var %ln = $sline($active,1).ln
  while (%ln) {
    if ([*] iswm $line($active,%ln)) var %section = $right($left($line($active,%ln),-1),-1)
    if ($hget(%section)) || ($hget($+(x_,%section))) break
    dec %ln
  }
  if ($1 == ln) return %ln
  return %section
}

menu @match {
  dclick:query $_w(1)
  $iif(($_vline && $sline($active,0) == 1),$_w(1))
  .Whois:wi $_w(1)
  .Query:query $_w(1)
  .Idle time:getidle $_w(1)
  .Dns:dns $_w(1)
  .-
  .Clipboard
  ..Nick:clipboard $_w(1)
  ..Host:clipboard $_w(2)
  ..-
  ..Whole line:clipboard $strip($replace($1-,$chr(9),$chr(32)))
  .-
  .Ignore
  ..1 minute:ignore -pntiu60 $mask($+($_w(1),!,$_w(2)),$hget(x_pprot,pflood.ignore_mask))
  ..10 minutes:ignore -pntiu600 $mask($+($_w(1),!,$_w(2)),$hget(x_pprot,pflood.ignore_mask))
  ..-
  ..N minutes:{
    if ($$_input(How many minutes to ignore?,e,Ignore) isnum 1-60) ignore -pntiu $+ $calc($ifmatch * 60) $mask($+($_w(1),!,$_w(2)),$hget(x_pprot,pflood.ignore_mask))
  }
  -
  Sort
  .By nick:_sortwin $active 1 9
  .By identd@:_sortwin $active 2 9
  .By @address:_sortwin $active 2 64
  -
  Echo scan to $_wchan
  .Message:{
    var %c = $_wchan, %n = 5, %host = $gettok($active,2,160)
    if (%c !ischan) return
    _say %c $replace($_echo(matchscan.start),<chan>,%c,<host>,%host)
    while ($line($active,%n)) {
      var %line = $strip($ifmatch), %address = $gettok(%line,2,9), %nick = $gettok(%line,1,9)
      _say %c $replace($_echo(matchscan.lines),<chan>,%c,<address>,%address,<nick>,%nick,<host>,%host)
      inc %n
    }
    _say %c $replace($_echo(matchscan.end),<chan>,%c,<host>,%host)
  }
  .Describe:{
    var %c = $_wchan, %n = 5, %host = $gettok($active,2,160)
    if (%c !ischan) return
    describe %c $replace($_echo(matchscan.start),<chan>,%c,<host>,%host)
    while ($line($active,%n)) {
      var %line = $strip($ifmatch), %address = $gettok(%line,2,9), %nick = $gettok(%line,1,9)
      describe %c $replace($_echo(matchscan.lines),<chan>,%c,<address>,%address,<nick>,%nick,<host>,%host)
      inc %n
    }
    describe %c $replace($_echo(matchscan.end),<chan>,%c,<host>,%host)
  }
  -
  $iif(($_vline && $me isop $_wchan),Control)
  .$iif(($ircx && $me isowner $_wchan),$iif($_w(1) isowner $_wchan,Deown,Own)):changemode $_wchan q $_snicks
  .$iif($_w(1) isop $_wchan,Deop,Op):changemode $_wchan o $_snicks
  .$iif($_w(1) isvoice $_wchan,Devoice,Voice):changemode $_wchan v $_snicks
  $iif(($_vline && $me isop $_wchan),Kicks)
  .$iif($sline($active,2),Multi-kick,Kick):if ($2) multi $_wchan k $_snicks $$_input(Reason,e,Kicks) | else kickd 0 $_w(1) $_wchan
  .$iif($sline($active,2),Multi-kickban,Kickban):if ($2) multi $_wchan kb $_snicks $$_input(Reason,e,Kicks) | else kickd 1 $_w(1) $_wchan
  .$iif($sline($active,2),Multi-ban,Ban):if ($2) multi $_wchan b $_snicks | else kickd 2 $_w(1) $_wchan
}
menu @clones {
  dclick:whois $_w(3)
  $iif($_vline,Clipboard):clipboard $strip($replace($1-,$chr(9),$chr(32)))
  $iif($_vline,Ignore)
  .1 minute:ignore -pntiu60 $_w(1)
  .10 minutes:ignore -pntiu600 $_w(1)
  .-
  .N minutes:{
    if ($$_input(How many minutes to ignore?,e,Ignore) isnum 1-60) ignore -pntiu $+ $calc($ifmatch * 60) $_w(1)
  }
  -
  Sort
  .By hostmask:_sortwin $active 1 9
  .By number of clones:_sortwin.num $active 2 9
  -
  $iif($me isop $_wchan,Kicks)
  .$iif($_vline,Filterkick):{
    var %c = $_wchan

    set -u %::masksite $_screw($_w(1))
    fk %c $_w(1) $_kickmsg(clones,%c)
  }
  .$iif($_vline,Filterkickban):{
    var %c = $_wchan
    set -u %::masksite $_screw($_w(1))
    fkb %c $_w(1) $_kickmsg(clones,%c)
  }
  .-
  .Filterkick all:{
    var %c = $_wchan, %n = 5
    while ($line($active,%n)) {
      var %host = $gettok($ifmatch,1,9)
      set -u %::masksite $_screw(%host)
      var %km = $_kickmsg(clones,%c)
      fk %c %host %km
      inc %n
    }
  }
  .Filterkickban all:{
    var %c = $_wchan, %n = 5
    set -u %::masksite $_screw($_w(1))
    while ($line($active,%n)) {
      var %host = $gettok($ifmatch,1,9)
      set -u %::masksite $_screw(%host)
      var %km = $_kickmsg(clones,%c)
      fkb %c %host %km
      inc %n
    }
  }
  -
  Echo scan to $_wchan
  .Message:{
    var %c = $_wchan, %n = 5
    if (%c !ischan) return
    _say %c $replace($_echo(clonescan.start),<chan>,%c)
    while ($line($active,%n)) {
      var %line = $strip($ifmatch), %host = $gettok(%line,1,9), %num = $gettok(%line,2,9), %nicks = $gettok(%line,3,9)
      _say %c $replace($_echo(clonescan.lines),<chan>,%c,<host>,%host,<num>,%num,<nicks>,%nicks)
      inc %n
    }
    _say %c $replace($_echo(clonescan.end),<chan>,%c)
  }
  .Describe:{
    var %c = $_wchan, %n = 5
    if (%c !ischan) return
    describe %c $replace($_echo(clonescan.start),<chan>,%c)
    while ($line($active,%n)) {
      var %line = $strip($ifmatch), %host = $gettok(%line,1,9), %num = $gettok(%line,2,9), %nicks = $gettok(%line,3,9)
      describe %c $replace($_echo(clonescan.lines),<chan>,%c,<host>,%host,<num>,%num,<nicks>,%nicks)
      inc %n
    }
    describe %c $replace($_echo(clonescan.end),<chan>,%c)
  }
}

;
;EOF
