;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; dialogs (5)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
; network dialog

alias nets {
  if ($1) set -u %_netsd $1
  _dialog -m nets nets
}
dialog nets {
  title "Network Settings"
  size -1 -1 314 156
  option dbu
  icon graphics\multi1.ico, 0
  tab "Services", 5, 101 4 205 132
  box "Popups", 44, 109 25 190 24, tab 5
  box "Service sets", 10, 109 51 190 78, tab 5
  combo 11, 147 35 100 120, tab 5 size edit drop
  text "Service's nicks", 12, 116 68 44 8, tab 5
  text "Service's site", 13, 116 81 44 8, tab 5
  edit "", 15, 161 65 110 12, tab 5 autohs
  edit "", 16, 161 78 110 12, tab 5 autohs
  check "Use /msg <service> instead of /<service>", 18, 116 98 110 8, tab 5
  button "Load", 45, 116 115 25 10, tab 5
  button "Save", 46, 142 115 25 10, tab 5
  tab "Sets", 6
  box "Usermodes", 19, 109 25 190 24, tab 6
  box "Advanced sets", 20, 109 51 190 78, tab 6
  check "", 21, 149 37 8 8, tab 6 3state
  edit "", 22, 158 33 90 12, tab 6 autohs
  text "Maximum simultaneous modes", 23, 128 63 85 8, tab 6
  text "Maximum nicks per kickline", 24, 128 75 85 8, tab 6
  text "Maximum nicks per event", 25, 128 87 85 8, tab 6
  text "Clonemask", 26, 127 101 28 8, tab 6
  text "Update IAL/IBL", 60, 127 114 40 8, tab 6
  edit "", 27, 215 61 20 11, tab 6
  edit "", 28, 215 73 20 11, tab 6
  edit "", 29, 215 85 20 11, tab 6
  combo 30, 178 99 110 150, tab 6 drop
  combo 61, 178 112 80 40, tab 6 drop
  tab "Channels", 7
  box "Favorite Channels", 31, 109 25 190 104, tab 7
  check "Use default list", 32, 127 38 70 8, tab 7
  edit "", 37, 205 37 65 11, tab 7 autohs
  list 33, 205 49 65 50, tab 7 size vsbar
  button "Up", 94, 271 64 20 9, tab 7
  button "Down", 95, 271 73 20 9, tab 7
  button "Add", 38, 177 51 25 11, tab 7
  button "Rem", 39, 177 63 25 11, tab 7
  button "Join all now", 40, 256 111 35 11, tab 7
  check "Enable autojoin, delay", 34, 127 103 75 8, tab 7
  edit "", 35, 205 102 16 10, tab 7 autohs
  text "secs", 36, 223 103 20 8, tab 7
  check "Default modes if alone", 58, 127 115 75 6, tab 7 3state
  edit "", 57, 205 112 36 11, disable tab 7 autohs
  tab "Login", 8
  box "Login sets", 43, 109 25 190 104, tab 8
  text "Login on", 80, 117 36 25 8, tab 8
  combo 81, 142 34 61 50, tab 8 drop
  edit "", 82, 252 37 40 11, tab 8 autohs
  list 83, 252 49 40 45, tab 8 size
  list 84, 5 1 0 0, hide tab 8
  text "Enter identify string (use <me> and <pass>)", 85, 117 107 125 8, tab 8
  edit "", 86, 117 114 125 11, tab 8 autohs
  button "Add", 87, 224 51 25 11, tab 8
  button "Rem", 88, 224 63 25 11, tab 8
  edit "", 17, 117 96 125 11, tab 8 autohs
  check "Hide login notices", 62, 118 53 80 10, tab 8
  check "No login popup dialog", 63, 118 63 80 10, tab 8
  text "Request-ID string/mask", 14, 117 88 125 8, tab 8
  button "Advanced", 41, 263 113 30 11, tab 8
  button "Add", 92, 179 115 25 11, tab 8
  button "Rem", 93, 206 115 25 11, tab 8
  box "Custom servers", 90, 109 25 190 104, tab 8
  list 91, 119 41 170 80, tab 8 extsel
  edit "", 217, 0 0 0 0, tab 8 autohs
  edit "", 218, 0 0 0 0, tab 8 autohs

  tab "Perform", 9
  box "Perform on connect", 70, 109 25 190 104, tab 9
  edit "", 71, 119 40 170 80, tab 9 multi return autohs
  button "Ok", 250, 241 141 30 12, default ok
  button "Cancel", 249, 274 141 30 12, cancel
  list 1, 18 17 68 105, size
  box "", 2, 8 5 88 133
  button "Add", 3, 26 125 25 10
  button "Rem", 4, 52 125 25 10
  edit "", 100, 0 0 0 0, hide autohs
  menu "&Setup", 500
  item "&General Setup", 501, 500
  item "&Channel Protections", 506, 500
  item "&Display Settings", 502, 500
  item break, 503, 500
  item "&Userlist", 504, 500
  menu "&Help", 700
  item "&Help dialog", 701, 700
  item break, 702, 700
  item "&About eXtreme", 703, 700
}

on 1:dialog:nets:*:* {
  if ($devent == init) {
    mdx.start
    multi.lang
    mdx SetControlMDX 91 listview rowselect single flatsb showsel report nosortheader > $mdx.vdll
    did -i $dname 91 1 headerdims 220 115
    did -i $dname 91 1 headertext 0 Server $_tab Network
    did -a nets 11 None
    var %i = 1
    while (%i <= 14) {
      if (%i !isnum 5-9) did -a nets 30 $mask(nick!ident@host-123.domain.net,%i)
      inc %i
    }
    if ($hget(x_sets,ns.hidelogin)) did -c nets 62
    if ($hget(x_sets,ns.noautolog)) did -c nets 63
    didtok nets 61 44 on join,on op,never
    didtok nets 81 44 never,connect,notice,pvtmsg
    did -c nets 81 1
    did -a nets 1 Default
    if ($_getnets) didtok nets 1 44 $ifmatch
    var %f = $findfile(nets\,*.srv,0,0,did -a nets 11 $nopath($1-))
    if (%_netsd isnum 1-5) .timer 1 0 did -f nets $calc(4+ $ifmatch)
    _loadn $iif((%_netsd && %_netsd !isnum),%_netsd,$iif($__i(network),$ifmatch,default))
  }
  if ($devent == edit) && ($did isnum 27-29) && (($did($did) !isnum) || ($did($did) > 50)) did -ra nets $did $left($did($did),-1)
  if ($devent == menu) {
    if ($did == 501) setup
    if ($did == 502) display
    if ($did == 506) cprot
    if ($did == 504) ul
    if ($did == 701) help
    if ($did == 703) about
  }
  if ($devent == dclick) && ($did == 83) && ($did(83).seltext) nick $ifmatch
  if ($devent == sclick) {
    if ($did(1).sel) var %net = $did(1).seltext
    if ($did == 1) _loadn $did(1).seltext
    if ($dialog(nets).tab == 7) did -t nets 38
    elseif ($dialog(nets).tab == 8) did -t nets 87
    else did -t nets 250
    if ($did == 3) {
      var %n = $$_input(Enter network to add,e,Add network,$iif($_isnotinlist(nets,1,$__i(network)),$__i(network)))
      if ($_isnotinlist(nets,1,%n)) _loadn %n
    }
    if ($did == 4) && ($did(1).sel) && ($did(1).seltext != default) && ($input(Are you sure?,yq)) {
      _unset $+(net-,$did(1).seltext)
      did -d nets 1 $did(1).sel
    }
    if ($did == 45) {
      var %f = $$nopath($sfile($mircdirnets\,Select a .srv file to load,Load)), %n = $readini($+(nets\,%f),sets,network)
      if (!$isfile($+(nets\,%f))) {
        sr -th Error File must be in nets\ folder
        return
      }
      %n = $iif(%n,%n,$$_input(Enter network name,e,Network))
      if (%n) _loadn %n %f
    }
    if ($did == 46) && ($did(1).seltext != default) _saven $did(1).seltext 1
    if ($did == 21) did $iif($did(21).state == 0,-rb,$iif($did(21).state == 1,-e,-rab)) nets 22 $hget(x_net-default,usermodes)
    if ($did == 32) {
      did $iif($did(32).state,-b,-e) nets 33,37,38,39
      did -r nets 33
      if ($did(32).state) && ($hget(x_net-default,chan.list)) didtok nets 33 44 $ifmatch
      elseif ($hget($+(x_net-,$did(1).seltext),chan.list)) didtok nets 33 44 $ifmatch
    }
    if ($did == 34) did $iif($did(34).state,-e,-rb) nets 35
    if ($did == 38) && ($did(37)) && ($_isnotinlist(nets,33,$_chan($did(37)))) {
      if ($did(33).lines == 15) sr -th Error Sorry, you can only have 15 entries
      else {
        did -a nets 33 $_chan($did(37))
        did -r nets 37
        did -t nets 38
      }
    }
    if ($did == 39) && ($did(33).sel) did -d nets 33 $ifmatch
    if ($did == 40) && ($did(33).lines) joinall
    if ($did == 58) did $iif($did(58).state == 0,-rb,$iif($did(58).state == 1,-e,-rab)) nets 57 $hget(x_net-default,chan.defmodes)
    if ($did == 87) && ($did(82)) {
      if ($_isnotinlist(nets,83,$did(82))) {
        var %p = $$_input(Enter password (or username password),p,Login)
        did -a nets 83 $did(82)
        did -a nets 84 %p
        did -r nets 82
      }
      else sr -th Error Nick already in list, delete first
    }
    if ($did == 88) && ($did(83).sel) did -d nets 83,84 $ifmatch
    if ($did == 250) && ($did(1).sel) {
      _saven $did(1).seltext
      if ($server) setservices
    }
    if ($did == 92) _cserv
    if ($did == 93) && ($did(91).sel) did -d nets 91 $ifmatch
    if ($did == 94) _listup 33
    if ($did == 95) _listdown 33
    if ($did == 41) var %a = $_dialog(adlogsets,adlogsets,-4)
  }
}
alias _net {
  if ($2 != $null) var %net = $1, %item = $2
  else var %net = $__i(network), %item = $1
  if ($hget($+(x_net-,%net),%item) != $null) return $ifmatch
  return $hget(x_net-default,%item)
}
alias -l _getnets {
  var %n = 1, %s, %a
  while ($hget(%n)) {
    %s = $ifmatch
    if (x_net-* iswm %s) && ($hget(%s,0).item > 0) && (%s != x_net-default) %a = $addtok(%a,$gettok(%s,2-,45),44)
    inc %n
  }
  return %a
}
alias -l _loadcservers {
  did -r nets 91
  var %n = 1
  while ($hget(x_net-default,%n).item) {
    var %s = $ifmatch
    if (customsrv:* iswm %s) {
      var %it = $hget(x_net-default,%s)
      if (%it) did -a nets 91 $gettok(%s,2-,58) $+ $_tab %it
    }
    inc %n
  }
}
alias -l _saven {
  var %nt = $+(net-,$1), %cmd = _-set %nt
  if ($2) var %file = $$sfile($+(nets\,$1,.srv),Enter filename,Save), %cmd = writeini " $+ %file $+ " Sets
  else {
    _-set sets ns.hidelogin $did(62).state
    _-set sets ns.noautolog $did(63).state
    _-unset %nt
  }
  if ($2) %cmd Network $1
  %cmd Popups $did(11).seltext
  if ($did(15)) %cmd Serv.Nicks $ifmatch
  if ($did(16)) %cmd Serv.Sites $ifmatch
  if ($did(27)) %cmd Max.Modes $ifmatch
  if ($did(28)) %cmd Max.Kicks $ifmatch
  if ($did(29)) %cmd Max.Events $ifmatch
  if ($did(30).sel) %cmd CloneMask $ifmatch
  if ($did(61).sel) %cmd IALupd $ifmatch
  %cmd Log.event $did(81).sel
  if ($did(18).state) %cmd Log.msgserv 1
  if ($did(17)) %cmd Log.String $ifmatch
  if ($did(217)) %cmd Log.String-Correct $ifmatch
  if ($did(218)) %cmd Log.String-Incorrect $ifmatch
  if ($did(86)) %cmd Log.Command $ifmatch

  if ($2) {
    sr -t Network Saved to $nopath(%file) $+ $crlf $+ (except channel and login lists)
    return
  }

  if ($1 == default) {
    var %i = 2
    while ($did(91,%i)) {
      var %l = $ifmatch
      _-set net-default customsrv: $+ $remove($gettok(%l,6,32),	+) $iif($gettok(%l,10,32) != <none>,$ifmatch,0)
      inc %i
    }
  }
  if (($1 == default) || ($did(21).state == 1)) && ($did(22)) _-set %nt Usermodes $did(22)
  elseif ($did(21).state == 0) _-set %nt Usermodes 0
  _-set %nt chan.def $did(32).state
  _-set %nt chan.ajoin $did(34).state
  if ($did(35)) _-set %nt chan.ajoindelay $ifmatch
  if (($1 == default) || ($did(58).state == 1)) && ($did(57)) _-set %nt chan.defmodes $did(57)
  elseif ($did(58).state == 0) _-set %nt chan.defmodes 0
  if ($did(32).state == 0) && ($did(33).lines) _-set %nt chan.list $didtok(33,44)

  var %i = 1, %l
  while (%i <= $did(71).lines) {
    if (%i == 1) %l = %l $did(71,1)
    elseif ($did(71,%i)) %l = %l $chr(124) $did(71,%i)
    inc %i
  }
  _-set %nt perform %l

  if ($didtok(83,1)) _-set %nt log.nicks $ifmatch
  if ($didtok(84,1)) _-set %nt log.passes $_pwd($ifmatch)
  hupd
}

alias -l _ldn {
  if ($3) return $readini($+(nets\,$3),sets,$2)
  return $hget($+(x_,$1),$2)
}
alias -l _loadn {
  if ($did(100)) _saven $ifmatch
  if ($didwm(1,$1)) did -c nets 1 $ifmatch
  else {
    did -a nets 1 $1
    did -c nets 1 $did(1).lines
  }
  var %nt = $+(net-,$1)
  if ($1 == default) {
    did -c nets 11 1
    did -ub nets 11,21,32,58,15,16,17,18,45,46
    did -h nets 43,80,81,82,83,84,85,86,87,88,90,91,92,93,17,14,41,62,63
    did -v nets 90,91,92,93
    did -ra nets 19 Default usermodes
    did -ra nets 8 Servers
    _loadcservers
  }
  else {
    did -e nets 11,21,32,58,15,16,17,18,45,46
    did -v nets 43,80,81,82,83,84,85,86,87,88,14,17,41,62,63
    did -h nets 90,91,92,93
    did -ra nets 19 Usermodes
    did -ra nets 8 Login
  }
  did -e nets 33,37,38,39
  did -ra nets 27 $modespl
  did -ra nets 28,29 1
  did -r nets 15,16,17,22,33,35,71,82,83,84,86
  if ($didwm(11,$_ldn(%nt,popups,$2))) did -c nets 11 $ifmatch
  else did -c nets 11 1
  if ($_ldn(%nt,serv.nicks,$2)) did -ra nets 15 $ifmatch
  if ($_ldn(%nt,serv.sites,$2)) did -ra nets 16 $ifmatch
  if ($_ldn(%nt,log.string,$2)) did -ra nets 17 $ifmatch
  if ($_ldn(%nt,log.string-correct,$2)) did -ra nets 217 $ifmatch
  if ($_ldn(%nt,log.string-incorrect,$2)) did -ra nets 218 $ifmatch
  if ($_ldn(%nt,log.event,$2)) did -c nets 81 $ifmatch | else did -c nets 81 1
  if ($_ldn(%nt,log.command,$2)) did -ra nets 86 $ifmatch
  if ($hget($+(x_,%nt),log.nicks)) didtok nets 83 1 $ifmatch
  if ($hget($+(x_,%nt),log.passes)) didtok nets 84 1 $_pwd($ifmatch)
  did $iif($_ldn(%nt,log.msgserv,$2),-c,-u) nets 18

  if ($1 == default) did -era nets 22 $hget(x_net-default,usermodes)
  elseif ($_ldn(%nt,usermodes,$2) == 0) { did -u nets 21 | did -b nets 22 }
  elseif ($_ldn(%nt,usermodes,$2)) { did -era nets 22 $ifmatch | did -c nets 21 }
  else { did -bra nets 22 $hget(x_net-default,usermodes) | did -cu nets 21 }

  if ($_ldn(%nt,max.modes,$2)) did -ra nets 27 $ifmatch
  if ($_ldn(%nt,max.kicks,$2)) did -ra nets 28 $ifmatch
  if ($_ldn(%nt,max.events,$2)) did -ra nets 29 $ifmatch
  if ($_ldn(%nt,clonemask,$2)) did -c nets 30 $ifmatch | else did -c nets 30 2
  if ($_ldn(%nt,ialupd,$2)) did -c nets 61 $ifmatch | else did -c nets 61 1
  if ($hget($+(x_,%nt),perform)) didtok nets 71 124 $ifmatch

  if ($hget($+(x_,%nt),chan.def)) {
    did -c nets 32
    did -b nets 33,37,38,39
    var %tn = net-default
  }
  else {
    did -u nets 32
    var %tn = %nt
  }

  if ($hget($+(x_,%nt),chan.ajoin)) {
    did -c nets 34
    if ($hget($+(x_,%nt),chan.ajoindelay)) did -ra nets 35 $ifmatch
    did -e nets 35
  }
  else { did -u nets 34 | did -rb nets 35 }

  if ($1 == default) did -era nets 57 $hget(x_net-default,chan.defmodes)
  elseif ($hget($+(x_,%nt),chan.defmodes) == 0) { did -u nets 58 | did -b nets 57 }
  elseif ($hget($+(x_,%nt),chan.defmodes)) { did -era nets 57 $ifmatch | did -c nets 58 }
  else { did -bra nets 57 $hget(x_net-default,chan.defmodes) | did -cu nets 58 }

  if ($hget($+(x_,%tn),chan.list)) didtok nets 33 44 $ifmatch
  did -ra nets 100 $1
}
;
dialog adlogsets {
  title "Advanced login settings"
  size -1 -1 143 68
  option dbu
  text "Enter 'password accepted' string/mask", 3, 10 10 100 8
  edit "", 4, 10 18 121 11, autohs
  text "Enter 'password incorrect' string/mask", 5, 10 29 100 8
  edit "", 6, 10 37 120 11, autohs
  button "OK", 8, 39 53 30 12, default ok
  button "Cancel", 9, 71 53 30 12, cancel
}
on 1:dialog:adlogsets:*:* {
  var %nt = $+(net-,$did(nets,1).seltext)
  if ($devent == init) {
    if ($did(nets,217)) did -ra adlogsets 4 $ifmatch
    if ($did(nets,218)) did -ra adlogsets 6 $ifmatch
  }
  if ($devent == sclick) && ($did == 8) {
    did -ra nets 217 $did(4)
    did -ra nets 218 $did(6)
  }
}
;custom server selection
alias _cserv if ($1) set -u %_cserv $1- | var %a = $_dialog(cserv,cserv,-4)
dialog cserv {
  title "Custom Server"
  size -1 -1 155 82
  option dbu
  text "Server", 1, 10 14 25 8
  edit "", 2, 37 12 105 11
  radio "Individual server", 3, 11 35 60 8
  radio "Associated with", 4, 11 47 60 8
  combo 5, 72 45 70 90, disable drop
  box "", 10, 6 4 142 61
  button "Ok", 50, 63 68 30 12, default ok
}
on 1:dialog:cserv:*:*:{
  if ($devent == init) {
    multi.lang
    if ($dialog(nets)) {
      did -b cserv 3
      did -c cserv 4
      did -e cserv 5
    }
    else did -c cserv 3
    if (%_cserv) did -bra cserv 2 $ifmatch
    didtok cserv 5 44 $_getnets
  }
  if ($devent == sclick) {
    did $iif($did(4).state,-e,-b) cserv 5
    if ($did == 50) {
      if (!$did(2)) return
      if (!$_isserv($did(2))) { sr -th Error You can only enter SERVERS here | return }
      if ($did(4).state) && ($did(5)) {
        _set net-default customsrv: $+ $did(2) $did(5)
        setservices $did(5)
      }
      else nets
      if ($dialog(nets)) _loadcservers
    }
  }
}

alias autologin nets 4
alias _log.again {
  if ($input(Password not accepted. $+ $crlf $+ Try again?,yw)) perflog
}

; *******************
alias cs {
  if ($istok($__i(nets-serv.nicks),CS,44)) .raw CS $1-
  else $iif($__i(nets-log.msgserv),.msg,.raw) chanserv $1-
}
alias ns {
  if ($istok($__i(nets-serv.nicks),NS,44)) .raw NS $1-
  else $iif($__i(nets-log.msgserv),.msg,.raw) nickserv $1-
}
alias ms {
  if ($istok($__i(nets-serv.nicks),MS,44)) .raw MS $1-
  else $iif($__i(nets-log.msgserv),.msg,.raw) memoserv $1-
}
alias os {
  if ($istok($__i(nets-serv.nicks),OS,44)) .raw OS $1-
  else $iif($__i(nets-log.msgserv),.msg,.raw) operserv $1-
}
alias hs {
  if ($istok($__i(nets-serv.nicks),HS,44)) .raw HS $1-
  else $iif($__i(nets-log.msgserv),.msg,.raw) helpserv $1-
}

alias perflog {
  if ($$_input(Enter password for ' $+ $me $+ ',p,Login)) {
    var %p = $ifmatch
    if ($__i(nets-log.command)) $replace($__i(nets-log.command),<pass>,%p,<me>,$me)
    elseif ($__i(s^n)) ns identify %p
    se $_c(1) $+ * Performing NickServ login...
  }
  elseif ($hget(x_sets,autojoin)) f11
}

alias _log.nicks {
  if (!$1) {
    if ($_net(log.nicks)) return $ifmatch
  }
  elseif ($istok($_net(log.nicks),$1,1)) return $1
}
alias _log.pass return $gettok($_pwd($_net(log.passes)),$findtok($_net(log.nicks),$1,1,1),1)

alias _@network return $__i(network) $+ �( $+ $cid $+ )
alias _network return $__i(network)
alias _networks {
  var %n = 1
  while ($scon(%n)) {
    var %net = $scon(%n)._network
    if ($1 == %net) return $scon(%n).cid
    var %list = %list %net
    inc %n
  }
  if (!$1) return $replace(%list,$chr(32),$chr(44))
}

;undernet specific alias
alias msg.x {
  var %c = $iif($1 ischan,$1,#), %m = $iif($1 ischan,$2-,$1-)
  .raw PRIVMSG x@channels.undernet.org : $+ %m
}

alias ptnet if ($__i(network) == ptnet) && (o !isin $usermode) return 1
alias ircx if ($__i(network) == microsoft) return 1

alias _isservice {
  if ($2) var %n = $1, %s = $gettok($2,-1,64)
  else var %n = $gettok($1,1,33), %s = $gettok($1,-1,64)
  if (%s == $server) || ($istok($__i(nets-serv.sites),%s,44)) || (($istok($__i(nets-serv.nicks),%n,44)) && (!$__i(nets-serv.sites))) return 1
}
alias s.opserv if (o isin $usermode) && ($__i(s^n)) return $1-

alias setservices {
  if (!$server) return
  unset $_i(nets-*) $_i(s^?)
  .rlevel -r 20
  if ($hget(x_net-default,$+(customsrv:,$server))) set $_i(network) $ifmatch
  else set $_i(network) $iif($1,$1,$iif($network,$ifmatch,$server))
  if (!$hget($+(x_net-,$__i(network)))) {
    if ($_isserv($__i(network))) _cserv $__i(network)
    else .timersetserv 1 0 if ($input(Settings for $__i(network) couldn't be found. $+ $crlf $+ Configure it now?,yw)) nets
  }
  set $_i(nets-max.kicks) 1
  set $_i(nets-max.modes) $modespl
  set $_i(nets-max.events) 1
  set $_i(nets-clonetype) 2
  set $_i(nets-ialupd) 1
  var %nt = $__i(network)
  loadservpops $_net(%nt,popups)
  if ($_net(%nt,serv.nicks)) {
    set $_i(nets-serv.nicks) $ifmatch
    if ($istok($__i(nets-serv.nicks),chanserv,44)) {
      set $_i(s^c) chanserv
      if (chanserv !isnotify) .notify Chanserv Services detection, don't remove
    }
    if ($istok($__i(nets-serv.nicks),nickserv,44)) set $_i(s^n) nickserv
    if ($istok($__i(nets-serv.nicks),memoserv,44)) set $_i(s^m) memoserv
  }
  if ($_net(%nt,serv.sites)) {
    var %h = $ifmatch
    .auser -a 20 $iif(@ isin %h,%h,$+(*!*@,%h)) services mask
  }
  if ($_net(%nt,log.string)) set $_i(nets-log.string) $ifmatch
  if ($_net(%nt,log.string-correct)) set $_i(nets-log.string-correct) $ifmatch
  if ($_net(%nt,log.string-incorrect)) set $_i(nets-log.string-incorrect) $ifmatch
  if ($_net(%nt,log.msgserv)) set $_i(nets-log.msgserv) $ifmatch
  if ($_net(%nt,max.modes)) set $_i(nets-max.modes) $ifmatch
  if ($_net(%nt,max.kicks)) set $_i(nets-max.kicks) $ifmatch
  if ($_net(%nt,max.events)) set $_i(nets-max.events) $ifmatch
  if ($_net(%nt,clonemask)) set $_i(nets-clonetype) $ifmatch
  if ($_net(%nt,ialupd)) set $_i(nets-ialupd) $ifmatch
  if ($_net(%nt,log.event)) set $_i(nets-log.event) $ifmatch
  if ($_net(%nt,log.command)) set $_i(nets-log.command) $ifmatch
  if ($_net(%nt,perform)) _perfd $ifmatch
  if ($__i(connecting)) && ($__i(nets-log.event) == 2) && ($__i(nets-log.command)) && ($_log.nicks($me)) $replace($__i(nets-log.command),<pass>,$_log.pass($me),<me>,$me)
}

alias loadservpops {
  var %srvfile = nets\ $+ $1
  if ($1 == none) || (!$isfile(%srvfile)) return
  .load -rs %srvfile
}

;
;EOF
