;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; seen module
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

;seen dialog

alias _seen {
  if (!$prop) return $iif($hget(x_seen,$1),1,0)
  elseif ($prop == time) return $asctime($gettok($hget(x_seen,$1),1,32))
  elseif ($prop == host) return $gettok($hget(x_seen,$1),2,32)
  elseif ($prop == event) return $gettok($hget(x_seen,$1),3-,32)
}
alias _addseen {
  var %h = $iif(@ isin $1,$1,$fulladdress), %n = $gettok($1,1,33), %l = $level(%h)
  if ($hget(x_sets,seen.status)) && ($_isservice(%n) != 1) && (%n != $me) && (guest* !iswm %n) {
    if ($hget(x_sets,seen.all) == 0) && (%n !isnotify) && ((%l == 1) || (%l == 20)) return
    if ($hget(x_sets,seen.all) isnum 1-) && (($hget(x_seen,0).item >= $hget(x_sets,seen.all)) || ($hget(x_seen,0).item >= 12000)) return
    if (!$hget(x_seen)) hmake x_seen 20
    hadd -m x_seen %n $ctime $iif(%h,$gettok(%h,2,33),-) $strip($2-) ( $+ $__i(network) $+ )
  }
}
alias seen {
  if ($1) set -u %_lseenm $1
  _dialog -m lseen lseen
}
dialog lseen {
  title "Seen database/configuration"
  size -1 -1 302 210
  option dbu
  icon graphics\users.ico, 0
  tab "Database", 1, 6 52 289 134
  list 100, 16 70 270 110, tab 1 size
  tab "!seen", 2
  box "", 3, 16 136 270 39, tab 2
  check "Everyone", 8, 131 95 44 8, tab 2
  check "Notify/userlist", 16, 131 117 44 8, disable tab 2
  check "Ops&&voices", 17, 131 106 44 8, tab 2
  text "Enter trigger word", 13, 29 147 44 7, tab 2
  edit "", 14, 77 145 45 11, tab 2 autohs
  text "Reply with", 12, 47 160 27 7, tab 2
  combo 15, 77 158 45 30, tab 2 drop
  text "Only on #chans", 34, 143 147 40 7, tab 2
  edit "", 36, 185 145 90 11, tab 2 autohs
  text "Except on #chans", 32, 137 160 46 7, tab 2
  check "Allow !seen from:", 7, 30 80 60 7, tab 2
  edit "", 33, 185 158 90 11, tab 2 autohs
  button "Ok", 50, 233 192 30 12, default ok
  button "Cancel", 49, 265 192 30 12, cancel
  box "", 4, 7 3 290 48
  check "Enable for:", 6, 17 13 40 7
  radio "Everyone", 11, 52 24 40 7
  radio "Notify/userlist", 18, 52 35 42 7
  edit "", 10, 251 20 20 11, autohs
  text "days", 5, 273 22 15 7
  text "users", 35, 273 35 15 7
  edit "", 31, 251 33 20 11, autohs
  text "Or to the limit of", 30, 199 35 50 7, right
  text "Keep entries for", 9, 199 22 50 7, right
}
on 1:dialog:lseen:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    mdx SetControlMDX 100 listview grid rowselect single showsel headerdrag report nosortheader > $mdx.vdll
    did -i $dname 100 1 headerdims 90 150 145 130
    did -i $dname 100 1 headertext $_tab(0 Nick,0 Hostmask,0 Date,0 Event)
    var %n = 1
    if (%_lseenm == list) var %list = 1
    elseif (%_lseenm) var %mask = $ifmatch
    while (%n < 250) && ($hget(x_seen,%n).item) {
      var %u = $ifmatch, %host = $_seen(%u).host, %fm = %u $+ ! $+ %host
      if ((%mask) && (%mask iswm %fm)) || (!%mask) did -a lseen 100 $_tab(0 [ %u ] ,$_seen(%u).host,$_seen(%u).time,$_seen(%u).event)
      inc %n
    }
    if ($hget(x_sets,seen.status)) did -c lseen 6
    if ($hget(x_sets,seen.all)) did -c lseen 11
    else did -c lseen 18
    if ($hget(x_sets,seen.max) isnum 1-9999) did -ra lseen 31 $ifmatch
    else did -ra lseen 31 1000
    if ($hget(x_sets,seen.duration) isnum 1-365) did -ra lseen 10 $ifmatch
    if ($hget(x_sets,seen.trigger.state)) {
      did -c lseen 7
      if (a isin $hget(x_sets,seen.trigger.state)) did -c lseen 8
      elseif (o isin $hget(x_sets,seen.trigger.state)) did -c lseen 17
    }
    else did -b lseen 8,17
    did -c lseen 16
    if ($hget(x_sets,seen.trigger)) did -ra lseen 14 $ifmatch
    else did -ra lseen 14 !seen
    if ($hget(x_sets,seen.onlychans)) did -ra lseen 36 $ifmatch
    if ($hget(x_sets,seen.exchans)) did -ra lseen 33 $ifmatch
    didtok lseen 15 44 message,notice
    if ($hget(x_sets,seen.trigger.msg)) did -c lseen 15 1
    else did -c lseen 15 2
    did $iif($did(6).state,-e,-b) lseen 11,18,10,7,8,17,14,15,31,33
    if ($did(6).state) {
      did $iif($did(7).state,-e,-b) lseen 8,17,14,15,33,36
      if ($did(7).state) did $iif($did(8).state,-b,-e) lseen 17
    }
  }
  if ($devent == sclick) {
    if ($did == 6) did $iif($did(6).state,-e,-b) lseen 11,18,10,7,8,17,14,15,31,33,36
    if ($did == 7) did $iif($did(7).state,-e,-b) lseen 8,17,14,15,33,36
    if ($did == 8) did $iif($did(8).state,-b,-e) lseen 17
    if ($did == 50) {
      _-set sets seen.status $iif($did(6).state,1,0)
      _-set sets seen.max $iif($did(31) isnum 1-9999,$ifmatch,1500)
      _-set sets seen.all $iif($did(11).state,$hget(x_sets,seen.max),0)
      _-set sets seen.duration $did(10)
      _-set sets seen.trigger.state $iif($did(7).state,$iif($did(8).state,a,$iif($did(17).state,o,1)))
      _-set sets seen.trigger $did(14)
      _-set sets seen.trigger.msg $iif($did(15).sel == 1,1)
      _-set sets seen.onlychans $replace($did(36),$chr(32),$chr(44))
      _-set sets seen.exchans $replace($did(33),$chr(32),$chr(44))
      hupd
    }
  }
}
on *:TEXT:*:*:{
  if ($1 != $hget(x_sets,seen.trigger)) || (!$2) || (!$hget(x_sets,seen.trigger.state)) || ($__i(lseen.,$site)) || ($__i(lseen.,global)) || ($hget(x_sets,seen.status) == 0) return
  if (a isin $hget(x_sets,seen.trigger.state)) || ((o isin $hget(x_sets,seen.trigger.state)) && (($nick isop $target) || ($nick isvoice $target))) || ($_isknown($fulladdress,F)) {
    if ($istok($hget(x_sets,seen.exchans),$target,44)) return
    if ($hget(x_sets,seen.onlychans)) && (!$istok($hget(x_sets,seen.onlychans),$target,44)) return
    var %tg = $iif($target ischan,$target,$nick)
    echo %tg $_c(1) $+ * Replying to $nick $+ 's $1 request
    if ($2 == $me) var %msg = That's me!!!
    elseif ($2 == $nick) var %msg = Who?
    elseif ($2 ison %tg) var %msg = $2 is still here
    else var %msg = Last seen info for $2 $+ : $strip($_getseen($2))
    $iif($hget(x_sets,seen.trigger.msg),_say %tg,.notice $nick) %msg
    set -u10 $_i(lseen.,$site) 1
    set -u3 $_i(lseen.,global) 1
  }
}
alias _cleanoldseens {
  if ($input(Your 'seen' database has reached the limit $crlf ( $+ $hget(x_sets,seen.max) entries) $+ $crlf $crlf $+ No more entries will be saved until you delete some or change the limit. $+ $crlf $crlf $+ Delete entries older than $1 days? $+ $crlf,yw,Seen)) cleanoldseens $1
}
alias cleanoldseens {
  var %t = $iif($1 isnum 0-365,$1,$iif($hget(x_sets,seen.duration) isnum 1-365,$ifmatch,90)), %ctime = $ctime, %i = 1
  if ($hget(x_seen,0).item >= 20000) ale WARNING: Your seen list is over 20.000 entries. You should review your 'seen' settings.
  while (%i <= $hget(x_seen,0).item) {
    var %l = $hget(x_seen,%i).item, %d = $gettok($hget(x_seen,%l),1,32), %c = $calc(%ctime - %d)
    if (%c > $calc(%t *86400)) || (%i > 50000) _--unset seen %l
    inc %i
  }
  _hsave x_seen
}
alias getseen {
  ale $_c(1) $+ Seen info for $_c(3) $+  $1 $+ $_c(1) $+ : $_getseen($1)
}
alias _getseen {
  if ($_seen($1)) {
    var %s = $ifmatch
    return $duration($calc($ctime - $gettok($hget(x_seen,$1),1,32)),2) ago [ $+ $_seen($1).time $+ ] $_c(1) $+ ( $+ $_seen($1).event $+ $_c(1) $+ )
  }
  return <n/a>
}

; EOF
