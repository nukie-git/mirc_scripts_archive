;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; CTCP and DCC routines
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

CTCP *:*:#:{
  if ($1 == motfv) var %1 = VERSION
  else var %1 = $upper($1)
  set -u %::nick $nick
  set -u %::address $address
  set -u %::ctcp %1
  set -u %::text $2-
  set -u %::target $target
  set -u %::chan #

  _addseen $nick ctcp %1 $target

  inc -u3 $_i(ctcps.,$site)
  if ($__i(ctcps.,$site) == 5) {
    set -u30 $_i(ignore.it) -ntd $wildsite
    var %ups = (ShiftF4 to ignore further CTCPs)
  }

  if ($_isflag($fulladdress,E)) {
    var %cloaking = (blacklist user)
    .ignore -ntdu $+ $hget(x_pprot,pflood.ignore_time) $wildsite
  }
  if ($hget(x_ctcps,cloak)) var %cloaking = (no reply)
  set -u %:comments %cloaking %ups
  set -u %:echo echo $color(ctcp) $iif($_echos(6,$target),-s,$target)
  theme.text ctcpchan
  _redir # $_display(ctcp)

  if (%cloaking) || ($__i(total.ctcps) == 4) || ($1 == dcc) halt
  inc -u5 $_i(total.ctcps)
  _on.ctcp %1 $2-
}

CTCP *:*:?:{
  if ($nick == $me) && ($2 == 101010101) {
    _lagcheck
    halt
  }

  if ($1 == motfv) var %1 = VERSION
  else var %1 = $upper($1)
  set -u %::nick $nick
  set -u %::address $address
  set -u %::ctcp %1
  set -u %::text $2-
  set -u %::target $me
  if ($nick == $me) {
    if (!$istok(dcc.page.away,%1,46)) {
      set -u %:echo _custom.echo CTCP
      theme.text ctcp
    }
    goto me
  }

  _addseen $nick ctcp %1 $me

  inc -u3 $_i(ctcps.,$site)
  if ($__i(ctcps.,$site) == 5) {
    set -u30 $_i(ignore.it) -ntd $wildsite
    var %ups = (ShiftF4 to ignore further CTCPs)
  }

  if ($_isflag($fulladdress,E)) {
    var %cloaking = (blacklist user)
    .ignore -ntdu $+ $hget(x_pprot,pflood.ignore_time) $ulist($fulladdress)
  }

  if (!$istok(dcc.page.away,%1,46)) {
    if ($hget(x_ctcps,cloak)) var %cloaking = %cloaking (no reply)
    set -u %:comments %cloaking %ups
    set -u %:echo _custom.echo CTCP
    theme.text ctcp
  }

  :end
  if ($1 != dcc) {
    if (%cloaking) || ($__i(total.ctcps) == 4) halt
    inc -u3 $_i(total.ctcps)
  }

  :me
  if ($1 == dcc) _on.dcc %1 $2-
  else _on.ctcp %1 $2-
}

alias -l _on.ctcp {

  if ($hget(x_ctcps,$+(reply-,$1)) != $null) && ($1 != dcc) {
    var %reply = $hget(x_ctcps,$+(reply-,$1))
    if ($1 == version) && (%reply == <random>) {
      if ($isfile(system\fversions.txt)) %reply = $read(system\fversions.txt)
      else %reply = $_script
      ctcpreply $nick $1 %reply
    }
    else ctcpreply $nick $1 $eval($hget(x_ctcps,$+(reply-,$1)),2)
    halt
  }

  if (!$istok(finger.time.ping.page.version.sound.away,$1,46)) goto misc
  goto $1

  :finger
  if ($_isknown($fulladdress,F)) || ($nick == $me) ctcpreply $nick $1 $_finger
  else {
    ctcpreply $nick $1 $_echo(no.finger)
    .ignore -ntu10 $wildsite
  }
  halt

  :time
  ctcpreply $nick $1 $asctime
  halt

  :ping
  if ($hget(x_ctcps,fakeping)) {
    if ($hget(x_ctcps,fakeping.time) isnum) var %delay = $ifmatch
    else var %delay = $rand(5,20)
    .timerfakeping. $+ $nick $+ $rand(11,99) 1 %delay ctcpreply $nick $1-
  }
  else ctcpreply $nick $1-
  halt

  :page
  _pager $1-
  halt

  :version
  ctcpreply $nick VERSION $_script
  halt

  :sound
  if ($hget(x_ctcps,soundreq)) && ($_soundext($2-)) splay.event $gettok($2-,-1,92)
  halt

  :away
  echo -t $target $_c(4) $+ ! $nick $_c(1) $+ is away: $2-
  halt

  :misc
  if (!$__i(misc.ctcp)) {
    if ($hget(x_ctcps,default.reply)) ctcpreply $nick $1 $_echo(miscctcpreply)
    set -u15 $_i(misc.ctcp) 1
  }
  halt
}

alias -l _on.dcc {
  if (($5 == 17) || ($5 == 19)) echo $iif(@* iswm $active,-s,-a) $_warn Probable DCC exploit attempt from $nick (port $5 $+ )
  var %flags = $_getflags($fulladdress)

  if ($away) && ($hget(x_away,block.dccs)) {
    if (!$__i(dcc.away.,$nick)) rawnotice $nick $replace($_echo(imaway),<areason>,$__i(awayreason))
    echo $iif(@* iswm $active,-s,-a) $replace($_echo(nodccs),<type>,$upper($2),<nick>,$nick,<address>,$address,<motive>,halted)
    set -u30 $_i(dcc.away.,$nick) 1
    halt
  }
  _dccaccepts $2
  if ($istok(chat.resume.send.accept,$2,46)) goto $2
  halt

  :chat
  event.sound chatreq
  if ($lock(chat)) {
    echo $iif(@* iswm $active,-s,-a) $replace($_echo(nodccs),<type>,$upper($2),<nick>,$nick,<address>,$address,<motive>,locked)
    halt
  }
  if ($5 isnum 4501-4505) echo $iif(@* iswm $active,-s,-a) $_warn Probable DCC Lock attempt from $nick (port $5 $+ )
  if (A isincs %flags) || (F isincs %flags) || (B isincs %flags) || ($__i(adcc.,$nick)) {
    var %creq = $creq
    .creq auto
    .timer 1 3 .creq $iif(%creq,%creq,ask)
  }
  return

  :send
  event.sound sendreq
  if ($lock(get)) {
    echo $iif(@* iswm $active,-s,-a) $replace($_echo(nodccs),<type>,$upper($2),<nick>,$nick,<address>,$address,<motive>,locked) - $3
    halt
  }
  if ($dccignore) && ($dccignore($3)) echo $iif(@* iswm $active,-s,-a) $_pre File type ignored ( $+ $3 $+ ) from $nick ( $+ $address $+ )
  if ($_check.badfiles($3)) {
    echo $iif(@* iswm $active,-s,-a) $_pre $replace($_echo(badfiles),<nick>,$nick,<address>,$address,<file>,$3)
    var %i = 1
    while ($comchan($nick,%i)) {
      var %chan = $ifmatch
      if ($me isop %chan) && ($_protset(badfiles,%chan)) && (!$_prot.disable(%chan)) && (!$_exempt.status($nick,%chan)) && (!$_exempt.ul($fulladdress,%chan)) {
        penalty badfiles $nick %chan $_kickmsg(badfiles,%chan)
      }
      inc %i
    }
    halt
  }
  if (A isincs %flags) || (F isincs %flags) {
    var %sreq = $sreq
    .sreq auto
    .timer 1 3 .sreq $iif(%sreq,%sreq,ask)
  }
  return

  :resume
  if (!$4) {
    .ignore -ntdu $+ $hget(x_pprot,pflood.ignore_time) $wildsite
    echo $iif(@* iswm $active,-s,-a) $replace($_echo(badresume),<nick>,$nick,<address>,$address,<text>,$3-)
    halt
  }
  return

  :accept | return

}
alias -l _finger {
  return $fullname ( $+ $emailaddr $+ ) Idle $idle seconds $iif($readini(mirc.ini,text,finger),( $+ $ifmatch $+ ))
}

on *:CTCPREPLY:*:{
  if ($nick == $server) && ($1 == ERRMSG) {
    echo -s $_pre CTCP not supported by $server ( $+ $2- $+ )
    halt
  }
  set -u %::nick $nick 
  set -u %::address $address
  set -u %::ctcp $upper($1)
  set -u %::text $iif($2 != $null,$2-,n/a)

  inc -u3 $_i(rctcps.,$site)
  if ($__i(rctcps.,$site) == 5) {
    set -u30 $_i(ignore.it) -nt $wildsite
    set -u %:comments (ShiftF4 to ignore further replies)
  }

  if ($__i(ctcp.replytime.,$nick)) {
    set -u30 $_i(reply.time) $1 $nick $round($calc(($ticks - $__i(ctcp.replytime.,$nick)) /1000),3)
    unset $_i(ctcp.replytime.,$nick)
  }

  if ($1 == ping) {
    var %reply = $iif($2 isnum,$round($calc(($ticks - $2) /1000),3) secs,$2-)
    if ($gettok(%reply,1,32) < 0) %reply = 0 secs
    set -u %::text %reply
    if ($__i(pingme.,$nick)) {
      rawnotice $nick Ping reply: %reply
      unset $_i(pingme.,$nick)
      halt
    }
  }

  var %w = $+(@Replies�,$_@network)
  if ($window(%w)) && ($fline(%w,$+($nick,$chr(9),*))) {
    rline %w $ifmatch $nick $+ $chr(9) $+ %reply
    if (!$fline(%w,*Waiting for reply)) {
      titlebar %w $window(@replies).title (completed)
      window -r %w
    }
    window -b %w
  }
  else {
    set -u %:echo _custom.echo CTCP
    theme.text ctcpreply
  }
  halt
}
;

alias ctcp {
  if (!$server) return
  if ($isid) {
    tokenize 32 $1
    var %1 = $upper($1)
    if ($1 == sound) return %1 ( $+ $replace($iif($2 != $null,$2-,n/a),_,$chr(32),$+($chr(37),20),$chr(32)) $+ )
    if ($2 == send) return %1 $2 ( $+ $3 $+ ) size: $iif($6 isnum,$bytes($6,3).suf,n/a)
    if ($2 == chat) return %1 $2
    return %1 $iif(($2 && $2 !isnum),$chr(40) $+ $2- $+ $chr(41))
  }

  if (!$server) || (!$2) return

  if ($2 == sound) {
    if ($3) var %3 = $gettok($3-,-1,92)
    else return
  }
  elseif ($2 == ping) var %3 = $iif($3,$3-,$ticks)
  else var %3 = $3-

  if ($numtok($1,44) == 1) && ($1 !ischan) set -u120 $_i(ctcp.replytime.,$1) $ticks

  elseif (($nick($1,0) > 1) || ($numtok($1,44) >= 3)) && (!$hget(x_ctcps,ctcp.noreplywindow)) && (!$istok(sound.mp3,$2,46)) { 
    var %w = $+(@Replies�,$_@network), %i = 1
    window -c %w
    window -knl -t20 %w $_gcoord(replies,-1 -1 300 200) @replies $_@font
    titlebar %w for $upper($2) on $iif($1 !ischan,selected nicks,$1)
    aline %w $chr(9)
    aline %w $_c(1) $+ Nick $+ $chr(9) $+ $_c(1) $+ Reply
    aline %w $chr(9)
    if ($1 ischan) {
      while ($nick($1,%i,a)) {
        var %ni = $ifmatch
        if (%ni != $me) aline %w %ni $+ $chr(9) $+ Waiting for reply
        inc %i
      }
    }
    else {
      while ($gettok($1,%i,44)) {
        var %ni = $ifmatch
        if (%ni != $me) aline %w %ni $+ $chr(9) $+ Waiting for reply
        inc %i
      }
      aline %w $chr(9)
    }
  }
  set -u120 $_i(ctcp.list) $1


  if (%3) mass.stuff $1 .raw PRIVMSG <item> : $+ $upper($2) %3 $+ 
  else mass.stuff $1 .raw PRIVMSG <item> : $+ $upper($2) $+ 

  if (!$show) return

  set -u %::nick $1
  set -u %::chan $1
  set -u %::target $1
  set -u %::ctcp $upper($2)
  set -u %::text $3-
  ;  set -u %:echo _custom.echo CTCP
  set -u %:echo echo $color(ctcp) -a
  theme.text $iif($1 ischan,ctcpchanself,ctcpself)
}

alias ctcpreply {
  if (!$server) return
  set -u %::nick $1
  set -u %::target $1
  set -u %::ctcp $2
  set -u %::text $3-
  ;  set -u %:echo _custom.echo CTCP
  set -u %:echo echo $color(ctcp) -a
  theme.text ctcpreplyself
  .raw NOTICE $1 : $+ $upper($2) $3- $+ 
}


;===================

;DCC stuff

on *:GETFAIL:*:{
  event.sound dccfail
  if ($__i(dsend.,$nick)) {
    .dccserver -s off
    unset $_i(dsend.,$nick)
  }
  $iif($hget(x_display,show.dccechoactive),ae,se) $replace($_echo(getfail),<nick>,$nick,<address>,$address>,<file>,$nopath($filename))
}
on *:SENDFAIL:*:{
  event.sound dccfail
  if ($server) && ($numtok($__i(dccsendretry),164) < 10) set -u300 $_i(dccsendretry) $addtok($__i(dccsendretry),$+($nick ",$filename,"),164)
  $iif($hget(x_display,show.dccechoactive),ae,se) $replace($_echo(sendfail),<nick>,$nick,<address>,$address,<file>,$nopath($filename))
  .timer.psend 1 $iif($hget(x_sets,dccs.delay),$ifmatch,0) _sendq $nick
}
on *:FILESENT:*:{
  event.sound filesent
  $iif($hget(x_display,show.dccechoactive),ale,sle) File $nopath($filename) ( $+ $bytes($lof($filename),3).suf $+ ) sucessfully sent to $nick
  .write $+(",$logdirdcclog.txt") Sent $chr(9) $ctime $chr(9) $nick $chr(9) $lof($filename) $chr(9) $filename
  set $_i(dccsendretry) $remtok($__i(dccsendretry),$+($nick ",$filename,"),1,164)
  .timer.psend 1 $iif($hget(x_sets,dccs.delay),$ifmatch,0) _sendq $nick
}

on *:FILERCVD:*:{
  event.sound filercvd
  if ($__i(dsend.,$nick)) {
    .dccserver -s off
    unset $_i(dsend.,$nick)
  }
  $iif($hget(x_display,show.dccechoactive),ale,sle) File $nopath($filename) ( $+ $bytes($lof($filename),3).suf $+ ) received from $nick at $get($nick).cps cps $iif($hget(x_ctcps,autorun) != 1, [ $_c(1) $+ (ShiftF7 to run/view [ $+ [ $_c(1) ] $+ ] ) ] )
  if ($hget(x_ctcps,autorun)) {
    if ($_soundext($filename)) splay.event $filename
    else run $shortfn($filename)
  }
  else set -u300 $_i(lastrcvdfile) $qtok($__i(lastrcvdfile),$shortfn($filename),5,164)

  .write $+(",$logdirdcclog.txt") Rcvd $chr(9) $ctime $chr(9) $nick $chr(9) $lof($filename) $chr(9) $filename
}

alias sendqueue {
  var %w = @Send�Queue� $+ $1
  if (!$window(%w)) window -lk %w -1 -1 350 300 @sendq $_@font
  else window -a %w
  titlebar %w - Right-click for options
}
alias _sendq {
  var %w = $+(@Send�Queue�,$1), %max = $iif($hget(x_sets,dccs.max),$ifmatch,4), %max2 = $calc(%max - $send(0) - $get(0))
  if (!$window(%w)) return
  var %i = 1
  while (%i <= %max2) {
    if ($line(%w,1)) {
      dcc send $1 $ifmatch
      dline %w 1
    }
    inc %i
  }
  if ($line(%w,0) == 0) window -c %w
}

;------------

alias _dccaccepts {
  if ($__i(adcc.,$nick)) return
  var %dcc = $hget(x_ctcps,dcc)
  if (%dcc) goto $ifmatch
  return

  :friends
  if ($_isflag($fulladdress,F)) return
  goto no

  :known
  var %flags = $_getflagsd($fulladdress,-)
  if ($nick isnotify) || (F isincs %flags) || (o isincs %flags) || (v isincs %flags) return
  goto no

  ;  :known2 | if ($nick isnotify) return | goto no
  ;  :known3| if ($ulist($fulladdress)) return | goto no

  :operators
  var %n = $comchan($nick,0)
  while (%n) {
    if ($nick isop $comchan($nick,%n)) return
    dec %n
  }
  goto no

  :everyone
  return

  :no
  ae $replace($_echo(nodccs),<type>,$upper($1),<nick>,$nick,<address>,$address,<reason>,halted)
  halt

  :%dcc
  return

}

;$_isflag(fulladdress,flag) returns <flags> if <flag> is in them
alias _isflag {
  var %add = $1, %flags = $_getflagsd(%add,#)
  if ($2 isincs %flags) return %flags
}



;
;EOF
