;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; default display/theme/msgs/kickmsgs
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
on ^*:JOIN:#:{
  haltdef
  set -u %::nick $nick
  set -u %::address $strip($address)
  set -u %::chan #
  set -u %::text $1-

  if ($nick == $me) {
    set $_i(just.joined.,#) 1
    if ($__i(just.kicked.,#)) || ($__i(just.cycled.,#)) {
      set -u %:echo echo $color(join) #
      theme.text rejoin
    }
    else {
      var %file = $shortfn($logdir) $+ $mklogfn(#)
      if ($hget(x_display,loadbuf.join)) && ($isfile(%file)) {
        loadbuf # %file
        linesep
      }
      set -u %:echo echo $color(join) #
      theme.text joinself
    }
    return
  }

  if ($query($nick)) && ($__i(queryquit.,$nick)) {
    echo $color(join) -t $nick $replace($_echo(queryjoin),<nick>,$nick,<chan>,#)
    unset $_i(queryquit.,$nick)
  }

  var %t.add = $address, %wildsite = $mask($fulladdress,$__i(nets-clonetype))

  if ($ialchan(%wildsite,#,2)) {
    if ($hget(x_display,show.cloneschk)) && ((!$hget(x_display,show.cloneschk.onlyop)) || ($me isop #)) {
      var %i = $ialchan(%wildsite,#,0)
      while (%i) {
        if ($numtok(%n_clones,32) <= 15) var %n_clones = $addtok(%n_clones,$ialchan(%wildsite,#,%i).nick,32)
        else var %n_clones = $addtok(%n_clones,-,32)
        dec %i
      }
      var %n_clones = $sorttok(%n_clones,32), %myclone = $istok(%n_clones,$me,32)
      if (%myclone) var %text = - Your host
      elseif ($me isop #) var %text = - CtrlF1 to kickban
      var %t_clones = $replace($_echo(joinclones),<host>,%wildsite,<num>,$ialchan(%wildsite,#,0),<clones>,%n_clones) %text
      if (!%myclone) set -u90 $_i(clones.,#) %wildsite
    }
  }
  elseif ($hget(x_display,show.lastseen) != 0) && (($__i(nets-ialupd) != 2) || ($me isop #)) && ($hget($+(x_tmp-cid,$cid,-lasthosts),$address)) {
    var %l = $ifmatch
    if ($gettok(%l,2,32) != $nick) var %seen = - Seen $duration($calc($ctime - $gettok(%l,1,32))) ago using nick $gettok(%l,2,32)
  }

  var %tmp = $+(x_tmp-cid,$cid,-netsplit)
  if ($hget(%tmp,$nick)) {
    var %info = $ifmatch, %serv = $gettok(%info,1,32), %list = $hget(%tmp,servers.list)
    if ($istok(%list,%serv,44)) && ($gettok($gettok(%info,2,32),2,64) == $site) {
      echo # $replace($_echo(netrejoin),<nick>,$nick,<server>,%serv)
      hadd -m %tmp servers.list $remtok(%list,%serv,1,44)
    }
  }

  set -u %::country $ccode($site)
  set -u %:comments %t_clones %seen
  set -u %:echo $e.ev(1,$color(join))
  theme.text join
  _redir # $_display(join)
  if ($_getcol($nick,%lev,#)) nickcol $nick # $ifmatch
}

on ^*!:PART:#:{
  haltdef
  hadd -mu1800 $+(x_tmp-cid,$cid,-lasthosts) $address $ctime $nick
  set -u %::nick $nick
  set -u %::address $strip($address)
  set -u %::chan #
  set -u %::text $1-
  set -u %:echo $e.ev(2,$color(part))
  theme.text part
  _redir # $_display(part)
}

on ^*:KICK:#:{
  haltdef
  set -u %::nick $nick
  set -u %::address $strip($address)
  set -u %::chan #
  set -u %::text $1-
  set -u %::knick $knick
  set -u %::kaddress $iif($address($knick,5),$gettok($ifmatch,2,33),n/a)

  if ($knick == $me) {
    set -u %:echo echo $color(kick) -ti2 #
    theme.text kickself
    set -u %:echo echo $color(kick) -tsi2
    theme.text kickself
    if ($nick != $me) {
      _save.chan.buf #
      .write $+(",$logdirkicklog.txt") $ctime Kicked from # by $nick ( $+ $strip($1-) $+ )
      if ($hget(x_display,show.warnecho)) && ($active != #) && (Status?Window !iswm $active) ale You were kicked from $_c(3) $+ # by $_c(3) $+ $nick ( $+ $1- $+ $_c(3) $+ )
    }
    return
  }
  if ($nick == $me) {
    write $+(",$logdirkicklog.txt") $ctime You kicked $knick from # ( $+ $strip($1-) $+ )
  }
  set -u %:echo $e.ev(8,$color(kick))
  theme.text kick

  _redir # $_display(kick)
}

on ^*:QUIT:{
  haltdef

  ;netsplit filter
  if ($isnetsplit($1-)) && ($hget(x_display,show.netsplits)) {
    var %tmp = $+(x_tmp-cid,$cid,-netsplit), %ttl = $iif($hget(x_sets,netsplit.ttl),$ifmatch,300)
    if (!$istok($hget(%tmp,netsplit.list),$2,44)) {
      hadd -mu $+ %ttl %tmp netsplit.list $addtok($hget(%tmp,netsplit.list),$2,44)
      sae $replace($_echo(netsplit),<nick>,$nick,<server>,$2)
    }
    hadd -mu $+ %ttl %tmp $nick $2 $address $_comchans($nick)
    .timer $+ %tmp 1 %ttl _hfree %tmp
    if ($query($nick)) {
      echo -t $nick $replace($_echo(queryquit),<nick>,$nick,<text>,netsplit at [ $2 ] )
      set -u300 $_i(queryquit.,$nick) 1
    }
    return
  }

  hadd -mu1800 $+(x_tmp-cid,$cid,-lasthosts) $address $ctime $nick
  var %_l,  %n = 1
  set -un %_l $1-
  set -u %::nick $nick
  set -u %::address $strip($address)
  set -un %::text %_l
  if ($query($nick)) {
    echo $color(quit) -t $nick $replace($_echo(queryquit),<nick>,$nick,<text>,$1-)
    set -u300 $_i(queryquit.,$nick) 1
  }
  while ($comchan($nick,%n)) {
    var %c = $ifmatch, %ec = $_echos(3,%c)
    set -u %::chan %c
    set -u %::target %c
    if (%ec == 0) || (%ec == 2) set -u %:echo echo $color(quit) -t %c
    elseif ((%ec == 1) || (%ec == 2)) && (%ec2 != 1) {
      set -u %:echo echo $color(quit) -st
      var %ec2 = 1
    }
    if (%:echo) theme.text quit
    _redir %c $_display(quit)
    inc %n
  }
}

on ^*:NICK:{
  haltdef
  set -u %::nick $nick
  set -u %::address $address
  set -u %::newnick $newnick

  if ($nick == $me) {
    set -u %:echo echo $color(nick) -s
    theme.text nickself
    if (!$chan(0)) return
  }
  if ($nick isnotify) set -u5 $_i(nickchange.,$nick) $newnick

  var %tmp = $+(x_tmp-cid,$cid,-recnicks)
  if ($hget(x_sets,no.recentnicks) != 1) && ($hget(%tmp,$nick)) && (guest* !iswm $nick) {
    hadd -m %tmp $newnick $remtok($qtok($hget(%tmp,$nick),$nick,20,44),$newnick,44)
    hdel %tmp $nick
  }
  else hadd -m %tmp $newnick $nick

  _addseen $nick nick -> $newnick

  var %fadd = $puttok($fulladdress,$newnick,1,33), %lev = $remove($level($ulist(%fadd)),=), %n = 1

  while ($comchan($newnick,%n)) {
    var %c = $ifmatch
    if (!$_echos(7,%c)) {
      set -u %:echo echo $color(nick) -t %c
      theme.text nick
    }
    if ($_getcol($newnick,%lev,#)) nickcol $newnick %c $ifmatch
    if ($__i(redir.,%c) == $nick) set $_i(redir.,%c) $newnick
    _redir %c $_display(nick)
    inc %n
  }
}

on ^*:TOPIC:#:{
  haltdef
  set -u %::nick $nick
  set -u %::address $strip($address)
  set -u %::chan #
  set -un %::text $1-
  set -u %:echo $e.ev(5,$color(topic))
  theme.text topic
  _redir # $_display(topic)
}

on ^*:RAWMODE:#:{
  haltdef
  set -u %::nick $nick
  set -u %::address $strip($address)
  set -u %::chan #
  set -u %::modes $1-
  set -u %:echo $e.ev(4,$color(mode))
  theme.text mode
  _addseen $nick mode #
  _redir # $_display(mode)
}
on ^*:INVITE:#:{
  haltdef
  if ($ajoininvite) || ($__i(invite.req.,#)) || ($istok($__i(invite.req),#,44)) set -u %:comments (F7 to join)
  set -u %::nick $nick
  set -u %::address $address
  set -u %::target $target
  set -u %::chan #
  set -u %:echo echo $color(invite) $iif($invonact,-at,-st)
  theme.text invite
}

on ^*:ERROR:*:{
  haltdef
  set -u %:echo se
  set -u %::text $1-
  theme.text servererror
}
on ^*:USERMODE:{
  haltdef
  set -u %::nick $nick
  set -u %::address $address
  set -u %::modes $1-
  set -u %::text $1-
  set -u %:echo echo $color(info2) -st
  theme.text modeuser
}
on ^*:WALLOPS:*:{
  haltdef
  if ($hget(x_wallops,all)) var  %all = 1
  var %wnf = $_filter.snotices.wallops(wallops,$1-)
  if ((%wnf) && ($hget(x_wallops,allow))) || ((!%wnf) && ($hget(x_wallops,allow) != 1)) || (%all) {
    set -u %::nick $nick
    set -u %::text $1-
    set -u %:echo _custom.echo Wallops $_timestamp
    theme.text wallop
  }
}
on ^*:SNOTICE:*:{
  haltdef
  if ($hget(x_snotices,all)) var %all = 1
  var %snf = $_filter.snotices.wallops(snotices,$1-)
  if ((%snf) && ($hget(x_snotices,allow))) || ((!%snf) && ($hget(x_snotices,allow) != 1)) || (%all) {
    set -u %::nick $nick
    set -u %::fromserver $nick
    set -u %::text $1-
    set -u %:echo _custom.echo SNotices $_timestamp
    theme.text noticeserver
  }
}

alias _filter.snotices.wallops {
  if ($hget($+(x_,$1),all)) return 1
  var %line = $strip($2), %s = $+(x_,$1)
  if ($hget(%s,$hmatch(%s,%line,1).data)) return 1
}

on *:OWNER:#:{
  if ($opnick == $me) {
    if ($hget(x_display,show.warnecho)) && ($active != #) ale You were owned on $_c(3) $+ # by $_c(3) $+ $nick
  }
}
on *:OP:#:{
  if ($opnick == $me) {
    if ($hget(x_display,show.warnecho)) && ($active != #) ale You were opped on $_c(3) $+ # by $_c(3) $+ $nick
  }
}
on *:VOICE:#:{
  if ($vnick == $me) {
    if ($hget(x_display,show.warnecho)) && ($active != #) ale You were voiced on $_c(3) $+ # by $_c(3) $+ $nick
  }
}
on *:DEOWNER:#:{
  if ($opnick == $me) {
    if ($hget(x_display,show.warnecho)) && ($active != #) ale You were deowned on $_c(3) $+ # by $_c(3) $+ $nick
  }
}
on *:DEOP:#:{
  if ($opnick == $me) {
    if ($hget(x_display,show.warnecho)) && ($active != #) ale You were deopped on $_c(3) $+ # by $_c(3) $+ $nick
  }
}
on *:DEVOICE:#:{
  if ($vnick == $me) {
    if ($hget(x_display,show.warnecho)) && ($active != #) ale You were devoiced on $_c(3) $+ # by $_c(3) $+ $nick
  }
}

;===================================================================================================================
;===================================================================================================================
;default theme
alias display {
  if (!$dialog(display)) _dialog -m display display
  return
}
alias _display {
  var %1 = $iif($1,$1,-)

  goto %1
  :join | return %::pre Joins: %::c3 $+ %::nick ( $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ )
  :joinself | return %::pre Now talking in %::chan
  :rejoin | return %::pre Rejoined %::chan
  :part | return %::pre Parts: %::c3 $+ %::nick ( $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ ) $+ $iif(%::text,: %::text)
  :quit | return %::pre Quits: %::c3 $+ %::nick ( $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ ): %::text
  :mode | return %::pre $iif(*.* iswm %::nick,ServerMode,Mode) ( $+ %::c3 $+ %::nick $+ : $+ %::c3 $+ %::chan %::modes $+ )
  :kickself | return %::pre %::c1 $+ You were kicked from $+ %::c3 %::chan %::c1 $+ by $+ %::c3 %::nick %::c1 $+ ( $+ %::c3 $+ %::text $+ %::c1 $+ )
  :kick | return %::pre %::c3 $+ %::knick was kicked by $+ %::c3 %::nick ( $+ %::c3 $+ %::text $+ )
  :modeuser | return %::pre Usermode changed to: $+ %::c3 %::modes
  :textqueryself | return %::c1 $+ %::lb $+ %::c3 $+ %::me $+ %::c1 $+ %::rb $+  %::text
  :textchanself | return %::c1 $+ %::lb $+ %::c3 $+ %::me $+ %::c1 $+ %::rb $+  %::text
  :actionchanself | return %::c1 $+ ! %::me %::text
  :actionqueryself | return %::c1 $+ ! %::me %::text
  :textmsgself | return -> %::c1 $+ [ $+ %::c3 $+ msg $+ %::c1 $+ ( $+ %::c3 $+ %::nick $+ %::c1 $+ )] %::text
  :textmsg | return %::c1 $+ * $+ %::nick $+ %::c1 $+ / $+ %::c3 $+ %::address $+ %::c1 $+ * %::text
  :textchan | return %::c1 $+ %::lb $+ %::c3 $+ %::nick $+ %::c1 $+ %::rb $+  %::text
  :textquery | return %::c1 $+ %::lb $+ %::c3 $+ %::nick $+ %::c1 $+ %::rb $+  %::text
  :actionchan | return %::c1 $+ ! $+ %::c3 %::nick $+  %::text
  :actionquery | return %::c1 $+ ! $+ %::c3 %::nick $+  %::text
  :nickself | return %::pre You are now known as %::c1 $+ %::newnick
  :nick | return %::pre %::c3 $+ %::nick %::c1 $+ is now known as %::c3 $+ %::newnick
  :invite | return %::pre %::nick ( $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ ) invites you to $+ %::c3 %::chan
  :wallop | return ! $+ %::c4 $+ %::nick $+ ! %::text
  :topic | return %::pre %::c3 $+ %::nick changes topic to ' $+ %::c3 $+ %::text $+ '
  :noticechan | return %::c4 $+ - $+ %::nick $+ : $+ %::target $+ - %::text
  :noticeself | return -> %::c1 $+ [notice $+ %::c1 $+ ( $+ %::nick $+ %::c1 $+ )] %::text
  :notice | return - $+ %::nick $iif(%::address,( $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ )) $+ - %::text
  :noticeserver | return - $+ %::c3 $+ %::fromserver $+ - %::text
  :ctcpself | return -> %::c2 $+ [[ $+ %::c3 $+ CTCP $+ %::c2 $+ ( $+ %::c3 $+ %::nick $+ %::c2 $+ )] $+ %::c3 $upper(%::ctcp) %::text
  :ctcpchanself | return -> %::c2 $+ [[ $+ %::c3 $+ CTCP $+ %::c2 $+ ( $+ %::c3 $+ %::chan $+ %::c2 $+ )] $+ %::c3 $upper(%::ctcp) %::text
  :ctcpreplyself | return -> %::c1 $+ CTCP $upper(%::ctcp) reply %::c4 $+ ( $+ %::c3 $+ %::text $+ %::c4 $+ ) $+ %::c1 sent to %::nick
  :ctcpreply | return %::pre %::c1 $+ CTCP %::ctcp reply from %::nick $+ : %::text
  :ctcp | return %::pre %::nick [ $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ ] requested $+ %::c2 %::ctcp from you
  :ctcpchan | return %::pre %::nick [ $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ ] requested $+ %::c2 %::ctcp from %::target
  :servererror | return %::c2 $+ (Server Error $+ %::c2 $+ ) %::text

  :notify | return $_notify(4) %::nick ( $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ ) is on IRC. %::parentext
  :unotify | return $_notify(2) %::nick ( $+ %::c3 $+ $replace(%::address,@,$+(@,%::c3)) $+ ) logged out. %::parentext

  :echo | return %::pre <text>
  :echotarget | return %::pre <c1>(<chan><c1>) <text>
  :error | return %::pre <c2>(Error<c2>) <text>
  :dns | return $_dns(4) Looking up $iif(%::nick,$ifmatch,%::address)
  :dnsresolve | return $_dns(4) Resolved %::c1 $+ %::address to $+ %::c1 %::raddress ( $+ $iif(%::nick,%::nick,%::address) $+ %::c1 $+ )
  :dnserror | return $_dns(2) Unable to resolve $iif(%::address,$ifmatch,%::nick)

  ;whois
  :raw.311
  %:echo $+(%::c4,[,%::c3,WHOIS,%::c4,],,$sepline1,)
  %:echo %::c1 $+ . %::c3 %::nick $+(%::c1,$chr(40),%::c4,%::ident,%::c1,@,%::c4,%::host,%::c1,$chr(41)) [[ $+ %::c3 $+ %::country $+ %::c1 $+ ]] $iif(%::userlevel != 1,[ $+ %::c3 $+ level %::userlevel $+ %::c1 $+ ])
  %:echo %::c1 $+ . %::c4 Ircname: %::realname
  return
  :raw.307 | return %::c1 $+ . %::c4 Status: %::text
  :raw.308 | return %::c1 $+ . %::c3 %::nick $+  %::text
  :raw.309 | return %::c1 $+ . %::c3 %::nick $+  %::text
  :raw.310 | return %::c1 $+ . %::c3 %::nick $+  %::text
  :raw.313 | return %::c1 $+ . %::c3 %::nick $+  %::text
  :raw.317 | return %::c1 $+ . %::c4 Idle: $duration(%::idletime) $iif(%::signontime,%::c1 $+ ( $+ %::c4 $+ Sign on $+ : %::signontime $+ %::c1 $+ ))
  :raw.312 | return %::c1 $+ . %::c4 Server: %::wserver $iif(%::serverinfo,%::c1 $+ ( $+ %::serverinfo $+ %::c1 $+ ))
  :raw.319 | return %::c1 $+ . %::c4 Channels: %::chan
  :raw.320 | return %::c1 $+ . %::c3 %::nick %::text
  :raw.335 | return %::c1 $+ . %::c3 %::nick %::text
  :raw.378 | return %::c1 $+ . %::c1 %::text
  :raw.379 | return %::c1 $+ . %::c3 %::nick %::text
  :raw.330 | return %::c1 $+ . %::c3 %::nick is logged in as %::value
  :raw.338 | return %::c1 $+ . %::c3 %::nick Address: %::address - IP: %::value
  :raw.301 | return %::c1 $+ . %::c4 Away $+ : %::away
  :wi.recnicks | return %::c1 $+ . %::c4 Recent nicks: %::recnicks
  :raw.318 | return $sepline2

  ;whowas
  :raw.314
  %:echo $+(%::c4,[,%::c3,WHOWAS,%::c4,],,$sepline1,)
  %:echo %::c1 $+ . %::c3 %::nick $+(%::c1,$chr(40),%::c4,%::ident,%::c1,@,%::c4,%::host,%::c1,$chr(41)) [[ $+ %::c3 $+ %::country $+ %::c1 $+ ]] $iif(%::userlevel != 1,[ $+ %::c3 $+ level %::userlevel $+ %::c1 $+ ])
  %:echo %::c1 $+ . %::c4 Ircname: %::realname
  return
  :raw.369 | return $sepline2

  ;topic
  :raw.332
  %:echo %::c1 $str(�,100)
  %:echo %::c1 � %::c3 $+ Topic: %::text
  return
  :raw.333
  %:echo %::c1 � %::c3 $+ Set by: %::nick %::c3 $+ on %::text
  %:echo %::c1 $str(�,70)
  return

  :raw.001 | return %::pre %::text
  :raw.002 | return %::pre %::text
  :raw.003 | return %::pre %::text
  :raw.004 | return %::pre %::text
  :raw.005 | return

  :raw.250 | return %::pre %::text
  :raw.251 | return %::pre %::text
  :raw.252 | return %::pre %::text
  :raw.253 | return %::pre %::text
  :raw.254 | return %::pre %::text
  :raw.255 | return %::pre %::text
  :raw.265 | return %::pre %::text
  :raw.266 | return %::pre %::text

  :raw.221 | return %::pre %::c1 $+ [ $+ %::c3 $+ MODE for %::nick $+ %::c1 $+ ]: %::modes
  :raw.302 | return %::pre %::c1 $+ [ $+ %::c3 $+ USERHOST for %::nick $+ %::c1 $+ ] %::address $iif(- isin %::value,(away)) $iif(* isin %::value,(ircop))
  :raw.324 | return %::pre %::c1 $+ [ $+ %::c3 $+ MODE for %::chan $+ %::c1 $+ ] %::modes
  :raw.328 | return %::pre %::c1 $+ [ $+ %::c3 $+ URL for %::chan $+ %::c1 $+ ] %::text
  :raw.329 | return %::pre %::c1 $+ [ $+ %::c3 $+ Created $duration($calc($ctime - %::value)) ago $+ %::c1 $+ ]

  :raw.341 | return %::pre %::c3 $+ %::nick has been invited to $+ %::c3 %::chan

  :raw.372 | return %::pre %::text
  :raw.375 | return %::pre %::text
  :raw.376 | return %::pre %::text

  :raw.377 | return %::pre %::text
  :raw.381 | return %::pre %::text
  :raw.391 | return %::pre Server time: %::text

  :raw.401 | return %::pre %::c3 $+ %::nick $+ : %::text
  :raw.402 | return %::pre %::c3 $+ %::nick $+ : %::text
  :raw.403 | return %::pre %::c3 $+ %::chan $+ : %::text
  :raw.404 | return %::pre %::c3 $+ %::chan $+ : %::text
  :raw.405 | return %::pre %::c3 $+ %::chan $+ : %::text
  :raw.406 | return %::pre %::c3 $+ %::chan $+ : %::text
  :raw.421 | return %::pre Error: $+ %::c3 / $+ %::value is an unknown command.
  :raw.432 | return %::pre %::c3 $+ %::nick $+ : %::text
  :raw.433 | return %::pre %::c3 $+ %::nick $+ : %::text

  :raw.439 | return %::pre %::text
  :raw.441 | return %::pre %::c3 $+ %::nick is not on %::chan
  :raw.442 | return %::pre %::c3 $+ You're not on %::chan
  :raw.443 | return %::pre %::c3 $+ %::nick is already on %::chan
  :raw.447 | return %::pre %::c3 $+ %::chan $+ : %::text
  :raw.467 | return %::pre %::c3 $+ %::chan $+ : %::text
  :raw.468 | return %::pre %::c3 $+ %::chan $+ : %::text
  :raw.472 | return %::pre %::c3 $+ %::value $+ : %::text

  :raw.471 | return %::pre Cannot join $+ %::c3 %::chan $+ , is full (+l)
  :raw.473 | return %::pre Cannot join $+ %::c3 %::chan $+ , is invite only (+i)
  :raw.474 | return %::pre Cannot join $+ %::c3 %::chan $+ , you're banned
  :raw.475 | return %::pre Cannot join $+ %::c3 %::chan $+ , key required (+k)
  :raw.477 | return %::chan $+ : %::text
  :raw.478 | return %::chan $+ : %::text
  :raw.482 | return %::chan $+ : %::text

  ;names
  :raw.353 | return !Script _names.parse
  :raw.366 | return !Script _names.parse.end

  ;who
  :raw.352 | return %::pre %::nick %::c1 $+ ( $+ %::address $+ %::c1 $+ ) - $iif(%::away == h,here,gone) %::c1 $+ - %::isoper ircop %::c1 $+ - on %::c3 $+ %::cmode $+  $+ %::chan %::c1 $+ - Server: %::wserver %::c1 $+ ( $+ %::value $+ %::c1 $+ ) - ircname: %::realname
  :raw.315 | return %::pre End of /WHO list %::c1 $+ ( $+ %::value $+ %::c1 $+ )

  :raw.other | return %::c1 $+ ( $+ %::numeric $+ %::c1 $+ ) %::text

  :%1 | return
}

alias _names.parse {
  var %w1 = $+(@_names1-cid,$cid,.,%::chan), %w2 = $+(@_names2-cid,$cid,.,%::chan), %w3 = $+(@_names3-cid,$cid,.,%::chan), %n = 1
  if (!$window(%w1)) window -hsl %w1
  if (!$window(%w2)) window -hsl %w2
  if (!$window(%w3)) window -hsl %w3
  while ($gettok(%::text,%n,32)) {
    var %nick = $ifmatch, %l = $left(%nick,1)
    if (%l isin .@) aline %w1 %nick
    elseif (%l isin +%) aline %w2 %nick
    else aline %w3 %nick
    inc %n
  }
}

alias _names.parse.end {
  var %w1 = $+(@_names1-cid,$cid,.,%::chan), %w2 = $+(@_names2-cid,$cid,.,%::chan), %w3 = $+(@_names3-cid,$cid,.,%::chan), %w = $+(@_names0-cid,$cid,.,%::chan), %just.joined = $__i(just.joined.,%::chan)
  if (!$window(%w1)) && (!$window(%w2)) && (!$window(%w3)) return

  if (!$hget(x_display,no.align.names)) {
    if (!$hget(x_wins,names)) && (%just.joined) var %target = %::chan
    else var %target = $active
    var %align = 1, %nc = $_nchr(%target), %font = $window(%target).font, %fontsize = $window(%target).fontsize, %max = 120, %ncs = $width(%nc,%font,%fontsize)
  }
  var %nc = $iif(%nc,%nc,$linesep)

  window -hl %w
  if ($line(%w1,0)) filter -ww %w1 %w
  if ($line(%w2,0)) filter -ww %w2 %w
  if ($line(%w3,0)) filter -ww %w3 %w

  if (!%just.joined) || (($__i(just.joined.,%::chan)) && ($hget(x_wins,names))) var %not.joined = 1

  %:echo %nc
  if (%not.joined) %:echo $+(%::c4,[,%::c3,NAMES for %::chan,%::c4,])

  var %i = 1
  while ($line(%w,%i,32)) {
    var %nick = $ifmatch
    if (%align) var %line = %line %nick $+ $str(%nc,$round($calc((%max - $width(%nick,%font,%fontsize)) / %ncs),0))
    else var %line = %line %nick

    if (5 // %i) {
      var %line = $replace(%line,@,$+(%::c4,@),+,$+(%::c1,+))
      ;      %:echo %::c1 $+ [ $str(%nc,3) %line $+ %::c1 $+ ]
      %:echo $str(%nc,3) %line
      unset %line
    }
    inc %i
  }
  if (%line) {
    var %line = $replace(%line,@,$+(%::c4,@),+,$+(%::c1,+))
    ;    %:echo %::c1 $+ [ $str(%nc,3) %line %::c1 $+ ]
    %:echo $str(%nc,3) %line
  }

  %:echo %nc
  close -@ $+(@_names?-cid,$cid,.,%::chan)
}


;===================================


; default echoes
alias _echo {

  ;custom msgs
  if ($hget(x_custom.msgs,$1)) var %echo = $ifmatch
  else var %echo = $__echo($1)
  if (%_custom.msgs) return %echo

  %echo = $replace(%echo,<pre>,$_pre,<c1>,$_c(1),<c2>,$_c(2),<c3>,$_c(3),<c4>,$_c(4),<timestamp>,$timestamp,<_timestamp>,$_timestamp,<k>,,<b>,,<u>,,<r>,,<me>,$me,<error>,$_error,<params>,$2-)
  return $eval(%echo,2)
}
alias -l __echo {

  var %1 = $1
  goto $1

  :nodccs | return <pre> <c2>DCC <type> request from <nick> <c1>(<address><c1>):  $+ <reason> $+ 
  :badfiles | return <c2>CTCP SEND<c3> request (badfile: <file><c3>) from <nick>!<address><c3>, halted
  :badresume | return <pre> Invalid <c2>RESUME request from <nick> <c1>(<address><c1>): <text>
  :getfail | return <error> DCC Get from <nick> (<file>) failed
  :sendfail | return <error> DCC Send to <nick> (<file>) failed <c1>(ShiftF6 to retry<c1>)
  :dccpingself | return -> <c2>[<c3>DCC PING<c2>(<c3><nick><c2>)]<c3>
  :dccping | return <pre> <c2>DCC PING requested by<c3> <nick>
  :dccpingreply | return <pre> <c3>DCC PING reply from<c3> <nick> $+ : <time> seconds

  :netsplit | return <timestamp> <c1>Netsplit detected at <server> <c1>(CtrlF3 to see who split<c1>)
  :netrejoin | return <timestamp> <c1>Probable net rejoin detected at <server> <c1>(<nick><c1>)
  :queryquit | return <pre> <nick> <c1>has left IRC (<text><c1>)
  :queryjoin | return <pre> <nick> <c1>is back (on <chan><c1>)
  :joinwarn | return <_timestamp> <c1>Joins: <nick> <c1>(<c3><address><c1>) on <chan> <c1>- <text>
  :ircopjoin | return <_timestamp> <c1>Joins: <nick> <c1>(<c3><address><c1>) on <chan> <c1>(is an <c2>IRCOP<c1>)
  :joinclones | return - Clones from <host> (<clones> [<num>])
  :chanstats | return <c1>[Total<c1>: <total><c1>] $iif($ircx, [Owners<c1>: <perc_owners><c1>] ) [Ops<c1>: <perc_ops><c1>] [Voice<c1>: <perc_voices><c1>] [Regular<c1>: <perc_regulars><c1>]

  :spam | return <_timestamp> <pre> <c2>Detected pvt spam from <nick> (<address>) <c2>('<text><c2>')
  :pflood | return <_timestamp> <pre> <c2><type> flood detected from <nick> <c1>(<address><c1>)
  :queryflood | return <_timestamp> <pre> <c2>QUERY flood detected <c1>(<host><c1>)
  :chatflood | return <_timestamp> <pre> <c2>DCC Lock attempt from <nick>. Closing chat...
  :massflood | return <_timestamp> <pre> <c2>*** Probable mass<type> flood detected on <chan>
  :ultraflood | return <_timestamp> <pre> <c2>*** ULTRA flood detected!!!

  :banned.nicks | return <pre> <c1>[Banned<c1>]: <text>
  :unbanned.nicks | return <pre> <c1>[Unbanned<c1>]: <text>
  :ban.on.me | return <pre> <c2>BAN on you detected!!! (<banmask>)
  :ban.on.me2 | return <pre> <c2>BAN on you detected on <chan> (<banmask>) set by <nick>
  :dont.ban.me | return (eXtreme) Don't ban me...
  :protected.user.echo | return <pre> Protecting <user> on <chan>...
  :protected.user.notice | return (eXtreme) That user is protected

  :localwarn | return <_timestamp> (<c2>Warn) <nick> has exceeded the limits set for <type> on <chan>. (F6 to kick, CtrlF6 to kickban)
  :localwarn2 | return <_timestamp> (<c2>Warn) Punishing <nick> with <penalty> for <type> on <chan>
  :localwarn3 | return <_timestamp> <pre> Warning has been sent to <target> about <type>.
  :localwarn4 | return <_timestamp> <pre> Performing custom penalty on <nick> about <type>.
  :clonewarn | return (Warn) You have exceeded the number of clones allowed on <chan>. Please remove some of them.
  :guestwarn | return (Warn) Guests are not allowed on <chan>. Try getting some help about registering/identifying your nick.
  :badwordwarn | return (Warn) Don't use that kind of language on <chan>.
  :customwarn_user | return (Warn) You have exceeded the limits set for <type> on <chan>. Please be more careful.
  :customwarn_public | return (Warn) <nick> has exceeded the limits set for <type>.
  :ignored | return You are now being ignored.
  :pvtblocked | return I'm not accepting any private msgs at the moment...
  :pagercvd | return Your page has been received
  :pagenotaway | return (Page) I'm not away...
  :pageroff | return (Page) Pager is off
  :miscctcpreply | return My mom always told me not to talk to strangers
  :no.finger | return You're not allowed to do that.

  :imaway | return I'm away right now - <areason> -
  :awayaction | return is now away, <areason> (log\<log> pager\<pager>)
  :awayadvert | return is away, <areason> $+  (<aduration>  ago)
  :autoaway | return auto-away after <minutes> minutes
  :backaction | return is back after <aduration>
  :awaystat | return (log\<log> pager\<pager>)
  :mp3echo | return mp3: <wname> -<wsr>khz/<wbr>kbps- <wlength>

  :clonescan.start | return ::: Clone scan for <chan>
  :clonescan.lines | return ::: <num> clones from <host> (<nicks>)
  :clonescan.end | return ::: End of scan

  :matchscan.start | return ::: Scan for <host>
  :matchscan.lines | return ::: <nick> - <address>
  :matchscan.end | return ::: End of scan

  :%1 | return
}

;===================================

; default kickmsgs
alias _kickmsg {
  var %km = $__kickmsg($1,$2)
  if ($nick) var %::nick = $ifmatch, %::address = $address, %::chan = $chan, %::site = $site, %::masksite = $_screw($wildsite)
  return $replace(%km,<nick>,%::nick,<address>,%::address,<site>,%::site,<chan>,%::chan,<badword>,%::badword,<badhostmask>,%::badhostmask,<badfile>,%::badfile,<badchan>,%::badchan,<reason>,%::reason,<idletime>,%::idletime,<masksite>,%::masksite)
}
alias __kickmsg {
  if ($2 != default) {
    if (%_kickmsg) return $ifmatch

    ;custom kickmsgs (netw/chan specific)
    if ($_protset($+($1,_kickmsg),$2)) return $ifmatch
  }
  ;default msgs
  var %item = $1
  goto $1

  :lines | return text flood detected (lines)
  :bytes | return text flood detected (bytes)
  :repeat | return don't repeat yourself
  :notice | return notice flood detected
  :nick | return nick flood detected
  :join | return join flood detected from <masksite>
  :ctcp | return CTCP flood detected
  :kick | return mass kick detected
  :deop | return mass deop detected
  :deown | return mass deown detected
  :ban | return mass ban detected
  :caps | return excess caps
  :codes | return excess codes
  :colors | return excess colors
  :chars | return line too long
  :clones | return clones detected from <masksite>
  :badhostmask | return bad nick/ident (<badhostmask>)
  :badword | return bad word detected (<badword>)
  :badchannel | return bad channel detected (<badchan>)
  :badfiles | return you're infected with (<badfile>)
  :guests | return no guests allowed
  :advertise | return don't advertise here
  :spam | return spamming not allowed
  :wingate | return wingate detected
  :socks5 | return socks5 detected

  :flooder | return flooder
  :selfban | return you've been warned...
  :idle | return idleing (<idletime>)
  :masskickall | return mass kick
  :masskickaway | return now you're really away...
  :masskill | return mass kill
  :excessfloodban | return <masksite> too many 'excess flood' quits from your host

  :revengekick | return don't do that
  :bannedby | return banned by <nick>
  :blacklist | return blacklisted <reason>
  :banned | return banned <reason>

  :%item | return $me
}

;
;EOF
