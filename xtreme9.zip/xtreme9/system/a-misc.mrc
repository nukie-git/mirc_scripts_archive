;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; misc aliases, popup aliases
; fkeys
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
_mopt {
  if ($hget(x_tmp-cache,$+(mopt.,$1,.,$2)) != $null) return $ifmatch
  var %1 = $gettok($readini(mirc.ini,options,$1),$2,44)
  hadd -mu15 x_tmp-cache $+(mopt.,$1,.,$2) %1
  return %1
}
comchar {
  if ($hget(x_tmp-cache,commandchar)) return $ifmatch
  var %c = $readini(mirc.ini,text,commandchar) $+ *
  hadd -mu15 x_tmp-cache commandchar %c
  return %c
}
showmodeprefix {
  return $_mopt(n2,30)
}
prefixownmsgs {
  return $_mopt(n0,23)
}
showaddresses {
  return $_mopt(n0,2)
}
shortjoinsparts {
  return $_mopt(n2,19)
}
notonact {
  return $_mopt(n5,13)
}
queryonact {
  return $_mopt(n4,5)
}
whoisonact {
  return $_mopt(n2,26)
}
ctcponact {
  return $_mopt(n4,19)
}
invonact {
  return $_mopt(n3,26)
}
beepquery {
  return $_mopt(n4,2)
}
flash.onchan {
  return $_mopt(n7,5)
}
flash.onquery {
  return $_mopt(n7,6)
}
beepchanmsg {
  if ($hget(x_tmp-cache,$+(beeping.,$1))) var %b = $ifmatch
  else {
    var %b = $readini(mirc.ini,beeping,$1)
    hadd -mu15 x_tmp-cache $+(beeping.,$1) %b
  }
  if ($hget(x_tmp-cache,beepchanmsg)) var %s = $ifmatch
  else {
    var %s = $_mopt(n0,3)
    hadd -mu15 x_tmp-cache beepchanmsg %s
  }
  if ((%s) || (%b)) && ($active != $1) return 1
}
_flashing.chan {
  if ($hget(x_tmp-cache,$+(flashing.,$1))) var %f = $ifmatch
  else {
    var %f = $readini(mirc.ini,flashing,$1)
    hadd -mu15 x_tmp-cache $+(flashing.,$1) %f
  }
  if (%f) || ($flash.onchan) return 1
}
_flashing.pvt {
  if ($hget(x_tmp-cache,$+(flashing.,$1))) var %f = $ifmatch
  else {
    var %f = $readini(mirc.ini,flashing,$1)
    hadd -mu15 x_tmp-cache $+(flashing.,$1) %f
  }
  if ((%f) || ($flash.onquery)) && ($__i(noflash.,$1) != 1) return 1
}

nnotifyonly if ($_mopt(n2,16) == 0) return 1
notifyactive return $_mopt(n3,24)
cancelawayonkp return $_mopt(n0,9)
ajoininvite return $_mopt(n3,11)
skipmotd return $_mopt(n1,11)
dedicquery return $_mopt(n0,22)
locklogs return $_mopt(n6,5)
logc return $_mopt(n1,13)
logq return $_mopt(n1,14)
keepchansopen return $_mopt(n3,23)
_maxbytes return $_mopt(n0,21)
whoisonquery return $_mopt(n1,19)
_timestamp {
  if ($_mopt(n4,12)) return $timestamp
}
_nolockedlog {
  var %q = $gettok($deltok($nopath($1-),-1,46),1,45)
  if ($locklogs) && (($query(%q)) || (%q ischan) || ($chat(%q))) return 0
  return 1
}
;----------------------------------------------------

_asc2bin {
  var %a = $asc($1), %r = $base(%a,10,2)
  return $str(0,$calc(8 - $len(%r))) $+ %r
}
_autotype {
  var %n = $replace($1-,$chr(32),$_nchr($active))
  editbox -a $editbox($active) $+ $left(%n,1)
  if ($right(%n,-1)) .timer -m 1 $rand(100,400) _autotype $ifmatch
}
_firstup {
  var %n = 1
  while ($gettok($1-,%n,32)) {
    var %w = $ifmatch
    if ($len(%w) > 1) && ($left(%w,1) isletter) var %w = $upper($left(%w,1)) $+ $lower($right(%w,-1))
    var %string = %string %w
    inc %n
  }
  return %string
}

;snippet by trb
_nohtml { 
  var %tmp, %ignore = $regsub($1-,/(<[^>]+>)/g,$null,%tmp) 
  return %tmp 
} 

;osinfo,meminfo,cpuinfo,uptime
moo return $dll(addons\moo.dll,$1,_)
cinfo var %c = $iif($1,say,ae) | %c $str(-,20) | %c CPU: $moo(cpuinfo) | %c MEM: $moo(meminfo) | %c OS: $moo(osinfo) | %c $str(-,20)

test.timers {
  var %n = 1
  while (%n <= 500) {
    .timer 1 60 return
    inc %n
    ae >>> $timer(0)
  }
  ae > total $timer(0)
}
;simple benchmark to test functions
benchmark {
  var %n = 1
  var %ticks1 = $ticks
  while (%n <= 10) {
    var %i = 1, %ticks = $ticks
    while (%i <= 50) {

      ;var %a = $_rempunct1(a..b..c!!!d=?)
      ;var %a = $dll(dlls\aircdll.dll, OptGet, teste + item1)
      ;var %a = $hget(teste,item1)

      ;var %a = $gettok($dll(dlls\aircdll.dll,winamp,isplaying),2,32)
      ;var %a = $dll(dlls\swamp.dll,WinAmpGet,state)
      ;var %a = $dll(dlls\r1dll.dll,GetCurrentWinampSong,0) 
      ;var %a = $calc($len(HaHaHaHaHaHaHaHaHaHaHaHaHaHaHa) - $len($removecs(HaHaHaHaHaHaHaHaHaHaHaHaHaHaHa,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)))
      ;var %a = $_count.upper(HaHaHaHaHaHaHaHaHaHaHaHaHaHaHa)
      ;var %a = $count_upper(HaHaHaHaHaHaHaHaHaHaHaHaHaHaHa)
      ;var %a = $_protset(lines,-)
      ;var %a = $_check.badword(this is a test with all kinds of... punctuation etc!!!!!)
      ;var %a = $_check.advertise(this is a test with all kinds of... punctuation etc!!!!!)
      ;var %f = $mflood(sites,#test)
      ;var %f = $cflood(lines,mask,#chan,nick,2)
      ;var %f = $pflood(pctcp,all)
      ;_set.all.vars.mts
      ;set -u %:echo return
      ;theme.text textchan
      var %f = $floodchk2(jflood, 5, 3, #chan, site)

      inc %i
    }
    var %sum = $calc(%sum + $calc($ticks - %ticks))
    inc %n
  }
  var %ticks = $ticks
  var %total1 = $calc(%ticks - %ticks1 -90), %total2 = $calc((%sum / (%n -1)) -8)
  echo -a  -> Total: %total1 $+ ms - average subtotal: %total2 $+ ms in $calc(%i -1) cycles ( $+ $round($calc(%total2 / $calc(%i -1)),2) $+ ms per cycle)
}

;
;

;=============================

F1 help
F2 setup
F3 cprot
F4 display
F5 {
  if ($server) && ($__i(reply.time)) echo $iif(@* iswm $active,-s,-a) $_pre $upper($gettok($__i(reply.time),1,32)) $_c(3) $+ reply from $gettok($__i(reply.time),2,32) $_c(3) $+ took $gettok($__i(reply.time),3,32) $_c(3) $+ secs.
  else nets
}
F6 {
  if ($__i(warnme)) {
    var %sel = $_select(Pick one,$__i(warnme))
    if (%sel) {
      qkick %sel
      set $_i(warnme) $remtok($__i(warnme),%sel,1,164)
    }
  }
  else sockstats
}
F7 {
  if ($server) {
    if ($__i(invited)) {
      join $ifmatch
      unset $_i(invited)
    }
    else sr -t Info You were not invited, or the invitation timed out.
  }
}
services.unban {
  if ($server) && ($__i(banned.from)) {
    var %chan = $ifmatch
    if ($__i(s^n)) cs unban %chan $iif($network == webnet,me,$me)
    elseif ($__i(network) == undernet) msg.x unban %chan $me
  }
}
F8 services.unban
F9 mp3p
F10 ul
F11 if ($server) && ($$input(Join all favorite channels?,yq)) joinall 1
F12 if ($server) awayd
;

cF1 {
  if ($active !ischan) return
  if ($__i(clones.,$active)) {
    set -u %::masksite $_screw($__(clones.,$active))
    fkb $__i(clones.,$active) $_kickmsg(clones,$active)
    unset $_i(clones.,$active)
  }
  else clones $active
}
cF2 {
  if ($window($__i(icmppingreply))) {
    window -a $__i(icmppingreply)
    unset $_i(icmppingreply)
  }
  if ($__i(spammer)) {
    var %n = $ifmatch, %m = $_kickmsg(spam)
    if ($numtok(%n,32) = 2) _kick.routine -kb %n %m
    else gkb %n %m
    unset $_i(spammer)
  }
}
cF3 {
  if ($server) {
    if ($hget($+(x_tmp-cid,$cid,-netsplit))) _getsplit
    else sr -t Netsplit No recent netsplits.
  }
}
cF4 {
  if (#) {
    if ($input(Part $active $+ ?,yq)) part #
  }
  elseif ($query($active)) {
    if ($input(Close query with $active $+ ?,yq)) close -m $active
  }
  elseif (Status* !iswm $active) window -c $active
}
cF5 if ($window($+(@infolog�,$_@network))) window -a $+(@infolog�,$_@network)
cF6 {
  if ($__i(warnme)) {
    var %sel = $_select(Pick one,$__i(warnme))
    if (%sel) {
      qkickb %sel
      set $_i(warnme) $remtok($__i(warnme),%sel,1,164)
    }
  }
  else dcch
}
cF7 {
  if ($server) _traceip
  else kickh
}
cF8 {
  if ($__i(s^n)) {
    var %c = $$_input(Clear ops on what channel?,e,Clear ops,#)
    cs clear $iif($__i(banned.from),$ifmatch,%c) ops
    ale Attempting to use ChanServ's clear ops
  }
}
cF9 {
  if ($server) && ($_select(Pick one,$__i(chan.full))) {
    var %c = $ifmatch
    .timerretry. $+ %c $+ .cid $+ $cid 61 5 join -n %c
    ale Retrying to join %c every 5secs (for the next 5mins)
  }
}
cF10 {
  if (Status?Window iswm $active) {
    clear -s
    script
    if (%profile) sle Profile: $gettok($ifmatch,-1,92)
    linesep
  }
  elseif ($$input(Clear buffer for $active $+ ?,yq)) clear
}
cF11 {
  if ($isfile($+(tmp\,$active,.buf))) _restore.chan.buf $active
  else email
}
cF12 {
  if ($isfile(debug.log)) run notepad debug.log
  else checkemail
}
;


sF1 {
  var %file = $+(",$logdirawaylog�,$_network,.log")
  if (awaylog isin $window($active).title) {
    window -c @logview
    .remove %file
    unset $_i(awaylog)
    ale Away messages have been cleared.
  }
  elseif ($window(@logview)) window -r @logview
  elseif ($isfile(%file)) logview $+(Awaylog�,$_network)
  else ale There are no away messages.
}
sF2 {
  if ($server) && ($__i(lag)) {
    sle Self-ping sent...
    set $_i(selfping) 1
    lagcheck 1
  }
}
sF3 {
  if ($isfile($+(",$logdirspamlog�,$_network,.log"))) logview Spamlog� $+ $_network
  else ale Spamlog does not exist.
}
sF4 {
  if ($_select(Ignore who?,$__i(ignore.it))) {
    var %i = $ifmatch
    ignore %i
    set $_i(clearthis) $addtok($__i(clearthis),$gettok(%i,2,32),32)
    set $_i(ignore.it) $remtok($__i(ignore.it),%i,1,164)
  }
  else ascii
}
sF5 {
  if ($window($+(@infolog�,$_@network))) && ($ircwin) && ($input(Relay last echo to $active $+ ? $+ $crlf $+ ' $+ $strip($line($+(@infolog�,$_@network),1)) $+ ',yq,Relay)) say $strip($line($+(@infolog�,$_@network),1))
}
sF6 {
  if ($__i(dccsendretry)) {
    var %targ = $_select(Retry to,$__i(dccsendretry))
    if (%targ) {
      dcc send %targ
      set $_i(dccsendretry) $remtok($__i(dccsendretry),%targ,1,164)
    }
  }
  elseif ($__i(lastjoin.,$active)) wi $ifmatch
}
sF7 if ($_select(Pick one,$__i(lastrcvdfile))) run $ifmatch
sF8 {
  if (!$server) || ($active !ischan) || (($me !isop #) && (!$__i(s^c))) || (!$input(Clear ops on $active $+ ?,yq)) return
  var %_x = $nick(#,0,o)
  while (%_x) {
    if ($nick(#,%_x,o) != $me) {
      if ($me isop #) .raw mode # -o $nick(#,%_x,o)
      elseif ($__i(s^n)) cs deop # $nick(#,%_x,o)
    }
    dec %_x
  }
}
sF9 {
  if ($server) && (($__i(s^c)) || ($__i(network) == undernet)) && (($__i(invite.only)) || ($__i(chan.full))) {
    var %c = $_select(Request Invitation,$iif($__i(chan.full),$ifmatch,$__i(invite.only)))
    if (%c) {
      if ($__i(s^c)) cs invite %c
      else msg.x invite %c $me
      set -u30 $_i(invite.req.,%c) 1
    }
  }
}
sF10 if ($server) && (#) update.ial #
sF11 {
  if ($__i(mfloodsites)) mfloodkick
  else find
}
sF12 {
  if ($__i(ret.nick)) {
    ale Nick retaking for $ifmatch has been canceled.
    if (!$__i(ret.nick.notify)) .notify -r $__i(ret.nick)
    unset $_i(ret.nick*)
  }
  elseif ($__i(ret.nick.prev)) _retnick
}
;-----------------------------------

;using dragonzap's stdio.dll
stdio return $dll(dlls\stdio.dll,$1,$2-)
std.run {
  var %p = $remove($gettok($1-,1,59),$chr(32)), %a = $stdio(ReleaseProcess,%p), %r = $stdio(RunConsole,%p,$gettok($1-,1,59))
  if ($gettok(%r,1,32) == OK) .timerstd. $+ %p -om 0 1 std.read %p ; $+ $gettok($1-,2-,59)
  else se (stdio) Couldn't create process: %r
}
std.read {
  while ($gettok(%o,1,32) != ERROR) {
    var %o = $stdio(ReadText,$1 out), %c = $gettok($1-,2,59), , %a = $gettok($1-,-1,59), %w = $wildtok(%c,@*,1,32), %l = $iif($remove(%o,ok),$gettok(%o,2-,32),$chr(9))
    if (%w) && (!$window(%w)) goto err2
    if ($gettok(%o,1,32) != ERROR) %c %l
  }
  if (ERROR STDE6 * iswm %o) {
    if (%a) { %a | goto err2 }
    goto err
  }
  return
  :err
  %c -
  :err2
  .timerstd. $+ $1 off
  var %a = $stdio(ReleaseProcess,$1)
}

;more dragonzap's idents (for MDX.dll)
mdx {
  if ($lock(dll)) return
  if ($isid) {
    if ($2- != $null) return $dll($mdx.udll,$1,$2-)
    return $dll($mdx.udll,$1,-)
  }
  dll $mdx.udll $1-
}
mdx.udll return dlls\mdx.dll
mdx.gdll return dlls\ctl_gen.mdx
mdx.vdll return dlls\views.mdx
mdx.bdll return dlls\bars.mdx
mdx.ddll return dlls\dialog.mdx
mdx.set if ($1 == icon) mdx SetDialog $dname icon $iif($3- != $mircexe,$+(graphics\,$2),$2-) | else mdx SetDialog $dname $1-
mdx.start mdx MarkDialog $dname
mdx.seticon mdx.set icon $1-
_tab {
  if (!$1-) return $chr(9) $+ 0
  var %list, %n = 1
  while (%n <= $0l) { %list = $instok(%list, $ [ $+ [ %n ] ] ,0,9) | inc %n }
  if (%list) return %list
}
dlldir var %p = $shortfn($mircdirdlls\) | if ($1) return %p $+ $1- | return %p

;using Soul_Eater's fileselect.dll
_sfile {
  var %l = $dll(dlls\fileselect.dll,FileSelectOld,$1)
  if ($2) && (!%l) halt
  return $gettok(%l,1,32) $replace($gettok(%l,2-,32),$chr(32),$chr(44))
}
_sfile1 return $dll(dlls\fileselect.dll,FileSelectNew,$1)


;===================
;using stdio.dll

;/drun <dos_app> (this runs a DOS program in a window, using stdio.dll by dragonzap)
drun {
  ale Running $upper($1) $+ ...
  var %w = $+(@,$1-)
  std.run $1- $+ ;aline %w $+ ;window -r %w
  if (!$window(%w)) window -nkl %w $_@font
  else clear %w
}

;/netstat, /icmpping <ip>, /tracer(oute) <ip> (using /drun)
netstat {
  ale Retrieving NETSTAT info...
  std.run netstat $iif($1,$1,-a) $+ ;aline @netstat;window -r @netstat
  if (!$window(@netstat)) window -nkl @Netstat $_gcoord(netstat,-1 -1 600 200) @nets $_@font
  else clear @netstat
  titlebar @netstat $iif($1,(switch $1),(active connections))
}
icmpping {
  _checkifip $1
  ale Requesting ICMP ping reply from $1 $+ ...
  var %w = $+(@ICMP,$chr(160),Ping,$chr(160),on,$chr(160),$1)
  std.run ping -n 2 $1 $+ ;aline %w $+ ;icmpping.an %w
  if (!$window(%w)) window -hkl %w $_gcoord(icmp,-1 -1 400 200) @icmp $_@font
  else clear %w
}
icmpping.an {
  if (!$window($1)) return
  var %n = 1, %q = $gettok($1,-1,160)
  while ($line($1,%n)) {
    var %l = $ifmatch
    if ($gettok($gettok(%l,2,58),2,32)) {
      var %t = $ifmatch, %m = $remove($iif(< isin %t,$gettok(%t,2,60),$gettok(%t,2,61)),ms)
      if (%m isnum) && ((%m < %s) || (%s !isnum)) var %s = %m
    }
    inc %n
  }
  if (%s) var %rp = %s $+ ms
  else var %rp = not responding
  ale ICMP ping reply results from %q $+ : %rp (ControlF2 for details)
  set -u20 $_i(icmppingreply) $1
}
tracert {
  _checkifip $1
  ale Tracing route for $1 $+ , it may take a while...
  var %w = $+(@Traceroute,$chr(160),for,$chr(160),$1)
  std.run tracert $1 $+ ;aline %w $+ ;window -r %w
  if (!$window(%w)) window -nkl %w $_gcoord(traceroute,-1 -1 550 300) @traceroute $_@font
  else clear %w
}
traceroute tracert $1-

_checkifip {
  if (!$1) { sr -th Error Parameters missing | halt }
  if (!$_isserv($1)) { sr -th Error You must specify an host or IP, not a nick | halt }
  if ((($ptnet) && (127.* iswm $1)) || (($ircx) && ($remove($1,.,x) !isnum))) { sr -th Error That IP is not real (fakemask) | halt }
}


;============================
; usage: /_draw.button <window> <x y w h> <pressed(1/0)> <font size> <text>
_draw.button {
  var %x = $2, %y = $3, %w = $4, %h = $5
  var %tx = $int($calc(%x + ((%w - $width($9-,$7,$8)) / 2))), %ty = $int($calc(%y + ((%h - $height($9-,$7,$8)) / 2)))
  if ($6) { inc %tx | inc %ty }
  drawrect -nrf $1 $rgb(face) 1 %x %y %w %h
  drawtext -n $1 1 $7 $8 %tx %ty $9-
  var %c1 = $iif($6,$rgb(shadow),$rgb(hilight)), %c2 = $iif($6,$rgb(hilight),$rgb(shadow))
  drawline -nr $1 %c1 2 %x $calc(%y + %h) %x %y $calc(%x + %w) %y
  drawline -nr $1 %c2 2 %x $calc(%y + %h) $calc(%x + %w) $calc(%y + %h) $calc(%x + %w) %y
  drawdot $1
}

;/cloak (toggle ctcps)
cloak {
  if ($hget(x_ctcps,cloak)) {
    _set ctcps cloak 0
    ale CTCP Cloaking is now off
  }
  else {
    _set ctcps cloak 1
    ale CTCP Cloaking is now on (no replies will be sent)
  }
}

;/ignore.after.kick <seconds> (ignores the user you kick for N seconds, to prevent he/she pvt you afterwards)
alias ignore.after.kick {
  if ($1 isnum 1-600) _set sets ignore.after.kick $1
  elseif ($1 == off) _unset sets ignore.after.kick
  elseif ($hget(x_sets,ignore.after.kick)) ale Ignore set to $ifmatch secs
  else ale Off
}


;IP Tracer (does an /who on the ip and it's dns)
iptracer iptrace $1-
iptrace {
  if ($_isserv($1)) set -u60 $_i(iptrace.ip) $ifmatch
  else set -u60 $_i(iptrace.ip) $$_input(What IP to trace?,e,Tracer)
  .dns $__i(iptrace.ip)
}


;====================
;logviewer

logs logview $1-
logview {
  var %f = $iif(*.log iswm $1,$1,$+($1,.log)), %file = $shortfn($logdir) $+ %f
  if ($isfile(%file)) {
    if ($window(@logview)) clear @logview
    else window $iif($2,-kn,-k) +e @LogView $_gcoord(logview,-1 -1 600 320)
    titlebar @logview - %f - $bytes($file(%file).size,3).suf $iif(awaylog� isin $1,(ShiftF1 to delete))
    loadbuf -p @logview %file
    return
  }
  if ($window(@logview)) window -c @logview
  if ($window(@logviewer)) { clear @logviewer | clear -l @logviewer }
  if (!$window(@logviewer)) window -nkSl20 +e @LogViewer $_gcoord(logviewer,-1 -1 600 320)
  var %i = 1, %e = $findfile($logdir,*.log,0,aline -l @LogViewer $nopath($1-)))
  if (%e == 0) { sr -t Logs No logs to display | window -c @logviewer }
  else { titlebar @logviewer - Right click for menu | window -a @logviewer }
}
upd.logview {
  if (!$window(@logview)) return
  var %title = $deltok($gettok($window(@logview).title,2,32),-1,46)
  if (%title != $remove($1,.log)) return
  logview %title
}
clearlogs {
  if ($input(Are you sure you want to delete $+ $crlf $+ ALL your logs?,yq,Logs)) {
    var %i = $findfile($logdir,*.log,0,if ($_nolockedlog($nopath($1-))) .remove $1-).shortfn
    if (%i == 0) ale No log files found
    elseif (%i == $window(@logviewer,1).lines) window -c @logviewer
    elseif ($window(@logviewer)) logview
  }
}
_slogs {
  if ($1 ischan) || ($chr(35) isin $1) var %mask = $+($mkfn($1),.*log)
  else var %mask = $+($mknickfn($1),.*log)
  var %bla = $findfile($logdir,%mask,0,var %list = $addtok(%list,$nopath($1-),164)), %n = $numtok(%list,164)
  if (!%n) sr -t Logs No logs found for $1
  else {
    var %sel = $$_select(Select log file,%list)
    logview $remove(%sel,.log)
  }
}

;==============
;alarm

alarm {
  if ($1) { if (*:* iswm $1) && ($gettok($1,1,58) <= 24) && ($gettok($1,2,58) <= 60) {
      .timeralarm -o $1 1 0 alarm 0
      ale Alarm set to $1
    }
    else sr Invalid format. Usage: /alarm HH:nn
    return
  }
  var %at = $hget(x_sets,alarmtype)
  if (%at == 1) ae $_c(1) $+ (Alarm $+ $_c(1) $+ ) It's now $gettok($time,1-2,58)
  elseif (%at == 2) && ($1 == 0) { if ($server) quit Time out | sr -t Alarm Exiting mIRC | .timer 1 2 exit }
  elseif (%at == 3) && ($1 == 0) { set $_i(shutdown) 1 | aaway }
  elseif (%at !isnum) && (%at) _perfd %at
  else sr -t Beeeep!!! Alarm $+ $crlf $+ It's now $gettok($time,1-2,58)
  var %s = $hget(x_sets,alarmsnd)
  if ($isfile(%s)) || ($isfile(sounds\beeper.wav)) .splay $iif(%s,%s,beeper.wav)
  else beep 5 100
}
alarm1 .timeralarm $+ $iif($1,1,2) -o 0 $iif($1,3600,1800) alarm | alarm
find30min {
  var %h = $gettok($time,1,58), %m = $gettok($time,2,58)
  if (%m < 30) return $+(%h,:30)
  return $+($iif(%h == 24,1,$calc(%h +1)),:00)
}
;=================
;ascii table

ascii {
  window -nklb -t4,8,12,16,20,24,28,32,36,40,44,48,52,56,60 +stb @Ascii $_gcoord(ascii,-1 -1 660 450) @ascii
  titlebar @Ascii Table
  var %n = 1, %c
  while (%n <= 255) {
    %c = $chr(%n)
    if (!%c) || ($istok(2.3.4.9.15.22.31.32,%n,44)) %c = <null>
    elseif (%n == 2) %c = <bold>
    elseif (%n == 3) %c = <color>
    elseif (%n == 9) %c = <tab>
    elseif (%n == 22) %c = <revrs>
    elseif (%n == 31) %c = <uline>
    elseif (%n == 32) %c = <space>
    var %n2 = $+(%n2,%n,.,$chr(9),%c,$chr(9))
    if (8 // %n) {
      aline @ascii %n2
      unset %n2
    }
    inc %n
  }
  if (%n2) aline @ascii %n2
  window -ab @ascii
}

;==========================

;/dccping <nick> (uses a chat to send a ping, only works in certain scripts)
dccping {
  if (!$ischat($1)) {
    if ($ischat($active)) var %u = $active
    else { sr -h Must use in a chat (use =nick for chats) | return }
  }
  else var %u = $1
  var %nick = $remove(%u,=)
  .msg %u PING $ticks
  set -u180 $_i(dping.,%nick) $ticks
  echo %u $replace($_echo(dccpingself),<nick>,%nick)
}

;/_dcc <send/chat> (replacer to /dcc)
_dcc {
  var %l = $lower($1)
  if (127.* iswm $2) { sr -h That IP is not real (fakemask) | return }
  if ($input(This will only work if the other party has $crlf DCC Server on ( $+ %l $+ ),ow)) {
    if ($2) {
      if (: !isin $2) {
        var %p = $_input(Port?,e,DCC,59), %h = $2 $+ : $+ $iif(%p,%p,59)
      }
      else var %h = $2
    }
    if (%h) dcc %l %h
  else dcc %l $$_input(Enter IP (or IP:port),e,DCC) }
}

;======================
;popups stuff

_getserv {
  if ($1 isin begin.end) return -
  var %t = $gettok($hget(x_misc,recservers),$1,44)
  if (%t) return $1 $+ . $gettok(%t,1,32) $+ $chr(9) $+ ( $+ $gettok(%t,2,32) $+ ):_goserv $1 $2
}
_goserv {
  if ($server) && (!$2) && (!$$input(Disconnect from current server?,yq,Server)) return
  var %s = $gettok($hget(x_misc,recservers),$1,44)
  server $iif($2,-m) %s $server($gettok(%s,1,32)).pass
}
_getchan {
  if ($1 isin begin.end) return -
  var %1 = $hget($+(x_net-,$__i(network)),chan.def), %n = $iif((%1 == 1 || %1 == $null),$hget(x_net-default,chan.list),$hget($+(x_net-,$__i(network)),chan.list)), %c = $gettok($gettok(%n,$1,44),1,32)
  if (%c) return $1 $+ . %c $+ :j $gettok(%n,$1,44)
}
_getrchan {
  if ($1 == begin) return
  if ($1 == end) return -
  var %t = $gettok($hget(x_misc,recchannels),$1,44)
  if (%t) return $1 $+ . $replace(%t,&,&&) $+ :j %t
}
_getrnick {
  if ($1 isin begin.end) return -
  var %t = $gettok($hget(x_misc,recnicks),$1,44)
  if (%t) return $1 $+ . %t $+ :nick %t
}
_rchann {
  var %net = $__i(network), %n = $iif($hget($+(x_net-,%net),chan.def),$hget(x_net-default,chan.list),$hget($+(x_net-,%net),chan.list)), %f = $iif($istok(%n,#,44),$ifmatch,$wildtok(%n,# *,1,44)), %1 = $iif($hget($+(x_net-,%net)),1,0)
  if ($isid) return $iif(%f,Remove,Add) #
  var %cp = # $chan(#).key, %m = _set $iif(%1,$+(net-,$__i(network)),net-default) chan.list
  ae %n %f
  if (%f) %m $remtok(%n,%f,44)
  else %m $addtok(%n,%cp,44)
}
_getclones {
  if ($2 isin begin.end) return -
  var %m = $iif($__i(nets-clonetype),$ifmatch,2), %add = $address($1,%m), %nick = $ialchan(%add,#,$2).nick
  if (%nick) return %nick $+ :wi %nick
}
_getteln {
  if ($1 isin begin.end) return -
  var %a = $gettok($hget(x_telnet,recent),$1,44)
  if (%a) return $1 $+ . $gettok(%a,1,32) $+ $chr(9) $+ ( $+ $gettok(%a,2,32) $+ ) $+ :telnet $gettok($hget(x_telnet,recent),$1,44)
}
_getrget {
  if ($1 isin begin.end) return -
  var %a = $gettok($hget(x_misc,recgets),$1,44)
  if (%a) return $1 $+ . $right($gettok(%a,2,58),-2) $+ :get %a
}
_getrwww var %a = $gettok($hget(x_misc,recwwws),$1,44) | if (%a) return $1 $+ . %a


addnewserver {
  _set misc recservers $qtok($hget(x_misc,recservers),$1-,10,44)
}

addnewprog {
  :new
  var %list = $hget(x_misc,progs), %prog, %name
  if ($numtok(%list,59) >= 10) { sr -h Can't add anymore | return }
  %prog = $$sfile(*.exe;*.com,Select a program to add,Add)
  if ($_input(Enter a description (optional),e,Programs)) %name = $ifmatch
  else %name = $nopath(%prog)
  _set misc progs $addtok(%list,$addtok(%prog,%name,44),59)
  if ($input(Add another?,yq,Programs)) goto new
}
retprogdesc {
  if ($1 isin begin.end) return -
  var %a = $gettok($hget(x_misc,progs),$1,59)
  if (%a) {
    if ($prop == rem) return $1 $+ . $gettok(%a,-1,44) $+ :_remprog $1
    return $1 $+ . $gettok(%a,-1,44) $+ :run -p $gettok(%a,1,44)
  }
}
_remprog if ($deltok($hget(x_misc,progs),$1,59)) _set misc progs $ifmatch | else _unset misc progs

addnewcom {
  :new
  var %list = $hget(x_misc,coms), %com, %name
  if ($numtok(%list,59) >= 10) { sr -h Can't add anymore | return }
  %com = $$_input(Enter command line,e,Command)
  if ($_input(Enter a description (optional),e,Command)) %name = $ifmatch
  else %name = $gettok(%com,1,32)
  _set misc coms $addtok(%list,$addtok(%com,%name,44),59)
  if ($input(Add another?,yq,Commands)) goto new
}
retcomdesc {
  if ($1 isin begin.end) return -
  var %a = $gettok($hget(x_misc,coms),$1,59)
  if (%a) {
    if ($prop == rem) return $1 $+ . $gettok(%a,-1,44) $+ :_remcom $1
    return $1 $+ . $gettok(%a,-1,44) $+ : $+ $gettok(%a,1,44)
  }
}
_remcom if ($deltok($hget(x_misc,coms),$1,59)) _set misc coms $ifmatch | else _unset misc coms

addnewdir {
  :new
  var %list = $hget(x_misc,dirs)
  if ($numtok(%list,59) >= 5) { sr -h Can't add anymore | return }
  var %dir = $$sdir($left($mircdir,3),Select a directory to add), %name = $_input(Enter a description (optional),e,Explorer)
  if (%name) var %dir = $addtok(%dir,%name,44)
  _set misc dirs $addtok(%list,%dir,59)
  if ($input(Add another?,yq,Explorer)) goto new
}
retdirdesc {
  if ($1 isin begin.end) return -
  var %a = $gettok($hget(x_misc,dirs),$1,59)
  if (%a) {
    if ($prop == rem) return $1 $+ . $gettok(%a,-1,44) $+ :_remdir $1
    return $1 $+ . $gettok(%a,-1,44) $+ :run explorer $gettok(%a,1,44)
  }
}
_remdir if ($deltok($hget(x_misc,dirs),$1,59)) _set misc dirs $ifmatch | else _unset misc dirs

;=================
;custom windows routines (save coords)

_savecoords {
  if ($window($1).state != normal) || ($__i(closewin.,$1)) return
  var %w = $gettok($gettok($remove($1,@),1,40),1,160)
  ;exceptions...
  if (@Whois�list isin $1) %w = who

  if ($istok(whois.snotices.wallops.ctcp.names.who.services.bans.notices.netstat.traceroute.ascii.infolog.logview.splited.logviewer.motd.icmp.textgrabber.blocked.mp3playlist.silence.telnet.replies.notice.nickfinder.explorer.memoserv.peak.clones.match.dcc.kick,%w,46)) {
    var %coords = $window($1).x $window($1).y $window($1).w $window($1).h
    _set wins coord. $+ %w %coords
    set -u1 $_i(closewin.,$1) 1
  }
}
_gcoord if ($hget(x_wins,$+(coord.,$1))) return $ifmatch | return $2
_closewin {
  _savecoords $1
  window -c $1
}

_@font {
  var %f = $+(",$window(Status Window).font,"), %s = $window(Status Window).fontsize
  return %f %s
  ;  if (%f != Arial) return %f %s
  ;  return Tahoma %s
}

_nchr {
  if ($window($1).font isin terminal.ibmpc) return $chr($iif(@* iswm $window($1),254,255))
  return $chr(160)
}

;$_check.alternate(word) checks if word is alternate caps
_check.alternate {
  var %m = $gettok($1,1,64), %n = 1, %f, %oc, %c
  while (%n <= $len(%m)) {
    %c = $mid(%m,%n,1)
    if ((%c isupper) && (%oc !islower)) || ((%c islower) && (%oc !isupper)) return
    %oc = %c
    inc %n
  }
  return 1
}

;/script.info (returns some info on the script)
script.info {
  se $sepline1
  se $_pre Version: $hget(x_status,xtreme.ver) $iif($hget(x_status,patch),$ifmatch)
  se $_pre Starts: $hget(x_status,starts)
  se $_pre Kicks: $hget(x_status,kicks)
  se $_pre Total lines: $hget(x_status,total-lines)
  se $_pre Total chars: $hget(x_status,total-chars)
  se $_pre Last news: $asctime($hget(x_status,lastnews))
  se $_pre Last ver: $asctime($hget(x_status,patch))
  se $sepline2
}

;/reset.stats (sets every stats back to 0)
reset.stats {
  var %s = _set status
  %s starts 0
  %s kicks 0
  %s total-lines 0
  %s total-chars 0
}


;EOF
