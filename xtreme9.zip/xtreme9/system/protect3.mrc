;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; protection dialogs
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;


alias cprot {
  if ($1) set -u %_loadchan $_chan($1)
  _dialog -m protect protect
}

dialog protect {
  title "Channel Protections"
  size -1 -1 390 206
  option dbu
  icon graphics\prot.ico, 0
  button "Ok", 250, 313 188 32 12, default ok
  button "Cancel", 249, 348 188 32 12, cancel
  box "Channels", 15, 7 6 76 177
  list 14, 13 27 63 135, size
  button "Add chan", 16, 15 167 29 10
  button "Del chan", 17, 45 167 29 10

  edit "", 300, 0 0 0 0, autohs
  edit "", 400, 0 0 0 0, autohs

  tab "Triggers", 241, 88 5 294 177
  list 1, 102 34 265 132, tab 241 extsel
  check "Disable", 9, 337 160 30 11, tab 241 push
  button "Edit", 10, 306 160 30 11, tab 241
  box "", 2, 96 25 279 150, tab 241

  tab "Protection lists", 242
  combo 7, 151 47 70 50, tab 242 size drop
  box "", 96, 96 25 279 150, tab 242
  button "Add mask", 18, 105 75 40 12, tab 242
  button "Rem mask", 19, 105 88 40 12, tab 242
  text "Select protection to edit", 8, 151 38 60 8, tab 242 right
  list 91, 151 62 213 107, hide tab 242
  check "Use global list", 44, 313 51 50 10, hide tab 242 left
  list 31, 151 62 213 107, hide tab 242
  check "Use global list", 45, 313 51 50 10, hide tab 242 left
  list 22, 151 62 213 107, hide tab 242
  check "Use global list", 46, 313 51 50 10, hide tab 242 left
  check "Use badword list", 69, 600 56 50 10, hide tab 242 left
  list 36, 151 62 213 107, hide tab 242
  check "Use global list", 47, 313 51 50 10, hide tab 242 left
  list 37, 151 62 213 107, hide tab 242
  check "Use global list", 48, 313 51 50 10, hide tab 242 left

  tab "Misc settings", 245
  text "Set limit to plus", 6, 117 55 65 8, tab 245 right
  check "Enable", 5, 104 40 50 10, tab 245
  box "Spambot", 4, 243 25 132 150, tab 245
  edit "", 11, 184 54 20 10, tab 245 right
  text "Every", 12, 117 66 65 8, tab 245 right
  text "users", 21, 206 55 25 8, tab 245
  edit "", 13, 184 65 20 10, tab 245 right
  text "minutes", 38, 206 66 25 8, tab 245
  box "Auto-limiter", 3, 96 25 143 64, tab 245
  box "Auto-unban", 39, 96 93 143 82, tab 245
  check "Enable", 56, 104 106 50 10, tab 245
  check "Only unban own bans", 40, 104 118 70 10, tab 245
  text "Unban older 4 if list exceeds", 41, 101 158 80 8, tab 245 right
  edit "", 42, 183 157 20 10, tab 245 right
  text "bans", 49, 205 158 25 8, tab 245
  text "minutes", 50, 205 147 25 8, tab 245
  text "minutes", 51, 205 136 25 8, tab 245
  edit "", 52, 183 146 20 10, tab 245 right
  edit "", 53, 183 135 20 10, tab 245 right
  text "Unban older than", 54, 116 136 65 8, tab 245 right
  text "Check every", 55, 116 147 65 8, tab 245 right
  check "Enable", 57, 252 40 50 10, tab 245
  check "Only on OP", 66, 272 59 45 10, tab 245
  check "Only if channel has at least", 58, 272 71 90 10, tab 245
  edit "", 59, 284 104 20 10, tab 245 right
  text "minutes", 60, 306 106 25 8, tab 245
  edit "", 61, 284 81 20 10, tab 245 right
  text "users", 62, 306 83 25 8, tab 245
  check "Part/Join channel every", 63, 272 94 90 10, tab 245
  check "Detect private spam", 64, 272 119 90 10, tab 245
  check "Detect DCC Sends (bad files)", 65, 272 131 90 10, tab 245


  button "Settings", 24, 247 159 40 12, tab 245
  button "Nickserv", 23, 289 159 40 12, tab 245
  button "Perform", 20, 331 159 40 12, tab 245
  edit "", 401, 0 0 0 0, autohs hide
  edit "", 402, 0 0 0 0, autohs hide
  edit "", 411, 0 0 0 0, autohs hide
  edit "", 412, 0 0 0 0, autohs hide
  edit "", 413, 0 0 0 0, autohs hide
  edit "", 414, 0 0 0 0, autohs hide
  edit "", 415, 0 0 0 0, autohs hide



  menu "&Setup", 500
  item "&General setup", 501, 500
  item "&Display settings", 502, 500
  item break, 505, 500
  item "&Network settings", 506, 500
  item break, 503, 500
  item "&Userlist", 504, 500
  menu "&Advanced", 600
  item "Ban protection", 601, 600
  item "Auto-rejoin to gain ops", 602, 600
  item break, 610, 600
  item "Chanserv auto-unban", 603, 600
  item "Chanserv auto-op on deop", 604, 600
  item break, 611, 600
  item "Badnick instead of badhostmask", 605, 600
  menu "&Help", 700
  item "&Help dialog", 701, 700
  item break, 702, 700
  item "&About eXtreme", 703, 700
}


on 1:dialog:protect:init:*:{
  mdx.start
  multi.lang
  mdx SetControlMDX 1 listview checkboxes rowselect single flatsb showsel report nosortheader > $mdx.vdll
  mdx SetControlMDX 91,22,31,36,37,43 listview rowselect single flatsb showsel report nosortheader > $mdx.vdll
  did -i $dname 1 1 headerdims 120 90 160 250
  did -i $dname 1 1 headertext 0 Protection $_tab Trigger $_tab Penalties $_tab Kick Message
  did -i $dname 91 1 headerdims 170 225
  did -i $dname 91 1 headertext 0 Mask $_tab Custom Kick Message
  did -i $dname 22,31,36,37 1 headerdims 100 295
  did -i $dname 22,31,36,37 1 headertext 0 Word/Mask $_tab Custom Kick Message

  if ($hget(x_sets,banprotect)) did -c protect 601
  if ($hget(x_sets,rejoingainops)) did -c protect 602
  if ($hget(x_sets,cs.autounban)) did -c protect 603
  if ($hget(x_sets,cs.autoop)) did -c protect 604
  if ($hget(x_prot,badhostmask.nick)) did -c protect 605

  didtok $dname 7 44 Advertise,Bad words,Bad nick/hostmask,Bad channels,Bad files
  did -c $dname 7 1
  _tog.lists

  _load.sets

  if (!$hget(x_sets,cflood)) && ($$input(Channel protections are disabled in main Setup dialog. Do you wish to re-enable them now?,yq)) _set sets cflood 1

}


on 1:dialog:protect:menu:*:{
  if ($did == 501) setup
  if ($did == 502) display
  if ($did == 504) ul
  if ($did == 506) nets
  if ($did == 701) help
  if ($did == 703) about
  if ($did isnum 601-605) did $iif($did($did).state,-u,-c) protect $did
}

alias -l _edit.prot {
  var %p = $gettok($gettok($did(1).seltext,1,9),6-,32), %l = $_cod(%p), %s = $gettok($did(1).seltext,5,32), %s = $iif(%s == 2,1,$iif(%s == <n/a>,-,0))
  var %trig = $remove($_mgt($did(1).seltext,2),events,per,mins,line,in,secs,clones,max), %pen = $_mgt($did(1).seltext,3), %km = $_mgt($did(1).seltext,4)

  trig %p $+  $+ %s $+  $+ %trig $+  $+ %pen $+  $+ %km
}

on 1:dialog:protect:dclick:*:{

  if ($did == 1) _edit.prot

  if ($did == 91) _edit.list
  if ($did == 31) _edit.list
  if ($did == 22) _edit.list
  if ($did == 36) _edit.list 
  if ($did == 37) _edit.list
}

alias -l _edit.list {
  tokenize 9 $did($did).seltext
  var %item = $gettok($1,6-,32), %km = $gettok($2,5-,32)
  var %newitem = $$input(Word/phrase mask,eq,Edit,%item), %newkm = $input(Custom kick message,eq,Edit,$iif(%km != -,%km))
  did -o $dname $did $did($did).sel %newitem $chr(9) $iif(%newkm,$ifmatch,-)
  dialog -v $dname
}

on 1:dialog:protect:sclick:*:{
  if ($did == 250) {

    _save.sets $did(14).seltext

    ; update aircdll sets
    _update.aircdll

    ; enforce protections with new settings
    if ($server) {
      var %n = 1
      while ($chan(%n)) {
        var %c = $ifmatch
        if ($me isop %c) {
          _alimiter %c
          _aunban %c
        }
        _chan.idle %c
        inc %n
      }
    }

  }

  if ($did == 9) did $iif($did(9).state,-b,-e) $dname 1,10
  if ($did == 10) && ($did(1).sel > 0) _edit.prot

  if ($did == 14) && ($did(300) != $did(14).seltext) {
    _save.sets $did(300)
    _load.sets $did(14).seltext
  }
  if ($did == 16) {
    _save.sets $did(14).seltext
    if ($$_input(Enter new channel,e,Add channel)) {
      did -a protect 14 $_chan($mkfn($ifmatch))
      did -c protect 14 $did(14).lines
      _load.sets $did(14).seltext
    }
  }
  if ($did == 17) && ($did(14).seltext != Global) && ($input(Delete protection settings for $did(14).seltext $+ ?,yq)) {
    _-unset $+(prot-,$did(14).seltext)
    did -d protect 14 $did(14).sel
    did -c protect 14 1
    _load.sets
  }


  ; LISTS
  if ($did == 7) _tog.lists


  ; ADD
  if ($did == 18) {
    var %id = $_tog.lists.index2($did(7).sel), %l = Enter word/phrase mask (eg: * enter #*), %text = $$input(%l,eq,$did(7))
    if ($_checklist.tb(%text,%id)) {
      sr -t Error ERROR: Item already exists
      return
    }
    if ($input(Enter custom kick message for this word/phrase?,yq)) var %text2 = $input(Enter custom kick message,eq,$did(7))
    if (%text != $null) did -a $dname %id %text $_tab $iif(%text2,$ifmatch,-)
  }

  ; REM
  if ($did == 19) {
    var %id = $_tog.lists.index2($did(7).sel)
    if ($did(%id).sel) did -d $dname %id $did(%id).sel
  }

  ;global
  if ($did == 44) {

    var %list, %n = 1, %km, %w, %chan
    if ($did(14).seltext != Global) %chan = $ifmatch

    if ($did(44).state) {
      did -b protect 91,18,19
      %list = $_protset(advertise.list)
    }
    else {
      did -e protect 91,18,19
      %list = $_protset(advertise.list,%chan)
    }
    did -r $dname 91
    while ($gettok(%list,%n,44)) {
      %w = $ifmatch
      tokenize 9 %w
      if ($2) %km = $2
      else %km = -
      did -a protect 91 $1 $chr(9) %km
      inc %n
    }
  }



  ;BADWORD
  ;global
  if ($did == 45) {

    var %list, %n = 1, %km, %w, %chan
    if ($did(14).seltext != Global) %chan = $ifmatch

    if ($did(45).state) {
      did -b protect 18,19,31
      %list = $_protset(badword.list)
    }
    else {
      did -e protect 18,19,31
      %list = $_protset(badword.list,%chan)
    }
    did -r $dname 31
    while ($gettok(%list,%n,44)) {
      %w = $ifmatch
      tokenize 9 %w
      if ($2) %km = $2
      else %km = -
      did -a protect 31 $1 $chr(9) %km
      inc %n
    }
  }



  ;BADNICK/HOST
  ;global
  if ($did == 46) {

    var %list, %n = 1, %km, %w, %chan
    if ($did(14).seltext != Global) %chan = $ifmatch

    if ($did(46).state) {
      did -b protect 18,19,22
      %list = $_protset(badhostmask.list)
    }
    else {
      did -e protect 18,19,22
      %list = $_protset(badhostmask.list,%chan)
    }
    did -r $dname 22
    while ($gettok(%list,%n,44)) {
      %w = $ifmatch
      tokenize 9 %w
      if ($2) %km = $2
      else %km = -
      did -a protect 22 $1 $chr(9) %km
      inc %n
    }
  }

  ;usebadwordlist (not in use for now)
  if ($did == 69) {

    var %list, %n = 1, %km, %w, %chan
    if ($did(14).seltext != Global) %chan = $ifmatch

    if ($did(69).state) {
      did -b protect 22,18,19,46
      if ($did(46).state) %list = $_protset(badword.list)
      else %list = $_protset(badword.list,%chan)
    }
    else {
      did -e protect 22,18,19,46
      if ($did(46).state) %list = $_protset(badhostmask.list)
      else %list = $_protset(badhostmask.list,%chan)
    }
    did -r $dname 22
    while ($gettok(%list,%n,44)) {
      %w = $ifmatch
      tokenize 9 %w
      if ($2) %km = $2
      else %km = -
      did -a protect 22 $1 $chr(9) %km
      inc %n
    }
  }


  ;BADCHANNELS
  ;global
  if ($did == 47) {

    var %list, %n = 1, %km, %w, %chan
    if ($did(14).seltext != Global) %chan = $ifmatch

    if ($did(47).state) {
      did -b protect 18,19,36
      %list = $_protset(badchan.list)
    }
    else {
      did -e protect 18,19,36
      %list = $_protset(badchan.list,%chan)
    }
    did -r $dname 36
    while ($gettok(%list,%n,44)) {
      %w = $ifmatch
      tokenize 9 %w
      if ($2) %km = $2
      else %km = -
      did -a protect 36 $1 $chr(9) %km
      inc %n
    }
  }




  ;BADFILES
  ;global
  if ($did == 48) {

    var %list, %n = 1, %km, %w, %chan
    if ($did(14).seltext != Global) %chan = $ifmatch

    if ($did(48).state) {
      did -b protect 18,19,37
      %list = $_protset(badfiles.list)
    }
    else {
      did -e protect 18,19,37
      %list = $_protset(badfiles.list,%chan)
    }
    did -r $dname 37
    while ($gettok(%list,%n,44)) {
      %w = $ifmatch
      tokenize 9 %w
      if ($2) %km = $2
      else %km = -
      did -a protect 37 $1 $chr(9) %km
      inc %n
    }
  }




  ; EXTRA

  if ($did == 5) did $iif($did(5).state,-e,-b) $dname 11,13
  if ($did == 56) did $iif($did(56).state,-e,-b) $dname 40,42,52,53

  if ($did == 58) did $iif($did(58).state,-e,-b) $dname 61
  if ($did == 63) did $iif($did(63).state,-e,-b) $dname 59
  if ($did == 57) {

    if ($did(57).state) {
      if ($did(14).seltext != Global) did -b $dname 20,23,24
      did $iif($did(58).state,-e,-b) $dname 61
      did $iif($did(63).state,-e,-b) $dname 59
      did -e $dname 66,58,63,64,65
    }
    else did -b $dname 66,58,63,64,65,61,59,20,23,24
  }
  if ($did == 24) var %a = $_dialog(sbotd,sbotd,-4)
  if ($did == 23) {
    var %pass = $_input(Enter Nickserv password for spambot,p,Spambot)
    did -ra $dname 401 %pass
  }
  if ($did == 20) did -ra $dname 402 $perfd(Perform,On connect,Spambot,$did(402))

}


alias -l _tog.lists {
  if ($did(400)) did -h $dname $ifmatch
  var %ids = $_tog.lists.index($did(7).sel)
  did -v $dname %ids
  did -ra $dname 400 %ids

  if ($did(7).sel == 1) did $iif($did(44).state,-b,-e) $dname 18,19
  if ($did(7).sel == 2) did $iif($did(45).state,-b,-e) $dname 18,19
  if ($did(7).sel == 3) did $iif($did(46).state,-b,-e) $dname 18,19
  if ($did(7).sel == 4) did $iif($did(47).state,-b,-e) $dname 18,19
  if ($did(7).sel == 5) did $iif($did(48).state,-b,-e) $dname 18,19
}
alias -l _tog.lists.index {
  ;advertise
  if ($1 == 1) return 91,44
  ;badword
  if ($1 == 2) return 31,45
  ;badnick/host
  if ($1 == 3) return 22,46,69
  ;badchans
  if ($1 == 4) return 36,47
  ;badfiles
  if ($1 == 5) return 37,48
}
alias -l _tog.lists.index2 {
  ;advertise
  if ($1 == 1) return 91
  ;badword
  if ($1 == 2) return 31
  ;badnick/host
  if ($1 == 3) return 22
  ;badchans
  if ($1 == 4) return 36
  ;badfiles
  if ($1 == 5) return 37
}

alias -l _cod {
  tokenize 32 $1-
  if ($2 == flood) return $1
  if ($1 == excess) || ($1 == mass) || ($2 == idle) return $2
  if ($1 == bad) return $remove($1-,$chr(32))
  return $1
}
alias -l _mgt {
  return $remtok($gettok($gettok($1,$2,9),5-,32),*,32)
}


; $_checklist.tb(text,list_id): returns 1 if <text> is already in list (for tabbed lists, compares 1st tab only)
alias -l _checklist.tb {
  var %n = 1, %text
  while ($did($dname,$2,%n)) {
    %text = $gettok($left($gettok($ifmatch,1,9),-1),6-,32)
    if ($1 == %text) return 1
    inc %n
  }
}


; ====================================================================
; ==================================================================== LOAD
; ====================================================================

alias -l _load.sets {

  did -r protect 1,91,31,22,36,37
  var %chan = $1

  ; first load
  if ($1 == $null) {
    did -r protect 14
    didtok protect 14 44 Global, $+ $_getchans
    var %line = 1
    if (%_loadchan) {
      var %n = 1
      while ($did(14,%n)) {
        if ($ifmatch == %_loadchan) {
          %line = %n
          %chan = %_loadchan
          break
        }
        inc %n
      }
    }
    did -c protect 14 %line

  }
  else {
    did -u $dname 5,9,40,56,57,58,63,64,65,66,44,45,46,47,48,69
    did -r $dname 11,13,42,52,53
    did -e $dname 1,10,18,19,91,31,22,36,37
  }

  if (!%chan) || (%chan == Global) {
    did -b $dname 44,45,46,47,48
    did -e $dname 20,23,24
  }
  else {
    did -e $dname 44,45,46,47,48
    did -b $dname 20,23,24
  }

  var %t = Lines Flood.Bytes Flood.Repeat Flood.Notice Flood.Nick Flood.Join Flood.CTCP Flood.�.Mass Kick.Mass Deop.Mass Ban $&
    .Excess Caps.Excess Codes.Excess Chars.Channel Idle.Clones.� $&
    .Bad Word.Bad Hostmask.Bad Channel.Bad Files.Advertise.Spam.Guests.SOCKS5.� $&
    .Flooder.SelfBan.MassKickAll.MassKickAway.MassKill
  var %n = 1

  did -ra protect 300 %chan

  while (%n <= $numtok(%t,46)) {
    var %p = $gettok(%t,%n,46), %l = $_getitem(%p)
    if (%p == �) {
      ;      did -a protect 1 �
    }
    else {
      var %switch = $_protset(%l,%chan), %switch = $iif(%switch,2,1), %pen = $_penalty(%l,%chan), %trig, %max = $_protset($+(%l,_max),%chan)
      if (%n <= 26) {
        if (mass isin %p) || (flood isin %p) %trig = %max in $_protset($+(%l,_time),%chan) secs
        elseif (excess isin %p) %trig = %max per line
        elseif (%p == clones) %trig = %max clones max
        elseif (idle isin %p) %trig = %max mins
        else %trig = -
      }
      else %trig = -
      if (!%pen) %pen = -
      did -a protect 1 1 + 0 0 %switch %p $_tab 0 0 %trig $_tab %pen $_tab $__kickmsg(%l,%chan)
    }
    inc %n
  }

  if ($_protset(disable,%chan)) {
    did -c protect 9
    did -b protect 1,10
  }
  if (%chan) && ($__i(noprotect.,%chan)) sr -t Warning Protections are temporarily disabled for this channel (Channel popup, Setup)

  ;;; LISTS

  var %a
  %a = $_load.lists(advertise,44,91,%chan)
  %a = $_load.lists(badword,45,31,%chan)
  %a = $_load.lists(badhostmask,46,22,%chan)
  %a = $_load.lists(badchan,47,36,%chan)
  %a = $_load.lists(badfiles,48,37,%chan)


  if ($_protset(autolimiter,%chan)) did -c protect 5
  if ($_protset(autolimiter.max,%chan)) did -ra protect 11 $ifmatch
  if ($_protset(autolimiter.time,%chan)) did -ra protect 13 $ifmatch

  if ($_protset(autounban,%chan)) did -c protect 56
  if ($_protset(autounban.own,%chan)) did -c protect 40
  if ($_protset(autounban.olderthan,%chan)) did -ra protect 53 $ifmatch
  if ($_protset(autounban.time,%chan)) did -ra protect 52 $ifmatch
  if ($_protset(autounban.limit,%chan)) did -ra protect 42 $ifmatch

  if ($_protset(spambot,%chan)) did -c protect 57
  if ($_protset(spambot.op,%chan)) did -c protect 66
  if ($_protset(spambot.min,%chan)) did -c protect 58
  if ($_protset(spambot.min.val,%chan)) did -ra protect 61 $ifmatch
  if ($_protset(spambot.cycle,%chan)) did -c protect 63
  if ($_protset(spambot.cycle.val,%chan)) did -ra protect 59 $ifmatch
  if ($_protset(spambot.spam,%chan)) did -c protect 64
  if ($_protset(spambot.badfiles,%chan)) did -c protect 65

  if ($_protset(spambot.nickserv) != $null) did -ra protect 401 $ifmatch
  if ($_protset(spambot.perform) != $null) did -ra protect 402 $ifmatch
  if ($_protset(spambot.nick) != $null) did -ra protect 411 $ifmatch
  if ($_protset(spambot.altnick) != $null) did -ra protect 412 $ifmatch
  if ($_protset(spambot.user) != $null) did -ra protect 413 $ifmatch
  if ($_protset(spambot.realname) != $null) did -ra protect 414 $ifmatch
  if ($_protset(spambot.server) != $null) did -ra protect 415 $ifmatch

  did $iif($did(5).state,-e,-b) $dname 11,13
  did $iif($did(56).state,-e,-b) $dname 40,42,52,53
  did $iif($did(58).state,-e,-b) $dname 61
  did $iif($did(63).state,-e,-b) $dname 59

  if ($did(57).state) {
    if ($1) && ($1 != Global) did -b $dname 20,23,24
    did $iif($did(58).state,-e,-b) $dname 61
    did $iif($did(63).state,-e,-b) $dname 59
    did -e $dname 66,58,63,64,65
  }
  else did -b $dname 66,58,63,64,65,61,59,20,23,24
}


; $_load.lists(tablename,check_id,list_id,chan,kickmsg)
alias _load.lists {

  var %list, %list.km, %chan = $4, %list_id = $3, %n = 1, %w, %km = $5, %global = $_protset($+($1,.global),%chan)

  ;  if ($1 == badhostmask) && ($_protset(badhostmask.usewordlist,%chan)) %list = $_protset(badword.list,%chan)

  if (%global) {
    did -c protect $2
    did -b protect %list_id
    %list = $_protset($+($1,.list))
    %list.km = $_protset($+($1,.list.km))
  }
  else {
    %list = $_protset($+($1,.list),%chan)
    %list.km = $_protset($+($1,.list.km),%chan)
  }

  while ($gettok(%list,%n,44)) {
    did -a protect %list_id $ifmatch $chr(9) $gettok(%list.km,%n,1)
    inc %n
  }

}


; $_save.lists(tablename,event,check_id,list_id)
alias _save.lists {

  var %table = $1, %event = $2, %check_id = $3, %list_id = $4, %n = 2, %list, %list.km

  hadd %table $+(%event,.global) $did(%check_id).state
  if (!$did(%check_id).state) {
    while ($did(%list_id,%n)) {
      tokenize 9 $ifmatch
      var %item = $gettok($1,6-,32), %km = $gettok($2,5-,32)
      %list = $_addtok(%list,%item,44)
      %list.km = $_addtok(%list.km,$iif(%km,%km,-),1)

      inc %n
    }
    hadd %table $+(%event,.list) %list
    hadd %table $+(%event,.list.km) %list.km
  }


}
; ====================================================================
; ==================================================================== SAVE
; ====================================================================


alias -l _save.sets {
  var %n = 2, %line, %item, %table = x_prot

  if ($1 != $null) && ($1 != Global) {
    %table = x_prot- $+ $1
  }
  if ($hget(%table) == $null) hmake %table 10

  while ($did(1,%n)) {
    %line = $ifmatch
    tokenize 9 %line
    var %sw = $iif($gettok($1,5,32) == 2,1,0), %prot = $gettok($1,6-,32), %trig = $gettok($2,5-,32), %pen = $gettok($3,5-,32), , %km = $gettok($4,5-,32)
    if (%n <= 24) {

      if (*in*secs iswm %trig) {
        if (mass isin %prot) %item = $gettok(%prot,2,32)
        else %item = $gettok(%prot,1,32)
        hadd %table %item %sw
        hadd %table $+(%item,_max) $gettok(%trig,1,32)
        hadd %table $+(%item,_time) $gettok(%trig,3,32)
        hadd %table $+(%item,_penalty) %pen
        hadd %table $+(%item,_kickmsg) %km
      }
      elseif (*per*line iswm %trig) {
        %item = $gettok(%prot,2,32)
        hadd %table %item %sw
        hadd %table $+(%item,_max) $gettok(%trig,1,32)
        hadd %table $+(%item,_penalty) %pen
        hadd %table $+(%item,_kickmsg) %km
      }
      elseif (idle isin %prot) {
        hadd %table idle %sw
        hadd %table idle_max $gettok(%trig,1,32)
        hadd %table idle_penalty %pen
        hadd %table idle_kickmsg %km
      }
      elseif (clones isin %prot) {
        hadd %table clones %sw
        hadd %table clones_max $gettok(%trig,1,32)
        hadd %table clones_penalty %pen
        hadd %table clones_kickmsg %km
      }
      else {
        %item = $remove(%prot,$chr(32))
        hadd %table %item %sw
        hadd %table $+(%item,_penalty) %pen
        hadd %table $+(%item,_kickmsg) %km
      }
    }
    else {
      %item = $remove(%prot,$chr(32))
      hadd %table $+(%item,_kickmsg) %km
    }
    inc %n
  }

  hadd %table disable $did(9).state

  var %a
  %a = $_save.lists(%table,advertise,44,91)
  %a = $_save.lists(%table,badword,45,31)
  %a = $_save.lists(%table,badhostmask,46,22)
  %a = $_save.lists(%table,badchan,47,36)
  %a = $_save.lists(%table,badfiles,48,37)


  hadd %table autolimiter $did(5).state
  hadd %table autolimiter.max $did(11)
  hadd %table autolimiter.time $did(13)

  hadd %table autounban $did(56).state
  hadd %table autounban.own $did(40).state
  hadd %table autounban.olderthan $did(53)
  hadd %table autounban.time $did(52)
  hadd %table autounban.limit $did(42)

  hadd %table spambot $did(57).state
  hadd %table spambot.op $did(66).state
  hadd %table spambot.min $did(58).state
  hadd %table spambot.min.val $did(61)
  hadd %table spambot.cycle $did(63).state
  hadd %table spambot.cycle.val $did(59)
  hadd %table spambot.spam $did(64).state
  hadd %table spambot.badfiles $did(65).state

  hadd x_prot spambot.nickserv $_pwd($did(401))
  hadd x_prot spambot.perform $did(402)
  hadd x_prot spambot.nick $did(411)
  hadd x_prot spambot.altnick $did(412)
  hadd x_prot spambot.user $did(413)
  hadd x_prot spambot.realname $did(414)
  hadd x_prot spambot.server $did(415)


  hadd x_sets banprotect $did(601).state
  hadd x_sets rejoingainops $did(602).state
  hadd x_sets cs.autounban $did(603).state
  hadd x_sets cs.autoop $did(604).state
  hadd x_prot badhostmask.nick $did(605).state

  _hsave %table
  _hsave x_sets

}
alias -l _penalty {
  if ($hget($+(x_prot-,$2),$+($1,_penalty))) return $ifmatch
  return $hget(x_prot,$+($1,_penalty))
}
alias -l _getitem {
  tokenize 32 $1-
  if ($2 == flood) return $1
  if ($1 == excess) || ($1 == mass) || ($2 == idle) return $2
  if ($1 == bad) return $remove($1-,$chr(32))
  return $1
}
alias -l _getchans {
  var %n = 1, %s, %a
  while ($hget(%n)) {
    %s = $ifmatch
    if (x_prot-* iswm %s) && ($hget(%s,0).item > 0) %a = $addtok(%a,$gettok(%s,2-,45),44)
    inc %n
  }
  return %a
}


;__________________________________________________________________________________________________________________________________________________

;
alias -l trig {
  if ($dialog(trigger)) return
  if ($1) {
    set -u %_trig $1-
    dialog -mo trigger trigger
  }
}
dialog trigger {
  title "Configure protection"
  size -1 -1 341 352
  option pixels
  icon graphics\notes4.ico, 0
  check "Enable", 1, 24 35 60 15
  box "Switch", 9, 9 10 90 60
  text "Trigger at", 10, 110 35 60 15, hide
  text "events", 11, 210 35 50 15, hide
  edit "", 12, 160 31 45 22, hide right
  edit "", 22, 258 31 40 22, hide right
  text "secs", 21, 300 35 26 15, hide
  box "Triggers", 210, 102 10 230 60
  list 101, 41 122 275 105, extsel
  combo 102, 42 98 125 308, drop
  button "Add", 103, 173 99 45 20
  button "Rem", 105, 221 99 45 20
  button "Edit", 201, 269 99 45 20, disable
  button "/\", 104, 24 123 17 46
  button "\/", 106, 24 170 17 46
  box "Penalties", 211, 9 77 322 157
  box "Kick message", 212, 9 240 323 73
  edit "", 107, 24 263 293 22, autohs
  button "Default", 108, 257 286 60 20
  text "No triggers for this event", 41, 122 35 190 15, hide disable center
  text "No penalties for this event", 42, 70 132 190 15, hide disable center
  button "Ok", 50, 200 321 60 24, default ok
  button "Cancel", 49, 270 321 60 24, cancel
  edit "", 40, 0 0 300 0, hide autohs
}

alias -l _custpenalty {
  var %t = Here you can use normal identifiers, but should use <nick>, <chan>, <fulladdress> and <type>., %a = $perfd(0,penalty,%t,$replace($gettok($did(trigger,101).seltext,2-,58),�,$chr(44))), %e = . Custom: $+ %a
  if (%a) {
    if ($1) did -o trigger 101 $1 $1 $+ %e
    else did -a trigger 101 $calc($did(trigger,101).lines +1) $+ %e
  }
}
on 1:dialog:trigger:*:*:{

  if (%_trig) did -ra trigger 40 $ifmatch
  var %name = $gettok($did(40),1,1), %sname = $_cod(%name), %s = $gettok($did(40),2,1)
  var %trig = $gettok($did(40),3,1), %1 = $gettok(%trig,1,32), %2 = $gettok(%trig,2,32)
  var %pen = $gettok($did(40),4,1), %km = $gettok($did(40),5-,1)

  if ($devent == init) {
    multi.lang
    var %ev = $lower($iif(%sname == idle,mins,$iif($right(%sname,1) == s,%sname,$+(%sname,s))))
    did -ra trigger 12,22 0
    if (%s == 1) did -c trigger 1
    if (%trig == -) did -v trigger 41
    elseif (%2) { did -ra trigger 11 %ev in | did -v trigger 10,11,12,21,22 | did -ra trigger 12 %1 | did -ra trigger 22 %2 }
    elseif (%1) { did -ra trigger 11 %ev | did -v trigger 10,11,12 | did -ra trigger 12 %1 }
    if (%pen == -) {
      did -b trigger 1
      dialog -t trigger Configure event
      did -h trigger 101,102,103,104,105,106
      did -v trigger 42
    }
    else {
      didtok trigger 102 46 Nothing.Local_Warn.Warn_User.Warn_Chan.Warn_Ops.Deop.Ban.Tempban.Kick.Filterkick.Filterkickban.Tempkickban.Kickban.Guestkickban.Badhostkickban.Sitekickban.Custom
      did -c trigger 102 2
      var %n = 1
      while (%n <= $numtok(%pen,183)) {
        did -a trigger 101 %n $+ . $gettok(%pen,%n,183)
        inc %n
      }
    }
    did -ra trigger 9 $_firstup(%name)
    did -ra trigger 107 %km
  }
  if ($devent == edit) && ($istok(12.22,$did,46)) && (($did($did) !isnum) || ($did($did) > 999)) did -ra trigger $did $left($did($did),-1)
  if ($devent == dclick) {
    if ($did == 101) {
      if ($+(*.,$chr(32),custom:*) iswm $did(101).seltext) _custpenalty $did(101).sel
      elseif ($+(*.,$chr(32),warn_*) iswm $did(101).seltext) _edit.warn $did(101).sel $did(101).seltext
    }

  }
  if ($devent == sclick) {
    if ($+(*.,$chr(32),custom:*) iswm $did(101).seltext) || ($+(*.,$chr(32),warn_*) iswm $did(101).seltext) did -e trigger 201
    else did -b trigger 201
    if ($did == 103) {
      if ($did(102) == custom) _custpenalty
      elseif (warn_* iswm $did(102)) {
        var %text = Enter your warning message (optional) $crlf $+ Use <type>, <nick>, <chan>, <me>
        var %msg = $_input(%text,yq,Warning)
        did -a trigger 101 $calc($did(101).lines +1) $+ . $did(102) $+ $iif(%msg,: $+ %msg)
      }
      else did -a trigger 101 $calc($did(101).lines +1) $+ . $did(102)
    }
    if ($did == 201) && ($did(101).sel) {
      if ($+(*.,$chr(32),custom:*) iswm $did(101).seltext) _custpenalty $did(101).sel
      elseif ($+(*.,$chr(32),warn_*) iswm $did(101).seltext) _edit.warn $did(101).sel $did(101).seltext
    }
    if ($did == 104) {
      _listup 101
      _updn
    }
    if ($did == 105) && ($did(101).sel) && ($did(101).lines > 1) {
      did -d trigger 101 $did(101).sel
      _updn
    }
    if ($did == 106) {
      _listdown 101
      _updn
    }

    if ($did == 108) {
      did -ra trigger 107 $__kickmsg(%sname,default)
    }

    if ($did == 50) {
      var %n = 1, %pen, %t1, %t2, %t3, %trig, %s, %li = $did(protect,1).sel, %km = $did(107)
      while (%n <= $did(101).lines) {
        %pen = $_addtok(%pen,$gettok($did(101,%n),2-,32),183)
        inc %n
      }
      if (!%pen) %pen = -
      %t1 = $did(12)
      %t2 = $did(22)
      if (%t2) %trig = %t1 in %t2 secs
      elseif (%t1) %trig = %t1 $iif(%name == clones,clones max,$iif(idle isin %name,mins,per line))
      else %trig = -
      %s = $iif($did(1).state,2,1)
      did -o protect 1 %li 1 + 0 0 %s %name $+ 	0 0 0 %trig $+ 	0 %pen $+ 	0 %km
      did -c protect 1 %li
      dialog -v protect
    }
  }
}
alias -l _edit.warn {
  var %text = Enter your warning message (optional) $crlf $+ Use <type>, <nick>, <chan>, <me>
  var %msg = $_input(%text,yq,Warning,$gettok($2-,2-,58))
  did -o trigger 101 $1 $gettok($2-,1,58) $+ $iif(%msg,: $+ %msg)
}
alias _listup {
  if ($did($1).sel > 1) {
    var %l = $calc($did($1).sel -1)
    did -i $dname $1 %l $did($1).seltext
    did -d $dname $1 $did($1).sel
    did -c $dname $1 %l
  }
}
alias _listdown {
  if ($did($1).sel < $did($1).lines) {
    var %l = $calc($did($1).sel +2)
    did -i $dname $1 %l $did($1).seltext
    did -d $dname $1 $did($1).sel
    did -c $dname $1 $calc(%l -1)
  }
}
alias -l _updn {
  var %c = $did(101).sel, %n = 1
  while (%n <= $did(101).lines) {
    did -o trigger 101 %n %n $+ . $gettok($did(101,%n),2-,32)
    inc %n
  }
  if (%c) did -c trigger 101 %c
}

;__________________________________________________________________________________________________________________________________________________

;
;kick dialog
alias kickd {
  set -u1 %_kickstuff $1-
  var %a = $_dialog(kickd,kickd,-4)
}
dialog kickd {
  title "Kick options"
  size -1 -1 204 97
  option dbu
  icon graphics\warning.ico, 0
  box "", 250, 10 25 44 53
  box "", 249, 56 25 139 53
  text "Reason", 1, 4 15 30 8, right
  combo 2, 36 13 152 80, edit drop
  radio "Kick", 3, 17 35 35 8
  radio "KickBan", 4, 17 46 35 8
  radio "Ban", 5, 17 57 35 8
  combo 6, 64 33 124 120, drop
  check "Tempban", 9, 64 48 40 8
  combo 10, 109 47 79 60, drop
  button "Ok", 50, 68 82 30 12, ok default
  button "Cancel", 51, 101 82 30 12, cancel
  check "Filter", 11, 161 67 27 10, push
  check "Include tempban in kickmsg", 12, 64 59 100 8, disable
  edit "", 100, 0 0 0 0, hide autohs
}
alias -l _gbt {
  if ($gettok($did(10),2,32) == min) return $calc($gettok($did(10),1,32) * 60)
  else return $gettok($did(10),1,32)
}
alias -l _resdids {
  did -e kickd 2,3,4,5,6,9,10,12
  if ($did(3).state) did -b kickd 6,9,10
  if ($did(4).state) did -b kickd 10
  if ($did(5).state) did -b kickd 2,10
  if ($did(11).state) { if ($did(5).state) did -c kickd 4 | did -ub kickd 5,10 | did -e kickd 6 }
  if ($did(9).state) did -e kickd 10,12
  else did -b kickd 12
}
on 1:dialog:kickd:*:*:{
  if ($devent == init) {
    tokenize 32 %_kickstuff
    did -ra kickd 100 $1-
    dialog -t kickd Kick options for $2 ( $+ $1 $+ )
    multi.lang
    var %km = $read(system\kicks.txt)
    if (%km) did -a kickd 2 %km
    var %dkm = $hget(x_misc,reckickmsgs)
    if (%dkm) didtok kickd 2 164 $ifmatch
    didtok kickd 2 46 not welcome.flood detected.badword detected.pub/spamming not allowed
    did -c kickd $calc($3 +3)
    _resdids
    var %m = $_address($2,5), %db = $hget(x_prot,default_banmask), %n = 0
    did -ra kickd 6 $2 $+ !*@*
    while (%n <= 9) {
      did -a kickd 6 $mask(%m,%n)
      inc %n
    }
    did -a kickd 6 $_mask(%m,20)
    did -a kickd 6 $_mask(%m,18)
    if (%db == 20) did -c kickd 6 12
    elseif (%db == 18) did -c kickd 6 13
    elseif (%db == 19) did -c kickd 6 1
    else did -c kickd 6 $calc(%db +2)
    didtok kickd 10 46 20 secs.60 secs.5 min.10 min.30 min
    did -c kickd 10 2
    did -c kickd 2 1
  }
  if ($devent == sclick) {
    tokenize 32 $did(100)
    _resdids
    if ($did == 50) {
      if ($did(2)) && ($did(2).sel != 1) && (!$istok(not welcome.flood detected.badword detected.pub/spamming not allowed,$did(2),46)) _set misc reckickmsgs $qtok($hget(x_misc,reckickmsgs),$did(2),5,164)
      var %km = $iif($did(2),$did(2),$randkickmsg)
      if ($did(9).state) && ($did(12).state) %km = %km ...tempban $gettok($did(10),1,32) $+  $+ $gettok($did(10),2,32)
      if ($did(11).state) {
        if ($did(3).state) fk $1 $_address($2,2) %km
        elseif ($did(4).state) fkb $1 $_address($2,2) %km
      }
      elseif ($did(3).state) qkick $1 $2 %km
      elseif ($did(4).state) {
        .raw MODE $1 $iif($2 isop $1,-o+b $2,+b) $did(6)
        qkick $1 $2 %km
      }
      elseif ($did(5).state) .raw MODE $1 $iif($2 isop $1,-o+b $2,+b) $did(6)
      if ($did(9).state) .timer 1 $_gbt _timed.unban $1 $did(6)
    }
  }
}
alias -l _timed.unban if ($me isop $1) .raw MODE $1 -b $2
;
; EOF
