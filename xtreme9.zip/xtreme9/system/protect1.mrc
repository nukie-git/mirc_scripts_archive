;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; channel and personal protection (events)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

on @!*:JOIN:#:{
  if ($_prot.disable(#)) || ($_exempt.ul($fulladdress,#)) return

  var %nsplit = $hget($+(x_tmp-cid,$cid,-netsplit)), %wildsite = $mask($fulladdress,$__i(nets-clonetype))
  if (!%nsplit) && ($cflood(join,%wildsite,#)) {
    penalty join $nick # $_kickmsg(join,#)
  }
  elseif ($_protset(clones,#)) && ($ialchan(%wildsite,#,0) >= $_protset(clones_max,#)) && ($ialchan(%wildsite,#,0) >= 2) {
    penalty clones $nick # $_kickmsg(clones,#)
  }
  elseif ($_protset(badhostmask,#)) {
    if ($hget(x_prot,badhostmask.nick)) {
      if ($_check.badhostmask($nick)) set -u %_badhost $ifmatch
    }
    elseif ($_check.badhostmask($replace($remove($gettok($fulladdress,1,64),~),!,$chr(32)))) set -u %_badhost $ifmatch
    if (%_badhost) penalty badhostmask $nick # $_kickmsg(badhostmask,#)
  }
  var %tls = $+(lastscan.cid,$cid)
  if (guest* iswm $nick) && ($_protset(guests,#)) penalty guests $nick # $_kickmsg(guests,#)
  elseif ($_protset(badchannel,#)) .timer 1 5 _badchan.wi2 # $nick
  elseif ($_protset(socks5,#)) && (!$istok($hget(x_vars,%tls),$site,44)) {
    var %sc = $+(socks�,$nick,�,#,�k)
    if (!$sock(%sc)) {
      sockopen %sc $site $iif($hget(x_prot,socksp),$hget(x_prot,socksp),1080)
      _var %tls $qtok($hget(x_vars,%tls),$site,20,44)
    }
  }

  ;massflood routine (massjoin)
  if (!%nsplit) && ($mflood($site,#)) {
    echo # $replace($_echo(massflood),<type>,join,<chan>,#)
    if ($hget(x_prot,mflood_action)) _perfd $ifmatch
    else mode # +im
  }
  set $_i(lastjoin.,#,.ips) $qtok($__i(lastjoin.,#,.ips),$wildsite,10,44)
}

on *:PART:#:{
  if ($nick == $me) {
    .timer $+ $+(op.event.,#) off
    return
  }
  if ($nick(#,0) == 2) && ($me !isop #) _gainop #
}

on @*!:KICK:#:{
  if ($_prot.disable(#)) return
  if ($knick != $me) && (!$_exempt.ul($fulladdress,#)) && ($cflood(kick,$site,#,$nick)) penalty kick $nick # $_kickmsg(kick,#)
}

on *:BAN:#:{
  var %w = $+(@Bans�,#,�,$_@network)
  if ($window(%w)) aline %w $banmask $+ $chr(9) $+ $_c(4) $+ $fulladdress $+ $chr(9) $+ now

  if ($__i(nets-ialupd) == 2) && ($me !isop #) return

  var %i = 1
  while ($ialchan($banmask,#,%i).nick) {
    var %nick = $ifmatch, %bnicks = $iif($len(%bnicks) < 850,$addtok(%bnicks,%nick,32),$addtok(%bnicks,...,32))
    nickcol %nick # $_ncread(enemy)
    inc %i
  }
  if (%bnicks) && ($hget(x_display,show.bannednicks)) echo # $replace($_echo(banned.nicks),<chan>,#,<text>,$sorttok(%bnicks,32))

  var %myaddress = $__i(myaddress)
  if ($banmask iswm %myaddress) || ($banmask iswm $puttok(%myaddress,$ip,2,64)) {
    var %banned = 1
    event.sound warning
    echo # $replace($_echo(ban.on.me),<nick>,$nick,<chan>,#,<banmask>,$banmask)
    if ($nick != $me) se $replace($_echo(ban.on.me2),<nick>,$nick,<chan>,#,<banmask>,$banmask)
    flash BANNED
  }
  if ($me !isop #) return

  if (%bnicks) && ($calc($len($__i(banned.nicks.,#)) + $len(%bnicks)) < 920) set -u2 $_i(banned.nicks.,#) $addtok($__i(banned.nicks.,#),%bnicks,32)
  set $_i(lastbans.,#) $qtok($__i(lastbans.,#),$banmask,30,44)
  set $_i(lastunbans.,#) $remtok($__i(lastunbans.,#),$banmask,1,44)

  ; ban protection
  if (%banned) && ($hget(x_sets,banprotect)) {
    if (($nick == $me) || (. isin $nick)) {
      .timer 1 0 _checkownban # $banmask
      return
    }
    if ($hget(x_sets,cs.autounban)) {
      if ($__i(s^n)) {
        cs deop # $nick
        cs unban # $iif($network == webnet,me,$me)
      }
      elseif ($network == galaxynet) {
        .msg Q deop # $nick
        .msg Q unban # $banmask
      }
    }

    ;;; kick on first atempt
    if ($hget(x_sets,banprotect) == 2) {
      .raw MODE # -ob+b $nick $banmask $_address($nick,$hget(x_prot,default_banmask))
      qkick # $nick $_kickmsg(selfban,#)
      rawnotice $nick $replace($_echo(dont.ban.me),<chan>,#,<nick>,$nick)
      return
    } 

    ;;; kick on second attempt
    elseif ($hget(x_sets,banprotect) == 3) {
      if ($__i(ban.try.,$nick)) {
        .raw MODE # -ob+b $nick $banmask $_address($nick,$hget(x_prot,default_banmask))
        qkick # $nick $_kickmsg(selfban,#)
        unset $_i(ban.try.,$nick)
        return
      }
      set -u180 $_i(ban.try.,$nick) 1
      .raw MODE # -ob $nick $banmask
      rawnotice $nick $replace($_echo(dont.ban.me),<chan>,#,<nick>,$nick)
    }

    ;;; just deop and warn
    else {
      .raw MODE # -ob $nick $banmask
      rawnotice $nick $replace($_echo(dont.ban.me),<chan>,#,<nick>,$nick)
    }
  }

  if ($ibl(#,0) > $gettok($hget(x_autounban,#),4,44)) {
    set $_i(aunban.,#) 4
    .raw mode # +b
  }
  if ($nick == $me) return

  ; protections
  if ($_prot.disable(#)) return
  if (%bnicks) && (!$_exempt.ul($fulladdress,#)) && ($cflood(ban,$site,#,$nick)) penalty ban $nick # $_kickmsg(ban,#)
  elseif ($_isprotected($banmask,#)) {
    var %pu = $ifmatch
    echo -t # $replace($_echo(protected.user.echo),<nick>,$nick,<user>,%pu,<chan>,#)
    _ff mode # -ob $nick $banmask
    rawnotice $nick $replace($_echo(protected.user.notice),<nick>,$nick,<user>,%pu,<chan>,#)
  }
  elseif ($_protset(kickonban,#)) fk # $banmask $_kickmsg(bannedby,#)
}

on *:UNBAN:#:{
  var %w = $+(@Bans�,#,�,$_@network)
  if ($window(%w)) {
    var %n = $line(%w,0)
    while (%n) {
      if ($gettok($line(%w,%n),1,9) == $1) dline %w %n
      dec %n
    }
    if ($line(%w,0) == 4) window -c %w
  }

  if ($__i(nets-ialupd) == 2) && ($me !isop #) return

  var %i = 1
  while ($ialchan($banmask,#,%i)) {
    var %host = $ifmatch, %nick = $ialchan($banmask,#,%i).nick, %ubnicks = $iif($len(%ubnicks) < 850,$addtok(%ubnicks,%nick,32),$addtok(%ubnicks,...,32))
    nickcol %nick # $_getcol(%nick,%host,#)
    inc %i
  }
  if (%ubnicks) && ($hget(x_display,show.bannednicks)) echo # $replace($_echo(unbanned.nicks),<text>,$sorttok(%ubnicks,32))

  if ($me !isop #) return
  set $_i(lastbans.,#) $remtok($__i(lastbans.,#),$banmask,1,44)
  set $_i(lastunbans.,#) $qtok($__i(lastunbans.,#),$banmask,30,44)
  _--unset tempbans $+($_network,:,#,:,$banmask)
}

on *:QUIT:{

  if ($hget(x_prot,excessfloodban)) && (excess flood* iswm $1-) {
    var %s = $site
    if ($__i(eflood.,%s)) {
      if ($ifmatch == 2) {
        var %exfloodb = 1
        unset $_i(eflood.,%s)
      }
      else inc $_i(eflood.,%s)
    }
    else set -u20 $_i(eflood.,%s) 1
  }

  var %n = 1
  while ($comchan($nick,%n)) {
    var %c = $ifmatch
    if ($nick(%c,0) == 2) && ($me !isop %c) _gainop %c
    if (!$_prot.disable(%c)) && ($me isop %c) && (%exfloodb) fkb %c $_kickmsg(excessfloodban)
    inc %n
  }
}

on *!:NICK:{
  if ($_check.badhostmask($newnick)) set -u %_badhost $ifmatch
  if (guest* iswm $newnick) var %guest = 1

  var %n = 1, %network = $__i(network), %nick = $newnick, %add = $fulladdress
  while ($comchan($newnick,%n)) {
    var %chan = $ifmatch, %net = %network
    if ($me !isop %chan) goto next

    if ($_aul(UserHost2Flags,%net %add $1)) var %lev = $ifmatch
    else var %lev = $_aul(UserHost2Flags,- %add $1), %net = -

    var %hand = $gettok(%lev,1,32), %flags = $gettok(%lev,2,32)
    if ($_aul(UserChrecIs,%net %hand $1)) var %flags- = $_aul(UserFlagsGet,%net %hand $1), %info = $_aul(UserGetChanInfo,%net %hand $1)
    else var %flags- = %flags, %info = $_aul(UserEntryGet,%net %hand INFO)
    var %color = $_aul(UserEntryGetW,%net %hand XTRA Nickcolor)
    if (%color isnum 0-15) _cline %color %nick

    if (E isincs %flags-) {
      set -u %::reason %info
      qkickb $1 %nick $_kickmsg(blacklist)
    }
    elseif (b isincs %flags) {
      set -u %::reason %info
      qkickb $1 %nick $_kickmsg(banned,$1)
    }
    elseif (o isincs %flags) && (%nick !isop $1) .raw mode $1 +o %nick
    elseif (v isincs %flags) && (%nick !isvoice $1) && (%nick !isop $1) .raw mode $1 +v %nick
    elseif (n isincs %flags) && (%nick isop $1) .raw mode $1 -o %nick
    elseif ($me isowner $1) && (q isincs %flags) && (%nick !isowner $1) .raw mode $1 +q %nick

    elseif (!$_prot.disable(%chan)) && (!$_exempt.status($newnick,%chan)) && (!$_exempt.ul($fulladdress,%chan)) && (e !isincs %flags) {
      if ($cflood(nick,$site,%chan)) penalty nick $newnick %chan $_kickmsg(nick,%chan)
      elseif ($_protset(badhostmask,%chan)) && (%_badhost) penalty badhostmask $newnick %chan $_kickmsg(badhostmask,%chan)
      elseif (%guest) && ($_protset(guests,%chan)) penalty guests $newnick %chan $_kickmsg(guests,%chan)
    }

    :next
    inc %n
  }
}

on @*:SERVEROP:#:{
  if (!$_prot.disable(#)) && ($hget(x_prot,nethack)) && ($opnick != $me) && (!$_exempt.ul($address($opnick,5),#)) _ff mode # -o $opnick
}

on *!:OP:#:{
  if ($opnick == $me) {
    if ($hget(x_sets,revkick)) && ($__i(revkick.,#)) {
      var %revnick = $ifmatch
      if (%revnick ison #) {
        if ($hget(x_prot,revenge.action)) _perfd $replace($ifmatch,<nick>,%revnick,<chan>,#,<me>,$me,<address>,$address)
        else qkick # %revnick $_kickmsg(revengekick)
      }
      unset $_i(revkick.,#)
    }
    .timer $+ $+(op.event.,#) 1 $iif($__i(just.joined.,#),20,10) _op.event #
  }
  else {
    if (!$_prot.disable(#)) && ($me isop #) && (($_protset(nethack,#)) || (n isincs $_getflagsd($address($opnick,5),#))) _ff mode # -o $opnick
  }
}
alias -l _op.event {
  if ($__i(nets-ialupd) == 2) && (!$chan($1).ial) ialupd $1
  else _process.ul $1 prot
  _process.tempbans $1
  _alimiter $1
  .timer 1 30 _aunban $1
}

on *!:DEOP:#:{
  if ($opnick == $me) && ($hget(x_sets,cs.autoop)) {
    var %d = $hget(x_sets,cs.autoop.deop)
    if ($__i(s^n)) {
      _ff cs op # $me
      if (%d) _ff cs deop # $nick
    }
    elseif ($network == undernet) {
      _ff msg.x op # $me
      if (%d) _ff msg.x deop # $nick
    }
    elseif ($network == galaxynet) {
      _ff .msg Q op # $me
      if (%d) _ff .msg Q deop # $nick
    }
  }
  elseif (!$_prot.disable(#)) && ($me isop #) && (!$_exempt.ul($fulladdress,#)) && ($cflood(deop,$site,#,$nick)) penalty deop $nick # $_kickmsg(deop,#)
}
on @*!:DEOWN:#:{
  if (!$_prot.disable(#)) && ($opnick != $me) && (!$_exempt.ul($fulladdress,#)) && ($cflood(deop,$site,#,$nick)) penalty deop $nick # $_kickmsg(deown,#)
}

on @*:TEXT:*:#:{
  _text.protect $nick # lines $1-
}
on @*:ACTION:*:#:{
  _text.protect $nick # lines $1-
}
on @*:NOTICE:*:#:{
  _text.protect $nick # notice $1-
}

CTCP @*:*:#:{
  var %wm = $mask($fulladdress,$hget(x_pprot,pflood.ignore_mask))
  if (!$_prot.disable(#)) && (!$_exempt.status($nick,#)) && (!$_exempt.ul($fulladdress,#)) {
    if ($cflood(ctcp,$site,#)) {
      ignore -ndtu $+ $hget(x_pprot,pflood.ignore_time) %wm
      penalty ctcp $nick # $_kickmsg(ctcp,#)
    }
    elseif ($mflood($site,#)) {
      echo # $replace($_echo(massflood),<type>,CTCP,<chan>,#)
      ignore -ntdu10 *!*@*
      if ($hget(x_prot,mflood_action)) _perfd $ifmatch
      else mode # +im
    }
  }
  halt
}

;_______________ PERSONAL PROTS

on *!:TEXT:*:?:{
  var %wm = $mask($fulladdress,$hget(x_pprot,pflood.ignore_mask))
  if (!$_isservice($nick,$site)) && ($pflood(pmsg,%wm)) {
    ae $replace($_echo(pflood),<type>,PVTMSG,<nick>,$nick,<address>,$address)
    prot.ignore -pu $+ $hget(x_pprot,pflood.ignore_time) %wm
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    if ($hget(x_pprot,pflood.kick)) prot.gkb $nick $_kickmsg(flooder)
  }
}
on *!:ACTION:*:?:{
  var %wm = $mask($fulladdress,$hget(x_pprot,pflood.ignore_mask))
  if (!$_isservice($nick,$site)) && ($pflood(pmsg,%wm)) {
    ae $replace($_echo(pflood),<type>,PVTMSG,<nick>,$nick,<address>,$address)
    prot.ignore -pu $+ $hget(x_pprot,pflood.ignore_time) %wm
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    if ($hget(x_pprot,pflood.kick)) prot.gkb $nick $_kickmsg(flooder)
  }
}
on *!:NOTICE:*:*:{
  var %wm = $mask($fulladdress,$hget(x_pprot,pflood.ignore_mask))
  if (!$_isservice($nick,$site)) && ($pflood(pnotice,%wm)) {
    ae $replace($_echo(pflood),<type>,NOTICE,<nick>,$nick,<address>,$address)
    prot.ignore -nu $+ $hget(x_pprot,pflood.ignore_time) %wm
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    if ($hget(x_pprot,pflood.kick)) prot.gkb $nick $_kickmsg(flooder)
    unset $_i(ignore.it)
  }
}
on *!:INVITE:#:{
  var %wm = $mask($fulladdress,$hget(x_pprot,pflood.ignore_mask))
  if ($pflood(invite,%wm)) {
    ae $replace($_echo(pflood),<type>,INVITE,<nick>,$nick,<address>,$address)
    prot.ignore -iu $+ $hget(x_pprot,pflood.ignore_time) %wm
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    if ($hget(x_pprot,pflood.kick)) prot.gkb $nick $_kickmsg(flooder)
  }
}
on *!:CTCPREPLY:*:{
  var %wm = $mask($fulladdress,$hget(x_pprot,pflood.ignore_mask))
  if ($nick !ison $__i(ctcp.list)) && (!$istok($__i(ctcp.list),$nick,44)) && ($pflood(pctcp,%wm)) {
    ae $replace($_echo(pflood),<type>,CTCPREPLY,<nick>,$nick,<address>,$address)
    prot.ignore -ntu $+ $hget(x_pprot,pflood.ignore_time) %wm
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    if ($hget(x_pprot,pflood.kick)) prot.gkb $nick $_kickmsg(flooder)
    unset $_i(ignore.it)
  }
  halt
}
CTCP *!:*:*:{
  var %wm = $mask($fulladdress,$hget(x_pprot,pflood.ignore_mask))
  if ($pflood(pctcp,$site)) {
    ae $replace($_echo(pflood),<type>,$iif($1 == dcc,DCC,CTCP),<nick>,$nick,<address>,$address)
    prot.ignore -ntdu $+ $hget(x_pprot,pflood.ignore_time) *!*@*
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    if ($hget(x_pprot,pflood.kick)) prot.gkb $nick $_kickmsg(flooder)
    halt
  }
}

on *!:OPEN:?:{
  if ($pflood(query,all)) {
    ae $replace($_echo(queryflood),<host>,$site)
    set -u [ $+ [ $hget(x_pprot,pflood.ignore_time) ] ] $_i(ignore.queries) 1
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    ale Ignoring new queries for the next $hget(x_pprot,pflood.ignore_time) $+ seconds
  }
}
on *:CHAT:*:{
  if (!$_isflag($address($nick,5),B)) && ($pflood(chat,$nick)) {
    close -c $nick
    ae $replace($_echo(chatflood),<nick>,$nick)
    prot.ignore -ndtu $+ $hget(x_pprot,pflood.ignore_time) $nick
    if ($hget(x_pprot,pflood.perform)) && ($hget(x_pprot,pflood.perform_text) != $null) _perfd $replace($ifmatch,<me>,$me,<nick>,$nick,<address>,$address,<site>,$site,<fulladdress>,$fulladdress)
    if ($hget(x_pprot,pflood.kick)) prot.gkb $nick $_kickmsg(flooder)
  }
}

alias prot.ignore { 
  if (!$hget(x_pprot,pflood.ignore)) return

  if ($hget(x_sets,pflood.silence)) silence $1-
  else  ignore $1-
}

alias prot.gkb {
  var %x = 1, %add = $address($1,5)
  while ($comchan($1,%x)) {
    var %c = $ifmatch
    if ($me isop %c) && (!$_exempt.status($1,%c)) && (!$_exempt.ul(%add,%c)) qkickb %c $1 $2-
    inc %x
  }
}




;
;EOF
