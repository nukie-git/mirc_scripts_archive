;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; mp3 player and mixer routines
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
alias mp3p _dialog $iif($hget(x_mp3,desktopplayer),-dm,-m) mp3p mp3p
dialog mp3p {
  title "MP3 Player v1.5"
  size -1 -1 385 135
  icon graphics\player.ico
  button "4", 12, 78 100 40 20
  button "9", 11, 38 100 40 20
  check ";", 13, 118 100 40 20, push
  button "<", 14, 158 100 40 20
  button ":", 15, 198 100 40 20
  button "5", 16, 238 100 40 20
  text "00:00", 1, 15 30 80 40, center
  edit "", 2, 100 30 200 20, read autohs
  text "", 3, 100 50 50 20
  text "", 4, 250 50 50 20
  text "", 5, 150 53 100 20, disable center
  button "0 0 50 - 20000 10000", 21, 15 75 285 15, disable
  ;  scroll "", 21, 15 75 285 15, horizontal
  ;scroll "text", id, x y w h, style (top left bottom right horizontal range N)
  check "", 60, 15 68 80 3, push
  check "shuffle", 61, 330 30 50 17, push
  check "playlist", 62, 330 47 50 17, push
  button "view id3", 63, 330 64 50 17, push disable
  button "volume", 64, 330 81 50 17
  button "Close", 50, 330 115 50 17, ok default
  box "", 70, 15 10 350 8
  list 100, 7 140 370 285, extsel size
  button "add", 101, 8 425 50 15
  button "del", 102, 58 425 50 15
  button "update", 104, 255 425 60 15
  button "edit", 103, 315 425 60 15
  edit "", 110, 0 0 0 0, autohs
  button "", 111, 0 0 0 0, hide cancel
}

on *:MP3END:if ($hget(x_mp3,continuous)) { if ($hget(x_mp3list,0).item) mp3play | elseif ($dialog(mp3p)) { did -ra mp3p 1 00:00 | did -r mp3p 2,3,4,5 | did -b mp3p 21 } }

alias _updmp3p {
  if ($insong) && ($dialog(mp3p)) {
    var %f = $insong.fname, %p = $insong.pos, %l = $insong.length, %n = $hget(x_mp3,mp3.ln)
    if ($gettok($did(mp3p,21),-1,32) == stopped) {
      if ($hget(x_mp3,decrease)) var %d = - $+ $_mtime($calc((%l - %p) /1000))
      else var %d = $_mtime($calc(%p /1000))
      if ($did(mp3p,1) != %d) did -ra mp3p 1 %d
      did -ra mp3p 21 %p 0 %l - 20000 10000
    }
    _enterparams %f playing
    .timerupdmp3 -cmo 1 250 _updmp3p
  }
}
alias -l _enterparams {
  if ($did(mp3p,110) == $1) return
  var %l = $_mtime($calc($mp3($1).length /1000)), %fn = $_formatmp3name($longfn($1)), %name = $_mp3.id3($1).artist - $_mp3.id3($1).title, %name = $iif((%name != n/a - n/a && $hget(x_mp3,dont.use.id3) != 1),%name,%fn), %ln = %name ( $+ %l $+ )
  if (%fn) && ($did(mp3p,2) != %ln) {
    did -ra mp3p 2 %ln | did -c mp3p 2 1
    did -ra mp3p 3 $chr(160) $+ $mp3($1).bitrate $+ kbps
    did -ra mp3p 4 $chr(160) $+ $round($calc($mp3($1).sample /1000),1) $+ khz
    did -ra mp3p 5 $mp3($1).mode
    did $iif($_mp3.id3($1).artist == n/a,-b,-e) mp3p 63
    var %wm = *. %name $+ $chr(9) $+ *
    if ($didwm(mp3p,100,%wm)) did -c mp3p 100 $ifmatch
  }
  if ($insong) {
    if ($did(mp3p,21).enabled == $false) did -e mp3p 21
    if (%name !isin $dialog(mp3p).title) { if ($hget(x_mp3,paused)) dialog -t mp3p %name (paused) | else { dialog -t mp3p %name | did -u mp3p 13 } }
  }
  did $iif($2,-ra,-r) mp3p 110 $1
}
alias -l _mp3.select {
  var %fn = $longfn($insong.fname), %name = $_mp3.id3(%fn).artist - $_mp3.id3(%fn).title, %name = $iif((%name != n/a - n/a && $hget(x_mp3,dont.use.id3) != 1),%name,$_formatmp3name(%fn)), %wm = *. %name $+ $chr(9) $+ *
  if ($didwm(mp3p,100,%wm)) did -c mp3p 100 $ifmatch
}
alias -l _load _enterparams $shortfn($iif($1 isnum,$gettok($hget(x_mp3list,$1),1,164),$1-))
alias -l _mp3.loadn if ($hget(x_mp3,random)) var %n = $rand(1,$hget(x_mp3list,0).item) | else var %n = $calc($hget(x_mp3,actual) +1) | %n = $iif(%n,%n,1) | _set mp3 previous $hget(x_mp3,actual) | _set mp3 actual %n | return %n
alias -l _loadmp3list {
  did -hr mp3p 100
  var %n = 1 | while ($hget(x_mp3list,%n)) {
    var %f = $ifmatch
    if ($numtok(%f,164) > 2) var %fg = 1, %s = %n $+ . $gettok(%f,3,164) $+ $chr(9) $+ $gettok(%f,4,164)
    else var %s = %n $+ . $_formatmp3name($gettok(%f,1,164)) $+ $chr(9) $+ $bytes($gettok(%f,2,164),3).suf
    did -a mp3p 100 %s
    inc %n
  }
  if ($insong) _mp3.select
  did -v mp3p 100
}
alias _formatmp3name if ($1) return $deltok($replace($nopath($1-),_,$chr(32)),-1,46)
on 1:dialog:mp3p:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    var %a = $mdx(SetControlMDX,21 scrollbar > [ $mdx.gdll ] )
    mdx SetFont 1 +a 26 400 Comic Sans MS
    mdx SetFont 100 +a 12 400 Verdana
    var %a = $mdx(SetControlMDX,100 listview rowselect single flatsb showsel report nosortheader > [ $mdx.vdll ] )
    did -i $dname 100 1 headerdims 300 60
    if ($numtok($hget(x_mp3list,1),164) > 2) did -i $dname 100 1 headertext 0 Title $_tab Length
    else did -i $dname 100 1 headertext 0 Title $_tab Size
    if ($hget(x_mp3,position)) var %p = $ifmatch | else var %p = -1 -1
    if ($hget(x_mp3,showplaylist)) { dialog -s mp3p %p 385 450 | did -c mp3p 62 | _loadmp3list } | else dialog -s mp3p %p 385 135
    mdx SetBorderStyle 1 clientedge dlgmodal
    mdx SetBorderStyle 2 clientedge
    mdx SetBorderStyle 3 clientedge
    mdx SetBorderStyle 4 clientedge
    mdx SetBorderStyle 10 staticedge
    mdx SetBorderStyle 11 staticedge
    mdx SetBorderStyle 12 staticedge
    mdx SetBorderStyle 13 staticedge
    mdx SetBorderStyle 14 staticedge
    mdx SetBorderStyle 15 staticedge
    mdx SetBorderStyle 16 staticedge
    mdx SetColor 1 text $iif($hget(x_mp3,dispcol.text),$ifmatch,65280)
    mdx SetColor 1 textbg $iif($hget(x_mp3,dispcol.backg),$ifmatch,0)
    mdx SetColor 1 background $iif($hget(x_mp3,dispcol.backg),$ifmatch,0)
    if ($hget(x_mp3,random)) did -c mp3p 61
    if ($hget(x_mp3,decrease)) did -c mp3p 60
    if ($hget(x_mp3,actual)) || ($hget(x_mp3,lastplay)) { var %f = $iif(($hget(x_mp3list) && $hget(x_mp3,actual)),$gettok($hget(x_mp3list,$hget(x_mp3,actual)),1,164),$hget(x_mp3,lastplay)) | _load %f | if ($insong) did -e mp3p 21 }
    if ($insong) && ($hget(x_mp3,paused)) { did -c mp3p 13 | dialog -t mp3p $dialog(mp3p).title (paused) }
    _updmp3p
    mdx SetFont 11 +a 20 400 Webdings
    mdx SetFont 12 +a 20 400 Webdings
    mdx SetFont 13 +a 20 400 Webdings
    mdx SetFont 14 +a 20 400 Webdings
    mdx SetFont 15 +a 20 400 Webdings
    mdx SetFont 16 +a 20 400 Webdings
  }
  ;  if ($devent == scroll) {
  ;  }
  if ($devent == sclick) {
    if ($did == 11) && ($hget(x_mp3list)) && ($hget(x_mp3,previous)) { var %n = $ifmatch | if ($insong) mp3play %n | else { _load %n | _set mp3 actual %n } }
    if ($did == 12) mp3play $iif(($hget(x_mp3,actual) && $hget(x_mp3list)),$hget(x_mp3,actual),$hget(x_mp3,lastplay))
    if ($did == 13) && ($insong) splay -p $iif($hget(x_mp3,paused),resume,pause)
    if ($did == 14) && ($insong) splay -p stop
    if ($did == 15) && ($hget(x_mp3list)) { if ($insong) mp3play | else _load $_mp3.loadn }
    if ($did == 16) mp3play open
    if ($did == 21) && ($hget(x_mp3,paused) != 1) && ($insong) { if ($gettok($did(21),-1,32) == stopped) splay -p seek $gettok($did(21),1,32) | if ($hget(x_mp3,decrease)) did -ra mp3p 1 - $+ $_mtime($calc(($gettok($did(21),3,32) - $gettok($did(21),1,32)) /1000)) | else did -ra mp3p 1 $_mtime($calc($gettok($did(21),1,32) /1000)) }
    if ($did == 60) { _set mp3 decrease $iif($did(60).state,1,0) | _updmp3p }
    if ($did == 61) _set mp3 random $iif($did(61).state,1,0)
    if ($did == 62) { if ($did(62).state) { dialog -s mp3p -1 -1 385 450 | _set mp3 showplaylist 1 | _loadmp3list } | else { dialog -s mp3p -1 -1 385 135 | _unset mp3 showplaylist } }
    if ($did == 63) _mp3id $iif(($insong == $false && $shortfn($gettok($hget(x_mp3list,$hget(x_mp3,actual)),1,164))),$ifmatch)
    if ($did == 64) mixer
    if ($did == 50) || ($did == 111) _set mp3 position $dialog(mp3p).x $dialog(mp3p).y
    if ($did == 101) { var %n = $calc($hget(x_mp3list,0).item +1), %f = $$sfile($_mp3lastdir,Select a MP3 file) | hadd -m x_mp3list %n %f $+ $chr(164) $+ $file(%f).size | did -a mp3p 100 %n $+ . $_formatmp3name($gettok(%f,1,164)) $+ $chr(9) $+ $bytes($file(%f).size,3).suf }
    if ($did == 102) && ($did(100).seltext) { hdel x_mp3list $remove($gettok($did(100).seltext,6,32),.) | did -d mp3p 100 $did(100).sel | _loadmp3list | _mp3arrange }
    if ($did == 103) playlist
    if ($did == 104) _loadmp3list
  }
  if ($devent == dclick) && ($did == 100) && ($remove($gettok($did(100,$did(100).sel),6,32),.) isnum) mp3play $ifmatch
}
;
;mixer
alias mixer var %s = $_dialog(mixer,mixer,-4)
dialog mixer {
  title "Mixer"
  size -1 -1 210 270
  icon graphics\volume.ico
  list 1, 30 30 35 200
  list 2, 95 30 35 200
  list 3, 145 30 35 200
  box "Master", 11, 21 15 52 220
  box "Wave", 12, 86 15 52 220
  box "Midi", 13, 136 15 52 220
  check "mute", 21, 25 215 44 15, push
  check "mute", 22, 90 215 44 15, push
  check "mute", 23, 140 215 44 15, push
  button "Close", 50, 80 245 50 20, ok default
}
on 1:dialog:mixer:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    var %a = $mdx(SetControlMDX,1 trackbar vertical > [ $mdx.bdll ] ), %a = $mdx(SetControlMDX,2 trackbar vertical > [ $mdx.bdll ] ), %a = $mdx(SetControlMDX,3 trackbar vertical > [ $mdx.bdll ] )
    did -i mixer 1 1 params $calc(65535- $vol(master)) 0 65535 5 25 0 0 -
    did -i mixer 2 1 params $calc(65535- $vol(wave)) 0 65535 5 25 0 0 -
    did -i mixer 3 1 params $calc(65535- $vol(midi)) 0 65535 5 25 0 0 -
    did -i mixer 1,2,3 1 ticfreq 6553
    if ($vol(master).mute) did -c mixer 21
    if ($vol(wave).mute) did -c mixer 22
    if ($vol(midi).mute) did -c mixer 23
  }
  if ($devent == sclick) {
    if ($did == 0) return
    if ($gettok($did($did,1),9,32) == track) dialog -t mixer Mixer $_sperc($calc(65535- $gettok($did($did,1),1,32)),65535) | else dialog -t mixer Mixer
    if ($did isnum 1-3) vol $iif($did == 1,-v,$iif($did == 2,-w,-m)) $calc(65535- $gettok($did($did,1),1,32))
    if ($did isnum 21-23) vol $iif($did == 21,-v,$iif($did == 22,-w,-m)) $+ u $+ $iif($did($did).state,1,2)
  }
}

alias winamp if ($hget(x_mp3,winamp) != 1) || ($lock(dll)) return | if ($isid) return $dll(dlls\swamp.dll,$iif($1 == id3,ID3Tag,WinAmpGet),$iif($1 == id3,$shortfn($2-),$1)) | .dll dlls\swamp.dll $iif($1 == -r,WinAmpRun,$iif($1 == -s,WinAmpSet,WinAmpCmd)) $iif(- isin $1,$shortfn($2-),$1)
alias mp3.echan if ($istok($hget(x_mp3,chan),$chan($1),32)) return $style(1) $chan($1) | if ($chan($1)) return $chan($1)
alias _togmp3chan _set mp3 chan $remtok($hget(x_mp3,chan),all,32) | if ($istok($hget(x_mp3,chan),$chan($1),32)) { if ($remtok($hget(x_mp3,chan),$chan($1),32)) _set mp3 chan $ifmatch | else _unset mp3 chan } | else _set mp3 chan $addtok($hget(x_mp3,chan),$chan($1),32)
alias _winamps if ($winamp(state)) _set mp3 wa.state $ifmatch | else _unset mp3 wa.state

alias _winampid3 var %i = $winamp(id3,$winamp(trackfilename)) | if (%i != $!null) var %. = $input($replace(%i,$chr(12),$crlf),4) | else sr -t MP3 No ID3 tag available
alias _tmpinmp3 if ($insong) { set -u1 %inmp3 $ifmatch | set -u1 %inmp3.fname $insong.fname }
alias _mp3id {
  var %file = $iif($1,$1,$insong.fname)
  if ($_mp3.id3(%file,1).artist) { var %a = $ifmatch $+ $crlf $+ $_mp3.id3(%file,1).album $+ $crlf $+ $_mp3.id3(%file,1).title $+ $crlf $+ $_mp3.id3(%file,1).genre $+ $crlf $+ $_mp3.id3(%file,1).year $+ $crlf $+ $_mp3.id3(%file,1).comment, %f = $input(%a,4,- ID3 tag) }
  else sr -t MP3 No ID3 tag available
}
alias _mp3.id3 {
  if ($hget(x_mp3,dont.use.id3v2) != 1) && ($_mp3idv2($1). [ $+ [ $prop ] ]) return $ifmatch
  if ($mp3($1). [ $+ [ $prop ] ]) return $ifmatch
  if ($2) return | return n/a
}
alias _mp3idv2 {
  if ($isfile($1) == $false) return
  bread " $+ $1 $+ " 0 4096 &id3
  if ($bvar(&id3,1,3).text != id3) return
  var %tags = album.track.title.artist.oartist.composer.genre.year.url.copyright, %id = $bvar(&id3,$calc($bfind(&id3,1,$gettok(TALB.TRCK.TIT2.TPE1.TOPE.TCOM.TCON.TYER.WXXX.TCOP,$findtok(%tags,$prop,1,46),46)).text +11),200).text
  if ($right(%id,4) === $upper($right(%id,4))) return $left(%id,-4)
  else return %id
}
alias _detmp3 {
  if ($winamp(state) == playing) {
    var %f = $winamp(trackfilename)
    if (($hget(x_vars,lastfile) == %f) && (!$1)) || (*.mp? !iswm %f) return
    var %s = $winamp(samplerate), %b = $winamp(bitrate), %t = $_mtime($winamp(tracktime))
    if (%f) goto echo
  }
  elseif ($insong.fname) {
    var %f = $longfn($insong.fname)
    if ($hget(x_vars,lastfile) == %f) && (!$1) return
    var %s = $int($calc($mp3(%f).sample /1000)), %b = $mp3(%f).bitrate, %t = $_mtime($calc($insong.length /1000))
    if (%f) goto echo
  }
  return
  :echo
  var %l = $bytes($lof(%f),3).suf, %fn = $deltok($replace($nopath(%f),_,$chr(32)),-1,46), %echo = [ [ $replace($def.echo(mp3echo),&filename,%f) ] ], %fnd = $replace($deltok($gettok(%f,-2-1,92),-1,46),_,$chr(32))
  var %idartist = $_mp3.id3(%f).artist, %idtitle = $iif($_mp3.id3(%f).title != n/a,$ifmatch,%fn), %idalbum = $_mp3.id3(%f).album, %idgenre = $_mp3.id3(%f).genre, %idtrack = $_mp3.id3(%f).track, %idyear = $_mp3.id3(%f).year, %idcopy = $_mp3.id3(%f).copyright
  var %randlist = $iif($read(mp3text.txt),$ifmatch,plays)
  var %e = $replace(%echo,<wartist>,%idartist,<wtitle>,%idtitle,<walbum>,%idalbum,<wgenre>,%idgenre,<wtrack>,%idtrack,<wyear>,%idyear,<wcopy>,%idcopy,<wfnd>,%fnd,<wfn>,%fn,<wsr>,%s,<wbr>,%b,<wlen>,%l,<wtime>,%t,<wrandom>,%random)
  if ($1 == -echo) {
    $iif($hget(x_mp3,use.msg),say,describe) $2 %e
    if ($3 == ctcp) .ctcp $2 SOUND $replace($nopath(%f),$chr(32),_)
  }
  elseif ($1) {
    $iif($hget(x_mp3,use.msg),say,me) %e
    if ($hget(x_mp3,sound)) || ($1 == 2) .ctcp $remove($active,=) SOUND $replace($nopath(%f),$chr(32),_)
  }
  elseif ($hget(x_mp3,chan) == local) ae 4!MP34! $me %e
  else _mp3echo $replace($nopath(%f),$chr(32),_) %e
  _var lastfile %f
}
alias mp3echo _detmp3 -echo $iif($1,$1,$active)
alias mp3ctcp _detmp3 -echo $iif($1,$1,$active) ctcp

alias _mp3echo {
  var %a = $hget(x_mp3,chan), %s = $hget(x_mp3,sound) | if (!%a) return
  if (%a == active) {
    if (($query($active)) && (!$islev(20,$address($active,5)))) || ($active ischan) || ($chat($active)) {
      if ($hget(x_mp3,use.msg)) say $2-
      else me $2-
      if (%s) .raw PRIVMSG $active :SOUND $1 $+ 
    }
  }
  elseif ($server) {
    var %l = $iif(%a != all,%a,$replace($_comchans($me),$chr(44),$chr(32))), %n = $numtok(%l,32)
    while (%n) {
      var %c = $gettok(%l,%n,32)
      if (%c ischan) { if (%s) .raw PRIVMSG %c :SOUND $1 $+  | if ($hget(x_mp3,use.msg.instead)) say %c $2- | else describe %c $2- }
      dec %n
    }
  }
}
alias mp3play {
  if ($1 == open) goto c
  elseif ($1-) && ($1 !isnum) { var %f = $1- | goto play }
  var %total = $hget(x_mp3list,0).item
  if (%total) {
    var %actual = $hget(x_mp3,actual)
    if ($1 isnum) var %n = $1
    elseif ($hget(x_mp3,playsel)) var %n = $gettok($ifmatch,1,44)
    elseif ($hget(x_mp3,random)) {
      var %n = $rand(1,%total), %v = 5
      while (%v) { if (%n == %actual) %n = $rand(1,%total) | dec %v }
    }
    else var %n = $iif(%actual,$calc(%actual +1),1)
    if (%n > $hget(x_mp3list,0).item) var %n = 1 | var %f = $gettok($hget(x_mp3list,%n),1,164)
  }
  else { :c | var %f = $$sfile($_mp3lastdir,Select MP3 file,Play) }
  if (%f) {
    if (%n) { if (%n != $hget(x_mp3,actual)) { if ($hget(x_mp3,actual)) _set mp3 previous $ifmatch | _set mp3 actual %n }
      if ($window(@mp3playlist)) sline @mp3playlist $fline(@mp3playlist,$+(%n,.*),1)
    }
    if ($istok($hget(x_mp3,playsel),%n,44) == $false) _unset mp3 playsel
    elseif ($deltok($hget(x_mp3,playsel),1,44)) _set mp3 playsel $ifmatch
    else _unset mp3 playsel
    :play
    if ($isfile($shortfn(%f))) {
      _set mp3 lastplay $shortfn(%f)
      splay -p $shortfn(%f)
      if ($dialog(mp3p)) _updmp3p
      _unset mp3 paused
      _detmp3
    }
    else .timer 1 0 mp3play
  }
}
alias _mp3clearlist _hfree x_mp3list | var %path = $iif($isdir(%profile),%profile,config\) | .remove $+(%path,mp3list.hsh) | _unset mp3 actual | _unset mp3 previous | .timer 1 0 if ($input(Create new playlist now?,8,MP3)) playlist
alias _mp3lastdir var %a = $nofile($gettok($hget(x_mp3list,$hget(x_mp3list,0).item),1,164)) | return $iif(%a,%a,$mp3dir)
alias _mp3state if ($insong) { if ($hget(x_mp3,paused)) return paused | return playing } | return stopped

;just testing...
alias _mp3stop.fadeout {
  var %vol = $vol(mp3), %x = %vol
  while (%x > 0) { vol -p %x | dec %x 85 }
  splay -p stop
  vol -p %vol
}

alias _updmp3dirs {
  if (!$hget(x_mp3list)) return
  var %i = 1, %w = @dirs- $+ $randnick
  window -c %w
  window -hl %w
  while ($hget(x_mp3list,%i)) {
    var %file = $gettok($ifmatch,1,164), %dir = $nofile(%file)
    if (!$fline(%w,%dir,1)) aline %w %dir
    inc %i
  }
  if ($line(%w,0) == 0) return
  hfree x_mp3list
  hmake x_mp3list 40
  var %i = 1
  while ($line(%w,%i)) {
    _mp3list $shortfn($ifmatch) upd
    inc %i
  }
  window -c %w
}
alias _mp3list {
  var %d = $iif($1,$longfn($1),$$sdir($_mp3lastdir,Select your MP3 dir))
  if (!%d) halt
  if ($2 != upd) var %recurse = $input(Recurse subdirectories?,y)
  if ($hget(x_mp3,no.load.tags)) var %hash = x_mp3list
  else var %hash = x_tmp-mp3list
  if (!$hget(%hash)) hmake %hash 40
  var %0 = $hget(%hash,0).item, %t = $findfile(%d,*.mp3,0)
  if (%recurse) var %n = $findfile(%d,*.mp3,0,_mpadd %0 %t %hash $1-)
  else var %n = $findfile(%d,*.mp3,0,0,_mpadd %0 %t %hash $1-)
  _pwait
  if (%n > 1) {
    if (%hash == x_tmp-mp3list) _mp3.info $ifmatch
    _hs x_mp3list
    if (!$window(@mp3playlist)) playlist
  }
  else ale No mp3 files found in %d
}

alias _mpadd _pwait $calc($hget($3,0).item - $1) $2 Creating MP3 list... | var %size = $file($4-).size | if (!%size) %size = 0 | hadd $3 $calc($hget($3,0).item +1) $4- $+ $chr(164) $+ %size
alias _mp3.info {
  var %n = 1, %hash = $iif($1,$1,x_mp3list), %total = $hget(%hash,0).item, %bottom = $hget(x_mp3list,0).item
  if (!$hget(x_mp3list)) hmake x_mp3list 40
  _pwait 1 %total Loading file info...
  while (%n <= %total) {
    var %line = $gettok($hget(%hash,%n),1-2,164)
    if ($numtok(%line,164) == 2) {
      var %song = $gettok(%line,1,164), %tag = $_mp3.id3(%song).artist - $_mp3.id3(%song).title, %p = $mp3(%song).length, %time = $_mtime($calc(%p /1000)), %item = $iif(%hash == x_mp3list,%n,$calc(%bottom + %n))
      hadd x_mp3list %item %line $+ $chr(164) $+ $iif(%tag != n/a - n/a,%tag,$remove($nopath(%song),.mp3)) $+ $chr(164) $+ %time
    }
    if (20 // %n) _pwait %n %total
    inc %n
  }
  hfree x_tmp-mp3list
  _pwait
}
alias _mp3arrange {
  _pwait 0 0 Updating list...
  var %win = @_temp. $+ $rand(111,999)
  window -hl %win
  var %n = 1, %total = $hget(x_mp3list,0).item
  while (%n <= %total) {
    var %item = $hget(x_mp3list,%n).item, %l = $hget(x_mp3list,%item)
    if (%l) aline %win %item $+ $chr(164) $+ %l
    inc %n
  }
filter -cwwtu 1 164 %win %win
  hfree x_mp3list
  hmake x_mp3list 40
  var %i = 1
  while ($line(%win,%i)) { hadd x_mp3list %i $gettok($ifmatch,2-,164) | inc %i }
  window -c %win
  _unset mp3 previous
  _unset mp3 actual
  if ($window(@mp3playlist)) playlist
  _pwait
}
alias mp3sort {
  if ($1 == 1) var %sort = by title, %sm = 1
  elseif ($1 == 2) var %sort = by filename, %sm = 2
  elseif ($1 == 3) var %sort = by path\filename, %sm = 3
  _pwait 0 0 Sorting %sort $+ ...
  var %win = @_temp. $+ $rand(111,999)
  window $iif($1 == 0,-hl,-hls) %win
  var %n = 1, %total = $hget(x_mp3list,0).item
  while (%n <= %total) {
    var %l = $hget(x_mp3list,$hget(x_mp3list,%n).item)
    if (%l) {
      if (%sm == 1) aline %win $gettok(%l,3,164) $+ $chr(164) $+ %l
      elseif (%sm == 2) aline %win $gettok($gettok(%l,1,164),-1,92) $+ $chr(164) $+ %l
      elseif (%sm == 3) {
        var %p1 = $gettok(%l,1,164), %p2 = $gettok(%p1,-2,92) $+ \ $+ $gettok(%p1,-1,92)
        aline %win %p2 $+ $chr(164) $+ %l
      }
      else aline %win - $+ $chr(164) $+ %l
    }
    inc %n
  }
  hfree x_mp3list
  hmake x_mp3list 40
  var %i = 1
  while ($line(%win,%i)) { hadd x_mp3list %i $gettok($ifmatch,2-,164) | inc %i }
  window -c %win
  _unset mp3 previous
  _unset mp3 actual
  if ($window(@mp3playlist)) playlist
  _pwait
}
alias _mp3.playlist.select {
  var %file = $longfn($insong.fname), %tag = $mp3(%file).artist - $mp3(%file).title, %song = $remove($gettok(%file,-1,92),.mp3)
  if (%tag != -) && ($fline(@mp3playlist,$+(*,%tag,*),1)) sline @mp3playlist $ifmatch
  elseif (%song) && ($fline(@mp3playlist,$+(*,%song,*),1)) sline @mp3playlist $ifmatch
}

;usage: /playlist <filename>
alias playlist {
  if ($1) var %e = $1
  if ($window(@mp3playlist)) clear $ifmatch
  if ($hget(x_mp3list,0).item == 0) || (!$hget(x_mp3list)) _mp3list
  else {
    if (%e) write -c %e
    var %n = 1
    if (!$window(@mp3playlist)) window -lk $+ $iif($hget(x_mp3,desktoplist) != 0,d) -t4,55 @MP3Playlist $_gcoord(mp3playlist,-1 -1 500 450) $_@font
    if ($numtok($hget(x_mp3list,1),164) > 2) var %length = 1
    aline @mp3playlist $_nchr(@mp3playlist)
    aline @mp3playlist #. $+ $chr(9) $+ Title $+ $chr(9) $+  $+ $iif(%length,Length,Size)
    aline @mp3playlist $_nchr(@mp3playlist)
    while ($hget(x_mp3list,%n)) {
      var %f = $ifmatch
      if (%length) var %s = %n $+ . $+ $chr(9) $+ $gettok(%f,3,164) $+ $chr(9) $+ $gettok(%f,4,164)
      else var %s = %n $+ . $+ $chr(9) $+ $nopath($gettok(%f,1,164)) $+ $chr(9) $+ $bytes($gettok(%f,2,164),3).suf
      aline @mp3playlist %s
      inc %n
    }
    if ($insong) {
      if ($hget(x_mp3,actual)) && ($fline(@mp3playlist,$+($hget(x_mp3,actual),.*),1)) sline @mp3playlist $ifmatch
      else _mp3.playlist.select
    }
    titlebar @MP3Playlist - $calc($line(@mp3playlist,0) -3) files - (right-click for options)
    if (%e) savebuf @mp3playlist %e
  }
  if ($window(@mp3playlist)) window -a @mp3playlist
}
;
