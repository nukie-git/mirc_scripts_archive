;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; channel aliases section
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
mode {
  if ($1 == $me) {
    if (!$2) .raw MODE $me
    else umode $2-
    return
  }
  var %chan = $iif($1 ischan,$1,#)
  if (%chan !ischan) {
    umode $1-
    return
  }
  if (!$2) set $_i(request.chanmode.,%chan) 1
  .raw MODE %chan $2-
}
cmode if (#) && ($1) .mode # $1-
umode if ($1) .raw MODE $me $1-

beep {
  if ($1) {
    if ($1 == on) { _set sets beep 1 | ale Beeps are now ON }
    elseif ($1 == off) { _set sets beep 0 | ale Beeps are now OFF }
    elseif ($hget(x_sets,beep)) && ((!$away) || (!$hget(x_away,disable.flash))) !beep $1-
  }
  else !beep 1
}

flash {
  if (!$hget(x_sets,flash)) || (($away) && ($hget(x_away,disable.flash))) return
  if (-*r* iswm $1) !flash $1-
  else {
    var %t = $iif($away,$iif($hget(x_sets,flashtimesaway),$ifmatch,2),$iif($hget(x_sets,flashtimes),$ifmatch,4))
    if (-* iswm $1) var %s = $remove($1,-), %l = $2-
    else var %l = $1-
    flash -r $+ %t $+ %s %l
  }
}
bflash {
  if ($flash.onquery) flash ( $+ $1 $+ )
  beep 3 100
}

j join $1-
joinall {
  var %l = $iif($hget($+(x_net-,$__i(network)),chan.def),$hget(x_net-default,chan.list),$hget($+(x_net-,$__i(network)),chan.list)), %i = 1, %aj = $_net(chan.ajoindelay)
  if (!%l) {
    nets 3
    return
  }
  while ($gettok(%l,%i,44)) {
    var %c = $ifmatch
    if (%aj) && ($1) {
      if ($gettok(%c,1,32) !ischan) .timerjoindelay. $+ %i 1 $calc(%aj * (%i -1)) join $iif(%i != 1,-n) %c
    }
    elseif ($numtok(%c,32) > 1) {

      if ($gettok(%c,-1,32) == +i) {
        set -u30 $_i(invite.req) $addtok($__i(invite.req),$deltok(%c,-1,32),44)
        if ($__i(s^c)) cs invite $gettok(%c,1,32) $me
        elseif ($__i(network) == undernet) msg.x invite $gettok(%c,1,32) $me
        else join %c
      }
      else join %c
    }
    else var %d = $addtok(%d,%c,44)
    if ($numtok(%d,44) == 4) {
      join %d
      unset %d
    }
    inc %i
  }
  if (%d) join %d
}
join {
  if (!$server) return
  elseif (!$1) joinall
  elseif (-* iswm $1) join $1 $iif($2,$_chan($2-))
  elseif ($chr(44) isin $1) join $1-
  else join $_chan($1-)
}
joinlast {
  var %n = 1
  while ($gettok($hget(x_misc,recchannels),%n,44)) {
    var %c = $ifmatch
    if (%c !ischan) { join %c | break }
    inc %n
  }
}

cycle {
  var %c = $iif($1 ischan,$1,#), %m = $iif($1 ischan,$2-,$1-)
  if (%c !ischan) return
  join %c
  if (i isin $chan(%c).mode) && (!$istok(ircnet,$__i(network),46)) && ($nick(%c,0) > 1) {
    ale You can't cycle channels with +i mode.
    return
  }
  set $_i(just.cycled.,%c) 1
  .hop -c %c %m
}
_gainop if (!$__i(s^n)) && ($hget(x_sets,rejoingainops)) cycle $1

cycle.all {
  var %i = $chan(0), %c
  while (%i) {
    %c = $chan(%i)
    if (i !isin $gettok($chan(%i).mode,1,32)) || ($nick(%c,0) == 1) {
      .hop -c %c
      set $_i(just.cycled.,%c) 1
    }
    else echo %c $_pre You can't cycle %c $+ , it's invite only.
    dec %i
  }
}
rejoin cycle

;/p <nick/chan> can be ping or part
p {
  if ($1) && ($1 !ischan) && (!$2) ping $1
  elseif ($1 ischan) || (#) part $iif($1 ischan,$1-,# $1-) 
}
part {
  if (!$server) return

  ;define part reason and format
  if ($1 ischan) var %chan = $1, %msg = $iif($2 != $null,$2-)
  elseif (# ischan) var %chan = #, %msg = $iif($1 != $null,$1-)
  var %pm = $iif($hget(x_display,format.part),$eval($ifmatch,2),<text>), %pm = $replace(%pm,<text>,%msg,<me>,$me,<chan>,%chan)

  if (%chan) !part %chan %pm
  elseif ($chan(0)) partall %pm
}

partlast {
  var %n = 1
  while ($gettok($hget(x_misc,recchannels),%n,44)) {
    var %c = $ifmatch
    if (%c ischan) { part %c | break }
    inc %n
  }
}
i {
  if ($2 ischan) invite $1-
  else ignore $1-
}
invite {
  var %n = $_nickcomp($1), %c = $iif($_chan($2) ischan,$_chan($2),#)
  if (%c !ischan) ae $_error Usage: /invite <nick> [#channel]
  elseif (%n) && (%c) {
    invite %n %c
    ale Inviting %n to %c
  }
}
motd {
  if ($server) {
    set $_i(motd) 1
    .raw MOTD $1-
  }
}


;=================

k kick $1-
kick {
  if ($1 == $null) return
  if (* isin $1) || (? isin $1) fk $1-
  else _kick.routine -k # $_nickcomp($1).chan $2-
}
kb {
  if ($1 == $null) return
  if (* isin $1) || (? isin $1) fkb $1-
  else _kick.routine -kb # $_nickcomp($1).chan $2-
}

;random kick
rkick {
  var %chan = $iif($1 ischan,$1,#), %r = $iif($1 ischan,$2-,$1-)
  if (%chan !ischan) || ($nick(%chan,0) == 1) return
  :sel
  var %n = $nick(%chan,$rand(1,$nick(%chan,0)))
  if (%n == $me) goto sel
  var %msg = $iif(%r != $null,%r,random kick)
  kick %chan %n %msg
}
rk rkick $1-
randkick rkick $1-

;kick selected nicks
ks {
  var %chan = #, %o = $iif(-* iswm $1,$1,-k) %reason = $iif(($1 != $null && -* !iswm $1),$1-,$randkickmsg)
  if (!$snick(%chan,0)) return
  multi %chan $remove(%o,-) $snicks %reason
}
kbs ks -kb
ksel ks

;/tkb <nick> [time] [reason]
tempkb tkb $1-
tkb {
  if ($2 isnum) var %1 = $_nickcomp($1,1).chan, %t = $2, %tr = $iif($3,$3-,$randkickmsg)
  elseif ($1) var %t = $$_input(Time for ban in minutes,e,Tempban,10), %1 = $_nickcomp($1,1).chan, %tr = $iif($2,$2-,$randkickmsg)
  else return

  var %tb = $_address(%1,$hget(x_prot,default_banmask)), %t2 = $calc(%t *60), %tkb = ... $+ %t $+  $+ $iif(%t != 1,mins,min) tempban, %km = $_kick.format(%tr $iif($hget(x_prot,show.tempban),%tkb))
  .raw MODE # $iif(%1 isop #,-o+b %1,+b) %tb $+ $lf $+ KICK # %1 : $+ %km
  .timerunban. $+ $rand(1,99) 1 %t2 _unban # %tb
}

;kick/kickban away (/kick.away [#] [-b])
kick.away {
  var %c = $iif($1 ischan,$1,#)
  if (!%c) return
  set $_i(kick.away.,%c) $iif($2 == -b,-b,-k)
  .raw who %c
}
kaway kick.away $1-
kbaway kick.away $iif($1 ischan,$1,#) -b

;banlast, kicklast, kickbanlast
bl _kickbanlast # $1 b
kl _kickbanlast # $1
kbl _kickbanlast # $1 kb
_kickbanlast {
  if ($2) var %list = $2
  elseif ($__i(lastjoin.,$1,.ips)) var %list = $ifmatch
  if (%list) multi $1 $3 %list
}

_kick.routine {
  if (!$2) return
  var %switch = $1, %chan = $2, %nick = $3, %reason = $4-
  if (!%chan) || (%nick !ison %chan) return
  if ($me !isop %chan) && ($_findbot(%chan)) _botkick %nick $ifmatch $iif(%switch == -kb,1)
  else _kick.routine2 %switch %chan %nick %reason
}
_kick.routine2 {
  if ($3 ison $2) {
    var %1 = KICK $2 $3 : $+ $_kick.format($iif($4,$4-,$randkickmsg))
    if ($1 == -kb) .raw MODE $2 $iif($3 isop $2,-o+b $3,+b) $_address($3,$hget(x_prot,default_banmask)) $+ $lf $+ %1
    else .raw %1
  }
  else ale $_c(3) $+ $3 is not on $2
}
_botkick {
  if ($input(Use $2 to $iif($3,kickban,kick) $1 $+ ?,yq,Bot)) .msg $2 $iif($3,kickban,kick) $1 $_botpass($2)
}

;=====================
;quickkick, ban, tempban: for usage in other routines
qkick {
  if ($2 ison $1) {
    .raw KICK $1-2 : $+ $_kick.format($3-)
  }
}
qkickb {
  if ($2 ison $1) {
    .raw MODE $1 $iif($2 isop $1,-o+b $2,+b) $_address($2,$hget(x_prot,default_banmask)) $+ $lf $+ KICK $1-2 : $+ $_kick.format($3-)
  }
}
qtkickb {
  if ($2 ison $1) {
    var %tb = $_address($2,$hget(x_prot,default_banmask)), %timeb = $hget(x_prot,tempban.time), %showtb = ...tempban for %timeb $+  $+ $iif(%timeb == 1,min,mins)
    .raw MODE $1 $iif($2 isop $1,-o+b $2,+b) %tb $+ $lf $+ KICK $1-2 : $+ $_kick.format($3- $iif($hget(x_prot,show.tempban),%showtb))
    var %time = $calc(%timeb *60)
    .timer 1 %time _unban $1 %tb
    hadd -m x_tempbans $+($_network,:,$1,:,%tb) $calc($ctime + %time)
  }
}

qnkickb {
  if ($hget(x_prot,tempban.time)) var %tb = $ifmatch
  else var %tb = 10
  .raw MODE $1 $iif($2 isop $1,-o+b $2,+b) $2 $+ !*@* $+ $lf $+ KICK $1-2 : $+ $_kick.format($3-)
  .timer 1 $calc(%tb *60) .raw mode $1 -b $2 $+ !*@*
}
guestkickban {
  var %chan = $iif($1 ischan,$1,#)
  fkb %chan guest*!*@* $iif($3,$3-,$_kickmsg(guests,%chan))
}

badhostkickban {
  if ($2 !ison $1) return
  var %bw = $iif($__i(badhost),$ifmatch,$2), %bm
  if (%bw iswm $2) || (%bw isin $2) %bm = %bw $+ !*@*
  else %bm = *!* $+ %bw $+ @*
  mode $1 +b %bm
  qkick $1-
}

;====================

v voice $1-
dv devoice $1-
o op $1-
dop deop $1-

op _modes +o $1-
deop _modes -o $1-
voice _modes +v $1-
devoice _modes -v $1-
vo _modes +v $1-
dvo _modes -v $1-
own _modes +q $1-
deown _modes -q $1-

_modes {
  var %n = $_nickcomp($2,1).chan, %mode1 = $left($1,1), %mode2 = $right($1,1)
  if (%n !ison #) && (* !isin %n) return
  if ($me !isop #) && ($_findbot(#)) {
    var %bot = $ifmatch, %mode
    if (%mode1 == +) {
      if (%mode2 == o) %mode = op
      if (%mode2 == v) %mode = voice
      if (%mode2 == q) %mode = owner
    }
    else {
      if (%mode2 == o) %mode = deop
      if (%mode2 == v) %mode = devoice
      if (%mode2 == q) %mode = deowner
    }
    .msg %bot %mode %n $_botpass(%bot)
  }
  else {
    var %list = $_mask2nick(#,%n $3-)
    if ($numtok(%list,32) == 1) mode # $1 %list
    else _mode.list # $1 %list
  }
}

deopme if ($me isop #) mode # -o $me
opme {
  if ($__i(s^n)) cs op # $me
  else op $me
}

;chanserv op/deop
cs.opdeop {
  var %n = 1
  while ($gettok($2,%n,44)) {
    var %c = $ifmatch
    cs $iif(%c isop $1,deop,op) $1 %c
    inc %n
  }
}
;/changemode <chan> <o|v> <list> toggles mode for each nick in a given list
changemode {
  var %i = 1
  while ($gettok($3,%i,44)) {
    var %n = $ifmatch

    if ($_nomode($1,$2,%n)) {
      if (%-) || (!%mode) var %mode = %mode $+ + $+ $2
      else var %mode = %mode $+ $2
      var %+ = 1, %- = 0
    }
    else {
      if (%+) || (!%mode) var %mode = %mode $+ - $+ $2
      else var %mode = %mode $+ $2
      var %+ = 0, %- = 1
    }
    var %nicks = $addtok(%nicks,%n,32)

    if ($numtok(%nicks,32) == $__i(nets-max.modes)) {
      .raw MODE $1 %mode %nicks
      unset %nicks %mode %+ %-
    }

    :next
    inc %i
  }
  if (%nicks) .raw MODE $1 %mode %nicks
}

;/_mode.list <chan> <+|-o|v|q|h> <list> same mode for all nicks in a given list
_mode.list {
  var %mode = $left($2,1), %mode2 = $right($2,1), %list1 = $replace($3-,$chr(32),$chr(44)), %i = 1
  while ($gettok(%list1,%i,44)) {
    var %n = $ifmatch, %not = 0
    if (%n != $me) {
      if ($2 == +v) && ((%n isowner $1) || (%n isop $1) || (%n ishop $1) || (%n isvoice $1)) %not = 1
      if ($2 == +h) && ((%n isowner $1) || (%n isop $1) || (%n ishop $1)) %not = 1
      if ($2 == +o) && ((%n isowner $1) || (%n isop $1)) %not = 1
      if ($2 == +q) && (%n isowner $1) %not = 1
      if (!%not) var %nicks = $addtok(%nicks,%n,32)
    }
    if ($numtok(%nicks,32) == $__i(nets-max.modes)) {
      .raw MODE $1 %mode $+ $str(%mode2,$numtok(%nicks,32)) %nicks
      unset %nicks
    }
    inc %i
  }
  if (%nicks) .raw MODE $1 %mode $+ $str(%mode2,$numtok(%nicks,32)) %nicks
}
ping ctcp $iif($1,$1,$remove($active,=)) ping
page if ($2) ctcp $1 page $2- | else ctcp $1 page $$_input(What msg?,e,Pager)
version ctcp $iif($1,$1,$remove($active,=)) version
ver if ($1) version $1-
s if (!$isid) server $1-

chat {
  if (!$1) return
  if ($lock(chat)) ale Private chats are locked.
  else dcc chat $1-
}
send {
  if (!$1) return
  if ($lock(send)) ale DCC Sends are locked.
  else dcc send $1-
}

dccs ale Active DCC's: Sends: $send(0) - Gets: $get(0) - Chats: $chat(0) - FServs: $fserv(0) (Total: $calc($send(0) + $get(0) + $chat(0) + $fserv(0)) $+ )
adcc {
  if ($hget(x_ctcps,dcc) == 1) {
    set -u300 $_i(adcc.,$1) 1
    if ($show) ale $1 is allowed to DCC you for the next 5 minutes.
  }
  else sr This only makes sense if you turn DCC's on in the main setup
}

fakeping {
  if ($1 isnum) {
    _set ctcps fakeping 1
    _set ctcps fakeping.time $1
  }
  elseif ($1 == off) {
    _unset ctcps fakeping
    ale Fake ping reply is now off
    return
  }
  if ($hget(x_ctcps,fakeping)) ale Fake ping reply set to $iif($hget(x_ctcps,fakeping.time),$ifmatch,random) secs (/fakeping off to disable)
  else ale Fake ping not set yet.
}

topic {
  if ($1 ischan) {
    if ($2 != $null) .raw TOPIC $1 : $+ $2-
    else .raw TOPIC $1
  }
  elseif (# ischan) {
    if ($1 != $null) .raw TOPIC # : $+ $1-
    else .raw TOPIC #
  }
}
lock.topic {
  if ($active !ischan) || (!$chan(#).topic) return
  if ($1 == off) { unset $_i(lock.topic.,#) | echo -qa $_pre Topic is unlocked | return }
  set $_i(lock.topic.,#) $chan(#).topic
  echo -qa $_pre Topic is locked
}

;==============================0

atopic {
  if ($_nochans) || ($1 == $null) return
  var %n = $chan(0)
  while (%n) {
    if ($me isop $chan(%n)) || (t !isin $chan(%n).mode) .raw TOPIC $chan(%n) : $+ $1-
    dec %n
  }
}
amode {
  if ($_nochans) || ($1 == $null) return
  var %n = $chan(0)
  while (%n) {
    if ($me isop $chan(%n)) .raw MODE $chan(%n) $1-
    dec %n
  }
}

acommand {
  var %n = $iif($1 == �op�,$2,$1), %x = $comchan(%n,0), %r = $iif($1 == �op�,$3-,$2-)
  while (%x) {
    if ($1 != �op�) || ($comchan(%n,%x).op) $eval($replace(%r,�chan�,$comchan(%n,%x)),2)
    dec %x
  }
}

;==========================

quit {
  if (!$server) return
  .quit $_quit.format($1-)
}

nick {
  if (!$1) return
  set -u15 $_i(/nick) $me
  if ($__i(network) == ptnet) && ($__i(s^n)) && ($_log.nicks($1)) ns login $1 $_log.pass($1)
  else .nick $1
  if ($show) && (!$server) {
    set -u %::nick $me
    set -u %::me $me
    set -u %::newnick $1
    set -u %:echo echo -s
    theme.text nickself
  }
}

;global stuff
_mass.comchans.op {
  if ($1 == $me) return
  var %x = 1
  while ($comchan($1,%x)) {
    var %c = $ifmatch
    if ($me isop %c) $replace($2-,<chan>,%c)
    inc %x
  }
}
_mass.chans.op {
  if ($1 == $me) return
  var %x = 1
  while ($chan(%x)) {
    var %c = $ifmatch
    if ($me isop %c) $replace($2-,<chan>,%c)
    inc %x
  }
}

gb _mass.comchans.op $1 .raw MODE <chan> -o+b $1 $_address($1,$hget(x_prot,default_banmask))
gk _mass.comchans.op $1 qkick <chan> $1 $iif($2,$2-,$me)
gkb _mass.comchans.op $1 qkickb <chan> $1 $iif($2,$2-,$me)
gfk _mass.chans.op $1 fk <chan> $1 $iif($2,$2-,$me)
gfkb _mass.chans.op $1 fkb <chan> $1 $iif($2,$2-,$me)

fk {
  if ($1 ischan) var %c = $1, %m = $2, %r = $iif($3,$3-,filter kick of %m)
  else var %c = $active, %m = $1, %r = $iif($2,$2-,filter kick of %m)
  if ($me !isop %c) return
  var %k = $ialchan(%m,%c,0), %_k = $hget(x_status,kicks), %r = $_kick.format(%r)

  while (%k) {
    var %add = $ialchan(%m,%c,%k), %n = $ialchan(%m,%c,%k).nick
    if (%n ison %c) && (%n != $me) {
      inc %_k
      var %l = $addtok(%l,%n,44)
      if ($numtok(%l,44) == $__i(nets-max.kicks)) {
        var %kc = %kc $+ KICK %c %l : $+ %r $+ $lf
        unset %l
      }
    }
    if ($count(%kc,$lf) >= 5) {
      _ffq .raw %kc
      unset %kc
    }
    dec %k
  }
  if (%l) var %kc = %kc $+ KICK %c %l : $+ %r
  if (%kc) _ffq .raw %kc
  hadd -m x_status kicks %_k
}

fkb {
  if ($1 ischan) var %c = $1, %m = $2, %r = $3-
  else var %c = $active, %m = $1, %r = $2-, %1 = 1
  if ($me !isop %c) return
  _filter.deopban %c %m %1
  fk %c %m $iif(%r,%r,filter kickban of %m)
}
_filter.deopban {
  var %n = 1
  while ($nick($1,%n,o)) {
    var %u = $ifmatch
    if ($2 iswm $address(%u,5)) && (%u != $me) var %l = $addtok(%l,%u,32)
    if ($numtok(%l,32) == $__i(nets-max.modes)) { .raw MODE $1 - $+ $str(o,$numtok(%l,32)) %l | unset %l }
    inc %n
  }
  if (%l) {
    if ($3) || ($hget(x_prot,dont65kickops)) .raw MODE $1 - $+ $str(o,$numtok(%l,32)) $+ +b %l $2
    else halt
  }
  else .raw MODE $1 +b $2
}

;/fkn [chan] <nick><masktype> filterkicks all users with same masktype as nick
fkn {
  if ($1 ischan) var %c = $1, %n = $2, %m = $iif($3 isnum,$3,2)
  else var %c = #, %n = $1, %m = $iif($2 isnum,$2,2)
  if (%c ischan) && (%n) fk %c $address($_nickcomp(%n,1).chan,%m)
}

;/fkbn [chan] <nick><masktype> filterkickbans all users with same masktype as nick
fkbn {
  if ($1 ischan) var %c = $1, %n = $2, %m = $iif($3 isnum,$3,2)
  else var %c = #, %n = $1, %m = $iif($2 isnum,$2,2)
  if (%c ischan) && (%n) fkb %c $address($_nickcomp(%n,1).chan,%m)
}


;/kbanned [chan] kicks all banned users, if any
kbanned {
  var %c = $iif($1 ischan,$1,#), %n = 1
  if (%c !ischan) return
  while ($ibl(%c,%n)) {
    var %b = $ifmatch
    if (%b !iswm $__i(myaddress)) fk %c %b
    inc %n
  }
}

;/multi <chan> <action k,b,kb or kill> <nick1,nick2,... or @window> <reason>
multi {
  if (!$1-) return
  if ($1 ischan) var %chan = $1, %action = $2, %win = $3, %reason = $4-
  else return
  var %i = 1, %reason = : $+ $_kick.format($iif(%reason,%reason,$randkickmsg)), %max.modes = $calc($__i(nets-max.modes) -1), %max.kicks = $__i(nets-max.kicks), %_k = $hget(x_status,kicks)

  var %win1 = @multi.mode. $+ $rand(11,99), %win2 = @multi.kick. $+ $rand(11,99)
  window -h %win1
  window -h %win2

  if (@* !iswm %win) {
    var %w = @multi.nicks. $+ $rand(11,99)
    window -hl %w
    var %n = 1
    while ($gettok(%win,%n,44)) {
      aline %w $ifmatch
      inc %n
    }
    %win = %w
  }
  elseif (!$window(%win)) return

  while (%i <= $line(%win,0)) {
    var %nick = $line(%win,%i)
    if (%nick == $me) goto next

    if (%action == kill) .raw KILL %nick %reason

    if (b isin %action) {
      if (%nick isop %chan) var %mode = %mode $+ -o+b, %ban = %ban %nick $_address(%nick,$hget(x_prot,default_banmask))
      else var %mode = %mode $+ b, %ban = %ban $_address(%nick,$hget(x_prot,default_banmask))

      if ($len($remove(%mode,+,-)) >= %max.modes) {
        aline %win1 MODE %chan $iif($left(%mode,1) != -,$+(+,%mode),%mode) %ban
        unset %ban %mode
      }
    }

    elseif (k isin %action) {
      if (%nick ison %chan) {
        var %kickline = $addtok(%kickline,%nick,44)
        inc %_k
        if ($numtok(%kickline,44) == %max.kicks) {
          var %kickraw = %kickraw $+ KICK %chan %kickline %reason $+ $lf
          unset %kickline
        }
      }
      if ($count(%kickraw,$lf) >= 5) {
        aline %win2 %kickraw
        unset %kickraw
      }
    }
    :next
    inc %i
  }

  if (%ban) aline %win1 MODE %chan $iif($left(%mode,1) != -,$+(+,%mode),%mode) %ban
  if (%kickline) || (%kickraw) {
    if (%kickline) aline %win2 %kickraw $+ KICK %chan %kickline %reason
    else aline %win2 %kickraw
  }

  var %i = 1
  while (%i <= $line(%win1,0)) {
    _ffq .raw $line(%win1,%i)
    inc %i
  }

  var %i = 1
  while (%i <= $line(%win2,0)) {
    _ffq .raw $line(%win2,%i)
    inc %i
  }

  close -@ %win
  close -@ %win1
  close -@ %win2

  hadd -m x_status kicks %_k
}
;

_mass {
  var %n = 1
  while ($nick(#,%n,a)) {
    if ($ifmatch != $me) $replace($1-,<nick>,$ifmatch)
    inc %n
  }
  ale Done (total: $calc(%n -2) nicks)
}

mass {
  if (!$1) goto error
  if ($remove($1,+,-) isin ovq) {
    if ($left($1,1) == +) {
      if ($right($1,1) == o) var %ch = a,o
      elseif ($right($1,1) == q) var %ch = a,q
      else var %ch = r
    }
    if ($left($1,1) == -) {
      if ($right($1,1) == o) var %ch = o
      elseif ($right($1,1) == q) var %ch = q
      else var %ch = v
    }
  }
  if ($2 ischan) { var %chan = $2 | goto next }
  else {
    if ($3 ischan) var %chan = $3
    if ($istok(q.nq.op.nop.v.r.all,$2,46)) goto $2
    :q | var %ch = q | goto next
    :nq | set -u %ch a,q | goto next
    :op | var %ch = o | goto next
    :nop | set -u %ch a,o | goto next
    :v | var %ch = v | goto next
    :r | var %ch = r | goto next
    :all | var %ch = a | goto next
  }
  :error ale /mass: Invalid switch (usage:/mass k/kb/kill/-+ovq q/nq/op/nop/v/nv/reg/all #chan) | return
  :next
  var %n = 1, %mk = $__i(nets-max.kicks), %mm = $__i(nets-max.modes)
  :loop
  var %nik = $nick(%chan,%n, [ %ch ] )
  if (%nik == $me) { inc %n | goto loop }
  if ($me !isop %chan) && (o !isin $usermode) return
  if ($remove($1,+,-) isin ovq) {
    if (%nik) {
      var %nicks = $addtok(%nicks,%nik,32)
      if ($numtok(%nicks,32) == %mm) { .raw MODE %chan $left($1,1) $+ $str($right($1,1),$numtok(%nicks,32))) %nicks | unset %nicks }
      inc %n
      goto loop
    }
    if (%nicks) .raw MODE %chan $left($1,1) $+ $str($right($1,1),$numtok(%nicks,32)) %nicks
  }
  elseif (k* iswm $1) && (%nik) {
    var %km = $_kick.format($_kickmsg(masskickall,%chan))
    if ($1 == kill) .raw kill %nik $_kickmsg(masskill)
    else {
      if ($1 == kb) .raw MODE %chan +b $_address(%nik,$hget(x_prot,default_banmask))
      var %kl = $addtok(%kl,%nik,44)
      if ($numtok(%kl,44) == %mk) { .raw KICK %chan %kl : $+ %km | unset %kl }
    }
    inc %n
    goto loop
  }
  if (%kl) .raw KICK %chan %kl : $+ %km
}


;====================

names {
  if (!$server) return
  var %names = $iif($1 != $null,$1,#)
  if (%names) {
    .raw NAMES $ifmatch
    echo -a $_pre Generating NAMES list for %names
    set -u60 $_i(names.,%names) 1
  }
  else ale /NAMES: insufficient parameters
}

wi {
  if (!$server) return
  whois $iif($1,$1,$me) $iif(!$ircx,$iif($1,$1,$me))
}

whois {
  if ($1) {
    if ($numtok($1,44) > 1) whoislist $1
    else whois $1-
  }
}

ww whowas $1-

getidle {
  if ($1 ischan) whoislist $1 1
  elseif ($chr(44) isin $1) whoislist $1 1
  elseif ($1) {
    set $_i(getidle.,$1) 1
    .raw whois $1 $1
  }
}
getip if ($1) .raw userhost $1
uhost getip $1
userhost getip $1

w {
  if ($hget(x_sets,w_as_whois)) wi $1
  else who $1-
}

who {
  if (!$server) { ale Not connected to server. | return }

  if (($1 == *) || ($1 == 0)) && ($2 == o) {
    ale Scanning for ircops (global)
    set $_i(ircop.g) 1
  }

  if ($1 == $server) && (!$input(This may lag you a lot. $crlf Continue anyway?,yq,Who)) return

  if ($1 ischan) && ($nick($1,0) >= $hget(x_sets,ialmax)) && (!$input(Channel is rather big... continue anyway?,yq,Who)) return

  if ($1 != $null) .raw WHO $1-
  elseif ($ircwin) {
    if ($active ischan) set $_i(who) $active $ticks
    who $remove($active,=)
  }
  else ale /WHO: insufficient parameters

  var %m = $iif($2 != $null,$2,$1)
  if (%m) {
    if (%m != o) ale Generating WHO list for %m
    var %w = %m
    if ($numtok(%m,44) > 1) {
      if ($numtok(%m,44) > 3) var %w = ( $+ $gettok(%m,1-3,44) $+ ,...)
      else var %w = ( $+ %m $+ )
      set $_i(who) %w $ticks %m
    }
    else set $_i(who) %w $ticks
    if ($window($+(@Who�,%w,�,$_@network))) window -c $+(@Who�,%w,�,$_@network)
  }
}
ircop.scan {
  unset $_i(ircop.*)
  set $_i(ircop.scan.,#) $ticks
  sline -r #
  _custom.echo Scans $_pre Scanning for ircops ( $+ # $+ )
  .raw WHO #
}
away.scan {
  unset $_i(aways.*)
  set $_i(aways.scan.,#) $ticks
  sline -r #
  _custom.echo Scans $_pre Scanning for aways ( $+ # $+ )
  .raw WHO #
}

;/clones [#chan] [switch(-s|-k|-kb)] [masktype]
clones {
  if ($1 ischan) var %c = $1, %op = $2, %m = $3
  else {
    var %c = #
    if (-* iswm $1) var %op = $1, %m = $2
    elseif ($1 isnum) var %m = $1
  }

  if (%c !ischan) {
    sr -th Error No channel specified
    return
  }

  if ($ialchan(*,%c,0) < $nick(%c,0)) {
    sr -th Error You must update IAL for %c first (Shift-F10)
    return
  }

  var %mt = $iif(%m isnum 0-4,%m,$__i(nets-clonetype)), %a = $ticks

  if (!%op) || (k !isin %op) echo %c $_pre Scanning for clones on %c $+ ...

  var %i = 1, %tmp = $+(x_tmp-cid,$cid,-clones)
  _hfree %tmp
  hmake %tmp 10

  while ($nick(%c,%i)) {
    var %mask = $address($ifmatch,%mt)
    if ($ialchan(%mask,%c,2)) hadd %tmp %mask 1
    inc %i
  }

  if (!$hget(%tmp,0).item) {
    echo %c $_pre No clones found ( $+ $calc(($ticks - %a) /1000) $+ secs)
    goto end
  }

  ;scan only
  if (!%op) || (k !isin %op) {
    var %n = 1, %w = $+(@Clones�,%c,�,$_@network), %total = 0

    if ($window(%w)) window -c %w

    window -kl -t20,25 +e %w $_gcoord(clones,-1 -1 650 350) @clones $_@font
    var %bc = $chr(9)

    aline %w %bc
    aline %w %bc
    aline %w $_c(1) $+ Hostmask $chr(9) $+ $_c(1) $+ Clones $chr(9) $+ $_c(1) $+ Nicks
    aline %w %bc

    while ($hget(%tmp,%n).item) {
      var %g = $ifmatch, %nicks, %v = 1

      while ($ialchan(%g,%c,%v).nick) {
        %nicks = $addtok(%nicks,$ifmatch,44)
        inc %v
      }
      aline %w %g $chr(9) $+ $numtok(%nicks,44) $chr(9) $+ %nicks
      %total = $calc(%total + $numtok(%nicks,44))
      inc %n
    }
    echo %c $_pre Scan completed ( $+ $calc(($ticks - %a) /1000) $+ secs)
    titlebar %w (Total: %total clones)
  }

  ;kick/kickban
  else {
    var %n = 1, %myadd = $__i(myaddress), %g
    while ($hget(%tmp,%n).item) {
      %g = $ifmatch
      if (%g !iswm %myadd) {
        set -u %::masksite $_screw(%g)
        $iif(b isin %op,fkb,fk) %c %g $_kickmsg(clones,%c)
      }
      inc %n
    }
  }

  :end
  _hfree %tmp
}


scan match $1-
match {
  if (!$1) return
  if ($ialchan(*,#,0) < $nick(#,0)) {
    sr -th Error You must update IAL for # first (Shift-F10)
    return
  }

  if ($1 == -s) {
    if (!$istok(10.11.12.13.14.15.20.dcc.black.op.opd.voice.voiced.ban.deop,$2,46)) {
      sr -th Error No such level
      return
    }
    var %level = $2
  }

  var %w = $+(@Match�,$iif(%s,(level $+ $2 $+ ),( $+ $1 $+ )),�,#,�,$_@network), %a = $ticks, %m = 1, %matchs = 0

  if ($2 isnum 0-15) && (#) var %col = 1
  else sline -r #

  if (%level) {
    echo # $_pre Scanning for users with level $_c(1) $+ %level on #
    while ($ialchan(*,#,%m)) {
      var %add = $ifmatch
      if ($istok($remove($level(%add),=),%level,44)) {
        var %nick = $ialchan(*,#,%m).nick
        if (%col) {
          if (%nick ison #) nickcol %nick # $2
        }
        else {
          if (%nick ison #) sline -a # %nick
          if (!$window(%w)) {
            window -kl -t15 +e %w $_gcoord(match,-1 -1 550 350) @clones $_@font
            var %bc = $chr(9)
            aline %w %bc
            aline %w %bc
            aline %w $_c(1) $+ Nick $chr(9) $+ $_c(1) $+ Address
            aline %w %bc
          }
          aline %w %nick $chr(9) $right($mask(%add,0),-2)
        }
        inc %matchs
      }
      inc %m
    }
  }

  else {
    echo # $_pre Scanning for hosts matching ( $+ $_c(1) $+ $1 $+ ) on #
    if (@ isin $1) || (. isin $1) || (* isin $1) var %h = $1
    else var %h = $+(*@*,$1,*)
    while ($ialchan(%h,#,%m)) {
      var %add = $ifmatch, %nick = $ialchan(%h,#,%m).nick
      if (%col) {
        if (%nick ison #) nickcol %nick # $2
      }
      else {
        if (%nick ison #) sline -a # %nick
        if (!$window(%w)) {
          window -kl -t15 +e %w $_gcoord(match,-1 -1 550 350) @match $_@font
          var %bc = $chr(9)
          aline %w %bc
          aline %w %bc
          aline %w $_c(1) $+ Nick $chr(9) $+ $_c(1) $+ Address
          aline %w %bc
        }
        aline %w %nick $chr(9) $right($mask(%add,0),-2)
      }
      inc %matchs
      inc %m
    }
  }

  :end
  var %time = ( $+ $calc(($ticks - %a) /1000) $+ secs)
  if (%matchs) {
    if (%col) echo # $_pre Done (ShiftF10 to restore colors).
    else {
      echo # $_pre Total: $+ $_c(1) %matchs found %time
      if ($window(%w)) titlebar %w (found: %matchs $+ )
    }
  }
  else echo # $_pre No matches found %time
}

;====================

_screw {
  if (!$1) return
  var %n = 1
  while (%n <= $len($1)) {
    var %l = $mid($1,%n,1)
    if (%l isin !*~@.) || (4 // $asc(%l)) || (2 // $rand(1,10)) var %r = %r $+ %l
    else var %r = %r $+ ?
    inc %n
  }
  return %r
}
_filter.address {
  var %n = 1
  while (%n <= $len($1)) {
    var %l = $mid($1,%n,1), %a = %a $+ $iif($asc(%l) < 127,%l,?)
    inc %n
  }
  return %a
}
_address {
  var %add = $address($1,5), %add = $_mask(%add,$2)
  if (!$address($1,5)) return $1 $+ !*@*
  return $_filter.address(%add)
}
_mask {
  if (!$isid) return
  if ($2 == 20) || ((@127. isin $1) && ($ptnet)) var %a = *!* $+ $gettok($gettok($1,1,64),2,33) $+ @*
  elseif ($2 == 18) var %a = $_screw($mask($1,0))
  elseif ($2 == 19) var %a = $gettok($1,1,33) $+ !*@*
  else var %a = $mask($1,$2)
  if ($ircx) && (*@*x iswm %a) return $deltok(%a,-1,46) $+ .*
  return %a
}
_mask2nick {
  var %n = 1
  while ($gettok($2-,%n,32)) {
    var %it = $ifmatch
    if (. isin %it) || (* isin %it) {
      var %i = 1
      while ($ialchan(%it,$1,%i)) {
        var %add = $ifmatch, %nick = $ialchan(%it,$1,%i).nick
        if (%nick != $me) var %list = $addtok(%list,$ifmatch,32)
        inc %i
      }
    }
    else var %list = $addtok(%list,%it,32)
    inc %n
  }
  return %list
}

;$_chan.name(chan) returns the channel without any mode prefix (regex example by qwerty)
_chan.name {
  var %a = $regex($1,/([ $+ $replace($chantypes,\,\\,^,\^,-,\-,],\]) $+ ].+)/)
  return $regml(1)
}

_chan.name.old {
  var %n = 1, %chan = $1
  while ($mid(%chan,%n,1)) {
    var %l = $ifmatch
    if (%l isin $chantypes) break
    if (%l isin $prefix) %chan = $right(%chan,-1)
    else inc %n
  }
  return %chan
}
_chan {
  if ($left($1,1) isin $chantypes) return $1-
  return $chr(35) $+ $1-
}
_nochans if (!$chan(0)) return 1


;=================
;ban stuff

unbanall _unban.all #
_unban.all {
  if ($1) {
    set $_i(resetall.,$1) 1
    mode $1 +b
  }
}
unbanown _unban.own #
_unban.own {
  if ($1) {
    set $_i(resetmine.,$1) 1
    mode $1 +b
  }
}

bans {
  var %c = $iif($1,$1,#)
  if (%c) {
    var %w = $+(@Bans�,%c,�,$_@network)
    if ($window(%w)) window -c %w
    if ($chan(%c).ibl) && ($me isop %c) && ($ibl(%c,1)) _bans2 #
    else mode %c +b
  }
}
validbandur {
  if ($1 >= 0) return $_shorttime($duration($1))
  return -
}
_bans2 {
  var %c = $1, %n = 1, %w = $+(@Bans�,%c,�,$_@network)
  window -c %w
  set -u %::chan %c
  while (%n <= $ibl(%c,0)) {
    var %b = $ibl(%c,%n), %by = $iif($ibl(%c,%n).by,$remove($ibl(%c,%n).by,$chr(9),$chr(40),$chr(41)),-), %when = $validbandur($calc($ctime - $ibl(%c,%n).ctime))
    if (%b iswm $__i(myaddress)) || (%b iswm $puttok($__i(myaddress),$ip,2,64)) var %banned = $addtok(%banned,%b,32)

    if ($hget(x_wins,bans) == window) _addban %c %b $+ $chr(9) $+ $_c(4) $+ %by $+  $+ $chr(9) $+ %when ago
    else {
      if (%n == 1) _custom.echo Bans $_pre $_c(1) $+ Listing bans for %c
      _custom.echo Bans $_c(1) $+ $calc(%n +1) $+ . %b $_c(1) $+ set by %by $_c(1) $+ [ $+ %when $+ $_c(1) $+ ]
    }
    inc %n
  }
  if ($me isop %c) && (%banned) _rem.mybans %c %banned
  if ($window(%w)) {
    titlebar %w (total: $calc($line(%w,0) -4) $+ )
    window -rb %w
  }
  else _custom.echo Bans $_pre $_c(1) $+ End of list
}

_unban if ($me isop $1) { .raw mode $1 -b $2 | _--unset tempbans $+($_network,:,$1,:,$2) }

_bbb if ($me isop #) && (($ibl(#,1)) || ($chan(#).ibl != $true)) return $1-
_bbb2 if ($chan(#).ibl != $true) || ($ibl(#,1)) return View bans $+ $chr(9) $+ $iif($chan(#).ibl,$+($chr(40),$ibl(#,0),$chr(41)))
_bbb3 if ($chan(#).ibl != $true) || ($ibl(#,1)) return Unban $+ $chr(9) $+ ( $+ $ibl(#,0) $+ )
_bbb4 if ($__i(lastunbans.,#)) return Reban $+ $chr(9) $+ ( $+ $numtok($__i(lastunbans.,#),44) $+ )

_addban {
  var %w = $+(@Bans�,$1,�,$_@network)
  if (!$window(%w)) {
    window -klbn -t30,45 %w $_gcoord(bans,-1 -1 620 250) @Ban $_@font
    if ($me isop $1) titlebar %w (double-click to unban)
    aline %w $chr(9)
    aline %w $chr(9)
    aline %w $_c(1) $+ Banmask $+ $chr(9) $+ $_c(1) $+ Banned by $+ $chr(9) $+ $_c(1) $+ When
    aline %w $chr(9)
  }
  aline %w $2-
}
_arbans {
  var %n = 1
  while (%n <= $numtok($3-,32)) {
    var %b = %b $gettok($3-,%n,32)
    if (4 // %n) { .raw mode $2 $1 $+ bbbb %b | unset %b }
    inc %n
  }
  if (%b) .raw mode $2 $1 $+ $str(b,$numtok(%b,32)) %b
}
_rem.mybans {
  if ($input(There are ban(s) in $1 that include you. $+ $crlf $+ Remove them?,yq,Bans)) .raw MODE $1 - $+ $str(b,$numtok($2-,32)) $2-
}

b {
  if ($away) && (($1 == $null) || (-* iswm $1)) { back $1 | return }
  if ($me !isop #) return
  if (!$1) {
    ale Usage: /b <chan/nick/mask> [masktype (if nick)] [duration in secs]
    return
  }
  elseif ($1 ischan) ban $1-
  elseif (*!*@* iswm $1) {
    if ($gettok($1-,-1,32) isnum) var %t = $ifmatch, %bl = $deltok($1-,-1,32)
    else var %bl = $1-
    mode # + $+ $str(b,$numtok(%bl,32)) %bl
    if (%t) .timer 1 %t mode # - $+ $str(b,$numtok(%bl,32)) %bl
  }
  else {
    var %tp = $iif($2 isnum 0-15,$2,$iif($hget(x_prot,default_banmask) isnum 0-15,$hget(x_prot,default_banmask),3))
    if ($3 isnum) var %t = $3
    ban $iif(%t,-u $+ %t) # $_nickcomp($1).chan %tp
  }
  if (%t) ale Ban(s) will be auto-removed in %t secs.
}

unban {
  if ($1 == *) || ($1 == *!*@*) || ($1 == all) _unban.all #
  elseif ($1 == own) _unban.own #
  elseif ($__i(lastbans.,#)) mode # -b $gettok($__i(lastbans.,#),1,44)
}
_unban {
  var %n = $sline($active,0)
  while (%n) {
    var %b = $gettok($sline($active,%n),1,9)
    var %bb = $addtok(%bb,%b,32)
    if ($numtok(%bb,32) == 4) { .raw mode $1 -bbbb %bb | unset %bb }
    dec %n
  }
  if (%bb) .raw mode $1 - $+ $str(b,$numtok(%bb,32)) %bb
}
reban if ($__i(lastunbans.,#)) mode # +b $gettok($__i(lastunbans.,#),1,44)
banpart if ($__i(part.mask.,#)) mode # +b $_mask($ifmatch,$hget(x_prot,default_banmask))
bankick if ($__i(kick.mask.,#)) mode # +b $_mask($ifmatch,$hget(x_prot,default_banmask))

_process.tempbans {
  if ($me !isop $1) || ($__i(process.tempbans.,$1)) return
  var %table = x_tempbans, %net = $_network
  if ($2) {
    var %item = $+(%net,:,$1,:,$2), %data = $hget(%table,%item), %time = $iif($calc(%data - $ctime) > 0,$ifmatch,0)
    if (%data) .timer $+ %item 1 %time _unban $1-
    return
  }
  var %n = 1
  while (%n <= $ibl($1,0)) {
    var %banmask = $ibl($1,%n), %item = $+(%net,:,$1,:,%banmask), %data = $hget(%table,%item), %time = $iif($calc(%data - $ctime) > 0,$ifmatch,0)
    if ($gettok($ibl($1,%n).by,1,33) == $me) && (%data) .timer $+ %item 1 %time _unban $1 %banmask
    inc %n
  }
  set $_i(process.tempbans.,$1) 1
}



;
;EOF
