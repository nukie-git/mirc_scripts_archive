;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; events section (personal)
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

on ^*:OPEN:?:*:{ 
  if ($_string(# appears as &) iswm $1-) halt
  if ($nick == $me) {
    if ($1 == �anti-idle�) {
      var %time = $iif($hget(x_away,anti-idle.time),$ifmatch,60), %rand = $calc($rand(90,110) / 100)
      .timeranti-idle.cid $+ $cid 1 $calc(%time * %rand) .msg $!me �anti-idle�
      halt
    }
    return
  }

  if ($__i(ignore.queries)) halt
  if ($_query.blocker($1-)) halt

  if ($hget(x_perform,on_msgme)) _perfd $ifmatch
  if ($queryonact) return

  ; *** SPAM
  _spam.detect $1-

  event.sound query
  set -u5 $_i(just.open.,$nick) 1
  if ($away) {
    if ($hget(x_away,notice.on.pvt)) {
      if (!$istok($__i(away.noticenick),$nick,44)) {
        rawnotice $nick $replace($_echo(imaway),<areason>,$__i(awayreason),<aduration>,$_leet.duration($_awaytime),<raw.aduration>,$_awaytime,<asince>,$asctime($calc($ctime - $_awaytime)))
        set $_i(away.noticenick) $qtok($__i(away.noticenick),$nick,45,44)
      }
    }
    if ($_awaylog) {
      set $_i(awaylog) $qtok($__i(awaylog),$nick,45,44)
      _addawaylog $nick < $+ $nick $+ > $strip($1-,c)
      if ($hget(x_away,nonewqueries)) halt
    }
  }
}

on ^*:TEXT:*:?:{
  if ($dedicquery) return
  haltdef
  if ($fulladdress isignore) halt
  if ($nick == $me) && ($1 == �anti-idle�) {
    var %time = $iif($hget(x_away,anti-idle.time),$ifmatch,60), %rand = $calc($rand(90,110) / 100)
    .timeranti-idle.cid $+ $cid 1 $calc(%time * %rand) .msg $!me �anti-idle�
    halt
  }

  if ($_isservice($nick,$site)) && (($__i(nets-log.string)) && (($__i(nets-log.string) iswm $1-) || ($__i(nets-log.string) isin $1-))) {
    if ($__i(nets-log.event) == 4) && ($_log.nicks($me)) && ($__i(nets-log.command)) {
      $replace($__i(nets-log.command),<pass>,$_log.pass($me),<me>,$me)
      se $_c(1) $+ * Performing $nick auto-login...
      if ($hget(x_sets,ns.hidelogin)) halt
    }
    elseif ($hget(x_sets,ns.noautolog) != 1) .timer 1 0 perflog
  }

  _addseen $nick pvt text
  if ($_flashing.pvt($nick)) flash $iif(!$_mopt(n5,3),$nick) ( $+ $nick $+ )
  if ($active != $nick) && ($beepquery) beep 1

  if ($hget(x_sets,text.calculator)) var %_l = $_decode($strip($1-,mo))
  else set -un %_l $_decode($strip($_text,mo))

  set -u %::nick $nick
  set -u %::address $address
  set -u %::target $target
  set -un %::text %_l
  set -u %::target $target
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)

  if ($__i(just.open.,$nick)) && ($query($nick)) {
    if ($nick == memoserv) && ($_isservice($nick,$site)) echo $nick $_c(1) $+ Commands: (S)end nick - (L)ist - (R)ead num - (D)el num - (Q)uit
    else {
      var %file = $shortfn($logdir) $+ $mklogfn($nick)
      if ($hget(x_display,loadbuf.query)) && ($isfile(%file)) loadbuf $nick %file
      else {
        echo -i2 $nick Query with $nick ( $+ $address $+ ) [[ $+ $_network $+ ]]
        echo -i2 $nick Common channels: $_comchans($nick).pnick
      }
    }
    linesep $nick
    unset $_i(just.open.,$nick)
    if ($whoisonquery) set -u15 $_i(whois.on.query.,$nick) 1
  }

  if ($1- !isnum) && ($highlight) && (($highlight($1-)) || ($highlight($nick).nicks)) var %col = $iif($highlight($1-).color,$calc($ifmatch -1),$color(highlight))
  else var %col = $color(normal)
  if ($query($nick)) {
    set -u %:echo echo %col -mlti2 $nick
    theme.text textquery
  }
  else {
    set -u %:echo echo %col $iif(@* iswm $active,-mltsi2,-mltai2)
    theme.text textmsg
  }

  _redir $nick $_display(textquery)
}

on ^*:ACTION:*:?:{
  haltdef
  if ($fulladdress isignore) halt
  if ($dedicquery) return

  _addseen $nick pvt action
  if ($_flashing.pvt($nick)) flash $iif(!$_mopt(n5,3),$nick) ( $+ $nick $+ )
  if ($active != $nick) && ($beepquery) beep 1

  set -un %_l $_decode($strip($1-,mo))

  set -u %::nick $nick
  set -u %::address $address
  set -u %::target $target
  set -un %::text %_l
  set -u %::target $target
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)

  if ($__i(just.open.,$nick)) && ($query($nick)) {
    var %file = $shortfn($logdir) $+ $mklogfn($nick)
    if ($hget(x_display,loadbuf.query)) && ($isfile(%file)) loadbuf $nick %file
    else {
      echo -i2 $nick Query with $nick ( $+ $address $+ ) [[ $+ $_network $+ ]]
      echo -i2 $nick Common channels: $_comchans($nick).pnick
    }
    linesep $nick
    unset $_i(just.open.,$nick)
    if ($whoisonquery) set -u15 $_i(whois.on.query.,$nick) 1
  }

  if ($1- !isnum) && ($highlight) && (($highlight($1-)) || ($highlight($nick).nicks)) var %col = $iif($highlight($1-).color,$calc($ifmatch -1),$color(highlight))
  else var %col = $color(action)

  if ($query($nick)) set -u %:echo echo %col -mlti2 $nick
  else set -u %:echo echo %col $iif(@* iswm $active,-mltsi2,-mltai2)
  theme.text actionquery

  _redir $nick $_display(actionquery)
}

on *:OPEN:=:{
  event.sound chatopen
  var %file = $logdir $+ $mklogfn($nick)

  if ($hget(x_display,loadbuf.query)) && ($isfile(%file)) {
    loadbuf =$nick " $+ %file $+ "
    linesep $nick
  }
  elseif ($query($nick)) && ($$input(Copy text from query and close it?,yq)) {
    _copy.query-chat
    .timer 1 1 close -m $nick
  }
}
alias -l _copy.query-chat {
  var %f = tmp\sb- $+ $_rand6 $+ .qc, %f2 = tmp\sb- $+ $_rand6 $+ .qc
  savebuf $nick %f
  savebuf =$nick %f2
  clear =$nick
  loadbuf =$nick %f
  echo =$nick -
  loadbuf =$nick %f2
  .remove %f
  .remove %f2
}
on *:CLOSE:=:event.sound chatclose

on ^*:CHAT:*:{
  haltdef
  set -u %::nick $nick
  set -u %::address $gettok($address($nick,5),-1,33)
  set -u %::target $nick
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)

  _addseen $nick dcc chat
  if ($_flashing.pvt($nick)) flash $iif(!$_mopt(n5,3),$nick) ( $+ $nick $+ )
  if (($active != =$nick) || (!$appactive)) && ($beepquery) beep 1

  if ($1 == ACTION) {
    set -un %t $remove($strip($2-,mo),)
    if ($hget(x_sets,ansi.chat)) %t = $ansi2mirc(%t)
    set -un %::text %t
    set -u %:echo echo $color(action) -mlti2 =$nick
    theme.text actionquery

    _redir =$nick $_display(actionquery)
  }

  ;  elseif ($1 === PRIVMSG) && ($0 == 8) { _get $nick $chat($nick).ip $remove($5-,) | halt }
  elseif ($1-2 === CHATX REQUEST) && ($4) { _reqchatx2 $nick $3-4 1 | halt }
  elseif ($1 === PING) && ($2 isnum) {
    if ($__i(dcc.ping.,$nick)) halt
    set -u15 $_i(dcc.ping.,$nick) 1
    echo =$nick $replace($_echo(dccping),<nick>,$nick)
    .msg =$nick PONG $2-
  }
  elseif ($1 == PONG) && ($2 isnum) && ($__i(dping.,$nick)) {
    var %t = $calc(($ticks - $__i(dping.,$nick)) /1000)
    echo =$nick $replace($_echo(dccpingreply),<nick>,$nick,<time>,%t)
    unset $_i(dping.,$nick)
  }

  else {
    set -un %t $strip($1-,mo)
    if ($hget(x_sets,ansi.chat)) %t = $ansi2mirc(%t)
    set -un %::text %t
    set -u %:echo echo $color(normal) -mlti2 =$nick
    theme.text textquery

    _redir =$nick $_display(textquery)
  }
}


on ^*:NOTICE:*:?:{
  haltdef
  if ($nick == $me) && ($1 == self-lag) && ($2 == 101010101) {
    _lagcheck
    halt
  }
  if ($1 == dcc) && ($istok(send.chat.fserve.resume,$2,46)) return

  if ($_isservice($nick,$site)) {
    var %service = 1
    if (($__i(nets-log.string)) && (($__i(nets-log.string) iswm $1-) || ($__i(nets-log.string) isin $1-))) {
      if ($__i(nets-log.event) == 3) && ($_log.nicks($me)) {
        if ($__i(nets-log.command)) $replace($__i(nets-log.command),<pass>,$_log.pass($me),<me>,$me)
        elseif ($__i(s^n)) && ($_log.pass($me)) ns identify $ifmatch
        else var %noa = 1
        if (%noa != 1) {
          se $_c(1) $+ * Performing $nick auto-login...
          if ($hget(x_sets,ns.hidelogin)) halt
        }
      }
      elseif ($hget(x_sets,ns.noautolog) != 1) .timer 1 0 perflog
    }
    elseif ($nick == memoserv) {
      memoserv.notice $nick $site $1-
      halt
    }
    elseif ($nick == chanserv) {
      if ($__i(banned.from) isin $1-) join $ifmatch
    }
    elseif ($nick == nickserv) {
      if (($__i(nets-log.string-correct)) && (($__i(nets-log.string-correct) iswm $1-) || ($__i(nets-log.string-correct) isin $1-))) var %correct = 1
      if (($__i(nets-log.string-incorrect)) && (($__i(nets-log.string-incorrect) iswm $1-) || ($__i(nets-log.string-incorrect) isin $1-))) var %incorrect = 1
      if (%incorrect) || (password*incorrect* iswm $1-) {
        if ($hget(x_sets,ns.noautolog) != 1) .timer 1 0 _log.again
        if ($hget(x_sets,ns.hidelogin)) { se $_c(2) $+ * Login failed | halt }
      }
      elseif (%correct) || (password*accepted* iswm $1-) || (Password*aceite* iswm $1-) || (*senha aceite* iswm $1-) {
        if ($hget(x_sets,ns.hidelogin)) { se $_c(1) $+ * Login successfull | halt }
      }
    }
  }
  elseif (($nick == bnc) && ($site == bnc.com)) || ($address == psybnc@lam3rz.de) {
    var %bnc = 1
    if (!$hget(x_bouncer,nopopups)) {
      if ($_string(/quote PASS) isin $1-) {
        if ($server isin $hget(x_bouncer,0)) && ($hget(x_bouncer,1)) .raw PASS $_pwd($ifmatch)
        else .timer 1 0 bounce.pass
      }
      elseif ($_string(/quote CONN) isin $1-) {
        if ($hget(x_bouncer,3)) .raw $ifmatch
        if ($hget(x_bouncer,2)) .timer 1 2 .raw CONN $hget(x_bouncer,2)
        else .timer 1 0 bounce.custom
      }
    }
  }

  else {
    inc -u3 $_i(flood.notices.,$site)
    if ($__i(flood.notices.,$site) == 5) {
      set -u30 $_i(ignore.it) -n $wildsite
      set -u %:comments (ShiftF4 to ignore further notices)
    }

    ; *** SPAM
    _spam.detect $1-

  }

  if ($1-2 === CHATX REQUEST) && ($4) {
    if (!$__i(chatx.requested.,$nick)) return
    set -u10 $_i(chatx.requested.,$nick) 1
    .timer 1 0 _reqchatx2 $nick $3-4
    return
  }

  var %nw = $+(@Notice�,$nick,�,$_@network)
  set -un %1 $strip($1-,mo)
  set -u %::nick $nick
  set -u %::address $address
  set -un %::text %1
  set -u %::target $me

  if (%service) || (%bnc) {
    if ($nick == nickserv) && ($query($active)) set -u %:echo echo $color(notice) -amti5
    elseif ($hget(x_wins,noticeservice) == window) set -u %:echo _custom.echo.win $color(notice) Service( $+ $nick $+ ) $_timestamp
    elseif ($hget(x_wins,noticeservice) == active) && (@* !iswm $active) set -u %:echo echo $color(notice) -amti5
    else set -u %:echo echo $color(notice) -smti5

    theme.text notice
    return
  }

  _addseen $nick notice
  event.sound notice

  if ($_flashing.pvt(notice)) flash ( $+ $nick $+ )
  if ($beepquery) && (!$appactive) beep 1

  if ($window(%nw)) {
    set -u %::lb $hget(x_display,lb)
    set -u %::rb $hget(x_display,rb)
    if ($hget(x_display,nw.asquery)) {
      set -u %:echo echo $color(normal) -mti5 %nw
      theme.text textquery
    }
    else {
      set -u %:echo echo $color(notice) -mti5 %nw
      theme.text notice
    }
    return
  }

  if ($hget(x_wins,notice) == window) set -u %:echo _custom.echo.win $color(notice) Notices $_timestamp
  else set -u %:echo echo $color(notice) $iif((@* !iswm $active && $notonact),-ati5,-stmi5)

  theme.text notice

  if ($away) && ($_awaylog) _addawaylog $nick - $+ $nick $+ - $strip($1-,c)

  if ($hget(x_perform,on_noticeme)) _perfd $ifmatch
  _redir $nick $_display(notice)
}

on *:SNOTICE:*:{
  if ($server == $gettok($hget(x_bouncer,0),1,32)) var %saved.bnc = 1
  if ($_string(/quote PASS) isin $1-) {
    if ($hget(x_bouncer,1)) && (%saved.bnc) {
      .raw PASS $_pwd($hget(x_bouncer,1))
      se $_c(1) $+ *** Performing auto-login...
    }
    else .timer 1 0 bounce.pass
  }
  elseif ($_string(/quote CONN) isin $1-) {
    if ($hget(x_bouncer,3)) && (%saved.bnc) .raw $ifmatch
    if ($hget(x_bouncer,2)) && (%saved.bnc) {
      var %s = $ifmatch
      .timer 1 1 .raw CONN %s
      se $_c(1) $+ *** Connecting to %s
    }
    else .timer 1 0 bounce.custom
  }
}

;/bounce (connects to the bouncer saved)
alias bounce {
  if ($hget(x_bouncer,0)) server $gettok($hget(x_bouncer,0),1,32) $gettok($hget(x_bouncer,0),2,32)
}
alias bounce.pass {
  .raw PASS $$_input(Enter password,p,BNC)
}
alias bounce.custom {
  if ($input(Send custom commands before connecting?,yq)) && ($_input(Custom commands,e,BNC)) .raw $ifmatch
  if ($_input(BNC irc server?,e,BNC)) .raw CONN $ifmatch
}


;notice window
on *:INPUT:@notice�*:{
  if ($comchar iswm $1) && ($ctrlenter == $false) {
    if ($_msbug($1)) { sr -t Micro$oft What do you wanna crash today? :P | halt }
    return
  }
  var %t = $gettok($target,2,160), %chan = $_chan.name(%t)
  set -un %::text $1-
  .notice %t $1-
  if (%chan ischan) set -u %::nick $nick(%chan,$me).pnick
  else set -u %::nick $me
  set -u %::chan %chan
  set -u %::target %t
  set -u %::lb $hget(x_display,lb)
  set -u %::rb $hget(x_display,rb)
  set -u %:echo echo $color(own) -qt $target
  theme.text $iif($hget(x_display,nw.asquery),textqueryself,noticeself)
  halt
}

;
;EOF
