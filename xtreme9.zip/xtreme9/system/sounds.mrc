;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; event sounds, mp3 player and mixer routines
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;

alias splay {
  if (!$1) { var %f = $$sfile(*,Select file to play,Play) | .timer 1 0 splay %f | return }
  if (-* iswm $1) || ($1 == stop) {
    if ($1 == -p) .signal splay $2
    !splay $1-
    return
  }
  var %f = $replace($1-,$+($chr(37),20),_), %e = $gettok($nopath(%f),-1,46), %wd = $shortfn($wavedir), %md = $shortfn($mididir)

  if ($_msbug(%f)) { ae $_warn Probable exploit in filename ( $+ $wildtok($1-,*/*,1,92) $+ ), halting... | return }

  if ((%e != mid) && (($inwave) || ($insong))) || ((%e == mid) && ($inmidi)) || (!%e) return

  if (%f == $nopath(%f)) {
    if ($isfile($+(%wd,%f))) var %f = $+(%wd,%f)
    elseif ($isfile($+($shortfn($mididir),%f))) var %f = $+(%md,%f)
    else var %f = $findfile($left($mircdir,3),$replace(%f,_,?),1)
  }
  var %f = $shortfn(%f)
  if (!$isfile(%f)) { if ($show) echo $iif($target ischan,$target,-a) $_pre Sound requested $nopath($1-) does not exist. | return }
  if ($istok(wav.mid.mp3,%e,46)) !splay $iif(%e == mid,-m,$iif(%e == mp3,-p,-w)) %f
  elseif ($_soundext(%e)) run %f
}

;==============================================================
;event sounds

alias defsounds {
  var %s = _set sounds, %f = $mircdirsounds\
  _unset sounds
  %s enable 1
  %s connect %f $+ connected.wav
  %s disconnect %f $+ disconnected.wav
  %s notify %f $+ online.wav
  %s chatopen %f $+ bipbip.wav
  %s filesent %f $+ filedone.wav
  %s filercvd %f $+ filedone.wav
  %s dccfail %f $+ ooh.wav
  %s invite %f $+ invite.wav
  %s query %f $+ bipbip.wav
  %s chatreq %f $+ chat.wav
  %s sendreq %f $+ file.wav
  %s joinwarn %f $+ beeper.wav
  %s kick %f $+ kicking.wav
  %s warning %f $+ kicked.wav
  %s pager %f $+ memo.wav
  sr Event sounds set to default.
}

alias splay.event if ((!$away) || (!$hget(x_away,disable.flash))) && ($isfile($1-)) .splay $1-
alias event.sound {
  if (($away) && ($hget(x_away,disable.flash))) || (!$hget(x_sets,event.sounds)) return
  if ($hget(x_sounds,$1)) {
    var %f = $ifmatch
    if ($isfile(%f)) .splay %f
  }
}

;========================================================
; mp3 player

alias mp3player mp3p
alias mp3p _dialog $iif($hget(x_mp3,desktopplayer),-dm,-m) mp3p mp3p

dialog mp3p {
  title "MP3 Player v2.0"
  size -1 -1 192 70
  option dbu
  icon graphics\mp3player.ico, 0
  button "4", 12, 42 50 20 10
  button "9", 11, 22 50 20 10
  check ";", 13, 62 50 20 10, push
  button "<", 14, 82 50 20 10
  button ":", 15, 102 50 20 10
  button "5", 16, 122 50 20 10
  text "00:00", 1, 10 10 40 20, center
  edit "", 2, 53 10 100 10, read autohs
  text "", 3, 53 20 25 10
  text "", 4, 128 20 25 10
  text "", 5, 78 21 50 10, disable center
  button "0 0 50 - 20000 10000", 21, 10 33 142 7, disable
  check "", 60, 10 29 40 1, push
  check "Shuffle", 61, 159 9 30 10, push
  check "Playlist", 62, 159 19 30 10, push
  button "View ID3", 63, 159 29 30 10, disable
  button "Volume", 64, 159 39 30 10
  button "Close", 50, 159 54 30 11, default ok
  list 100, 5 70 181 142, size extsel hide
  ;  text "Loading playlist...", 115, 15 75 80 8, size extsel
  button "Update", 104, 126 215 30 10
  button "Edit", 103, 157 215 30 10
  edit "", 110, 0 0 0 0, autohs
  button "", 111, 0 0 0 0, hide cancel
  check "", 112, 0 0 0 0, hide
  edit "", 6, 5 215 87 10
  button "Filter", 9, 95 215 30 10
  button "", 999, 0 0 0 0
}

on 1:dialog:mp3p:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    mdx SetControlMDX 21 scrollbar > $mdx.gdll
    mdx SetFont 1 +a 26 400 Comic Sans MS
    mdx SetFont 100 +a 12 400 Verdana
    mdx SetControlMDX 100 listview rowselect single flatsb showsel report nosortheader > $mdx.vdll

    mdx SetControlMDX 999 positioner size minbox > $mdx.ddll

    did -i $dname 100 1 headerdims 285 55
    if ($numtok($hget(x_mp3list,1),164) > 2) did -i $dname 100 1 headertext 0 Title $_tab Length
    else did -i $dname 100 1 headertext 0 Title $_tab Size

    if ($numtok($hget(x_mp3,position),32) == 4) var %p = $hget(x_mp3,position)
    else var %p = -1 -1 390 494

    if ($hget(x_mp3,showplaylist)) {
      dialog -sp mp3p %p
      var %h = $dialog(mp3p).h
      mdx MoveControl $dname 100 * * * $calc(%h - 210)
      mdx MoveControl $dname 103 * $calc(%h - 64) * *
      mdx MoveControl $dname 104 * $calc(%h - 64) * *
      mdx MoveControl $dname 6 * $calc(%h - 64) * *
      mdx MoveControl $dname 9 * $calc(%h - 64) * *

      did -c mp3p 62
      _loadmp3list
    }
    else {
      dialog -sp mp3p $gettok(%p,1-2,32) 390 140
    }

    mdx SetBorderStyle 1 clientedge dlgmodal
    mdx SetBorderStyle 2,3,4 clientedge
    mdx SetBorderStyle 10,11,12,13,14,15,16 staticedge
    mdx SetColor 1 text $iif($hget(x_mp3,dispcol.text),$ifmatch,65280)
    mdx SetColor 1 textbg $iif($hget(x_mp3,dispcol.backg),$ifmatch,0)
    mdx SetColor 1 background $iif($hget(x_mp3,dispcol.backg),$ifmatch,0)
    if ($hget(x_mp3,random)) did -c mp3p 61
    if ($hget(x_mp3,decrease)) did -c mp3p 60
    if ($hget(x_mp3,actual)) || ($hget(x_mp3,lastplay)) {
      var %f = $iif(($hget(x_mp3list) && $hget(x_mp3,actual)),$gettok($hget(x_mp3list,$hget(x_mp3,actual)),1,164),$hget(x_mp3,lastplay))
      _load %f
      if ($insong) did -e mp3p 21
    }
    if ($insong) && ($hget(x_mp3,paused)) {
      did -c mp3p 13
      dialog -t mp3p $addtok($dialog(mp3p).title,(paused),32)
    }
    _update.mp3p
    mdx SetFont 11,12,13,14,15,16 +a 20 400 Webdings
  }
  if ($devent == sclick) {

    ;************ RESIZE EVENT ******************
    if ($did == 999) {
      tokenize 32 $did(999)
      if ($1 == sizing) {
        if (!$did(62).state) {
          did -a $dname 999 setsize w 396 172
        }
        else {
          var %w = $5, %h = $6
          did -a $dname 999 setsize w 396 %h
          if (%h < 492) {
            did -a $dname 999 setsize w 396 494
            mdx MoveControl $dname 100 * * * 284
            mdx MoveControl $dname 103 * 430 * *
            mdx MoveControl $dname 104 * 430 * *
            mdx MoveControl $dname 6 * 430 * *
            mdx MoveControl $dname 9 * 430 * *
          }
          else {
            mdx MoveControl $dname 100 * * * $calc(%h - 210)
            mdx MoveControl $dname 103 * $calc(%h - 64) * *
            mdx MoveControl $dname 104 * $calc(%h - 64) * *
            mdx MoveControl $dname 6 * $calc(%h - 64) * *
            mdx MoveControl $dname 9 * $calc(%h - 64) * *
          }
        }
      }
    }

    if ($did == 111) {
      ; EXIT
      if ($insong) && ($hget(x_mp3,stop.on.close)) splay -p stop
    }

    if ($did == 100) did -t mp3p 12
    else did -t mp3p 50

    if ($did == 11) && ($hget(x_mp3list)) && ($hget(x_mp3,previous)) {
      var %n = $ifmatch
      _set vars mp3.recent $deltok($hget(x_vars,mp3.recent),1-2,44)
      if ($insong) mp3play %n
      else {
        _load %n
        _set mp3 actual %n
      }
    }
    if ($did == 12) {
      var %sel = $remove($gettok($did(100,$did(100).sel),6,32),.)
      mp3play $iif(%sel isnum,%sel,$hget(x_mp3,lastplay))
    }
    if ($did == 13) {
      if ($insong) splay -p $iif($hget(x_mp3,paused),resume,pause)
      else did -u mp3p 13
    }
    if ($did == 14) && ($insong) splay -p stop
    if ($did == 15) && ($hget(x_mp3list)) {
      if ($insong) mp3play
      else {
        var %n = $_mp3.loadn
        _load %n
        _set mp3 actual %n
      }
    }
    if ($did == 16) mp3play open
    if ($did == 21) && ($hget(x_mp3,paused) != 1) && ($insong) {
      if ($gettok($did(21),-1,32) == stopped) splay -p seek $gettok($did(21),1,32)
      if ($hget(x_mp3,decrease)) did -ra mp3p 1 - $+ $_mtime($calc(($gettok($did(21),3,32) - $gettok($did(21),1,32)) /1000))
      else did -ra mp3p 1 $_mtime($calc($gettok($did(21),1,32) /1000))
    }
    if ($did == 60) { _set mp3 decrease $did(60).state | _update.mp3p }
    if ($did == 61) _set mp3 random $did(61).state
    if ($did == 62) {
      if ($did(62).state) {
        dialog -sp mp3p $dialog(mp3p).x $dialog(mp3p).y 390 494
        var %h = $dialog(mp3p).h
        mdx MoveControl $dname 100 * * * $calc(%h - 210)
        mdx MoveControl $dname 103 * $calc(%h - 64) * *
        mdx MoveControl $dname 104 * $calc(%h - 64) * *
        mdx MoveControl $dname 6 * $calc(%h - 64) * *
        mdx MoveControl $dname 9 * $calc(%h - 64) * *

        _set mp3 showplaylist 1
        _loadmp3list
      }
      else {
        dialog -sp mp3p $dialog(mp3p).x $dialog(mp3p).y 390 140
        _unset mp3 showplaylist
      }
    }
    if ($did == 63) mp3.id $iif(($insong == $false && $shortfn($gettok($hget(x_mp3list,$hget(x_mp3,actual)),1,164))),$ifmatch)
    if ($did == 64) mixer
    if ($did == 50) || ($did == 111) {
      _set mp3 position $dialog(mp3p).x $dialog(mp3p).y 390 $dialog(mp3p).ch
      if ($hget(x_mp3,stop.on.close)) splay -p stop
    }
    if ($did == 103) playlist
    if ($did == 104) {
      _loadmp3list
      did -u $dname 112
      did -ra $dname 104 Update
    }
    if ($did == 9) && ($did(6) != $null) {
      var %mask = $ifmatch, %n = $did(100).lines
      did -ra $dname 104 Reset
      did -c $dname 112
      while (%n >= 2) {
        var %line = $did(100,%n), %song = $_rempunct.all($gettok($gettok(%line,7-,32),1,9)), %isin = 0
        if ($len(%mask) > 5) && (%mask isin %song) var %isin = 1
        if (!$istok(%song,%mask,32)) && (%mask !iswm %song) && (!%isin) did -d $dname 100 %n
        dec %n
      }
    }
  }
  if ($devent == dclick) && ($did == 100) && ($remove($gettok($did(100,$did(100).sel),6,32),.) isnum) mp3play $ifmatch
  if ($devent == edit) && ($did == 6) did -t $dname 9
}

on *:MP3END:{
  if ($hget(x_mp3,continuous)) {
    if ($hget(x_mp3list,0).item) mp3play
    elseif ($dialog(mp3p)) { did -ra mp3p 1 00:00 | did -r mp3p 2,3,4,5 | did -b mp3p 21 }
  }
}


on *:SIGNAL:splay:{
  if ($1 == pause) {
    _set mp3 paused 1
    .timerupdmp3 off
    if ($dialog(mp3p)) {
      did -c mp3p 13
      dialog -t mp3p $addtok($dialog(mp3p).title,(paused),32)
      did -b mp3p 21
      did -ra mp3p 21 $gettok($did(mp3p,21),1-6,32)
    }
  }
  else {
    if ($1 != seek) _update.mp3p
    _unset mp3 paused
    if ($dialog(mp3p)) {
      did -u mp3p 13
      dialog -t mp3p $remtok($dialog(mp3p).title,(paused),32)
      did -e mp3p 21
    }
  }
  if ($1 == stop) && ($dialog(mp3p)) {
    did -u mp3p 13
    did -ra mp3p 1 00:00
    did -b mp3p 21
    .timerupdmp3 off
    dialog -t mp3p MP3 Player v2.0
  }
}
alias _update.mp3p {
  if ($insong) && ($dialog(mp3p)) {
    var %f = $insong.fname, %p = $insong.pos, %l = $insong.length, %n = $hget(x_mp3,mp3.ln)
    if ($gettok($did(mp3p,21),-1,32) == stopped) {
      if ($hget(x_mp3,decrease)) var %d = - $+ $_mtime($calc((%l - %p) /1000))
      else var %d = $_mtime($calc(%p /1000))
      if ($did(mp3p,1) != %d) did -ra mp3p 1 %d
      did -ra mp3p 21 %p 0 %l - 20000 10000
    }

    _enterparams %f playing
    .timerupdmp3 -cmo 1 250 _update.mp3p
  }
}

alias -l _enterparams {
  if ($did(mp3p,110) == $1) && (!$3) return
  var %l = $_mp3.info2($1).length, %fn = $_mp3.info2($1).fname, %name = $_mp3.info2($1), %name = $iif((%name && $hget(x_mp3,dont.use.id3) != 1),%name,%fn), %ln = %name ( $+ %l $+ )

  if (%fn) && ($did(mp3p,2) != %ln) {
    did -ra mp3p 2 %ln
    did -c mp3p 2 1
    did -ra mp3p 3 $chr(160) $+ $sound($1).bitrate $+ kbps
    did -ra mp3p 4 $chr(160) $+ $round($calc($sound($1).sample /1000),1) $+ khz
    did -ra mp3p 5 $sound($1).mode
    did $iif(!$_mp3.id3($1).artist,-b,-e) mp3p 63
    var %wm = *. %name $+ $chr(9) $+ *
    if ($didwm(mp3p,100,%wm)) did -c mp3p 100 $ifmatch
  }
  if ($insong) {
    if ($did(mp3p,21).enabled == $false) did -e mp3p 21
    if (%name !isin $dialog(mp3p).title) {
      if ($hget(x_mp3,paused)) dialog -t mp3p $addtok(%name,(paused),32)
      else { dialog -t mp3p %name | did -u mp3p 13 }
    }
  }
  did $iif($2,-ra,-r) mp3p 110 $1
}

alias -l _mp3.select {
  var %fn = $longfn($insong.fname), %name = $_mp3.info2(%fn), %name = $iif((%name && $hget(x_mp3,dont.use.id3) != 1),%name,$_mp3.info2(%fn).fname), %wm = *. %name $+ $chr(9) $+ *
  if ($didwm(mp3p,100,%wm)) did -c mp3p 100 $ifmatch
}
alias -l _load _enterparams $shortfn($iif($1 isnum,$gettok($hget(x_mp3list,$1),1,164),$1-))
alias -l _mp3.loadn {
  if ($hget(x_mp3,random)) var %n = $rand(1,$hget(x_mp3list,0).item)
  else var %n = $calc($hget(x_mp3,actual) +1)
  return $iif(%n,%n,1)
}
alias -l _loadmp3list {
  did -hr mp3p 100
  var %n = 1
  while ($hget(x_mp3list,%n)) {
    tokenize 164 $ifmatch
    if ($0 > 2) var %fg = 1, %s = %n $+ . $3 $+ $chr(9) $+ $4
    else var %s = %n $+ . $_mp3.info2($1).fname $+ $chr(9) $+ $bytes($2,3).suf
    did -a mp3p 100 %s
    inc %n
  }
  if ($insong) _mp3.select
  did -v mp3p 100
}


;======================================================
;routines

;using swamp.dll
;alias winamp {
;  if ($hget(x_mp3,winamp.popups)) || ($lock(dll)) return
;  if ($isid) return $dll(dlls\swamp.dll,WinAmpGet,$1)
;  .dll dlls\swamp.dll $iif($1 == -r,WinAmpRun,$iif($1 == -s,WinAmpSet,WinAmpCmd)) $iif(- isin $1,$shortfn($2-),$1)
;}
;alias _winamps {
;  if ($winamp(state)) _set mp3 wa.state $ifmatch
;  else _unset mp3 wa.state
;}

;using r1dll.dll
alias winamp2 {

  if ($1 == running) {
    if (!$hget(x_mp3,winamp.popups)) return 0
    return $dll(dlls\r1dll.dll,GetCurrentWinampSong,0) 
  }
  if ($1 == track) return $dll(dlls\r1dll.dll,GetCurrentWinampSong,0)
  if ($1 == trackfilename) return $dll(dlls\r1dll.dll,GetCurrentWinampSongFileName,0)
  if ($1 == tracktime) return $dll(dlls\r1dll.dll,GetCurrentWinampSongTotalTime,0)
  if ($1 == samplerate) return $dll(dlls\r1dll.dll,GetCurrentWinampSongKHz,0)
  if ($1 == bitrate) return $dll(dlls\r1dll.dll,GetCurrentWinampSongKbps,0)
  if ($1 == mode) {
    if ($dll(dlls\r1dll.dll,GetCurrentWinampSongChannels,0) == 2) return Stereo
    return Mono
  }
}

;using aircdll.dll
alias winamp {

  if ($lock(dll)) return
  if ($isid) return $gettok($dll(dlls\aircdll.dll,winamp,$1-),2,32)
  else .dll dlls\aircdll.dll winamp $1-
}

alias _winamps {
  var %st = $winamp(isplaying)
  if (%st == 1) _set mp3 wa.state Playing
  elseif (%st == 3) _set mp3 wa.state Paused
  elseif (%st == 0) _set mp3 wa.state Stopped
  else _unset mp3 wa.state
}

alias mp3.echan {
  if ($istok($hget(x_mp3,chan),$chan($1),32)) return $style(1) $chan($1)
  if ($chan($1)) return $ifmatch
}
alias _togmp3chan {
  _set mp3 chan $remtok($hget(x_mp3,chan),all,32)
  if ($istok($hget(x_mp3,chan),$chan($1),32)) {
    if ($remtok($hget(x_mp3,chan),$chan($1),32)) _set mp3 chan $ifmatch
    else _unset mp3 chan
  }
  else _set mp3 chan $addtok($hget(x_mp3,chan),$chan($1),32)
}
alias _tmpinmp3 {
  if ($insong) {
    set -u1 %inmp3 $ifmatch
    set -u1 %inmp3.fname $insong.fname
  }
}

;----------------

;/mp3.id opens up mp3 file info dialog
alias mp3.id {
  var %f = $iif($1,$1-,$insong.fname)
  if ($_mp3.id3(%f).artist) {
    if ($dialog(mp3.id3)) __mp3.id %f
    else {
      if ($1) set $_i(mp3.id3.fname) $1-
      var %a = $_dialog(mp3.id3,mp3.id3,-4)
    }
  }
  else sr -t MP3 No ID3 tag available
}

dialog mp3.id3 {
  title "MP3 file info box"
  size -1 -1 265 172
  option dbu
  edit "", 1, 7 11 250 10, read autohs
  box "ID3v1-v2", 2, 89 25 169 125
  text "Title", 3, 94 42 35 8, right
  text "Artist", 4, 94 52 35 8, right
  text "Album", 5, 94 62 35 8, right
  text "Year", 6, 94 72 35 8, right
  text "Comment", 7, 94 82 35 8, right
  text "Composer", 8, 94 103 35 8, right
  text "Orig. Artist", 9, 94 113 35 8, right
  text "Copyright", 10, 94 123 35 8, right
  text "URL", 11, 94 133 35 8, right
  edit "", 12, 131 41 120 10
  edit "", 13, 131 51 120 10
  edit "", 14, 131 61 120 10
  edit "", 15, 131 71 26 10
  text "Genre", 16, 164 72 30 8, right
  edit "", 17, 196 71 55 10
  edit "", 18, 131 81 120 20, autovs
  edit "", 19, 131 102 120 10
  edit "", 20, 131 112 120 10
  edit "", 21, 131 122 120 10
  edit "", 22, 131 132 120 10
  text "", 23, 15 42 60 90
  box "MPEG Info", 24, 7 25 76 125
  button "Close", 25, 113 155 35 12, ok default
  edit "", 26, 231 31 20 10
  text "Track #", 27, 194 32 35 8, right
}
on *:dialog:mp3.id3:init:0:{
  var %f = $iif($__i(mp3.id3.fname),$ifmatch,$insong.fname)
  unset $_i(mp3.id3.fname)
  __mp3.id %f
}
alias -l __mp3.id {
  var %f = $1-
  did -ra mp3.id3 12 $_mp3.id3(%f).title
  did -ra mp3.id3 13 $_mp3.id3(%f).artist
  did -ra mp3.id3 14 $_mp3.id3(%f).album
  did -ra mp3.id3 15 $_mp3.id3(%f).year
  did -ra mp3.id3 17 $gettok($_mp3.id3(%f).genre,-1,41)
  did -ra mp3.id3 18 $_mp3.id3(%f).comment
  did -ra mp3.id3 19 $_mp3.id3(%f).composer
  did -ra mp3.id3 20 $_mp3.id3(%f).oartist
  did -ra mp3.id3 21 $_mp3.id3(%f).copyright2
  did -ra mp3.id3 22 $_mp3.id3(%f).url
  did -ra mp3.id3 26 $iif($_mp3.id3(%f).track isnum 1-,$ifmatch)

  did -ra mp3.id3 1 $longfn(%f)
  var %line1 = Bitrate: $_mp3.id3(%f).bitrate $+ kbps $+ $crlf $+ Sample: $_mp3.id3(%f).sample $+ Hz $+ $crlf $+ Mode: $_mp3.id3(%f).mode $+ $crlf $+ VBR: $iif($_mp3.id3(%f).vbr,Yes,No)
  var %line2 = Private: $iif($_mp3.id3(%f).private,Yes,No) $+ $crlf $+ Copyrighted: $iif($_mp3.id3(%f).copyright,Yes,No) $+ $crlf $+ CRCs: $iif($_mp3.id3(%f).crc,Yes,No)
  did -ra mp3.id3 23 Size: $lof(%f) bytes $+ $crlf $+ Length: $_mp3.info2(%f).length $+ $crlf $+ $_mp3.id3(%f).version $+ $crlf $crlf $+ %line1 $+ $crlf $+ %line2

}

alias _mp3.id3 {
  if (!$hget(x_mp3,dont.use.id3v2)) && ($_mp3.idv2($1). [ $+ [ $prop ] ]) return $ifmatch
  if ($sound($1). [ $+ [ $prop ] ]) return $ifmatch
  if ($2) return n/a
}
alias -l _mp3.idv2 {
  if (!$isfile($1)) return
  bread $shortfn($1) 0 4096 &id3
  if ($bvar(&id3,1,3).text != id3) return
  var %tags = album.track.title.artist.oartist.composer.genre.year.url.copyright2, %id = $bvar(&id3,$calc($bfind(&id3,1,$gettok(TALB.TRCK.TIT2.TPE1.TOPE.TCOM.TCON.TYER.WXXX.TCOP,$findtok(%tags,$prop,1,46),46)).text +11),200).text
  if ($right(%id,4) === $upper($right(%id,4))) return $left(%id,-4)
  else return %id
}



alias mp3echo _detect.mp3 -echo $iif($1,$1,$active)
alias mp3ctcp _detect.mp3 -echo $iif($1,$1,$active) ctcp

alias _detect.mp3 {
  if ($winamp(isplaying) == 1) {
    var %f = $winamp2(trackfilename)
    if (($hget(x_vars,wa.lastfile) == %f) && (!$1)) return
    if ($hget(x_vars,wa.lastfile)) .signal WINAMP STOP $hget(x_vars,wa.lastfile)
    .signal WINAMP PLAY %f
    var %sr = $winamp2(samplerate), %br = $winamp2(bitrate), %length = $_mtime($winamp2(tracktime)), %wname = $winamp2(track), %client = WinAmp
    if ($gettok(%f,-1,46) != mp3) var %idtitle = %wname, %fn = %wname, %wmode = $winamp2(mode), %br = 144
    _var wa.lastfile %f
    _var wa.lastfile.title %wname
    if (%�.glbtimer == 1) return
    goto echo
  }
  elseif ($insong.fname) {
    var %f = $ifmatch
    if ($hget(x_vars,lastfile) == %f) && (!$1) return
    var %sr = $int($calc($sound(%f).sample /1000)), %br = $sound(%f).bitrate, %length = $_mtime($calc($insong.length /1000)), %wname = $_mp3.info2(%f), %client = MP3 Player
    _var lastfile %f
    _var lastfile.title %wname
    goto echo
  }
  return

  :echo

  var %f = $longfn(%f), %echo = $_echo(mp3echo), %size = $bytes($lof(%f),3).suf, %fn = $deltok($nopath(%f),-1,46), %fnd = $deltok($gettok(%f,-2-1,92),-1,46)
  if ($gettok(%f,-1,46) == mp3) {
    var %idartist = $_mp3.id3(%f,1).artist, %idtitle = $_mp3.id3(%f,1).title, %idalbum = $_mp3.id3(%f,1).album, %idgenre = $_mp3.id3(%f,1).genre
    var %idtrack = $_mp3.id3(%f,1).track, %idyear = $_mp3.id3(%f,1).year, %idcopy = $_mp3.id3(%f,1).copyright, %idmode = $_mp3.id3(%f,1).mode
  }
  var %randquote = $iif($read(mp3lines.txt),$ifmatch,plays)
  var %e = $replace(%echo,<wfnd>,%fnd,<wfn>,%fn,<wname>,%wname,<wartist>,%idartist,<wtitle>,%idtitle,<walbum>,%idalbum,<wgenre>,%idgenre,<wtrack>,%idtrack,<wyear>,%idyear,<wcopy>,%idcopy,<wsr>,%sr,<wbr>,%br,<wmode>,%idmode,<wsize>,%size,<wlength>,%length,<wrandom>,%randquote,<wclient>,%client)

  ; manual command
  if ($1) {
    if ($1 == all) $iif($hget(x_mp3,use.msg),amsg,ame) %e
    else $iif($hget(x_mp3,use.msg),_say,describe) $1 %e
    if ($2 == ctcp) .ctcp $1 SOUND $replace($nopath(%f),$chr(32),_)
  }

  ; auto
  else _mp3echo $replace($nopath(%f),$chr(32),_) %e

}

alias _mp3echo {
  var %a = $hget(x_mp3,echo), %ctcp = $hget(x_mp3,send.ctcp)
  if (!%a) return

  ; local echo only
  if (%a == local) ae ! $2-
  elseif ($server) {

    if (%a == active) {
      if ($active ischan) {
        $iif($hget(x_mp3,use.msg),say,me) $2-
        if (%ctcp) .ctcp $active SOUND $1
      }
    }
    else {
      var %n = 1, %only = $hget(x_mp3,chan.only), %except = $hget(x_mp3,chan.except)
      while ($chan(%n)) {
        var %chan = $ifmatch, %echo
        if (%a == all) %echo = 1
        elseif (%a == only) && ($istok(%only,%chan,44)) %echo = 1
        elseif (%a == except) && (!$istok(%except,%chan,44)) %echo = 1
        if (%echo) {
          $iif($hget(x_mp3,use.msg),_say,describe) %chan $2-
          if (%ctcp) .ctcp %chan SOUND $1
        }
        inc %n
      }
    }
  }

}

;--------------------

;/mp3 <mask> finds first music matching mask (or keyword)
alias mp3 {
  if ($isid) return $!mp3
  if ($1-) && ($hget(x_mp3list)) {
    var %mask = $1-, %n = 1
    while ($hget(x_mp3list,%n)) {
      var %f = $ifmatch, %f1 = $_rempunct.all($gettok(%f,1,164)), %f2 = $_rempunct.all($gettok(%f,3,164)), %isin = 0
      if ($len(%mask) > 5) && ((%mask isin %f1) || (%mask isin %f2)) var %isin = 1
      if ($istok(%f1,%mask,32)) || (%mask iswm %f1) || ($istok(%f2,%mask,32)) || (%mask iswm %f2) || (%isin) { mp3play $gettok(%f,1,164) | return }
      inc %n
    }
    ae *** No mp3 matching $1- were found.
  }
  else mp3play
}

alias mp3play {
  if ($1 == open) goto open
  elseif ($1-) && ($1 !isnum) { var %f = $1- | goto play }

  var %total = $hget(x_mp3list,0).item
  if (%total) {
    var %actual = $hget(x_mp3,actual), %rec = $hget(x_vars,mp3.recent)
    if ($1 isnum) var %n = $1
    elseif ($hget(x_mp3,playsel)) var %n = $gettok($ifmatch,1,44)
    elseif ($hget(x_mp3,random)) {

      if ($dialog(mp3p)) && ($did(mp3p,112).state) && ($did(mp3p,100).lines > 1) {
        var %n = $remove($gettok($did(mp3p,100,$rand(2,$did(mp3p,100).lines)),6,32),.), %v = $numtok(%rec,44)
        while (%v) {
          if (%n == %actual) || ($istok(%rec,%n,44)) var %n = $remove($gettok($did(mp3p,100,$rand(2,$did(mp3p,100).lines)),6,32),.), %rec = $deltok(%rec,-1,44)
          else %v = 1
          dec %v
        }
      }
      else {
        var %n = $rand(1,%total), %v = $numtok(%rec,44)
        while (%v) {
          if (%n == %actual) || ($istok(%rec,%n,44)) var %n = $rand(1,%total), %rec = $deltok(%rec,-1,44)
          else %v = 1
          dec %v
        }
      }
    }
    else {
      if ($dialog(mp3p)) && ($did(mp3p,112).state) && ($did(mp3p,100).lines > 1) {
        var %sel = $did(mp3p,100,1).sel, %next = $calc(%sel +1)
        if (%next <= $did(mp3p,100).lines) || (!%sel) var %n = $remove($gettok($did(mp3p,100,%next),6,32),.)
        else var %n = $remove($gettok($did(mp3p,100,2),6,32),.)
      }
      else var %n = $iif(%actual,$calc(%actual +1),1)
    }
    if (%n > $hget(x_mp3list,0).item) var %n = 1
    var %f = $gettok($hget(x_mp3list,%n),1,164)

  }

  else {
    :open
    var %f = $$sfile($_mp3lastdir,Select MP3 file,Play)
  }

  if (%f) {

    if (%n) {
      if (%n != $hget(x_mp3,actual)) {
        if ($gettok($hget(x_vars,mp3.recent),1,44)) _set mp3 previous $ifmatch
        _set mp3 actual %n
      }
      if ($window(@mp3playlist)) sline @mp3playlist $fline(@mp3playlist,$+(%n,.*),1)

      ;play selection (from @mp3playlist)
      if (!$istok($hget(x_mp3,playsel),%n,44)) _unset mp3 playsel
      elseif ($deltok($hget(x_mp3,playsel),1,44)) _set mp3 playsel $ifmatch
      else _unset mp3 playsel

      ;keep recent mp3 played
      _set vars mp3.recent $qtok($hget(x_vars,mp3.recent),%n,30,44)
    }

    :play
    var %f = $shortfn(%f)
    if ($isfile(%f)) {
      _set mp3 lastplay %f

      splay -p %f
      if ($dialog(mp3p)) {
        _update.mp3p
        _enterparams %f playing 1
      }
      _unset mp3 paused
      _detect.mp3
    }
    else .timer 1 0 mp3play
  }
}
alias _mp3clearlist {
  _hfree x_mp3list
  var %path = $iif($isdir(%profile),%profile,config\)
  .remove $+(%path,mp3list.hsh)
  _unset mp3 actual
  _unset mp3 previous
  .timer 1 0 if ($input(Create new playlist now?,yq,MP3)) playlist
}
alias _mp3lastdir {
  var %a = $longfn($nofile($gettok($hget(x_mp3list,$hget(x_mp3list,0).item),1,164)))
  return $iif(%a,%a,$mp3dir)
}
alias _mp3state {
  if ($insong) {
    if ($hget(x_mp3,paused)) return Paused
    return Playing
  }
  return Stopped
}

;just testing...
alias _mp3stop.fadeout {
  var %vol = $vol(mp3), %x = %vol
  while (%x > 0) { vol -p %x | dec %x 85 }
  splay -p stop
  vol -p %vol
}

alias _updmp3dirs {
  if (!$hget(x_mp3list)) return
  var %i = 1, %w = @dirs- $+ $_rand6
  window -c %w
  window -hl %w
  while ($hget(x_mp3list,%i)) {
    var %file = $gettok($ifmatch,1,164), %dir = $nofile(%file)
    if (!$fline(%w,%dir,1)) aline %w %dir
    inc %i
  }
  if ($line(%w,0) == 0) return
  hfree x_mp3list
  hmake x_mp3list 40
  var %i = 1
  while ($line(%w,%i)) {
    _mp3list $shortfn($ifmatch) upd
    inc %i
  }
  window -c %w
}
alias _mp3list {
  var %d = $iif($1,$longfn($1),$$sdir($_mp3lastdir,Select your MP3 dir))
  if (!%d) halt
  if ($2 != upd) && ($finddir(%d,*,0)) var %recurse = $input(Recurse subdirectories?,yq)
  if ($hget(x_mp3,no.load.tags)) var %hash = x_mp3list
  else var %hash = x_tmp-mp3list
  if (!$hget(%hash)) hmake %hash 40

  var %0 = $hget(%hash,0).item
  if (%recurse) var  %t = $findfile(%d,*.mp3,0), %n = $findfile(%d,*.mp3,0,_mpadd %0 %t %hash $1-).shortfn
  else var %t = $findfile(%d,*.mp3,0,0), %n = $findfile(%d,*.mp3,0,0,_mpadd %0 %t %hash $1-).shortfn
  _pwait
  if (%n > 1) {
    if (%hash == x_tmp-mp3list) _mp3.info $ifmatch
    _hsave x_mp3list
    if (!$window(@mp3playlist)) playlist
  }
  else ale No mp3 files found in %d
}

alias _mpadd {
  _pwait $calc($hget($3,0).item - $1) $2 Creating MP3 list...
  var %size = $file($4-).size
  if (!%size) %size = 0
  hadd $3 $calc($hget($3,0).item +1) $4- $+ $chr(164) $+ %size
}

;$_mp3.info2(file) returns id3 info for file, or filename (.length returns length)
alias _mp3.info2 {
  var %file = $1-
  if ($prop == length) return $_mtime($calc($sound(%file).length /1000))
  if ($prop == fname) return $replace($deltok($nopath($longfn(%file)),-1,46),_,$chr(32))
  var %artist = $_mp3.id3(%file).artist, %title = $_mp3.id3(%file).title
  if (%artist) && (%title) return %artist - %title
  return $replace($deltok($nopath($longfn(%file)),-1,46),_,$chr(32))
}

alias _mp3.info {
  var %n = 1, %hash = $iif($1,$1,x_mp3list), %total = $hget(%hash,0).item, %bottom = $hget(x_mp3list,0).item
  if (!$hget(x_mp3list)) hmake x_mp3list 40
  _pwait 1 %total Loading file info...
  while (%n <= %total) {
    var %line = $gettok($hget(%hash,%n),1-2,164)
    if ($numtok(%line,164) == 2) {
      var %file = $gettok(%line,1,164), %item = $iif(%hash == x_mp3list,%n,$calc(%bottom + %n)), %name = $_mp3.info2(%file), %time = $_mp3.info2(%file).length
      hadd x_mp3list %item %line $+ $chr(164) $+ %name $+ $chr(164) $+ %time
    }
    if (20 // %n) _pwait %n %total
    inc %n
  }
  hfree x_tmp-mp3list
  _pwait
}
alias _mp3arrange {
  _pwait 0 0 Updating list...
  var %win = @_temp. $+ $rand(111,999)
  window -hl %win
  var %n = 1, %total = $hget(x_mp3list,0).item
  while (%n <= %total) {
    var %item = $hget(x_mp3list,%n).item, %l = $hget(x_mp3list,%item)
    if (%l) aline %win %item $+ $chr(164) $+ %l
    inc %n
  }
  filter -cwwtu 1 164 %win %win
  hfree x_mp3list
  hmake x_mp3list 40
  var %i = 1
  while ($line(%win,%i)) { hadd x_mp3list %i $gettok($ifmatch,2-,164) | inc %i }
  window -c %win
  _unset mp3 previous
  _unset mp3 actual
  if ($window(@mp3playlist)) playlist
  _pwait
}
alias mp3sort {
  if ($1 == 1) var %sort = by title
  elseif ($1 == 2) var %sort = by filename
  elseif ($1 == 3) var %sort = by path\filename
  elseif ($1 == 4) var %sort = reverse
  _pwait 0 0 Sorting %sort $+ ...
  var %win = @_temp. $+ $rand(111,999)
  window $iif($2 == 0,-hl,-hls) %win
  var %n = 1, %total = $hget(x_mp3list,0).item
  while (%n <= %total) {
    var %l = $hget(x_mp3list,%n)
    if (%l) {
      if ($1 == 1) aline %win $gettok(%l,3,164) $+ $chr(164) $+ %l
      elseif ($1 == 2) aline %win $gettok($gettok(%l,1,164),-1,92) $+ $chr(164) $+ %l
      elseif ($1 == 3) {
        var %p1 = $gettok(%l,1,164), %p2 = $gettok(%p1,-2,92) $+ \ $+ $gettok(%p1,-1,92)
        aline %win %p2 $+ $chr(164) $+ %l
      }
      elseif ($1 == 4) iline %win 1 %n - $+ $chr(164) $+ %l
      else aline %win - $+ $chr(164) $+ %l
    }
    inc %n
  }
  hfree x_mp3list
  hmake x_mp3list 40
  var %i = 1
  while ($line(%win,%i)) {
    hadd x_mp3list %i $gettok($ifmatch,2-,164)
    inc %i
  }
  window -c %win
  _unset mp3 previous
  _unset mp3 actual
  if ($window(@mp3playlist)) playlist
  _pwait
}
alias _mp3.playlist.select {
  var %file = $longfn($insong.fname), %tag = $sound(%file).artist - $sound(%file).title, %song = $remove($gettok(%file,-1,92),.mp3)
  if (%tag != -) && ($fline(@mp3playlist,$+(*,%tag,*),1)) sline @mp3playlist $ifmatch
  elseif (%song) && ($fline(@mp3playlist,$+(*,%song,*),1)) sline @mp3playlist $ifmatch
}

;usage: /playlist <filename>
alias playlist {
  if ($1) var %e = $1
  if ($window(@mp3playlist)) clear $ifmatch
  if ($hget(x_mp3list,0).item == 0) || (!$hget(x_mp3list)) _mp3list
  else {
    if (%e) write -c %e
    var %n = 1
    if (!$window(@mp3playlist)) window -lk $+ $iif($hget(x_mp3,desktoplist) != 0,d) -t4,55 @MP3Playlist $_gcoord(mp3playlist,-1 -1 500 450) $_@font
    else var %info = 0
    aline @mp3playlist $chr(9)
    aline @mp3playlist #. $+ $chr(9) $+ Title $+ $chr(9) $+  $+ $iif(if ($numtok($hget(x_mp3list,1),164) > 2),Length,Size)
    aline @mp3playlist $chr(9)
    while ($hget(x_mp3list,%n)) {
      var %f = $ifmatch
      if ($numtok(%f,164) > 2) var %s = %n $+ . $+ $chr(9) $+ $gettok(%f,3,164) $+ $chr(9) $+ $gettok(%f,4,164)
      else var %s = %n $+ . $+ $chr(9) $+ $nopath($gettok(%f,1,164)) $+ $chr(9) $+ $bytes($gettok(%f,2,164),3).suf
      aline @mp3playlist %s
      inc %n
    }
    if ($insong) {
      if ($hget(x_mp3,actual)) && ($fline(@mp3playlist,$+($hget(x_mp3,actual),.*),1)) sline @mp3playlist $ifmatch
      else _mp3.playlist.select
    }
    titlebar @MP3Playlist - $calc($line(@mp3playlist,0) -3) files - (right-click for options)
    if (%e) savebuf @mp3playlist %e
  }
  if ($window(@mp3playlist)) window -a @mp3playlist
}


;------------------------------------

alias _mp3.load.m3u {
  var %f = $1, %w = @ $+ $_rand6
  if (!%f) var %f = " $+ $$sfile(*.m3u,Select playlist file) $+ "
  if ($hget(x_mp3list)) {
    if (!$$input(This will replace your existing playlist $+ $crlf $+ Are you sure?,yw)) return
    hfree x_mp3list
  }
  hmake x_mp3list 40
  window -c %w
  window -hl %w
  loadbuf %w %f
  var %i = 1, %n = 2, %total = $lines(%f)
  _pwait 0 %total Loading list
  while (%n < $line(%w,0)) {
    var %file = $line(%w,%n)
    if (#EXTINF:* iswm %file) {
      inc %n
      var %inf = $gettok(%file,2-,58), %file = $line(%w,%n)
    }
    if (?:\* !iswm %file) %file = $left($mircdir,3) $+ %file
    %file = $shortfn(%file)
    if (%inf) var %length = $_mtime($gettok(%inf,1,44)), %title = $gettok(%inf,2-,44)
    else var %length = $_mp3.info2(%file), %title = $_mp3.info2(%file)
    if ($isfile(%file)) {
      hadd x_mp3list %i $shortfn(%file) $+ � $+ $file(%file).size $+ � $+ %title $+ � $+ %length
      inc %i
    }
    _pwait %n %total
    inc %n
  }
  _pwait
  window -c %w
  if (%i == 1) sr -th MP3List No files could be found
  else {
    echo $iif(@* iswm $active,-s,-a) *** Loaded %i entries from $nopath(%f)
    playlist
  }
}

alias _mp3.save.m3u {
  if (!$hget(x_mp3list)) {
    sr -th MP3List Your playlist is empty
    return
  }
  var %f = $1, %w = @ $+ $_rand6
  if (!%f) var %f = " $+ $$sfile(*.m3u,Save to,Save) $+ "
  if ($isfile(%f)) && (!$$input(File exists. Overwrite?,yq)) return
  window -c %w
  window -hl %w
  var %n = 1, %i = 1, %total = $hget(x_mp3list,0).item
  _pwait 0 %total Saving list
  aline %w #EXTM3U
  while ($hget(x_mp3list,%n)) {
    var %line = $ifmatch, %file = $gettok(%line,1,164), %title = $gettok(%line,3,164), %time = $_aduration2($gettok(%line,4,164))
    if (%file) {
      if (%title) && (%time) aline %w #EXTINF: $+ %time $+ , $+ %title
      aline %w %file
      inc %i
    }
    _pwait %n %total
    inc %n
  }
  _pwait
  if ($line(%w,0) > 1) {
    savebuf %w %f
    echo $iif(@* iswm $active,-s,-a) *** Saved %i entries to $nopath(%f)
  }
  else sr -th MP3List No list to save
  window -c %w
}


;=========================================================
;mixer

alias mixer var %s = $_dialog(mixer,mixer,-4)
dialog mixer {
  title "Mixer"
  size -1 -1 105 138
  option dbu
  icon graphics\volume.ico, 0
  list 1, 15 15 17 100
  list 2, 47 15 17 100
  list 3, 72 15 17 100
  box "Master", 11, 10 7 26 110
  box "Wave", 12, 43 7 26 110
  box "Midi", 13, 68 7 26 110
  check "mute", 21, 13 107 21 9, push
  check "mute", 22, 45 107 21 9, push
  check "mute", 23, 70 107 21 9, push
  button "Close", 50, 39 123 30 12, default ok
}
on 1:dialog:mixer:*:*:{
  if ($devent == init) {
    mdx.start
    multi.lang
    mdx SetControlMDX 1,2,3 trackbar vertical > $mdx.bdll
    did -i mixer 1 1 params $calc(65535- $vol(master)) 0 65535 5 25 0 0 -
    did -i mixer 2 1 params $calc(65535- $vol(wave)) 0 65535 5 25 0 0 -
    did -i mixer 3 1 params $calc(65535- $vol(midi)) 0 65535 5 25 0 0 -
    did -i mixer 1,2,3 1 ticfreq 6553
    if ($vol(master).mute) did -c mixer 21
    if ($vol(wave).mute) did -c mixer 22
    if ($vol(midi).mute) did -c mixer 23
  }
  if ($devent == sclick) {
    if ($did == 0) return
    if ($gettok($did($did,1),9,32) == track) dialog -t mixer Mixer ( $+ $_percentage($calc(65535- $gettok($did($did,1),1,32)),65535) $+ )
    else dialog -t mixer Mixer
    if ($did isnum 1-3) vol $iif($did == 1,-v,$iif($did == 2,-w,-m)) $calc(65535- $gettok($did($did,1),1,32))
    if ($did isnum 21-23) vol $iif($did == 21,-v,$iif($did == 22,-w,-m)) $+ u $+ $iif($did($did).state,1,2)
  }
}


;EOF
