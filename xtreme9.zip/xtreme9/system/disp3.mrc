.;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; display dialogs
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
dialog display {
  title "Display Settings"
  size -1 -1 362 223
  option dbu
  icon graphics\display.ico, 0

  tab "THM Themes", 3, 6 10 203 190
  list 21, 14 39 64 134, tab 3 size vsbar
  combo 95, 14 182 64 80, disable tab 3 size drop
  box "Theme info", 22, 82 35 122 96, tab 3
  button "Load", 23, 112 183 30 11, tab 3
  button "Unload", 24, 144 183 30 11, tab 3
  text "Theme:", 11, 86 48 25 8, tab 3 right
  text "", 12, 113 48 85 8, tab 3
  text "Author:", 10, 86 57 25 8, tab 3 right
  text "", 16, 113 57 85 8, tab 3
  link "", 14, 113 66 85 8, tab 3
  text "URL:", 13, 86 75 25 8, tab 3 right
  link "", 15, 113 75 85 8, tab 3
  edit "", 17, 85 95 111 30, tab 3 read multi vsbar
  text "Load...", 26, 82 134 25 8, tab 3
  text "Schemes:", 30, 15 174 50 8, tab 3
  text "Email:", 25, 86 66 25 8, tab 3 right
  check "Toolbar/switchbar", 6, 142 154 60 10, tab 3
  check "Toolbar buttons", 7, 142 164 60 10, tab 3
  check "Background images", 8, 142 144 60 10, tab 3
  check "Nicklist colors", 9, 85 164 50 10, tab 3
  check "Fonts", 18, 85 154 50 10, tab 3
  check "Timestamp", 19, 85 144 50 10, tab 3
  text "Description", 1, 86 87 50 8, tab 3

  tab "MTS Themes", 4
  list 1021, 14 39 64 134, tab 4 size vsbar
  combo 1095, 14 182 64 80, disable tab 4 size drop
  box "Theme info", 1022, 82 35 122 96, tab 4
  button "Load", 1023, 112 183 30 11, tab 4
  button "Unload", 1024, 144 183 30 11, tab 4
  text "Theme:", 1011, 86 48 25 8, tab 4 right
  text "", 1012, 113 48 85 8, tab 4
  text "Author:", 1010, 86 57 25 8, tab 4 right
  text "", 1016, 113 57 85 8, tab 4
  link "", 1014, 113 66 85 8, tab 4
  text "URL:", 1013, 86 75 25 8, tab 4 right
  link "", 1015, 113 75 85 8, tab 4
  edit "", 1017, 85 95 111 30, tab 4 read multi vsbar
  text "Load...", 1026, 82 134 25 8, tab 4
  text "Schemes:", 1030, 15 174 50 8, tab 4
  text "Email:", 1025, 86 66 25 8, tab 4 right
  check "Toolbar/switchbar", 1006, 142 154 60 10, tab 4
  check "Toolbar buttons", 1007, 142 164 60 10, tab 4
  check "Background images", 1008, 142 144 60 10, tab 4
  check "Nicklist colors", 1009, 85 164 50 10, tab 4
  check "Fonts", 1018, 85 154 50 10, tab 4
  check "Timestamp", 1019, 85 144 50 10, tab 4
  text "Description", 5, 86 87 50 8, tab 4

  list 1001, 0 0 0 0, hide sort
  list 1002, 0 0 0 0, hide sort
  edit "", 105, 0 0 0 0, hide autohs
  icon 2, 222 38 125 84,  graphics\20.bmp, 0
  box "Preview", 27, 214 23 141 106
  button "Theme Editor", 248, 7 206 42 12
  button "Cancel", 249, 320 206 30 12, cancel
  button "Ok", 250, 287 206 30 12, default ok

  box "Alignment (fixed width fonts only)", 520, 214 130 141 70
  check "Use nick alignment", 521, 219 141 60 10
  text "Alignment type", 522, 261 151 45 8, right
  text "Alignment size", 523, 261 162 45 8, right
  text "Blank ascii char", 524, 261 173 45 8, right
  combo 525, 307 149 45 50, size drop
  combo 526, 307 161 45 50, size drop edit
  combo 527, 307 173 45 50, size drop edit
  check "Use text alignment", 528, 219 186 60 10
  text "Size", 529, 286 187 20 8, right
  edit "", 530, 307 185 37 10


  menu "&Setup", 500
  item "&General Setup", 501, 500
  item "&Channel Protections", 502, 500
  item break, 505, 500
  item "&Network Settings", 506, 500
  item break, 503, 500
  item "&Userlist", 504, 500
  menu "&Advanced", 600
  item "Show highlight line on active", 601, 600
  item "Show clones on join", 602, 600
  item "Show clones only when op", 607, 600
  item "Show op/deop/kick on active", 603, 600
  item "Show netsplits filtered", 604, 600
  item "Show sends/rcvs on active", 605, 600
  item "Show seen host on join", 613, 600
  item break, 608, 600
  item "Use NickColor settings", 617, 600
  item "Color my clone's nick", 611, 600
  item "Color nicks in messages", 616, 600
  item break, 612, 600
  item "Load log on join", 609, 600
  item "Load log on query", 610, 600
  item break, 614, 600
  item "Auto-preview", 615, 600
  menu "&Help", 700
  item "&Help dialog", 701, 700
  item break, 702, 700
  item "&About eXtreme", 703, 700
}

on 1:dialog:display:*:*:{
  if ($devent == init) {
    multi.lang

    ;thm load (i use an hidden list to hide subdirs in it)
    var %n = $findfile(thm\,*.thm,0,did -a display 1001 $lower($remove($1-,$mircdirthm\))), %i = 1
    while (%i <= %n) {
      did -a display 21 $gettok($did(1001,%i),-1,92)
      inc %i
    }
    did -i display 1001,21 1 Default
    ;mts load
    var %a = $findfile(mts\,*.mts,0,did -a display 1002 $lower($remove($1-,$mircdirmts\))), %i = 1
    while (%i <= %a) {
      did -a display 1021 $gettok($did(1002,%i),-1,92)
      inc %i
    }
    did -bra display 95,1095 Default
    did -c display 95,1095 1
    var %thm.file = $hget(x_display,theme), %thm = $gettok(%thm.file,-1,92)

    if (*.mts iswm %thm.file) {
      if ($didwm(1021,%thm)) var %l = $ifmatch
      if (%l) {
        did -c display 1021 %l
        did -b display 521,522,523,524,525,526,527,528,529,530
        _init.header.mts %l
        .timer 1 0 did -f display 4
      }
      if ($hget(x_display,scheme)) {
        did -c display 1095 $calc($remove($ifmatch,scheme) +1)
        did -e display 1095
      }
    }
    elseif (%thm.file) {
      if ($didwm(21,%thm)) {
        var %l = $ifmatch
        did -c display 21 %l
        _init.header %l
      }
      if ($hget(x_display,scheme)) {
        did -c display 95 $calc($remove($ifmatch,scheme) +1)
        did -e display 95
      }
    }
    else {
      did -c display 21 1
      _init.header 1
      did -c display 95 $iif($color(back) == 0,1,2)
      did -e display 95
    }

    didtok display 525 44 left,left2,center,right
    didtok display 526 44 10,12,14,16,18,20
    didtok display 527 44 160,255
    did -c display 525 2
    did -c display 526 4
    did -c display 527 1

    var %list = $hget(x_display,load.items.thm), %n = 1
    while ($gettok(6.7.8.9.18.19,%n,46)) {
      var %did = $ifmatch
      if ($gettok(%list,%n,44) == 0) did -u display %did
      else did -c display %did
      inc %n
    }
    var %list = $hget(x_display,load.items.mts), %n = 1
    while ($gettok(1006.1007.1008.1009.1018.1019,%n,46)) {
      var %did = $ifmatch
      if ($gettok(%list,%n,44) == 0) did -u display %did
      else did -c display %did
      inc %n
    }

    if ($hget(x_display,show.highlightonactive)) did -c display 601
    if ($hget(x_display,show.cloneschk)) did -c display 602
    if ($hget(x_display,show.cloneschk.onlyop)) did -c display 607
    if ($hget(x_display,show.warnecho)) did -c display 603
    if ($hget(x_display,show.netsplits)) did -c display 604
    if ($hget(x_display,show.dccechoactive)) did -c display 605
    if ($hget(x_display,show.lastseen)) did -c display 613

    if ($hget(x_display,nickcolors.stat) != 0) did -c display 617
    if ($hget(x_display,color.myclones) != 0) did -c display 611
    if ($hget(x_display,color.nicks.messages)) did -c display 616
    if ($hget(x_display,loadbuf.join)) did -c display 609
    if ($hget(x_display,loadbuf.query)) did -c display 610
    if ($hget(x_display,auto.preview)) did -c display 615
    _init
  }
  if ($devent == menu) {
    if ($did == 501) setup
    if ($did == 502) cprot
    if ($did == 504) ul
    if ($did == 506) nets
    if ($did == 701) help
    if ($did == 703) about
    if ($did isnum 601-650) did $iif($did($did).state,-u,-c) display $did
    if ($did == 615) _set display auto.preview $did(615).state
  }
  if ($devent == sclick) {
    if ($did == 21) {
      _init.header $did(21).sel
      if ($hget(x_display,auto.preview)) _init.preview $did(1001,$did(21).sel)
      else _init.previewb
      did -f display 21
    }
    if ($did == 1021) {
      _init.header.mts $did(1021).sel
      if ($hget(x_display,auto.preview)) _init.preview mts\ $+ $did(1002,$did(1021).sel)
      else _init.previewb
      did -f display 1021
    }
    if ($did == 14) && (@ isin $did(14)) email $did(14)
    if ($did == 15) && (. isin $did(15)) run $did(15)

    if ($did == 95) {
      var %l = $iif($did(95).sel > 1,$calc($ifmatch -1))
      _init.preview $did(1001,$did(21).sel) $iif(%l,$+(scheme,%l))
    }
    if ($did == 1095) {
      var %l = $iif($did(1095).sel > 1,$calc($ifmatch -1))
      _init.preview $+(mts\,$did(1002,$did(1021).sel)) $iif(%l,$+(scheme,%l))
    }

    if ($did == 23) {
      if ($did(21).sel) {
        if ($did(21).sel == 1) theme.unload $iif($did(95).sel == 2,black,1)
        else theme.load $did(1001,$did(21).sel) $iif($did(95).sel > 1,$+(scheme,$calc($ifmatch -1)))
      }
      _init
    }
    if ($did == 1023) {
      if ($did(1021).sel) theme.load mts\ $+ $did(1002,$did(1021).sel) $iif($did(1095).sel > 1,$+(scheme,$calc($ifmatch -1)))
      _init
    }
    if ($did == 24) {
      theme.unload
      did -re display 95
      didtok display 95 44 Default,Black
      did -c display 21,95 1
      _init.header 1
      _init
    }
    if ($did == 1024) {
      theme.unload
      did -re display 95
      didtok display 95 44 Default,Black
      did -c display 21,95 1
      _init.header 1
      _init
      .timer 1 0 did -f display 3
    }
    if ($did == 2) {
      if ($dialog(display).tab == 4) {
        if ($did(1021).sel) var %thm = $+(mts\,$did(1002,$did(1021).sel)) $iif($did(1095).sel > 1,$+(scheme,$calc($ifmatch -1)))
      }
      else {
        if ($did(21).sel) var %thm = $did(1001,$did(21).sel) $iif($did(95).sel > 1,$+(scheme,$calc($ifmatch -1)))
      }
      _init.preview %thm
    }
    if ($did == 3) {
      var %thm = $did(1001,$did(21).sel) $iif($did(95).sel > 1,$+(scheme,$calc($ifmatch -1)))
      if ($did(21).sel) && (%thm != $did(105)) .timer 1 0 _init.preview %thm
      did -e display 521,528
      if ($did(521).state) did -e display 525,526,527
      if ($did(528).state) did -e display 530
    }
    if ($did == 4) {
      var %thm = $+(mts\,$did(1002,$did(1021).sel)) $iif($did(1095).sel > 1,$+(scheme,$calc($ifmatch -1)))
      if ($did(1021).sel) && (%thm != $did(105)) .timer 1 0 _init.preview %thm
      did -b display 520,521,522,523,524,525,526,527,528,529,530
    }
    if ($did == 521) {
      did $iif($did(521).state,-e,-b) display 525,526,527
      if ($did(521).state) _-set display align.nick $iif($did(526) isnum 5-50,$did(526),10) $+ ; $+ $did(525).sel $+ ; $+ $did(527)
      else _-unset display align.nick
    }
    if ($did == 528) {
      did $iif($did(528).state,-e,-b) display 530
    }
    if ($did == 248) ctheme
    if ($did == 250) { 

      if ($did(521).state) _set display align.nick $iif($did(526) isnum 5-50,$did(526),10) $+ ; $+ $did(525).sel $+ ; $+ $did(527)
      else _unset display align.nick
      if ($did(528).state) && ($did(530) isnum) _set display align.text $did(530)
      else _unset display align.text

      var %dlist = 6.7.8.9.18.19, %n = 1, %list
      while ($gettok(%dlist,%n,46)) {
        var %did = $ifmatch, %list = %list $did(%did).state
        inc %n
      }
      _-set display load.items.thm $replace(%list,$chr(32),$chr(44))
      var %dlist = 1006.1007.1008.1009.1018.1019, %n = 1, %list
      while ($gettok(%dlist,%n,46)) {
        var %did = $ifmatch, %list = %list $did(%did).state
        inc %n
      }
      _-set display load.items.mts $replace(%list,$chr(32),$chr(44))

      _-set display show.highlightonactive $did(601).state
      _-set display show.cloneschk $did(602).state
      _-set display show.cloneschk.onlyop $did(607).state
      _-set display show.warnecho $did(603).state
      _-set display show.netsplits $did(604).state
      _-set display show.dccechoactive $did(605).state
      _-set display show.lastseen $did(613).state
      _-set display nickcolors.stat $did(617).state
      _-set display color.myclones $did(611).state
      _-set display color.nicks.messages $did(616).state
      _-set display loadbuf.join $did(609).state
      _-set display loadbuf.query $did(610).state
      _-set display auto.preview $did(615).state
      hupd
    }
  }
}
alias -l _init {
  var %thm = $hget(x_display,theme)
  did -ra display 27 $iif(%thm,Loaded theme: $gettok($ifmatch,-1,92),No theme (default))

  if ($hget(x_display,align.nick)) {
    var %a = $ifmatch
    did -e display 525,526,527
    did -c display 521
    did -c display 525 $gettok(%a,2,59)
    did -ac display 526 $gettok(%a,1,59)
    did -c display 527 $iif($gettok(%a,3,59) == 160,1,2)
  }
  else did -b display 525,526,527
  if ($hget(x_display,align.text)) {
    did -rae display 530 $ifmatch
    did -c display 528
  }
  else did -b display 530

  if (*.mts iswm %thm) did -b display 521,528
  else did -e display 521,528
  _init.preview
}
alias -l _init.header {
  if ($1 == 1) var %t1 = Default, %t2 = Kall, %t3 = Default theme, %t4 = kall@extreme-script.net, %t5 = http://www.extreme-script.net/
  else {
    var %f = thm\ $+ $did(1001,$1), %w = @ $+ _tmp.header, %t1, %t2, %t3, %t4, %t5, %t6
    window -c %w
    window -lh %w
    filter -fwr 1-10 $+(",%f,") %w

    if ($fline(%w,*name:*,1)) %t1 = $gettok($line(%w,$ifmatch),2-,58)
    if ($fline(%w,*author:*,1)) %t2 = $gettok($line(%w,$ifmatch),2-,58)
    if ($fline(%w,*desc:*,1)) %t3 = $gettok($line(%w,$ifmatch),2-,58)
    if ($fline(%w,*email:*,1)) %t4 = $gettok($line(%w,$ifmatch),2-,58)
    if ($fline(%w,*url:*,1)) %t5 = $gettok($line(%w,$ifmatch),2-,58)
    if ($fline(%w,*version:*,1)) %t6 = $gettok($line(%w,$ifmatch),2-,58)
    window -c %w
  }
  did -ra display 12 $iif(%t1,$left(%t1,12),n/a) %t6
  did -ra display 16 $iif(%t2,%t2,n/a)
  if (@ isin %t4) did -ra display 14 %t4
  else did -r display 14
  if (. isin %t5) did -ra display 15 %t5
  else did -r display 15
  did -ra display 17 $iif(%t3,%t3,no description)
  did -c display 17 1
  var %n = 1
  did -rab display 95 Default
  if ($1 == 1) did -a display 95 Black
  else {
    while ($ini(%f,start,%n)) {
      var %item = $ifmatch
      if (scheme* iswm %item) did -a display 95 $readini(%f,start,%item)
      inc %n
    }
  }
  did -c display 95 1
  if ($did(95).lines > 1) did -e display 95
}
alias -l _init.header.mts {
  var %f = $mircdirmts\ $+ $did(1002,$1), %w = @ $+ _tmp.header, %t1, %t2, %t3, %t4, %t5, %t6
  window -c %w
  window -lh %w
  filter -fwr 1-10 $+(",%f,") %w
  if ($fline(%w,name *,1)) %t1 = $gettok($line(%w,$ifmatch),2-,32)
  if ($fline(%w,author *,1)) %t2 = $gettok($line(%w,$ifmatch),2-,32)
  if ($fline(%w,description *,1)) %t3 = $gettok($line(%w,$ifmatch),2-,32)
  if ($fline(%w,email *,1)) %t4 = $gettok($line(%w,$ifmatch),2-,32)
  if ($fline(%w,website *,1)) %t5 = $gettok($line(%w,$ifmatch),2-,32)
  if ($fline(%w,version *,1)) %t6 = $gettok($line(%w,$ifmatch),2-,32)
  window -c %w

  did -ra display 1012 $iif(%t1,$left(%t1,12),n/a) %t6
  did -ra display 1016 $iif(%t2,%t2,n/a)
  if (@ isin %t4) did -ra display 1014 %t4
  else did -r display 1014
  if (. isin %t5) did -ra display 1015 %t5
  else did -r display 1015
  did -ra display 1017 $iif(%t3,%t3,no description)
  did -c display 1017 1
  var %n = 1
  did -rab display 1095 Default
  while (%n) {
    var %n = $read(%f,w,scheme*,$calc($readn +1))
    if ($readn) did -a display 1095 $gettok(%n,2-,32)
  }
  did -c display 1095 1
  if ($did(1095).lines > 1) did -e display 1095
}

alias -l _didwm2 {
  var %n = 1
  while ($did($1,$2,%n)) {
    var %a = $ifmatch
    if (%a == $3) return %n
    inc %n
  }
  return 0
}
alias _font.chan {
  var %r = $readini(mirc.ini,fonts,fchannel)
  return $gettok(%r,1,44)
}
alias _font.ch.size {
  var %r = $readini(mirc.ini,fonts,fchannel), %r = $gettok(%r,2,44)
  return $_fix.font.size(%r)
}
alias _fix.font.size {
  if ($calc(400 - $1) < $calc(700 - $1)) var %v = $calc($1 - 400)
  else var %v =  $calc($1 - 700)
  if (%v < 0) return $calc($abs(%v) + 3)
  return %v
}

alias -l __color return $iif($gettok($1,$findtok($retcols,$2,46),44) isnum 0-15,$ifmatch,$color($2))

alias -l mts.preview.set {
  if ($fline(@_mts.preview,$1 *,1)) return $gettok($line(@_mts.preview,$ifmatch),2-,32)
}
alias -l preview.set {
  var %file = thm\ $+ %_preview
  if ($_readini(%file,n,$2,$1)) return $ifmatch
  return $_readini(%file,n,start,$1)
}

alias _init.preview {
  set -u %_preview $iif($1,$1,$hget(x_display,theme))
  did -ra display 105 $iif(%_preview,%_preview,default)
  var %font = $_font.chan, %size = $_font.ch.size
  if ($_mopt(n4,12)) var %_timestamp = 1
  if (*.mts iswm %_preview) var %mts = 1

  if ($1) {
    _pwait 0 10 Loading preview

    if (*.mts iswm $1) {
      var %w = @_mts.preview
      window -lh %w
      if ($2) {
        var %w2 = @_mts.prev.sch
        window -lh %w2
        loadbuf -t $+ $2 %w " $+ $1 $+ "
        loadbuf -tmts %w2 " $+ $1 $+ "
        var %i = 1
        while (%i <= $line(%w2,0)) {
          var %ln = $line(%w2,%i)
          if ($remove(%ln,$chr(32),$lf,$cr)) aline -n %w %ln
          inc %i
        }
        window -c %w2
      }
      else loadbuf -tmts %w " $+ $1 $+ "

      var %rgbcols = $rgbcolors.mts2thm($mts.preview.set(rgbcolors))
      if ($mts.preview.set(colors)) var %clist = $ifmatch, %backc = $gettok(%clist,1,44)
      if ($mts.preview.set(basecolors)) var %bcolors = $_fixbasecolors($ifmatch)
      if ($mts.preview.set(prefix)) var %prefix = $ifmatch
      if ($mts.preview.set(timestampformat)) var %timestamp = $ifmatch
      if ($mts.preview.set(fontchan)) var %_font = $ifmatch, %font = $gettok(%_font,1,44), %size = $gettok(%_font,2,44)
      if ($mts.preview.set(parentext)) var %parentext = $ifmatch
      else var %parentext = (<text>)
      _pwait 2 10 Loading preview
    }
    else {
      if ($1 == default) {
        if ($2 == scheme1) var %clist = $colors.blackback, %backc = $gettok(%clist,1,44), %bcolors = 10,04,15,11
        else var %clist = $colors.whiteback, %backc = $gettok(%clist,1,44), %bcolors = 02,04,01,12
        var %prefix = <c1>:<c3>:<c1>:, %timestamp = <c1>(<c3>HH:nn:ss<c1>), %font = Tahoma, %size = 11
        set -u %::lb (
        set -u %::rb )
      }
      else {
        var %rgbcols = $rgbcols.fix($preview.set(rgbcolors,$2))
        if ($preview.set(colors,$2)) var %clist = $ifmatch, %backc = $gettok(%clist,1,44)
        if ($preview.set(basecolors,$2)) var %bcolors = $_fixbasecolors($ifmatch)
        if ($preview.set(prefix,$2)) var %prefix = $ifmatch
        if ($preview.set(lb,$2)) set -u %::lb $ifmatch
        if ($preview.set(rb,$2)) set -u %::rb $ifmatch
        if ($preview.set(timestamp,$2)) var %timestamp = $ifmatch
        if ($preview.set(fchannel,$2)) var %_font = $ifmatch, %font = $gettok(%_font,1,44), %size = $gettok(%_font,2,44)
        .load -a thm\ $+ $1
      }
      _pwait 2 10 Loading preview
    }
    if (!%rgbcols) var %rgbcols = $defaultrgbcolslist
  }
  else {

    ;    var %rgbcols = $getrgbcols
    var %prefix = $hget(x_display,prefix)
    var %timestamp = $timestampfmt
    set -u %::lb $hget(x_display,lb)
    set -u %::rb $hget(x_display,rb)
    var %bcolors = $hget(x_display,basecolors)
  }
  window -ph @_pw 0 0 260 200
  var %back = $iif(%backc isnum 0-15,$ifmatch,$color(background))
  drawrect -f @_pw %back 0 0 0 300 300
  var %. = drawtext -pb @_pw, %.. = %back " $+ $remove(%font,") $+ " %size 0, %a = $hget(x_sets,align.nick), %me = $iif($me,$me,Nick), %bl = $str($chr($iif(terminal isin $_font.chan,255,160)),50)

  set -u %::c1  $+ $gettok(%bcolors,1,44)
  set -u %::c2  $+ $gettok(%bcolors,2,44)
  set -u %::c3  $+ $gettok(%bcolors,3,44)
  set -u %::c4  $+ $gettok(%bcolors,4,44)
  set -u %::pre $replace(%prefix,<c1>,%::c1,<c2>,%::c2,<c3>,%::c3,<c4>,%::c4)
  if (%timestamp) %timestamp = $replace($ifmatch,<c1>,%::c1,<c2>,%::c2,<c3>,%::c3,<c4>,%::c4)
  else var %timestamp = %::c1 $+ ( $+ %::c3 $+ HH:nn:ss $+ %::c1 $+ )
  if (%_timestamp) %_timestamp = $asctime(%timestamp)
  var %nick1 = Slack, %nick2 = Kart, %nick3 = Another1
  if (%me == Slack) var %nick1 = Bragster
  if (%me == Kart) var %nick2 = Frankster
  if (%me == Another1) var %nick3 = Reptile
  if ($1) _pwait 4 10 Drawing...
  set -u %::timestamp $_timestamp
  set -u %::me %me
  set -u %::chan #scripters
  set -u %:echo %. $__color(%clist,join) %.. 5 $_timestamp
  set -u %_pv.linew 5
  set -u %_pv.height $iif($calc($height(ABC,%font,%size) + 2) >= 14,$ifmatch,14)
  set -u %::nick %me
  set -u %::address myself@host.net
  _theme.text.preview joinself
  set -u %::nick %nick1
  set -u %::address userid@ht-212.dialup.net
  set -u %::chan #scripters
  set -u %::country $ccode(net)
  set -u %::userlevel 1
  set -u %:echo %. $__color(%clist,join) %.. $_prev.linew %_timestamp
  _theme.text.preview join
  set -u %::nick %nick2
  set -u %::address swds@drm3.utad.pt
  set -u %::chan #scripters
  set -u %::text time to go
  set -u %::parentext $replace(%parentext,<text>,%::text,<c1>,%::c1,<c2>,%::c2,<c3>,%::c3,<c4>,%::c4)
  set -u %:echo %. $__color(%clist,part) %.. $_prev.linew %_timestamp
  _theme.text.preview part
  set -u %::nick %nick3
  set -u %::address qwert@blabla.com
  set -u %::chan #scripters
  set -u %::modes +o %me
  set -u %:echo %. $__color(%clist,part) %.. $_prev.linew %_timestamp
  _theme.text.preview mode
  if ($1) _pwait 5 10 Drawing...
  if (%mts) set -u %::nick %nick1
  else set -u %::nick $_align(%nick1,%a)
  set -u %::address userid@ht-212.dialup.net
  set -u %::chan #scripters
  set -u %::text baaaaaah
  set -u %:echo %. $__color(%clist,normal) %.. $_prev.linew %_timestamp
  _theme.text.preview textchan
  set -u %::nick %nick1
  set -u %::address userid@ht-212.dialup.net
  set -u %::chan #scripters
  set -u %::text is getting tired of this channel
  set -u %:echo %. $__color(%clist,action) %.. $_prev.linew %_timestamp
  _theme.text.preview actionchan
  set -u %::nick %nick1
  set -u %::address userid@ht-212.dialup.net
  set -u %::chan #games
  set -u %:echo %. $__color(%clist,invite) %.. $_prev.linew %_timestamp
  _theme.text.preview invite
  if (%mts) set -u %::nick $+(@,%me)
  else set -u %::nick $_align($+(@,%me),%a)
  if ($1) _pwait 6 10 Drawing...
  if ($showmodeprefix) set -u %::cmode @
  set -u %::chan #scripters
  set -u %::text who are you %nick1 $+ ?!?!
  set -u %:echo %. $__color(%clist,own) %.. $_prev.linew %_timestamp
  _theme.text.preview textchanself
  unset %::cmode
  set -u %::nick %nick1
  set -u %::address userid@ht-212.dialup.net
  set -u %::text hey there
  set -u %:echo %. $__color(%clist,notice) %.. $_prev.linew %_timestamp
  _theme.text.preview notice
  set -u %::nick %nick1
  set -u %::address userid@ht-212.dialup.net
  set -u %::ctcp PING
  set -u %::target %me
  set -u %::text 991793731
  set -u %:echo %. $__color(%clist,ctcp) %.. $_prev.linew %_timestamp
  _theme.text.preview ctcp
  set -u %::nick %me
  set -u %::address myself@host.net
  set -u %::kaddress userid@ht-212.dialup.net
  set -u %::chan #scripters
  set -u %::knick %nick1
  set -u %::text hmmm?  $+ $chr(183) $+ 6251 $+ $chr(183) $+ 
  set -u %::parentext $replace(%parentext,<text>,%::text,<c1>,%::c1,<c2>,%::c2,<c3>,%::c3,<c4>,%::c4)
  set -u %:echo %. $__color(%clist,kick) %.. $_prev.linew %_timestamp
  _theme.text.preview kick
  if ($1) {
    var %n = 1, %i = 1
    _pwait 7 10 Setting colors
    while (%n <= $numtok(%rgbcols,44)) {
      if ($color($calc(%n -1)) != $gettok(%rgbcols,%n,44)) {     
        drawreplace -nr @_pw $color($calc(%n -1)) $gettok(%rgbcols,%n,44)
      }
      inc %n
    }
    _pwait 8 10
    if (*.mts !iswm $1) {
      if ($hget(x_display,theme) != $1) && ($1 isin $alias($alias(0))) .unload -a " $+ $alias($alias(0)) $+ "
    }
    if ($window(%w)) window -c %w
  }

  drawsave @_pw tmp\_preview.bmp
  close -@ @_pw
  if ($1) _pwait 10 10
  if ($isfile(tmp\_preview.bmp)) { did -g display 2 tmp\_preview.bmp | .remove tmp\_preview.bmp }
  if ($1) _pwait
}

alias -l _theme.text.preview {
  var %line
  var %th1 = %_preview, %th2 = $gettok(%th1,-1,92)
  if (*.mts iswm %th1) {
    if ($window(@_mts.preview)) {
      if ($fline(@_mts.preview,$1 *,1)) %line = $gettok($line(@_mts.preview,$ifmatch),2-,32)
      else %line = $_display($1)
    }
    else %line = $theme.setting($1,1)
    if ($gettok(%line,1,32) != !script) %line = $dll(dlls\mtsgen.dll,MTSEvalString,%line)
  }
  else {
    if ($alias(%th2)) %line = $theme_ [ $+ [ $remove(%th2,.thm) $+ ($1) ] ]
    else %line = $_display($1)
  }
  if ($gettok(%line,1,32) == !script) {
    %:echo <scripted line, can't preview>
    return
  }
  %:echo %line
}
alias -l _prev.linew {
  inc -u %_pv.linew %_pv.height
  return %_pv.linew
}
alias -l _init.previewb {
  if (%_blank.preview) return
  window -ph @_pw 0 0 260 200
  drawtext @_pw $color(info) Arial 14 60 60 Click here to preview $+ $str($chr(160),50)
  drawsave @_pw tmp\_preview.bmp
  close -@ @_pw
  if ($isfile(tmp\_preview.bmp)) { did -g display 2 tmp\_preview.bmp | .remove tmp\_preview.bmp }
  set -u %_blank.preview 1
}
;
;scolors
alias scolors {
  if ($dialog(scolors)) dialog -v scolors
  elseif ($isid) {
    var %t = $dialog(colors,colors,-4)
    if (%t isnum) return %t
  }
}
dialog colors {
  title "Select color"
  size -1 -1 126 51
  option dbu
  button "", 50, 0 0 0 0, default ok
  icon 1, 15 8 10 10, graphics\0.bmp, 0
  icon 2, 27 8 10 10, graphics\1.bmp, 0
  icon 3, 39 8 10 10, graphics\2.bmp, 0
  icon 4, 51 8 10 10, graphics\3.bmp, 0
  icon 5, 63 8 10 10, graphics\4.bmp, 0
  icon 6, 75 8 10 10, graphics\5.bmp, 0
  icon 7, 87 8 10 10, graphics\6.bmp, 0
  icon 8, 99 8 10 10, graphics\7.bmp, 0
  icon 9, 15 20 10 10, graphics\8.bmp, 0
  icon 10, 27 20 10 10, graphics\9.bmp, 0
  icon 11, 39 20 10 10, graphics\10.bmp, 0
  icon 12, 51 20 10 10, graphics\11.bmp, 0
  icon 13, 63 20 10 10, graphics\12.bmp, 0
  icon 14, 75 20 10 10, graphics\13.bmp, 0
  icon 15, 87 20 10 10, graphics\14.bmp, 0
  icon 16, 99 20 10 10, graphics\15.bmp, 0
  icon 21, 99 33 10 10, graphics\20.bmp, 0
  text "None", 17, 76 36 21 7, right
  edit "", 100, 0 0 0 0, result
  box "", 18, 5 1 115 46
}
on 1:dialog:colors:sclick:*:{
  if ($did isnum 1-16) || ($did == 21) did -ra colors 100 $calc($did -1)
  dialog -k colors
}
;
alias _rgb {
  return $gettok($dll(dlls\aircdll.dll,PickColor,$iif($1,$1,-) $replace($getrgbcols,$chr(44),$chr(32))),2,32)
  if ($1) set -u %_temp.rgb $1
  if ($dialog(rgb)) dialog -v rgb
  if ($isid) {
    var %c = $dialog(rgb,rgb,-4)
    if (%c isnum) return %c
  }
  else _dialog -m rgb rgb
}
alias -l _updrgbcol {
  var %a = $rgb($gettok($did(1,1),1,32),$gettok($did(2,1),1,32),$gettok($did(3,1),1,32))
  did -ra rgb 4 %a
  mdx SetColor 5 background %a
}
dialog rgb {
  title "RGB"
  size -1 -1 350 200
  icon graphics\paint.ico
  list 1, 30 30 200 55
  list 2, 30 80 200 55
  list 3, 30 130 200 55
  edit "", 4, 250 90 70 20, read result
  text "", 5, 250 40 70 40
  button "Close", 50, 260 140 50 20, ok default
}
on 1:dialog:rgb:*:*:{
  if ($devent == init) {
    multi.lang
    if (%_temp.rgb) var %rgb = $rgb($ifmatch), %r1 = $gettok(%rgb,1,44), %r2 = $gettok(%rgb,2,44), %r3 = $gettok(%rgb,3,44)
    mdx.start
    mdx SetControlMDX 1,2,3 trackbar tooltips > $mdx.bdll
    mdx SetBorderStyle 5 clientedge dlgmodal
    did -i rgb 1 1 params $iif(%r1,%r1,0) 0 255 - - 0 0 -
    did -i rgb 2 1 params $iif(%r2,%r2,0) 0 255 - - 0 0 -
    did -i rgb 3 1 params $iif(%r3,%r3,0) 0 255 - - 0 0 -
    mdx SetColor 5 background 0
    _updrgbcol
  }
  if ($devent == sclick) && ($did isnum 1-3) _updrgbcol
}
;
;EOF
