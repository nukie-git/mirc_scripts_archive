;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
; extreme v9.0
; display dialogs
;
;~   ~   ~   ~   ~   ~  ~   ~   ~   ~   ~   ~  
;
; theme editor
alias ctheme _dialog -m theme theme

dialog theme {
  title "Theme/Messages Editor"
  size -1 -1 342 256
  option dbu
  icon graphics\display.ico, 0
  tab "Custom Theme", 3, 6 5 330 232
  list 1, 14 95 315 105, tab 3 extsel
  edit "", 2, 65 192 255 10, disable tab 3 autohs
  button "", 4, 65 204 254 8, tab 3
  button "Export to MTS", 41, 14 219 40 12, tab 3
  button "Set", 50, 221 219 32 12, disable tab 3
  button "Default", 48, 254 219 32 12, disable tab 3
  button "Default all", 47, 287 219 32 12, tab 3
  text "Prefix", 5, 19 37 30 8, tab 3 right
  edit "", 6, 51 36 65 10, tab 3 autohs
  text "BaseColors", 7, 19 76 30 8, tab 3 right
  text "Timestamp", 9, 19 48 30 8, tab 3 right
  edit "", 10, 51 47 65 10, tab 3 autohs
  text "Brackets", 11, 19 59 30 8, tab 3 right
  edit "", 12, 51 58 25 10, tab 3
  icon 8, 52 75 10 10,  graphics\20.bmp, 0, tab 3
  icon 13, 68 75 10 10,  graphics\20.bmp, 0, tab 3
  icon 14, 84 75 10 10,  graphics\20.bmp, 0, tab 3
  icon 15, 100 75 10 10,  graphics\20.bmp, 0, tab 3
  text "Status", 16, 129 43 25 8, tab 3 right
  text "You", 17, 237 39 25 8, tab 3 right
  text "Channel", 18, 129 54 25 8, tab 3 right
  text "Query", 19, 129 65 25 8, tab 3 right
  text "IRCOps", 20, 237 51 25 8, tab 3 right
  text "Aways", 21, 237 63 25 8, tab 3 right
  text "Friends", 22, 237 75 25 8, tab 3 right
  text "Voices", 23, 283 63 25 8, tab 3 right
  text "Ops", 24, 283 51 25 8, tab 3 right
  text "Enemies", 25, 283 39 25 8, tab 3 right
  text "Regular", 55, 283 75 25 8, tab 3 right
  box "NickColors", 26, 233 24 96 66, tab 3
  box "Fonts", 27, 125 24 104 66, tab 3
  icon 28, 265 37 10 10,  graphics\20.bmp, 0, tab 3
  icon 29, 265 49 10 10,  graphics\20.bmp, 0, tab 3
  icon 30, 265 61 10 10,  graphics\20.bmp, 0, tab 3
  icon 31, 265 73 10 10,  graphics\20.bmp, 0, tab 3
  icon 34, 311 37 10 10,  graphics\20.bmp, 0, tab 3
  icon 33, 311 49 10 10,  graphics\20.bmp, 0, tab 3
  icon 32, 311 61 10 10,  graphics\20.bmp, 0, tab 3
  icon 56, 311 73 10 10,  graphics\20.bmp, 0, tab 3
  edit "", 35, 156 42 65 10, tab 3 autohs
  edit "", 36, 156 53 65 10, tab 3 autohs
  edit "", 37, 156 64 65 10, tab 3 autohs
  edit "", 535, 156 42 65 10, hide tab 3 autohs
  edit "", 536, 156 53 65 10, hide tab 3 autohs
  edit "", 537, 156 64 65 10, hide tab 3 autohs
  box "General", 46, 15 24 106 66, tab 3
  text "Edit", 51, 14 194 48 8, tab 3 right
  text "Preview", 52, 14 204 48 8, tab 3 right
  tab "Custom Echoes", 38
  list 39, 14 42 315 148, tab 38 extsel
  edit "", 40, 65 192 255 10, tab 38 autohs
  button "", 42, 65 204 254 8, tab 38
  button "Set", 43, 221 219 32 12, disable tab 38 default
  button "Default", 44, 254 219 32 12, disable tab 38
  button "Default all", 45, 287 219 32 12, tab 38
  text "Preview", 53, 14 204 48 8, tab 38 right
  text "Edit", 54, 14 194 48 8, tab 38 right
  button "Cancel", 49, 304 242 30 12, cancel
  button "Ok", 500, 271 242 30 12, default ok
}

on 1:dialog:theme:*:*:{
  if ($devent == init) {
    multi.lang
    mdx.start
    mdx SetControlMDX 1,39 listview rowselect single flatsb showsel report nosortheader > $mdx.vdll
    did -i $dname 1,39 1 headerdims 100 505
    did -i $dname 1,39 1 headertext 0 Event $_tab Message
    mdx SetControlMDX 4,42 window > $mdx.ddll
    var %w = @_prv.thm
    window -lh %w 0 0 500 50
    did -a theme 4 grab $window(%w).hwnd %w
    var %w = @_prv.msgs
    window -lh %w 0 0 500 50
    did -a theme 42 grab $window(%w).hwnd %w

    if ($readini($mircini,fonts,fstatus)) {
      var %f = $ifmatch, %font = $gettok(%f,1,44), %size = $_fix.font.size($gettok(%f,2,44))
      did -ra theme 35,535 %font $+ , $+ %size
    }
    if ($readini($mircini,fonts,fchannel)) {
      var %f = $ifmatch, %font = $gettok(%f,1,44), %size = $_fix.font.size($gettok(%f,2,44))
      did -ra theme 36,536 %font $+ , $+ %size
    }
    if ($readini($mircini,fonts,fquery)) {
      var %f = $ifmatch, %font = $gettok(%f,1,44), %size = $_fix.font.size($gettok(%f,2,44))
      did -ra theme 37,537 %font $+ , $+ %size
    }

    did -ra theme 6 $_pre
    if ($timestampfmt) did -ra theme 10 $ifmatch
    if ($hget(x_display,lb)) var %lb = $ifmatch
    if ($hget(x_display,rb)) var %rb = $ifmatch
    if (%lb) && (%rb) did -ra theme 12 %lb %rb
    if ($hget(x_display,basecolors)) {
      var %bcolors = $ifmatch
      _load.img $gettok(%bcolors,1,44) 8
      _load.img $gettok(%bcolors,2,44) 13
      _load.img $gettok(%bcolors,3,44) 14
      _load.img $gettok(%bcolors,4,44) 15
    }

    if ($_ncread(you)) var %c = $ifmatch
    else var %c = 20
    did -g theme 28 graphics\ $+ $_cf(%c) $+ .bmp
    if ($_ncread(ircop)) var %c = $ifmatch
    else var %c = 20
    did -g theme 29 graphics\ $+ $_cf(%c) $+ .bmp
    if ($_ncread(away)) var %c = $ifmatch
    else var %c = 20
    did -g theme 30 graphics\ $+ $_cf(%c) $+ .bmp
    if ($_ncread(friend)) var %c = $ifmatch
    else var %c = 20
    did -g theme 31 graphics\ $+ $_cf(%c) $+ .bmp
    if ($_ncread(enemy)) var %c = $ifmatch
    else var %c = 20
    did -g theme 34 graphics\ $+ $_cf(%c) $+ .bmp
    if ($_ncread(op)) var %c = $ifmatch
    else var %c = 20
    did -g theme 33 graphics\ $+ $_cf(%c) $+ .bmp
    if ($_ncread(voice)) var %c = $ifmatch
    else var %c = 20
    did -g theme 32 graphics\ $+ $_cf(%c) $+ .bmp
    if ($_ncread(regular)) var %c = $ifmatch
    else var %c = 20
    did -g theme 56 graphics\ $+ $_cf(%c) $+ .bmp

    _loadcthm
    _loadcmsgs
  }
  var %l = $remove($gettok($did(1).seltext,6,32),	0), %l2 = $remove($gettok($did(1).seltext,11-,32),	0)
  var %m = $remove($gettok($did(39).seltext,6,32),	0), %m2 = $remove($gettok($did(39).seltext,11-,32),	0)
  if ($devent == edit) {
    if ($did == 2) {
      did -te theme 50
      _prevcthm %l
    }
    if ($did == 40) {
      did -te theme 43
      _prevcmsgs %m
    }
  }
  if ($devent == sclick) {

    if ($did == 8) _load.img3
    if ($did == 13) _load.img3
    if ($did == 14) _load.img3
    if ($did == 15) _load.img3
    if ($did == 28) _load.img3
    if ($did == 29) _load.img3
    if ($did == 30) _load.img3
    if ($did == 31) _load.img3
    if ($did == 34) _load.img3
    if ($did == 33) _load.img3
    if ($did == 32) _load.img3
    if ($did == 56) _load.img3

    if ($did == 1) && (%_sel != $did(1).sel) {
      if (!%l2) {
        did -rb theme 2
        did -ra theme 51 Edit
      }
      else {
        did -era theme 2 %l2
        did -ra theme 51 %l
        did -b theme 50
        did -t theme 500
        if ($hget(x_custom.theme,%l)) did -e theme 48
        else did -b theme 48
      }
      _prevcthm %l
      set -u1 %_sel $did(1).sel
    }

    if ($did == 39) && (%_sel != $did(39).sel) {
      if (!%m2) {
        did -rb theme 40
        did -ra theme 54 Edit
      }
      else {
        did -era theme 40 %m2
        did -ra theme 54 %m
        did -b theme 43
        did -t theme 500
        if ($hget(x_custom.msgs,%m)) did -e theme 44
        else did -b theme 44
      }
      _prevcmsgs %m
      set -u1 %_sel $did(39).sel
    }

    if ($did == 48) {
      _unset custom.theme %l
      _set.all.vars.mts
      var %w = @_cth.bla
      window -lh %w
      set -u %:echo aline %w
      clear %w
      _theme.text.ctheme %l
      if ($line(%w,0) == 0) did -ra theme 2 <output blocked>
      elseif ($line(%w,0) == 1) {
        if (!script* !iswm $line(%w,1)) did -ra theme 2 $line(%w,1)
        else did -ra theme 2 <scripted>
      }
      else did -ra theme 2 <multiline display>
      window -c %w
      did -b theme 48,50
      did -t theme 500
      _updtheme %l
      _prevcthm %l
    }
    if ($did == 50) && ($did(2)) {
      _set custom.theme %l $did(2)
      did -b theme 50
      did -e theme 48
      _updtheme %l
    }
    if ($did == 47) {
      if ($hget(x_custom.theme,0).item == 0) sr -th Error No custom theme settings found
      elseif ($input(Discard all custom theme settings?,yw)) {
        _unset custom.theme
        _loadcthm
      }
    }
    if ($did == 41) _save.mts

    if ($did == 44) {
      _unset custom.msgs %m
      did -ra theme 40 $_echo(%m)
      did -b theme 45,43
      did -t theme 500
      _updmsg %m
      _prevcmsgs %m
    }
    if ($did == 43) && ($did(40)) {
      _set custom.msgs %m $did(40)
      did -b theme 43
      did -e theme 44
      _updmsg %m
    }
    if ($did == 45) {
      if ($hget(x_custom.msgs,0).item == 0) sr -th Error No custom messages found
      elseif ($input(Discard all custom messages?,yw)) {
        _unset custom.msgs
        _loadcmsgs
      }
    }

    if ($did == 49) && ($dialog(display)) _init.preview

    if ($did == 500) {

      if ($did(35)) {
        var %lfont = $ifmatch, %font = $gettok(%lfont,1,44), %size = $gettok(%lfont,2,44)
        if (%font) && (%size isnum) {
          if (%lfont != $did(535)) set.font -s %size %font
        }
      }
      if ($did(36)) {
        var %lfont = $ifmatch, %font = $gettok(%lfont,1,44), %size = $gettok(%lfont,2,44)
        if (%font) && (%size isnum) {
          if (%lfont != $did(536)) set.font -c %size %font
        }
      }
      if ($did(37)) {
        var %lfont = $ifmatch, %font = $gettok(%lfont,1,44), %size = $gettok(%lfont,2,44)
        if (%font) && (%size isnum) {
          if (%lfont != $did(537)) set.font -q %size %font
        }
      }
      if ($did(6)) _--set display prefix $ifmatch
      else _--set display prefix <none>
      if ($numtok($did(12),32) == 2) {
        var %both = $did(12)
        _--set display lb $gettok(%both,1,32)
        _--set display rb $gettok(%both,2,32)
      }
      else {
        _--unset display lb
        _--unset display rb
      }
      .timestamp -f $did(10)
      var %listdids = 8.13.14.15, %list, %i = 1
      while ($gettok(%listdids,%i,46)) {
        var %did = $ifmatch, %col = $_fc2($remove($gettok($did(%did),-1,92),.bmp)), %list = %list $+ , $+ %col
        inc %i
      }
      _--set display basecolors $right(%list,-1)
      var %listdids = 28.29.30.31.34.33.32.56, %list, %i = 1
      while ($gettok(%listdids,%i,46)) {
        var %did = $ifmatch, %col = $_fc2($remove($gettok($did(%did),-1,92),.bmp)), %list = %list $+ , $+ %col
        inc %i
      }
      var %nickcolors = $right(%list,-1)
      if ($hget(x_display,nickcolors) != %nickcolors) var %ncolchange = 1
      _--set display nickcolors %nickcolors
      set.nickcolors %nickcolors
      _hsave display

      if ($dialog(display)) _init.preview
      if ($server) && (%ncolchange) .timer 1 0 colornicks.all
    }
  }
}

alias -l _load.img {
  var %file = graphics\ $+ $_cf($1) $+ .bmp
  if ($isfile(%file)) did -g theme $2 %file
}
alias -l _load.img2 {
  return $_fc2($deltok($gettok($did(theme,$1),-1,92),-1,46))
}
alias -l _load.img3 {
  did -g theme $did graphics\ $+ $_cf($$scolors) $+ .bmp
}

alias -l _prevcthm {
  var %text = $iif($did(theme,2) != $null,$ifmatch)
  var %c1 =  $+ $_load.img2(8), %c2 =  $+ $_load.img2(13), %c3 =  $+ $_load.img2(14), %c4 =  $+ $_load.img2(15), %color = $iif($1,$_conv.cols($1),normal)
  if ($did(theme,6)) var %prefix = $replace($ifmatch,<c1>,%c1,<c2>,%c2,<c3>,%c3,<c4>,%c4)
  if ($_mopt(n4,12)) && ($did(theme,10)) var %timestamp = $asctime($replace($ifmatch,<c1>,%c1,<c2>,%c2,<c3>,%c3,<c4>,%c4))
  if (<lb> isin %text) {
    var %lb = $gettok($did(theme,12),1,32), %rb = $gettok($did(theme,12),2,32)
    if (!%lb) || (!%rb) var %lb = <, %rb = >
    %text = $replace(%text,<lb>,%lb,<rb>,%rb)
  }
  %text = $replace(%text,<c1>,%c1,<c2>,%c2,<c3>,%c3,<c4>,%c4,<pre>,%prefix)

  var %w = @_prv.thm
  if ($window(%w)) clear %w
  else {
    window -lh %w 0 0 500 50
    did -a theme 4 grab $window(%w).hwnd %w
  }
  if (%text != $null) aline $color(%color) %w %timestamp %text
}

alias -l _updtheme {
  var %s = $did(1).sel
  did -o theme 1 %s $1 $_tab $did(2)
  did -c theme 1 %s
}
alias -l _updmsg {
  var %s = $did(39).sel
  did -o theme 39 %s $1 $_tab $did(40)
  did -c theme 39 %s
}
alias -l _conv.cols {
  if (join isin $1) return join
  if (kick isin $1) return kick
  if ((text isin $1) || (action isin $1)) {
    if (self isin $1) return own
    if (action isin $1) return action
    return normal
  }
  if (ctcp isin $1) return ctcp
  if (mode isin $1) return mode
  if (nick isin $1) return nick
  if (notice isin $1) return notice
  if (notify isin $1) return notify
  return $1
}
alias -l _loadcthm {
  did -r theme 1,2
  did -b theme 2
  var %e = Join JoinSelf Rejoin Part Quit Mode KickSelf Kick ModeUser TextChanSelf TextQuerySelf ActionChanSelf ActionQuerySelf $&
    TextMsgSelf TextChan TextQuery TextMsg ActionChan ActionQuery NickSelf Nick Invite Wallop Topic Notice NoticeChan NoticeSelf NoticeServer $&
    CtcpSelf CtcpChanSelf CtcpReplySelf Ctcp CtcpChan CtcpReply . ServerError Notify UNotify Dns DnsResolve DnsError .
  var %r = Raw.311 Raw.307 Raw.308 Raw.309 Raw.310 Raw.313 Raw.317 Raw.312 Raw.319 Raw.320 Raw.335 Raw.330 Raw.378 Raw.379 Raw.301 Raw.318 . $&
    Raw.314 Raw.369 Raw.332 Raw.333 . Raw.001 Raw.002 Raw.003 Raw.004 Raw.005 Raw.250 Raw.251 Raw.252 Raw.253 Raw.254 Raw.255 Raw.265 Raw.266 . $&
    Raw.221 Raw.302 Raw.324 Raw.328 Raw.329 Raw.341 Raw.372 Raw.375 Raw.376 Raw.377 Raw.391 . Raw.401 Raw.402 Raw.403 Raw.404 Raw.405 Raw.406 $&
    Raw.421 Raw.432 Raw.433 Raw.439 Raw.441 Raw.442 Raw.443 Raw.467 Raw.468 Raw.472 . Raw.471 Raw.473 Raw.474 Raw.475 Raw.477 Raw.478 Raw.482 . $&
    Raw.353 Raw.366 Raw.352 Raw.315 Raw.Other
  _pwait 0 1 Loading theme events...
  _set.all.vars.mts
  var %n = 1, %total = $numtok(%e,32), %w = $+(@_cth.,$_rand6)
  window -lh %w
  set -u %:echo aline %w
  while ($gettok(%e,%n,32)) {
    var %i = $ifmatch
    _pwait %n %total
    if (%i == .) did -a theme 1 -
    else {
      clear %w
      _theme.text.ctheme %i
      if ($line(%w,0) == 0) did -a theme 1 %i $_tab <output blocked>
      elseif ($line(%w,0) == 1) {
        if (!script* !iswm $line(%w,1)) did -a theme 1 %i $_tab $line(%w,1)
        else did -a theme 1 %i $_tab <scripted>
      }
      else did -a theme 1 %i $_tab <multiline display>
    }
    inc %n
  }
  _pwait 0 1 Loading theme raws...
  var %n = 1, %total = $numtok(%r,32)
  while ($gettok(%r,%n,32)) {
    var %i = $ifmatch
    _pwait %n %total
    if (%i == .) did -a theme 1 -
    else {
      clear %w
      _theme.text.ctheme %i
      if ($line(%w,0) == 0) did -a theme 1 %i $_tab <output blocked>
      elseif ($line(%w,0) == 1) {
        if (!script* !iswm $line(%w,1)) did -a theme 1 %i $_tab $line(%w,1)
        else did -a theme 1 %i $_tab <scripted>
      }
      else did -a theme 1 %i $_tab <multiline display>
    }
    inc %n
  }
  did -b theme 48,50
  window -c %w
  _prevcthm
  _pwait
}
alias -l _theme.text.ctheme {
  var %line
  if ($hget(x_custom.theme,$1)) %line = $ifmatch
  elseif ($hget(x_mts,$1)) %line = $ifmatch
  else {
    var %thm = $gettok($hget(x_display,theme),-1,92)
    if ($alias(%thm)) %line = $theme_ [ $+ [ $remove(%thm,.thm) $+ ($1) ] ]
    else %line = $_display($1)
  }
  if (%line != $null) %:echo %line
}
;
alias -l _loadcmsgs {
  did -r theme 39,40
  did -b theme 40
  var %list = CloneWarn GuestWarn BadwordWarn CustomWarn_User CustomWarn_Public Ignored AwayAction BackAction ImAway $&
    AutoAway AwayAdvert AwayStat PvtBlocked PageRcvd PageNotAway PagerOff MiscCtcpReply MP3Echo
  set -u %_custom.msgs 1
  _pwait 0 1 Loading script messages...
  var %n = 1, %total = $numtok(%list,32)
  while ($gettok(%list,%n,32)) {
    var %i = $ifmatch
    did -a theme 39 %i $_tab $_echo(%i)
    _pwait %n %total
    inc %n
  }
  _prevcmsgs
  _pwait
}
alias -l _prevcmsgs {
  var %text = $did(theme,40), %w = @_prv.msgs
  if ($window(%w)) clear %w
  else {
    window -h %w 0 0 500 50
    did -a theme 4 grab $window(%w).hwnd %w
  }
  if (%text != $null) aline %w %text
}
alias _set.all.vars.mts {
  set -u %::nick <nick>
  set -u %::address <address>
  set -u %::chan <chan>
  set -u %::newnick <newnick>
  set -u %::me <me>
  set -u %::server <server>
  set -u %::port <port>
  set -u %::numeric <numeric>
  set -u %::text <text>
  set -u %::ctcp <ctcp>
  set -u %::knick <knick>
  set -u %::kaddress <kaddress>
  set -u %::c1 <c1>
  set -u %::c2 <c2>
  set -u %::c3 <c3>
  set -u %::c4 <c4>
  set -u %::lb <lb>
  set -u %::rb <rb>
  set -u %::pre <pre>
  set -u %::timestamp <timestamp>
  set -u %::parentext <parentext>
  set -u %::cmode <cmode>
  set -u %::cnick <cnick>
  set -u %::target <target>
  set -u %::modes <modes>
  set -u %::away <away>
  set -u %::idletime <idletime>
  set -u %::signontime <signontime>
  set -u %::realname <realname>
  set -u %::isoper <isoper>
  set -u %::operline <operline>
  set -u %::isregd <isregd>
  set -u %::wserver <wserver>
  set -u %::serverinfo <serverinfo>
  set -u %::value <value>
  set -u %::realname <realname>
  set -u %::fromserver <fromserver>
  set -u %::userlevel <userlevel>
  set -u %::country <country>
}

alias -l _save.mts {
  var %w = $+(@_save.mts.,$_rand6)
  window -lh %w
  aline %w [mts]
  set -u %_save.mts %w
  var %a = $dialog(mts_sets,mts_sets,-4), %name = $gettok($line(%w,2),2,32)
  if ($line(%w,0) < 3) {
    window -c %w
    return
  }
  :file
  var %file = $sfile($+(mts\,%name,.mts),Save as...,Save)
  if ($isfile(%file)) {
    if (!$input(That file already exists. Overwrite?,yw)) goto file
  }
  if (!%file) {
    window -c %w
    return
  }
  _pwait 0 0 Exporting settings...
  aline %w MTSVersion 1.3 $+ $lf

  aline %w Load <pre> <c1>Loaded MTS Theme: %name
  aline %w Unload <pre> <c1>Unloaded MTS Theme: %name
  aline %w Parentext <c1>(<text><c1>)

  var %listdids = 8.13.14.15, %list, %i = 1
  while ($gettok(%listdids,%i,46)) {
    var %did = $ifmatch, %col = $_fc2($remove($gettok($did(%did),-1,92),.bmp)), %list = %list $+ , $+ %col
    inc %i
  }
  var %bcolors = $right(%list,-1), %c1 =  $+ $gettok(%bcolors,1,44), %c2 =  $+ $gettok(%bcolors,2,44), %c3 =  $+ $gettok(%bcolors,3,44), %c4 =  $+ $gettok(%bcolors,4,44)
  aline %w BaseColors %bcolors
  aline %w Colors $getactualcols
  aline %w RGBColors $rgbcolors.thm2mts($getrgbcols)

  if ($did(6)) aline %w Prefix $replace($ifmatch,%c1,<c1>,%c2,<c2>,%c3,<c3>,%c4,<c4>)
  if ($did(10)) aline %w Timestampformat $replace($ifmatch,%c1,<c1>,%c2,<c2>,%c3,<c3>,%c4,<c4>)

  if ($did(35)) aline %w FontDefault $ifmatch
  if ($did(36)) aline %w FontChan $ifmatch
  if ($did(37)) aline %w FontQuery $ifmatch

  var %listdids = 28.29.30.31.34.33.32.56, %list, %i = 1
  while ($gettok(%listdids,%i,46)) {
    var %did = $ifmatch, %col = $_fc2($remove($gettok($did(%did),-1,92),.bmp)), %list = %list $+ , $+ %col
    inc %i
  }
  if ($gettok(%list,1,44) isnum 0-15) aline %w CLineMe $ifmatch
  if ($gettok(%list,2,44) isnum 0-15) aline %w CLineIrcOp $ifmatch
  if ($gettok(%list,4,44) isnum 0-15) aline %w CLineFriend $ifmatch
  if ($gettok(%list,5,44) isnum 0-15) aline %w CLineEnemy $ifmatch
  if ($gettok(%list,6,44) isnum 0-15) {
    var %c = $ifmatch
    aline %w CLineOp %c
    aline %w CLineOwner %c
  }
  if ($gettok(%list,7,44) isnum 0-15) {
    var %c = $ifmatch
    aline %w CLineVoice $ifmatch
    aline %w CLineHOp $ifmatch
  }
  if ($gettok(%list,8,44) isnum 0-15) aline %w CLineRegular $ifmatch

  if ($numtok($did(12),32) == 2) var %both = $did(12), %lb = $gettok(%both,1,32), %rb = $gettok(%both,2,32)
  else var %lb = <, %rb = >

  aline %w $lf
  var %n = 2
  while (%n <= $did(1).lines) {
    var %line = $did(1,%n), %item = $remove($gettok(%line,6,32),	0), %data = $remove($gettok(%line,11-,32),	0)
    if (-* !iswm %item) {
      if (%data == <output blocked>) aline %w %item
      elseif (%data !isin <scripted><multiline display>) aline %w %item $replace(%data,<lb>,%lb,<rb>,%rb)
    }
    _pwait %n $did(1).lines Exporting settings
    inc %n
  }
  _pwait 10 10 Done
  savebuf %w " $+ %file $+ "
  window -c %w
  _pwait
  dialog -v theme
  sr -tw MTS Please note that this feature is far from perfect. It doesn't export <scripted> nor <multiline> items, and it might fail in some events.
}
dialog mts_sets {
  title "MTS Settings"
  size -1 -1 175 112
  option dbu
  text "*Name", 1, 8 16 30 8, right
  text "*Author", 2, 8 26 30 8, right
  text "Email", 3, 8 36 30 8, right
  text "Website", 5, 8 46 30 8, right
  text "Description", 13, 8 56 30 8, right
  text "Version", 4, 8 66 30 8, right
  edit "", 6, 41 15 125 10, autohs
  edit "", 7, 41 25 125 10, autohs
  edit "", 8, 41 35 125 10, autohs
  edit "", 9, 41 45 125 10, autohs
  edit "", 14, 41 55 125 10, autohs
  edit "", 10, 41 65 125 10, autohs
  text "Fill the editboxes with the correct info so the script can create your MTS theme file. (* are mandatory)", 11, 9 78 157 16
  edit "", 100, 0 0 0 0, autohs hide
  button "Next >>", 12, 130 95 37 12, default
}
on *:dialog:mts_sets:init:*:did -ra mts_sets 100 %_save.mts
on *:dialog:mts_sets:sclick:12:{
  if (!$did(6) != $null) || (!$did(7) != $null) {
    sr -th Error Please fill the * fields
    return
  }
  var %w = $did(100)
  aline %w Name $did(6)
  aline %w Author $did(7)
  if ($did(8)) aline %w Email $ifmatch
  else aline %w Email n/a
  if ($did(9)) aline %w Website $ifmatch
  else aline %w Website n/a
  if ($did(10) != $null) aline %w Version $ifmatch
  else aline %w Version 1.0
  if ($did(14) != $null) aline %w Description $ifmatch
  dialog -x mts_sets
}

;
;EOF
